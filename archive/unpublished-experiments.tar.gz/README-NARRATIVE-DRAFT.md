# Metal Drone Navigation

> **Draft v2 — structural rewrite following the X-article model:**
> problem → idea → what I built → how it works → how I trained it → what happened →
> where it fails → why it matters. Story on top, evidence underneath. The live README.md
> is untouched. Every number below is carried from the repo's published records, and the
> two throughput figures were re-verified against BENCHMARKS.md (see the numbers block).

---

Can a tiny neural policy fly a drone quickly through clutter it has never seen, using only a depth camera and a nearby goal?

[![A drone slowing down, centering, and holding in a doorway it was never shown](artifacts/videos/native-doorway-preview.jpg)](artifacts/videos/native-doorway.mp4)

*Real Webots footage. The policy was trained in a different simulator, on different worlds. It has 12,104 parameters and this doorway is not in its training set. Receipts: [manifest](evidence/inputs/native-flight-videos/manifest.json).*

I built a reinforcement-learning system that trains thousands of quadrotors at the same time on an M3 GPU. The whole training loop is written by hand in Metal: physics, depth sensor, rollouts, gradients, optimizer. Nothing else.

The result is a 48 KB navigator. It reads a small depth image, the drone's motion, and a nearby 3-D goal. Every 50 ms it decides how fast to move left, right, up, down, and forward, and how quickly to turn. Those commands go to RAPTOR, a frozen learned flight controller that drives the four motors.

No PyTorch. No TensorFlow. No Python in the training loop.

## The idea

The deployed system will have a cloud model above the drone. Every few seconds it looks at a camera view and picks the next meaningful place to go: a doorway, the far side of a table, the bottom of the stairs. The navigator's whole job is the part in between.

```
cloud / higher-level planner
          ↓
    local 3-D goal
          ↓
 depth + ego state
          ↓
  navigation policy
          ↓
 vx  vy  vz  yaw-rate
          ↓
       RAPTOR
          ↓
      4 motors
```

Why two layers? Because they are different problems. RAPTOR handles the hard part of keeping the drone stable. My policy only decides where the drone should move next. Splitting there means the policy can be small, retrained, and re-deployed without ever touching a controller that is already proven, and RAPTOR never has to care what room it is in.

It also means honesty about scope. This repository does not do mission planning or semantic understanding. It gets the drone from wherever it is to the target the layer above picked, through whatever geometry is in the way. Nothing more.

## What I built

Most drone navigation stacks bolt a planner, a mapper, and a collision checker onto a conventional flight controller, and each piece carries its own tuning. This project asks how much of that local geometric decision-making a single tiny policy can take over.

Here is the whole thing:

```
320 depth rays (16×20, 90° field of view)
        ↓ 2×2 min-pooling
 80 current + 80 previous ranges
        +
 goal direction and distance
        +
 velocities, rotation rates, gravity direction
        +
 previous command, sensor age, tracking error
        +
 short geometry memory
        ↓
    184 inputs
        ↓
 Dense (184 → 64), tanh
        ↓
 vx  vy  vz  yaw-rate
```

12,104 parameters. 48 KB on disk. That is the entire policy.

The geometry memory and a hand-written geometry prior deserve a word, because the policy is a hybrid. The prior is a small deterministic function that looks at the depth image and says which way looks safe. The network's job is to correct that prior: its velocity output is `prior + learned correction`, and the correction gets more authority when the sky above the drone is open, less under a low ceiling. The prior alone sometimes beats the full policy on easy scenes. I report both numbers everywhere, and say so again in the failures section.

During training, the simulator knows where every obstacle is. The policy does not. I use that extra knowledge for a privileged critic that helps learning go faster, and then throw it away: the exported 48 KB actor sees only what a real drone could see.

## How I trained it

Not with one drone. With a stadium of them:

```
8,192 simulated quadrotors
        ↓
 different starts, goals, obstacles,
 dynamics, wind, sensor noise
        ↓
 all fly at the same time,
 20 Hz decisions, 100 Hz motors
        ↓
 rollout → GAE → PPO update
        ↓
 repeat, a few thousand times
```

The physics, the depth rays, the RAPTOR controller, the policy, the rollout collection, GAE, PPO backpropagation and Adam all run as Metal shaders on one M3.

```
8,192 environments in parallel
262,144 transitions per update
~290,000 transitions/second, training included
```

And the number that made this project possible. One complete rollout plus PPO update, identical math each time:

```
1.66 s  →  0.295 s  →  0.026 s
```

0.026 s is the optimized small-batch loop (128 environments). At 8,192 environments the same loop takes ~0.90 s per rollout, which is where the 290k transitions/second figure comes from. A tuned CPU reference runs the same workload 1.85× slower. Machine, commands and discarded intermediate measurements: [BENCHMARKS](docs/BENCHMARKS.md#matched-complete-ppo-optimization).

Training worlds come from two places: procedural families (open rooms, boxes, poles, moving spheres, doorways, tables, mixtures) and a frozen bank of saved levels with three hard families: bent hallways, connected rooms, and vertical over/under choices. Every bank level carries a geometric witness route, a proven collision-free path used for training diagnostics only.

![One saved level per bank family, with its witness route in green](artifacts/challenge-bank-witness-worlds.png)

*One development level per bank family, with its witness route in green. The route proves a collision-free path exists for the 0.18 m vehicle envelope. It is never sent to the actor. Source: [bank](evidence/inputs/challenge-bank-v1.jsonl).*

One training lesson changed how I score everything: reaching the goal and arriving are different skills. My first policy flew into the goal region almost every time and almost never stopped there. So arrival became an explicit contract: within 0.35 m, under 0.5 m/s, held for 0.2 s. Training for the hold moved Webots stable arrivals from 0/18 to 17/18.

## What it learns

| Situation | What the policy does |
|---|---|
| Open space | Accelerate hard, brake into a clean stop |
| Doorway | Slow down, center, pass through |
| Table or counter | Go above or around |
| Blocked goal | Move away from the goal briefly, then back in |
| Moving object | Give way, dodge, keep clearance |
| Narrow gap | Reduce speed, hold the envelope |

The doorway behavior on camera:

[![Two offset doors and a table](artifacts/videos/native-connected-rooms-preview.jpg)](artifacts/videos/native-connected-rooms.mp4)

*The room policy through two offset doors and a table. First door at 5.23 s, no contact. [Manifest](evidence/inputs/native-flight-videos/manifest.json).*

And a moving threat, from the controlled-crossing evaluation scene:

![Paired crossing scene](artifacts/paired-crossing-scene.gif)

## What happened

**Local goal tasks.** The strongest local-waypoint policy reaches **103/128** unseen local tasks, versus 96/128 for the previous policy. Modest, single-seed, and arrivals are slower than the baseline's. It is a real gain on safety and completion, not a claimed leap.

![Local waypoint evaluation success](artifacts/local-waypoint-eval-success.png)

*Per-task outcomes for the local waypoint candidate. Records: [results/omp-local-waypoints](results/omp-local-waypoints).*

**Independent transfer.** On the same 16 frozen local tasks flown in a second simulator, the policy scored **12/16 in Metal and 12/16 in independent Webots**, with 31/32 agreement on pass/fail verdicts. Receipts: [flight records](results/omp-waypoint-transfer).

**Connected rooms.** Focused connected-room training reached **25/30 development rooms**, up from 0/30 before that curriculum. On the same 30 rooms in Webots, **18/30** transferred, and all 12 native contacts happened in the hardest scenes.

![Paired room transfer](artifacts/room-webots-transfer.png)

*Same 30 rooms, both simulators. Source: [paired proof](evidence/inputs/room-webots-transfer/proof.json).*

## What still doesn't work

These are unresolved. They are also the most interesting results in the repo.

**Training longer made the policy worse.** From the 25/30 room peak, more training fell to 10/30. Gradient norms sat pinned at the clip on 98.5% of rollouts. A big hyperparameter search and a seed replication both failed to beat the frozen peak checkpoint, so I froze it.

![Retention regression](artifacts/arrival-legacy-retention-regression.png)

**The hand-written prior sometimes beats the learned policy.** On held-out two-doorway scenes the prior alone scores 96.1% against 89.1% for prior + network. Learning pays off on tables, counters, and moving spheres, and hurts slightly on the easiest geometry. Both always get reported.

**Long routes exposed a reward problem.** An audit of real corner flights found 2 of 24 successful flights scoring below a drone that just hovers, because with γ=0.99 at 20 Hz the credit for a distant goal decays faster than the penalties accumulate. The obvious fix, a longer discount, was tested properly: two matched 800-rollout arms, zero corner successes in either, about 60,000 episodes. Hypothesis rejected. [Audit](docs/RESEARCH_CREDIT_ASSIGNMENT.md) and [experiment](docs/DISCOUNT_EXPERIMENT.md) preserved.

![Reward and credit audit](artifacts/reward-credit-audit.png)

**Imitation learned the loss but solved 0/30 tasks.** Cloning a privileged teacher drove error down 10× and took held-out performance to zero. A controlled probe found why: I built mirrored level pairs where all 184 inputs are bit-identical at spawn but the correct first turn is opposite. The information needed to act is not in the observation. No loss curve fixes that. [Experiment](docs/IMITATION_EXPERIMENT.md).

![Imitation learning failure](artifacts/imitation-learning-failure.png)

**Some collisions involved geometry the sensor never saw.** In the local-waypoint visibility audit, 17 of 27 colliding obstacles had never been measured by any ray before contact, and 6 sat entirely outside the field of view in every frame of the flight. That is an observability limit, not a policy failure, and it now feeds back into task generation. [Audit records](results/omp-local-waypoints).

**Hallway corners are unsolved.** The bank's hardest family sits at 0/30 in essentially every run ever recorded, across every method tried so far.

## Why Metal?

JAX/Brax and PyTorch are already excellent RL systems. I wanted to know what happens when the entire training system is specialized for one small policy, one simulator, and one machine.

What happens is the ladder above, and it comes from boring, checkable work: buffers allocated once and reused, one command buffer per rollout so the GPU never waits on the CPU, the actor forward pass tiled across simdgroups, and gradients computed one thread per parameter instead of through a scratch tensor the size of a small movie.

None of it is trusted on faith. Every Metal kernel has a CPU twin compiled from the same headers, and `test` checks them against each other and against upstream fixtures: RAPTOR oracle at 6e-7, physics at 9.5e-7, the integrated control loop at 9.1e-6, 40,960 ray tests exact.

---

# Technical reference

Everything above is deliberately shallow. This half carries the rigor. Deeper still: [GOAL.md](GOAL.md) (outcome specification and execution contract), [docs/BENCHMARKS.md](docs/BENCHMARKS.md) (every measured number with machine, commit and command), [docs/RESULTS_GALLERY.md](docs/RESULTS_GALLERY.md) (every figure with its source data), [docs/RESEARCH_LOG.md](docs/RESEARCH_LOG.md) (every hypothesis, including rejected ones).

## Control stack timing

Navigation and depth run at 20 Hz. RAPTOR and the RK4 quadrotor dynamics run at 100 Hz. Between them sits a trajectory adapter: the policy's velocity command integrates into a persistent reference position that RAPTOR tracks, so a 20 Hz decision becomes a smooth 100 Hz trajectory with no discontinuity. The action interface is a 1.5 m/s spherical cap on velocity and 0.5 rad/s on yaw; actual speed can overshoot the cap, and one table case measured 7.34 m/s from a 1.5 m/s request.

## Observation contract

The exported actor takes 184 floats ([deployment.hpp](deployment.hpp), CPU-only, no Metal dependency):

| Indices | Content |
|---|---|
| 0–79 | Current frame: 8×10 min-pooled ranges / 12 |
| 80–159 | Previous frame, same layout |
| 160–172 | Goal unit direction, distance /10, body velocities and rates /4, gravity direction in body frame |
| 173–180 | Previous applied command, sensor age, reference-tracking error ×2 |
| 181–183 | Geometry-prior latents |

Build targets exist for 661 (raw depth), 181 (no prior), 184 (selected), and 824 (184 + two raw frames) inputs. Weights do not transfer across input dimensions.

## Training engine

PPO: clip 0.2, γ 0.99, λ 0.95, value coefficient 0.5, minibatch 256, two epochs, global norm clip 0.5, Adam (0.9, 0.999). Termination bootstraps zero; timeout bootstraps the critic, so time limits cannot leak credit. The one accepted anti-collapse mechanism is an L2 anchor toward warm-start weights (actor drift 2.08 → 0.07 when introduced). Domain randomization spans mass, thrust, wind, IMU calibration, sensor noise, delay and dropout over declared stress ranges; these are stress settings, not identified hardware uncertainty.

Parity gates run on every build (`./build/metal_nav test`): analytic ray/clearance cases plus 40,960 GPU-vs-CPU rays, RAPTOR against the pinned upstream fixture (oracle 5.96e-7), L2F physics against the rl-tools fixture (9.54e-7), the PX4 transform (5.96e-8), PPO/GAE/Adam kernel-vs-CPU including a finite-difference check, and a closed-loop GPU pipeline against a hand-written CPU replica.

## Evaluation protocol

TRAIN may affect weights. DEV may be inspected repeatedly and drives selection. FINAL must not influence anything, and the original FINAL split is **no longer fully blind**: research exposed aggregate geometry. Bank bytes are unchanged and no policy was evaluated on it, but any future final claim requires a fresh sealed suite generated after weights and logic freeze. Webots transfer uses clean depth and ideal ego sensing; Metal stress sweeps apply declared corruption separately, so the two are not confused.

## Evidence layer

- Every figure, record and video with source data: [docs/RESULTS_GALLERY.md](docs/RESULTS_GALLERY.md)
- Every measured number with provenance: [docs/BENCHMARKS.md](docs/BENCHMARKS.md)
- Hypothesis → experiment → result, failures included: [docs/RESEARCH_LOG.md](docs/RESEARCH_LOG.md)
- Compact inputs behind every figure, hashed: [`evidence/inputs/`](evidence/inputs)
- Selected checkpoints: [`assets/checkpoints/`](assets/checkpoints); exported actor: `assets/navigation.bin`
- Rebuild every figure without Metal: `python3 evidence.py --out artifacts`

## Limitations

- Simulation only. No real flight, no validated stereo front-end, no flight-controller link.
- The geometry prior is sometimes better than the learned policy; both are always reported.
- Commanded speed does not bound actual speed.
- Doorway performance is sensitive to 50 ms command delay (85.2% → 76.6%).
- Collision scoring uses a conservative 0.18 m sphere, not a mechanical model.
- Transfer is incomplete: 25/30 Metal against 18/30 Webots on the same rooms.
- No GR2PO or recurrent result is claimed; those arms failed or stalled and are preserved.
- The selected policies' native videos are single-case examples, not reliability claims.

## Build and run

Apple Silicon, macOS 15+, CMake, Command Line Tools. Metal compiles at runtime; full Xcode is not needed.

```sh
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build -j 4
./build/metal_nav_guided test
```

Train a fresh policy and evaluate it:

```sh
./build/metal_nav_guided train 3000 7 results/guided.bin '' 1.5 4
./build/metal_nav_guided eval assets/checkpoints/guided-table-memory.bin.best 17 8 800001 1.5 4
```

<details>
<summary>Full command reference</summary>

```text
train ROLLOUTS FAMILY CHECKPOINT [WARMSTART] [SPEED] [DISTANCE]
      [RISK] [ENTROPY] [LEARNING_RATE] [VELOCITY_CONTRACT] [GEOMETRY_MEMORY]
eval CHECKPOINT MODE FAMILY SEED SPEED DISTANCE [SENSOR_DELAY] [WIND_ACCEL]
     [DEPTH_NOISE] [DROPOUT] [COMMAND_DELAY]
bank-eval CHECKPOINT BANK_JSONL SPLIT OUTPUT_CSV [MODE=17] [SPEED=1.5] [MAX_STEPS=400]
bank-witness BANK_JSONL train|dev OUTPUT_CSV [SPEED=1] [MAX_STEPS=1200]
task-eval CHECKPOINT OUTPUT_CSV STAGE FAMILY DOMAIN_AMPLITUDE [SEED] [MODE]
train-tasks ROLLOUTS CHECKPOINT WARMSTART STAGE FAMILY DOMAIN_AMPLITUDE [SEED]
```

Families: 0 open room, 1 boxes, 2 poles, 3 moving spheres, 4 offset doorway, 5 table/counter, 6 mixed, 7 mixture, 8 held-out two-door composition, 10/11 moving threats, 14 bent hallway, 15 connected rooms, 16 vertical choices. Eval modes: 1 random, 2 goal script, 4 learned mean, 13 prior alone, 17 overhead-gated residual (selected), 18/19 ablations. Stress arguments after GEOMETRY_MEMORY: SENSOR_DELAY, WIND_ACCEL, DEPTH_NOISE, DROPOUT, COMMAND_DELAY, SELECTION_MODE.

</details>

## Repository map

| Path | What it holds |
|---|---|
| [GOAL.md](GOAL.md) | Outcome specification and the execution contract |
| [docs/RESULTS_GALLERY.md](docs/RESULTS_GALLERY.md) | Every figure, record and video, with source data |
| [docs/BENCHMARKS.md](docs/BENCHMARKS.md) | Every measured number, machine, commit, command |
| [docs/RESEARCH_LOG.md](docs/RESEARCH_LOG.md) | All hypotheses, including the rejected ones |
| `main.mm` | Objective-C++ host: pipelines, harnesses, training orchestration |
| `*.metal` | GPU kernels: physics, depth, RAPTOR, PPO, geometry memory |
| [deployment.hpp](deployment.hpp) | CPU-only deployable actor interface |
| [challenge_bank.py](challenge_bank.py) | Frozen level bank generator with witness routes |
| [THIRD_PARTY_LICENSES.txt](THIRD_PARTY_LICENSES.txt) | RAPTOR / RLtools MIT notices (pinned upstream commits inside) |
