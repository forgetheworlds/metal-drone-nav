# Local training distribution audit — waypoint runner and navigation tasks

Mission: local-capability learner (navigation-awareness worktree @ c30e44f).
Primary objects audited: `navigation_waypoint_training.mm` (copied source-owner
runner, sha `ac953404f670…`, self-hash renamed) and `navigation_tasks.hpp`.
Evidence: reproduced baselines (fast dev-a 100/128, dev-b 101/128; local 103/128;
arrival 96/128), a full joined failure taxonomy against
`results/navigation-visibility` and `results/view-conditioning`, and train/DEV
bank cross-tabs computed from the kept bank CSVs. All numbers below are measured
on this machine; hashes in `results/omp-aware-navigation/PROGRESS.md`.

## 1. What the current code actually trains

**Task construction** (`build_bank`, one deterministic record per task):

- Source TRAIN bank: seed 20261004, 1024 tasks = 128 envs × period 8, families
  {0 open, 1 boxes, 2 poles, 4 doorway, 5 table, 14 bent hallway, 15 connected
  rooms, 16 vertical choices} (128 each). DEV: dev-a @20261005, dev-b @20261007,
  128 tasks each, families {2,4,5,14,15,16}, period 1.
- Start box x∈[−1.4,1.0], y∈[−3,3], z∈[0.8,2.6]; goal 1–3 m away in
  x∈[−1.7,13.7], y∈[−4.7,4.7], z∈[0.3,4.7]; endpoint acceptance
  `wclearance > 0.30` where `wclearance` already subtracts the 0.18 m body →
  **surface ≥ 0.48 m** (parent-corrected fact).
- Route: straight segment if segment clearance > 0.02 m (body-adjusted, i.e. ≥2 cm
  slack past the 0.18 m sphere), else bounded doglegs
  (`navigation_task_find_witness`) then a coarse waypoint lattice; witness
  length / Euclidean distance ≤ 2.5. Class preference alternates direct/detour
  per cycle with fallback to any accepted draw.
- **Start yaw uniform ±π; start velocity points exactly at the goal**, speed
  U(0,1) m/s. (Coupling: velocity direction ≡ goal direction.)
- Episode: 400 nav steps × 0.05 s = 20 s budget; success = `FINAL_HOLD`:
  inside 0.35 m, speed ≤ 0.5 m/s for 0.2 s, no contact; contact = 0.18 m sphere
  (`wclearance ≤ 0`).

**Task step / reward** (`navigation_task_step`): per step
`2.0·Δ(euclidean distance) − time_cost·0.05 − 0.05·Δu²·0.05`,
terminal `−10` contact, `+10` stable arrival. `time_cost` 0.2 s⁻¹ (verified
recipe) or 1.0 s⁻¹ (fast arm); waypoint objective exists in code but the local
recipe always uses `FINAL_HOLD`.

**Observation/action contract**: 184 inputs = 80 min-pooled depth (current) +
80 previous + 21 context (body-frame goal direction, `min(d/10,1.5)` distance —
saturates, 1–3 m maps to 0.1–0.3 — body velocity/4, angular velocity/4,
world-up, previous nav, sensor age, reference error) + 3 deterministic geometry
prior latents (`guidance.hpp`,8-frame pose/range memory ring). Action: mode 22
training = Gaussian latent, executed `tanh(prior + s·(a−prior))` for XYZ and
`tanh(s·a₄)` for yaw with `s = 0.25 + 0.75·(open-overhead fraction)`; mode 17
eval is the deterministic mean of the same map; velocity contract spherical cap
at 1.5 m/s; yaw reference rate ≤ 0.5 rad/s.

**Training loop**: PPO, 128 envs × horizon 32,2 epochs, lr 1e-4, entropy 1e-3,
log σ init −1, γ 0.99 / λ 0.95, warmstart = arrival checkpoint
(`arrival-open-domain-experimental.bin.best`, sha `bb6e8309…`); selection
`.best` on dev-a every 50 rollouts (success → collision → arrival time).
Sampler = deterministic bank cycling (`index = env·period + episodes%period`),
uniform, no adaptive weighting in this path. Nominal plant enforced
(`enable_task_control` refuses runtime dynamics); clean sensor (no delay/noise
in training; delays exist only in eval).

**Measured baselines (reproduced exactly this session):** fast 100/128 dev-a
(27 contact, 1 timeout), 101/128 dev-b; local (reliable) 103/128 but 4.51 s vs
3.68 s arrival; arrival warmstart 96/128.

## 2. What aligns with the staged cloud → local-goal architecture

- **Local horizon**: one valid 1–3 m goal,20 s budget — matches
  "reach the next visually grounded target", not global routing.
- **Deployable inputs only**: depth + ego + relative goal + deterministic
  geometry prior; witness route is generator-side only and never enters the
  actor observation (checked: `BankEntry` fields → `waypoint_task_apply` sets
  task metadata, not obs).
- **Terminal semantics**: `FINAL_HOLD` matches "cloud reassesses on arrival";
  the `WAYPOINT` pass-through objective already exists in
  `navigation_task_step` for intermediate subgoals (unused by the local recipe).
- **Trained in the deployed action map** (mode 22 trains exactly the mode 17
  evaluation/deployment map); export/deploy interface exists from prior work.
- **Independent TRAIN/DEV seeds**, provenance-hashed banks, resume contracts —
  selection hygiene is already good.
- **Stable-arrival success + contact + arrival-time metrics** are reported per
  flight with full denominators (no filtering).

## 3. What is mismatched or underrepresented (measured)

- **M1 — detours outside the initial view are a high-failure cell.**
  Cross-tab of the reproduced fast arm:
  - dev-a: detour + goal outside horizontal FOV at t=0 → **7 S / 26 C / 1 T**;
    detour + in-FOV → 12 S / 1 C; direct → 81/81 S.
  - dev-b: detour + out-FOV → 13 S / 24 C / 1 T; detour + in-FOV → 4 S / 1 C.
  - The17 never-seen contacts (root visibility audit) have **median yaw travel
    0.11 rad over the whole flight** and median goal bearing 143.9°: the policy
    never turns to look. Root's physical brake+face protocol gets 104/128
    (14 wins / 10 losses, detour 24/47,5.10 s) — the behavior is physically
    viable and worth +4 net, but it is scripted, not learned.
  - 75–76 % of TRAIN starts have the goal outside the horizontal FOV
    (246/1024 in-FOV, **yaw-hemisphere convention** ±45° horizontal half-angle;
    under the full legacy camera frustum the contract mission counts 169/1024 —
    both reproduce under their own convention), blank history. The relative goal direction is observed, and yawing can reveal some blocking
    geometry. This does not establish timely observability or physical
    feasibility for every task. The measured arms show little sustained yaw
    exploration; an observe-before-motion capability remains a hypothesis.
- **M2 — start velocity is coupled to the goal direction.**
  `entry.start_velocity = direction·speed` with `direction` = goal direction, so
  every episode starts already flying toward the goal — and on detour tasks,
  toward the blocker. Deployment episodes start from the previous arrival
  (≈0 velocity, next goal may be anywhere). Velocity direction should be an
  independent axis; today it is an accidental coupling that concentrates the
  first contact at0.5–2 s (measured:10/27 contacts ≤1 s).
- **M3 — easy mass vs frontier mass are unbalanced.** Direct tasks are 81/81
  (dev-a) and 669/1024 of TRAIN: useful rehearsal, little new information.
  Detour+out-FOV+tight (witness <0.20 m) is 166/1024 TRAIN; on dev-a that cell
  succeeds 2/20 — nearly-impossible cells are silently mixed into the learning
  distribution (goal.md: label them).
- **M4 — no observability metadata.** Bank CSV keeps family, route class,
  clearances, witness ratio, yaw/velocity — but no goal bearing, no
  warning-time / first-blocker visibility, no "was the relevant obstacle
  observable before the decision was unavoidable". Root's visibility audit did
  this posthoc for128 dev tasks only.
- **M5 — geometric and control/sensor difficulty are conflated (and the
  control axis is absent in training).** Wind, sensor delay, command delay,
  depth noise/dropout exist as eval knobs only; waypoint training pins the
  nominal plant and clean sensor (`enable_task_control` refuses runtime
  dynamics). They cannot be independently measured in training today.
- **M6 — terminal contract fixed to stable hold.** No pass-through waypoint arm
  even though the code supports `NAV_TASK_OBJECTIVE_WAYPOINT`.
- **M7 — direction/template shortcuts are possible**: start box is one-sided,
  travel is mostly +x, detour-class draws flip `direction.x<0` with p=0.75, no
  explicit mirroring/rotation invariance; `difficulty` scalar (0.5) is written
  but does not modulate the bank draw (goal distance is uniform1–3 m).
- **M8 — near-goal distance encoding is compressed**: `min(d/10,1.5)` gives
  0.10–0.30 over the whole1–3 m range (open item from the waypoint handoff; not
  changed here).
- **M9 — reward reference for the local blocked-goal class has not been
  audited** (success vs hover vs blind-straight vs detour vs collision). The
  old reward audit proved long detours can rank below hover under discount; for
 1–3 m tasks the terminal `+10` still dominates at observed arrival times
  (2.6–4.5 s, γ⁰·⁹⁹^140 ≈ 0.25), but this must be verified *before* tasks get
  harder (item 11).

## 4. Capability-based taxonomy for the next generator

Named obstacle families are primitives, not the taxonomy. Next generator should
sample *capabilities*:

| id | capability | generator ingredients (existing) |
|----|-----------|----------------------------------|
| C1 | accelerate / brake / arrive without overshoot | open room, goal distance ×, start speed × |
| C2 | recover from nonzero velocity; handle arbitrary starting yaw | start velocity direction (decoupled from goal!), start yaw |
| C3 | **observe-before-motion**: goal or blocking geometry outside FOV → yaw-to-look before committing | yaw draw (already), start velocity ×, occluder placement |
| C4 | blocked direct segment → choose side/height, return efficiently | detour witness machinery (already) |
| C5 | passage under constraint: doorway / gap / corridor / furniture spacing / vertical opening, clearance strata | doorway, table, vertical, hallway generators |
| C6 | multiple traversable gaps, prefer wider/safer (no fixed side) | two-doorways (family 8) + mirrored placement |
| C7 | short memory: geometry leaves FOV, briefly retained | memory ring (exists) + goal beyond visible affordance |
| C8 | dynamic threats (later phase): crossing / approach / closing gap | threat sphere primitives (families 10/11); today blocked by `NAV_TASK_GENERATION_UNSUPPORTED_DYNAMIC` — unify deliberately, controlled |

Cross-cutting axes, kept orthogonal: terminal contract (pass-through vs stable
hold); geometry difficulty vs control/sensor difficulty (§5).

## 5. Variables that should define task difficulty

Keep as per-task metadata (CSV already carries several; add the rest):

- direct route clear vs blocked (route class) ✔ in CSV
- shortest-feasible-path / Euclidean ratio (`witness_length/initial_distance`) ✔
- required detour distance, minimum route clearance ✔ (witness clearance)
- **goal bearing at start / in horizontal FOV** (computable from CSV columns —
  must be used in every report from now on)
- gap width relative to vehicle envelope; vertical clearance (expose doorway
  width as a parameter — today implicit)
- number of meaningful route choices; obstacle density
- required heading change; required braking (start speed × distance to first
  blocking surface along the goal line)
- start speed ✔, goal distance ✔, start velocity direction (new axis, §3 M2)
- sensor warning time for the relevant obstacle; occlusion duration
  (analytic ray at generation, host side)
- control/sensor axes when training on them: sensor delay, command delay,
  depth noise/dropout, wind, vehicle parameter variation
- (later) relative obstacle speed, time-to-collision

Do **not** collapse into one scalar; stratify results by these columns.

## 6. Existing generators reusable as-is

- `wgenerate` families 0,1,2,4,5,6,8 (open/boxes/poles/doorway/table/mixed/
  two-doorways), 14,15,16 (hallway/rooms/vertical); threat primitives 10/11 for
  a later dynamic phase.
- `navigation_task_find_witness` doglegs + `route_via_waypoint` lattice;
  `navigation_task_segment_clearance`; `wclearance`/`wray` physics-exact
  clearance and ray helpers.
- `build_bank` draw machinery (seeded scene/start/goal loop, class
  alternation, fallback, per-task CSV), bank ABI + SHA-256 provenance +
  resume contracts.
- `local_task_recipe` / `navigation_task_step` step-reward and terminal
  contract; mode 22/17 action map; Sim rollout/PPO stack unchanged.
- Eval knobs already built: sensor/command delay sweeps, wind, noise, dropout
  (production `eval`); legacy retention harness (families 7/8).
- Challenge-bank failure-weighted sampler (`challenge_training.hpp`) as a
  *pattern* for later adaptive sampling (uniform floor 0.5, score/staleness
  mix) — not wired to the waypoint path and not assumed correct.

## 7. New generators genuinely necessary (minimum set)

1. **Observe-before-motion training signal** — not a new world, but the missing
   teaching signal for C3 (first experiment, §12).
2. **Decouple start-velocity direction from goal direction** (M2): one-line draw
   change plus strata; direction sampled independently of the goal.
3. **Observability/feasibility labelling at generation** (§8): goal bearing,
   first-blocker ray visibility, warning time as CSV columns.
4. **Clearance/gap strata exposure**: expose doorway width and gap clearance as
   explicit difficulty draws with a floor (e.g. ≥10 cm slack past body) for the
   main mass, tighter cells kept but labelled "diagnostic-tight".
5. **Multi-gap choice variant** reusing family 8 with mirrored placements (C6).
6. **Memory task**: goal just beyond a visible affordance with the intervening
   geometry previously observed (C7) — requires a short observe phase before
   motion; build only after C3 lands.
7. Later, controlled dynamic tasks (C8) — explicitly out of scope for the first
   experiment.

Not necessary now: any change to world format, observation layout, network
size, or PPO.

## 8. Feasibility and observability without leaking privileged information

- Keep generator-side checks: endpoint clearance (body-adjusted), witness
  existence, route ratio; **add a time-feasibility bound**: witness length ÷
  1.5 m/s + turn allowance < 20 s (bounded sample check, host side).
- **Observability labels at generation** (host side, analytic rays à la the
  visibility audit): goal-in-FOV flag, first blocking-geometry visibility and
  warning time from the start pose along the goal bearing. These become CSV
  metadata used for stratification and for labelling
  `observable / active-perception-required / occluded-diagnostic`.
- Labels are **never** actor inputs; the184-dim observation and the mode-17
  map stay byte-identical (no mapping change without explicit versioning).
- Privileged geometry remains allowed for: rejecting impossible starts/goals,
  witness feasibility, difficulty metadata, training-only teachers/rewards.
- Impossible-after-yaw cases (goal bearing unreachable even after rotating, or
  blocker hidden by other geometry from every reachable view) stay as a labelled
  diagnostic subset, never silent main mass.

## 9. Proposed TRAIN / DEV / future-sealed split

- **TRAIN**: kept source bank @20261004 (1024 tasks, hashes unchanged). Labels
  for the first experiment are collected **only** from TRAIN flights.
- **Selection**: dev-a @20261005 (unchanged, same rule as every prior arm:
  success → collision → arrival).
- **Held-out**: dev-b @20261007 (existing) and **dev-c, new predeclared seed
  20261010**, 128 tasks, families {2,4,5,14,15,16}, period 1 — generated and
  hash-recorded *before* any training run; never used for selection.
- **Legacy retention**: production families 7/8, mode 17, seed 800001 (existing
  harness) for control and final candidate.
- **Future sealed suite**: fresh bank after weight/obs/map/generation freeze —
  old FINAL geometry is exposed research, not a claim target.
- Stratified reporting everywhere: route class × goal-in-FOV × clearance
  buckets (columns already derivable from bank CSV).

## 10. Curriculum / sampling that preserves prior skills

- First experiment stays uniform (waypoint path) — no adaptive sampler until a
  measured need exists; if needed later, reuse the challenge-sampler pattern:
  per-stratum weights from recent success/collision/staleness with a **≥0.5
  uniform floor** over the whole bank (goal.md: do not assume mean-|GAE| is the
  right difficulty).
- Cumulative rehearsal = keep the full source bank in the mixture and keep the
  arrival warmstart chain (warmstart → BC → PPO), then prove retention on
  dev-a/dev-b + legacy 7/8 after the run. New capability banks (C5–C7) must be
  *added* to the mixture, never swapped in.
- Labelled diagnostic-tight cells (§7.4) may be up-weighted only as a declared
  arm, with their own denominators.

## 11. Reward changes required before making tasks harder

- **No reward change before the first experiment** — the first experiment does
  not make tasks harder; it teaches an existing task class.
- Required before any harder/horizon-extended class: a **reference-return
  audit for the local blocked-goal task** — success vs hover vs blind-straight
  vs detour vs collision under γ=0.99, using actual `navigation_task_step`
  returns. Owned by the research/experiment mission (isolated reward/sampler
  studies per coordination dispatch); concrete request filed in
  `results/omp-coordination/inbox`.
- Horizon bound while that is pending: γ=0.99 gives terminal weight γ^T; at the
  observed 2.6–4.5 s arrivals (T≈50–90) γ^T≈0.60–0.41 — the `+10` dominates and
  ordering is safe. Beyond ≈7 s arrivals (T≈140, γ^T≈0.25) ordering versus time
  cost must be re-measured; therefore **do not extend the1–3 m horizon before
  the reward audit** (answers "do not assume1–3 m is final" with a bound, not a
  guess). Geodesic potential shaping exists for challenge banks and can be
  ported to the waypoint path later under the research mission.

## 12. Smallest first experiment with the most information

**Hypothesis (falsifiable):** the dominant held-out failure (detour + goal
outside FOV) is an unexplored *observe-before-motion* behavior — "stop/slow and
yaw the goal into view, then fly" — that is (a) a pure function of the
deployable observation (goal body direction + distance are inputs), and (b)
physically viable (root's scripted brake+face:104/128 vs100,14/10 paired).
Therefore a **positive-trajectory imitation warmstart of that behavior,
followed by full PPO with a matched control**, should cut contacts and raise
held-out success without giving up speed.

**Minimum infrastructure:**
1. `local-teacher` in my runner: hybrid controller on TRAIN flights —
   where `|goal bearing| > 35°` and `distance > 0.6 m` (root's predeclared
   constants, no sweeps): body velocity = 0, yaw = `clamp(4·bearing_error, ±1)`;
   otherwise the deployed actor's own mode-17 command. Labels are recorded in
   the deployed command space (spherical-capped body velocity /1.5, yaw ∈[−1,1])
   — **all label components are functions of the observation only** (no truth,
   no witness, no omniscient target). Rows retained only from **successful
   actual-RAPTOR episodes** (positive trajectories); failed episodes discarded
   and counted.
2. `local-bc`: verified imitation-gradient BC (finite-difference-checked, as in
   the existing verified kernel) on the collected dataset; produce a warmstart
   checkpoint (actor params; critic from the same checkpoint; explicitly not a
   PPO resume).
3. dev-c bank predeclared and hashed before training.

**Arms (one recipe, matched, no sweeps):** time cost 1.0 (the fast recipe, keeps
speed), same warmstart chain otherwise, seed 20261004. Teacher base and both
arms start from `candidate-fast.bin.best` (`7a37ace8…`, the strongest verified
baseline, dev-a 100/128) — the single difference between the arms is the BC
step:

- **Arm T**: candidate-fast → `local-teacher`+`local-bc` → PPO, 10 000 rollouts.
- **Arm C (control)**: candidate-fast → PPO, 10 000 rollouts, identical settings.
- Second seed for both only if arm T shows useful gain on dev-a.

**Evaluation:** closed-loop `local-eval` mode 17 on dev-a (selection), dev-b,
dev-c (held-out), plus geometry-only mode 13 vs residual mode 17 on dev-c
(compare prior/actor/residual), plus legacy families 7/8 retention, plus
speed/contact/arrival/clearance per flight with full denominators. Source
snapshots + `local-contract` hashes recorded before every training run.

**Falsification:** if arm T at 10 000 rollouts does not beat arm C on held-out
contact rate / success while keeping arrival time within baseline bounds, the
"missing observe-before-motion behavior is the binding bottleneck" claim is
rejected; next candidate would be distribution grounding (draw start yaw inside
FOV), i.e. removing the aliased mass rather than teaching it — decided only
after the falsifying result.

**Explicit non-goals of the first experiment:** no generator rewrite, no
reward/map/obs change, no horizon change, no threshold sweeps (35°/0.6 m and
the4·gain are inherited verbatim from the predeclared physical protocol), no
network/PPO changes.

## Revision history

- **v1** — `05bd0f7c…`, published 10:52 EDT, round-1 accepted.
- **v2** — `4c6792b7…`, edited **12:11:10 EDT, before any experiment data**
  (teacher first ran 12:13 EDT; coordinator verified the ordering, round 8):
  (a) FOV counts labelled with the convention (yaw-hemisphere ±45° vs the
  contract mission's camera-frustum-legacy 169/1024); (b) §12 arm base
  changed `arrival → candidate-fast.bin.best` (`7a37ace8…`) with matching
  critic line, so both arms share the strongest verified base and the BC step
  remains the single difference. Pre-data matched amendment, accepted by
  round 8.
- **v3** — this revision block appended (post-run bookkeeping only; no
  experiment design text changed after v2).
