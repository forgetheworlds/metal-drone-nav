# Local task contract audit — independent verification

Mission: omp-task-contract (calibrated-navigation-sensors worktree). This is
the independent contract audit of the CURRENT local waypoint task distribution
that `goal.md` requires before any new training. The learning owner's separate
distribution audit is `docs/LOCAL_DISTRIBUTION_AUDIT.md`; this document covers
contract invariants, executability of the step/reward contract, actual
RAPTOR-flown source trajectories, observability and goal grounding, braking and
arrival budgets, and reward ordering. Every number below was produced by the
commands in §10 on this machine; the verifier scripts live in the
calibrated-navigation-sensors worktree and the records in
`results/omp-task-contract/`.

Scope boundaries: no core file was modified, no training was started, no
checkpoint was selected or promoted, no Webots run was made by this mission.

## 1. Contract status in one table

| Contract element | Verifier | Result |
|---|---|---|
| Bank geometric witness/separation/denominators | `local_contract_audit.py` | PASS, 0 failures over 1,280 tasks (coordinator also ran it twice incl. a fault-injection run: 6 injected defects caught) |
| Step contract: pass-through vs stable hold, terminal precedence, finite horizon | `local_step_contract_check.mm` | PASS, 36/36 assertions against the real `navigation_task_step` |
| Reward decomposition vs simulator reward buffer | `local_contract_probe.mm` | max per-tick error 9.7e-7 over all flights (float32 round-off) |
| Published baselines reproduced | official `local-eval` + probe | dev-a fast 100/27/1 exactly; blind mode-2 dev-a 82/46/0 with 128/128 per-task agreement |
| Root's visibility audit reproduced independently | `local_flight_evidence.py` | dev-a 128/128 outcomes, 27/27 colliders, 17/27 unseen contacts — exact |
| Full TRAIN flights (1,024 tasks, all 8 slots) | probe, period-cycling protocol | completed: policy 796/205/23, blind 675/349/0, hover 0/0/1024 |
| Reward ordering (goal.md item 11) | `local_reward_ordering.py` | reference ranks above hover, blind-straight, unnecessary detours, collisions under undiscounted, γ=0.99-discounted and the fast arm's time cost |
| Difficulty axes + exclusions recorded before training | `results/omp-task-contract/pretraining-record.json` | written 10:57, before any training exists |
| Resume/provenance contract (independent fault injection) | `local_resume_contract_audit.py` | PASS 9/9: pristine control succeeds; 8 mutations (time cost, lr, speed cap, bank entries, eval spec, warmstart hash, bank bytes, missing sidecar) all refused with every artifact byte-identical |
| Verifiers reject injected faults (round-1 requirement) | `verifier_fault_selftest.py` | PASS 4/4 on the flight-evidence and reward-ordering verifiers (outcome flip, dropped rows, perturbed reward); bank audit fault-injected by the coordinator (6/6) |

## 2. What the current distribution is (verified, not assumed)

Source TRAIN bank `source` (seed 20261004, SHA-256 of `.bin` file
`72ba5a3ac913…`, entry hash `d8db583ae543…`): 1,024 tasks = 128 envs × period 8,
families {open, boxes, poles, doorway, table, bent_hallway, connected_rooms,
vertical_choices} ×128 each. DEV banks dev-a (20261005) and dev-b (20261007),
128 tasks each, six families, period 1. Evidence copies in
`evidence/inputs/local-waypoint/banks/` are byte-identical to the audited CSVs
(checked by hash).

Independently recomputed from the CSV rows, all PASS:

- endpoint clearances > 0.30 m body margin at both ends (surface ≥ 0.48 m);
- goal distance in [1, 3] m; witness ratio ≤ spec (2.5 source/DEV, 3.0
  open/clutter); witness clearance floor 0.02 m;
- route class exactly matches the direct-segment clearance threshold;
- start speed ≤ 1 m/s and start velocity parallel to the start→goal direction
  (all 1,280 rows — see finding P-3);
- TRAIN/DEV scene seeds and start/goal tuples disjoint;
- bank `.bin` hashes match their manifests (the hashes training bound to);
- every bank rebuild receipt across 131 retained logs is byte-identical
  (`bank_build … direct=669 detour=355 class_fallback=157` for source, 15/19
  fallbacks for dev-a/dev-b).

Generator exclusions (recorded before training): the build receipts are the
only retained exclusion record. The CSV `attempts` column is an echo of route
class (detour=2, direct=1), not a rejection count. Detour-preference
fallbacks are recoverable per row and match the receipts exactly
(157/15/19); direct-preference fallbacks are not row-recoverable (5 exist in
clutter, visible only in the receipt total). Per-draw rejections are not
persisted anywhere — recorded as a limitation in `pretraining-record.json`.

## 3. Vacuous denominator in `local-eval --spec source` (P1, prominent)

`evaluate_bank` runs exactly one episode per environment and scores
`bank[env*period + 0]`. For the source bank (period 8) that is slot 0 only,
which is family `open` for every env — **`local-eval --spec source` scores
128/1,024 TRAIN tasks, all family open, all route class direct, and returns
128/128 success** (verified on all 18 retained `*-source-mode*.csv` files: 128
rows, family open only). Anybody reading "source" as a TRAIN score gets an
empty denominator. The published tables do not cite it (they use the separate
`open` spec), but the command name invites the error. The full-TRAIN score in
this audit (§4) was obtained with an explicit period-cycling protocol in the
independent probe, not with `local-eval --spec source`.

Recommendation for the learning owner: keep `--spec source` for training-bank
regeneration only, and print a warning line when the evaluator is asked to
score a period>1 bank; or evaluate all slots and report the real denominator.

## 4. Actual RAPTOR source trajectories (full TRAIN, all slots)

Protocol: `local_contract_probe.mm` (embeds the published root runner,
`WAYPOINT_EMBEDDED`, no edits to any existing file), non-eval auto-reset
cycling exactly as training sees tasks (`episodes % period` slot selection),
`period × 400 = 3,200` ticks so every slot completes even under all-timeout.
Cumulative `SimRun` counters survive auto-reset and provide per-episode
time/path/outcome deltas; state columns come from pre-tick snapshots; rewards
come from the simulator reward buffer rows. Guarded by `reset_invariants` and
`observation_contract` PASS at start, ray-model error < 2e-4 m against the
measured GPU sensor (actual max 0 on every run), and a hard
`min_episodes_per_env ≥ period` check.

Frozen actor: `local-waypoint-fast-experimental.bin.best` (`7a37ace8e86b…`,
byte-identical to `results/omp-local-waypoints/runs/candidate-fast.bin.best`),
mode 17, seed 700001, legacy camera profile, runner `aabe46e7c7c5…`, compiled
core `0672e140a3de…`.

Full-TRAIN results (1,024/1,024 denominator, first per-flight TRAIN record of
this actor):

| controller | success | contact | timeout |
|---|---|---|---|
| frozen actor (mode 17) | 796 | 205 | 23 |
| blind goal-seeker (mode 2) | 675 | 349 | 0 |
| zero-command hover | 0 | 0 | 1,024 |

By route class (policy): direct 662/669 success (5 contact, 2 timeout);
detour 134/355 success, 200 contact, 21 timeout. By family: open 128/128,
table 119/128, bent_hallway 119/128, vertical_choices 108/128, boxes 90/128,
poles 84/128, doorway 75/128, connected_rooms 73/128. Blind flies direct
tasks well (668/669) and essentially cannot solve detour tasks (7/355, 348
contacts) — the detour capability is genuinely learned, not incidental.

Controls: the same probe and the official runner reproduce every published
baseline exactly — dev-a policy 100/27/1 (arrival 3.68051 s, path 2.12035 m),
dev-a blind 82/46/0 with 128/128 per-task verdict agreement against the
retained `fast-deva-mode2.csv`.

## 5. Observability and goal grounding (labels, not excuses)

All of the following is generator/observer-side evidence; none of it enters
the actor observation.

- **Collider visibility, TRAIN:** of 205 contact flights, the colliding
  geometry never appeared in the 320 measured rays for **91 (44%)**; root's
  dev-a audit found 17/27 unseen and this probe reproduces that count and
  every first-seen time exactly (27/27 colliders, 128/128 outcomes).
- **Detour blocker visibility, TRAIN:** for the 355 blocked-direct tasks, the
  obstacle that blocks the straight line was never seen in the whole flight
  in **120/355 (34%)** (raw rays; pooled 80-bin view similar), even on
  successful flights. First-sighting times and pooled views per task are in
  `warning-evidence.json`; warning times are conservative by at most one
  0.05 s tick because terminal-tick rays are destroyed by `sim_reset_one`
  inside the command buffer (documented protocol limitation).
- **Goal grounding at selection, TRAIN** (legacy camera convention
  `camera-frustum-legacy`: tan_h 1.0, tan_v 0.75, mount 0, yaw-only
  orientation), five declared classes:
  - **116/1,024** goal inside the frustum with clear line of sight —
    "visually grounded at selection" in the strict onboard-camera sense;
  - **74/1,024** occluded but the goal-bearing blocking surface is already
    visible within 0.25 s — the "just beyond a visible opening" candidate
    class (blocked-direct tasks where the affordance geometry is in view);
  - **53/1,024** in frustum but occluded;
  - **97/1,024** occluded and the blocking geometry not (or late) visible —
    requires look-around or short memory;
  - **684/1,024** outside frustum with clear line of sight.
  Frustum-only total: **169/1,024** (= 116 + 53). The learning owner's
  246/1,024 uses the coarser `yaw-hemisphere` convention; both are correct
  under their labels (coordinator round-2 note).
- Interpretation follows `goal.md`: this mass is not necessarily impossible —
  the goal direction is in the observation and yawing can bring the scene
  into view (coordinator's vertical check: only 2 of 34 horizontally-out
  dev-a detour tasks are also vertically outside) — but today it is
  unlabelled in the bank, and failures split into "unobservable-collider",
  "insufficient warning" and "observable, policy/control failure" only in
  this mission's records. These labels must travel with any new training
  distribution (learning owner's items M1/M4, agreed independently here).

## 6. Braking and arrival budgets

- Episode time budget: max observed episode time 20.0004 s over all 4,096
  flights across controllers; nothing exceeds the 20 s contract.
- Stable arrival: **796/796 policy successes show ≥3 observed in-radius,
  ≤0.5 m/s hold ticks** (plus the terminal tick required by the contract) —
  the FINAL_HOLD success flag is backed by flight evidence, not just code.
- Pass-through without hold exists in the data: **1 timeout flight entered
  the 0.35 m radius and never stabilized** (recorded in
  `braking-arrival.json`), confirming that crossing at speed cannot fake
  success and that such cases are countable.
- Observed deceleration capability (max 3-tick/0.15 s speed drop over all
  policy+hover TRAIN flights): p50 small (steady cruise), p90 0.36 m/s²,
  max 5.54 m/s². Hover flights passively brake the bank's toward-goal start
  velocity (≤1 m/s) to ≤0.05 m/s in a median 1.0 s — these sampled starts can brake in the nominal plant. This does not establish
  physical feasibility for every route or exclude actuation limits in harder tasks.
- Braking budget axis per task (stopping distance at the 1.5 m/s cap using
  the p90 decel vs straight-line distance) is computed in
  `braking-arrival.json` as a distribution axis; early braking before the
  goal line is required for most short tasks — normal, not a failure.

## 7. Reward ordering — answers the learner's §11 request (gate 1)

`local_reward_ordering.py` on ground-truth per-tick rewards (component
identity vs `reward_sum` verified to 3.6e-15):

Behaviour means over full TRAIN denominators (1,024 each controller).
Note: "contacts" (n=205) and "unnecessary detour" (n=205) are **disjoint
sets that coincidentally share a count** — contact flights are failures
(200 detour + 5 direct), unnecessary detours are direct-class *successes*
whose path was ≥1.5× the straight distance.

| behaviour | n | undiscounted | γ=0.99 discounted | time cost 1.0 |
|---|---|---|---|---|
| reference success (detour) | 134 | +13.95 | +7.67 | — |
| reference success (direct) | 457 | +12.86 | +7.73 | — |
| unnecessary detour (direct-class, ≥1.5× path) | 205 | +11.76 | +7.21 | — |
| blind straight (aggregate) | 1,024 | +5.69 | +3.97 | +4.50 |
| hover | 1,024 | −4.02 | −0.98 | −20.06 |
| contacts (direct+detour) | 205 | −8.43 | −5.42 | −10.33 |
| timeouts | 23 | −1.66…−4.65 | — | — |

Verdicts: the valid reference ranks above every goal.md undesirable —
hover, blindly-straight, unnecessary detours, unsafe shortcuts/collision —
under all three views (undiscounted, γ=0.99 discounted, and the fast arm's
1.0 time cost reweighted exactly from recorded components). **Scope of each
claim:** the undesirable rankings are **class-mean comparisons** (full
denominators, table above); the **per-flight** evidence is (a) the paired
policy-vs-blind table below and (b) the inversion count —
**0/591** successful reference flights rank below the flown hover under
γ=0.99 (the per-flight hover pairing; bonus weight γ^ticks mean 0.54, min
0.06). The historical "long detour below hovering" pathology does not
reproduce on 1–3 m local tasks at observed arrival times. The horizon bound
in the learner's §11 (do not extend the goal horizon before re-measuring)
remains the right operational rule; this audit supplies the missing
measurement at the current horizon.

Paired same-task policy vs blind: policy wins 436, loses 588, mean Δ +2.50;
stratified, policy wins the detour stratum 205/355 vs 150 and loses the
direct stratum 231/669 vs 438 (the blind beeline is often faster where the
path is clear). Both facts are in `reward-ordering.json`; they say the reward
tracks success and collision, not speed-purity, under this contract.

The step-contract probe additionally pins the semantics: pass-through
(`WAYPOINT`) latches a nonterminal event with no bonus; `FINAL_HOLD` needs
four inside-slow ticks (0.2 s) and pays the +10 exactly once; contact on the
same tick as a would-be hold pays −10 and never +10; episodes end exactly at
400 steps; progress terms telescope to 2× net distance (this identity is what
makes the exact time-cost reweighting above valid).

## 8. Difficulty axes recorded before training

`results/omp-task-contract/pretraining-record.json` (written before any new
training exists) fixes: per-task axes recorded (family, route class, distance,
clearances, witness ratio, yaw, velocity), axes derivable (bearing/in-FoV,
braking requirement), axes now measured by the flight probe (warning time,
LOS grounding, observed deceleration, hold evidence) and axes absent from the
current distribution (velocity-direction variation, delay/noise/wind in
training, moving obstacles). `task-axes.csv` holds the per-task rows for
source/dev-a/dev-b (1,280 rows).

## 9. Findings

- **P1 — vacuous `source`-spec evaluation denominator** (§3): 128/1,024,
  family open only. Coordinator verified independently. Fix or warn before
  anyone reports a TRAIN score from that command.
- **P1 — grounding/observability mass is real and must be labelled** (§5):
  only 116/1,024 goals are frustum-visible with clear LOS at selection;
  91/205 contact colliders and 120/355 detour blockers are never seen in the
  rays at all. Any new task mix should carry these labels per task (already
  requested by both audits; my records supply the per-task values for the
  current banks).
- **P2 — start velocity is coupled to the goal direction** (learning owner's
  M2, confirmed independently here over all 1,280 rows): every start flies
  straight at the goal, so the first decision arrives early and biased. Not
  a bug in the record — a distribution axis that is currently constant.
- **P2 — CSV `attempts` column is a route-class echo**, and per-draw
  generator rejections are not persisted; only receipt totals exist. Keep
  receipts with every regenerated bank (§2).
- **P3 — terminal-tick sensor evidence is unrecoverable** in the cycling
  protocol (`sim_reset_one` fills the sensor ring with 12 m in the same
  command buffer); warning times are conservative by ≤1 tick. Documented in
  the probe and in `warning-evidence.json`.
- **No regressions**: no core file changed; all published baselines
  reproduced exactly (dev-a 100/27/1, blind 82/46/0, visibility 17/27,
  per-task agreements 128/128).

## 10. Reproduction

```sh
# verifiers (host only)
python3 local_contract_audit.py                 # -> bank-invariants.json, task-axes.csv, pretraining-record.json
./build/omp-task-contract/local_step_contract_check   # -> step-contract.json

# resume/provenance fault injection (GPU lock; 1-rollout smoke + 8 mutations)
python3 /Users/muadhsambul/RL/results/mimo-learning-next/run_locked.py -- \
  python3 local_resume_contract_audit.py        # -> resume-contract-audit.json

# flights (shared GPU lock, foreground)
python3 /Users/muadhsambul/RL/results/mimo-learning-next/run_locked.py -- \
  ./build/omp-task-contract/metal_nav_waypoint local-eval \
  /Users/muadhsambul/RL/assets/checkpoints/local-waypoint-fast-experimental.bin.best \
  /Users/muadhsambul/RL/results/omp-task-contract/control-deva-fast-mode17.csv \
  --spec dev-a --mode 17
python3 /Users/muadhsambul/RL/results/mimo-learning-next/run_locked.py -- sh -c \
  './build/omp-task-contract/local_contract_probe contract-flight <ckpt> \
   <out>/source-policy --bank results/omp-local-waypoints/banks/source.bin \
   --mode 17 --controller policy --envs 128 --ticks 3200 --trace-envs 8'
# ... source-blind (--mode 2 --controller blind), source-hover (--controller hover)

# analysis
python3 local_flight_evidence.py
python3 local_reward_ordering.py
```

Receipts: every flight run writes `<out>-summary.json` with runner/core/
checkpoint/bank hashes, episode counts, ray error and formula error; binaries
`build/omp-task-contract/{metal_nav_waypoint,local_contract_probe,local_step_contract_check}`
were built from root sources with `-DSOURCE_DIR=/Users/muadhsambul/RL
-DFIXED_PPO_ACTOR_OBS_DIM=184 -DNAV_SENSOR_PROFILE=1`. All GPU work ran
foreground under `run_locked.py` on `results/metal-training.lock`; no
orphan jobs.

## 10b. Public evidence bundle (root-reviewable, tracked paths)

`results/` is gitignored; the canonical publication copies live at
**`evidence/inputs/local-contract/`** (9 files):

| file | content |
|---|---|
| `manifest.json` | scoped claims, exact build/run commands, dependencies with source/checkpoint/bank hashes, fault-injection evidence, record index |
| `verifiers/local_contract_audit.py` | bank invariants/denominators/exclusions (coordinator-verified: clean PASS + 6/6 injected faults caught) |
| `verifiers/local_step_contract_check.mm` | executable step-contract assertions (36/36) |
| `verifiers/local_contract_probe.mm` | full-TRAIN flight probe (rewards, visibility, braking capture) |
| `verifiers/local_flight_evidence.py` | visibility cross-check + warning/grounding/braking analysis |
| `verifiers/local_reward_ordering.py` | reward ordering with per-flight/class-mean scope labels |
| `verifiers/local_resume_contract_audit.py` | resume/provenance fault injection (9/9) |
| `verifiers/verifier_fault_selftest.py` | 4/4 fault rejections for the two analysis verifiers |
| `records.tar.gz` | all underlying records (47 members: bank-invariants, pretraining-record, task-axes, step-contract, reward-ordering, warning-evidence, braking-arrival, visibility-crosscheck, resume-contract-audit, fault-selftest, per-flight episodes/summaries/traces, control eval, dev-c predeclaration) |

`records.tar.gz` sha256 `281fd7d6b44a148acacf43a26d94a5e5574114e9006ee4779470578a34f6220a`.
Every record this document cites is a member of that archive; the manifest
maps claims to members. Python verifiers use the standard library only; the
two `.mm` probes build with the clang line recorded in the manifest and read
the published root sources at the hashes recorded there. Publication/
committing is Root's step; the bundle was staged for review, not pushed.

## 11. Pending, deliberately not claimed

- **Independent tests of the learner's new interface** (`local-teacher`,
  `local-bc`, dev-c bank): not yet available on disk; will be tested against
  physical-teacher behaviour, dataset provenance, action-likelihood/GAE
  numerics, resume contracts — not by mirroring their own tests — once
  published.
- **Local Webots transfer matrix**: waits for a NEW frozen source candidate
  plus contract verification; it will be predeclared from unseen DEV tasks
  with fixed frozen controls and marked development transfer, never a blind
  final. Nothing was fabricated in advance.
- No claim about training improvement: this mission ran no training and
  promoted no weights.
