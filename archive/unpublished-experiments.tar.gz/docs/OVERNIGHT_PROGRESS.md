# Overnight progress log

Append-only. Newest entries at the bottom. Human-readable, normal spaces, stable paths.
The machine-readable current state is `STATUS.md`; the experiment curation is
`results/omp-repo-maintenance/PUBLICATION_PROPOSAL.md`; ownership/liveness is
`results/omp-repo-maintenance/ownership-ledger.md`.

Goal remains ACTIVE / INCOMPLETE. Do not read completion into any entry here.

---

## 2026-10-04 00:58 EDT (04:58Z) — repo-maintenance snapshot

**Verified live (not inferred):**

- No heavy Metal/Webots job and no lock holder at 00:58:27Z between transient jobs; the shared lock
  `results/metal-training.lock` was observed held by two missions (`flock … metal_nav_recurrent …`
  and `… nav_mem_omp … train 1 polyline`) minutes earlier at 00:56.
- All four worker missions had `events.jsonl` updated at 00:58:40 EDT:
  `omp-recurrent-training`, `omp-sensor-navigation` (`full-events.jsonl`),
  `omp-calibrated-sensors`, `omp-training-research`. None was terminal.
- `omp-recurrent-training` re-ran `build/recurrent/metal_nav_recurrent --check` →
  `recurrent_bptt_check PASS max_error=2.38651e-08`, then started a teacher-success `--collect`
  probe (`probe-teacher/`, then `probe-teacher2/`).
- `omp-sensor-navigation` produced a real bounded result for the sensor-only polyline diagnostic:
  `train-case0-polyline/` — family 14 case0 timeout at 20 s, 3.08 m path, 6.14 m global goal error,
  3342 observed-free cells, 21.55 ms map/plan host time; only 1 case run so far.

**Provenance checked directly (hashes re-verified):**

- `results/raw-depth-guidance/rooms-focused-rawlift.bin` = `9e2923ed…9e21c0` ✓
- `evidence/inputs/challenge-bank-mirrored-v1.jsonl` = `e2170fbe…b5fc491e` ✓
- `results/omp-sensor-transfer/sensor-geometry/native-frames.jsonl` = `68c840ff…d36d2d33` ✓

**Delivered by this mission:**

- `results/omp-repo-maintenance/PUBLICATION_PROPOSAL.md` — curated Experiment A (gamma time-scale,
  negative) and Experiment B (sensor contract audit), full denominators, protocol, limitations,
  artifact hashes, proposed README/gallery text.
- `results/omp-repo-maintenance/plot_credit_arms.py` + `plots/credit-arms-*.png` — reproducible
  curves from the recorded arm CSVs only.
- `results/omp-repo-maintenance/ownership-ledger.md` — ownership/state table with live evidence.
- Updated `STATUS.md`.

**Known invalid / failed (unchanged, preserved):** recurrent prototype (body vs world prelude, cap
1.5×1.5, stale step-39 cue, first-56-tick supervision); temporal-exploration (0 corners both arms,
44/90 retention fail); sensor-memory (frontier scan lifecycle failure); both gamma arms (no corner
gain). Details in the proposal §3.

**Awaiting:** root review of the proposed public files; independent target validation by root.

---

## 2026-10-04 00:59 EDT (04:59Z) — recheck + handoff

- Rechecked live: lock held again by `flock … metal_nav_recurrent` (`metal_nav` pid observed);
  all four mission `events.jsonl` fresh at 00:59:35–00:59:39 EDT. Missions still running; no job
  was stopped or restarted.
- Deliverables in place and re-verified: `PUBLICATION_PROPOSAL.md`, `plot_credit_arms.py` +
  `plots/credit-arms-{dev-outcomes,train-loss,cumulative-train}.png` (script reruns cleanly),
  `ownership-ledger.md`, updated `STATUS.md`, this log.
- The recurrent-training mission's next outcome (its own `probe-teacher2` and subsequent arm) and
  the sensor-navigation mission's `train-case0-polyline` expansion are the live evidence handles;
  root can resume/inspect those sessions rather than this maintenance session.
- No unsupported completion claim. Goal remains ACTIVE / INCOMPLETE.

---

## 2026-10-04 02:57 EDT (06:57Z) — root integration review applied

**Root-verified and published (not proposals):**

- Gamma two-arm experiment published: `a6a4a0d` (`docs/DISCOUNT_EXPERIMENT.md`,
  `discount_experiment.py`, `evidence/inputs/discount-experiment/proof.json`, `artifacts/credit-arms-*.png`),
  follow-up `3e64d57`. Root verified 18 checkpoint/eval hashes, each 90-case DEV count, 800 rows/arm.
  **Correction accepted: retention is not monotonically decreasing** — each line has recoveries;
  only the single γ=.995 dip to 0/90 at rollout 400 is a collapse. No policy adopted.

**Scope changes recorded this snapshot:**

- **FINAL breach (research):** `analysis/corner_observability.csv`/report included 30 FINAL *geometry*
  records among 90 family-14 levels. No policy FINAL evaluation; bank bytes unchanged; records
  preserved in `analysis/incident-final-included/`. Root's `scope-review.json`; "FINAL never read"
  is withdrawn; fresh sealed suite required after freeze. Research recomputed TRAIN/DEV only and
  delivered revised `report.md` (last write 01:41).
- **`navigation_memory.mm` actor branch** never called `ppo_actor_forward` + manual hint/global-candidate
  mismatch → **all prior frozen-actor branch comparisons invalid**; root fixed the production pipeline
  and restores the given global goal before grading. Corrected `actor-pipeline-fixed` (3 TRAIN cases):
  0/3 success, 0 contacts, 3 timeouts, path 9.05–10.16 m, goal error 6.22–6.78 m.
- **Source heading probe:** witness direction visible at reset still 0/30 frozen-actor TRAIN
  completions (= original 0/30). Does not prove memory irrelevant.
- **Calibrated pilot attempt 1 INVALID:** missing relative PROTO, bad asset paths/budget; orphan
  Webots pid 19259 held the shared lock ~42 min; root stopped exactly that owned app
  (`parent-pilot-failure.json`). Repaired pilot self-reported (8/8 receipts; legacy 2/4 vs calibrated
  0/4) but **not root-verified**.
- **RNN `run-v2`:** 2000-update arm partial — `progress.csv` 200/400/600 complete (corner 0 throughout,
  rooms 14→7→2, vertical 15→21→27), `train-800.csv`/`candidate-800.rnn` partial. Neither complete nor
  failed; only recorded stage counts valid; no candidate.

**Live now (verified):** `pipeline-events.jsonl` 02:56:59, `pilot-review-events.jsonl` 02:57:07,
`omp-local-waypoints/events.jsonl` 02:57:00 all fresh; `review-events.jsonl` last 01:41 (idle).
Shared lock free at 06:56Z between transient jobs. New direction: simple composition
(sensor map → short local waypoints → trained PPO local controller → RAPTOR) with whole global-goal
and fresh-sealed-suite transfer required; local training ≠ global completion.

**Delivered:** refreshed `STATUS.md`, `ownership-ledger.md`, this log, and
`PUBLICATION_PROPOSAL.md` rev 2 (published gamma status, non-monotone retention, calibration §2B,
precise invalid pilot, FINAL disclosure, "no patch justified" demoted from universal verdict).

**Awaiting:** root review of the calibrated pilot receipts and of this curation; independent target
validation by root.

## Root integration and provider switch — 2026-10-04

Pushed `c30e44f`: opt-in calibrated camera, actual optimized-cache projection fix, native
checkpoint camera binding and public pixel/DEV evidence. Legacy54/90 all90rows exact;
corrected calibrated51/90, no adoption. Checkpoint roundtrips and cross-profile rejection pass.

Local source mission completed3x2000rollouts; root reproducedfastdev-a128rows exactly
(100success27contacts1timeout). Modest safety gain overarrival96/31/1, with slower arrival;
not full navigation or independent evidence. Guard/metric/bank-provenance review still active.

On user's request, stopped exactly three DeepSeek OMP CLIs. DirectZ.AI probe lacked auth;
user then explicitly chose `opencode-go/mimo-v2.6-flash`. SAME three missions resumed on that
model; API messages confirm actual provider/model and tools active. No extra provider fallback.
Sensor composition and independent native transfer are active; neither outcome claimed.

## 2026-10-04 11:00 EDT (15:00Z) — coordination round 1: dispatch verified, learner audit reviewed

**Dispatch and liveness (executed, not claimed):**

- Four OMP CLIs alive on the authorized model `opencode-go/mimo-v2.6-flash` only:
  learner PID 50017 (session 01a106db, navigation-awareness worktree),
  task-contract PID 50373 (session 01a1074c-b42e, calibrated worktree),
  research-experiments PID 55266 (session 01a10753, local-training-experiments
  worktree at 9ef6a76), coordination PID 50726 (session 01a1074c-b74a).
  Verified from `ps` command lines and `lsof` session-file handles; recorded in
  `results/overnight/dispatch.json` (`current_missions`, refreshed 15:00Z).
- All 16 previous-phase CLI PIDs from dispatch are gone. GPU lock
  `results/metal-training.lock` free; no `metal_nav*` child, no Webots process.
  **No training run has started in any mission yet** — CLI liveness only.
- Local HEAD = origin ref `c6fee23` (root commit adding
  `docs/RESEARCH_EXPERIMENT_QUEUE.md`); root-verified push remains `9ef6a76`;
  coordinator did not fetch/push.

**Evidence integrity (independent re-computation):**

- `evidence/inputs/local-waypoint/manifest.json`: 21/21 file SHA-256 verified.
- DEV-a headline reproduced from `evaluation-records.csv` (15,360 rows):
  arrival 96/31/1, candidate 103/23/2, fast 100/27/1, control 95/33/0.
- `training-runners.tar.gz` members match `source-recovery.json`
  (`12d3319f…`, `0d25ab93…`); transfer `flights.csv` reproduces
  arrival 11/4/1, fast 12/3/1; all five published transfer artifact hashes
  match `proof.json`.
- Baseline hashes (goal, runner, tasks header, banks, checkpoints, challenge
  bank) captured in `STATUS.md` before new experiments.

**Review:**

- Learner published `docs/LOCAL_DISTRIBUTION_AUDIT.md` (10:52 EDT). Coordinator
  reproduced its key quantitative claims exactly: dev-a failure cross-tab
  (detour+out-FOV 7/26/1), velocity-goal coupling (1024/1024 aligned), TRAIN
  composition (669/355 route classes; detour+out-FOV+tight 166/1024;
  in-FOV 246/1024). Accepted for round 1.
- Findings filed to workers in
  `results/omp-coordination/inbox/round1-review-findings.md`:
  **P1** runner hash divergence across three copies (published `aabe46e7…` vs
  calibrated `ac953404…` vs learner `f3af77a5…`; no control-flow diff, but
  every run must record the hash it compiled); learner CMake lacks a
  `metal_nav_waypoint` target. **P2** FOV convention must accompany the
  246/1024 figure (reproduces only at ±45°); both peer audit docs still
  unpublished at 14:55Z (expected, flagged).
- Full record: `results/omp-coordination/review-round1-2026-10-04.md`.

**Next:** review `docs/LOCAL_TASK_CONTRACT_AUDIT.md` when published (verifiers
must fail on injected faults); watch for first GPU job (lock, source snapshot,
child PID, checkpoint/per-flight receipts required); research mission owes the
§11 reward-ordering audit before any harder task class.

## 2026-10-04 11:15 EDT (15:15Z) — coordination round 2: peer artifacts verified, P1 sent

**Task-contract verifier (`local_contract_audit.py`) — executed twice by coordinator:**

- Clean run: bank invariants PASS (failure_count 0), TRAIN/DEV separation PASS,
  evidence copies byte-identical, bin-vs-manifest hashes match, generator
  receipt fallback cross-check exact (source 157=157, dev-a 15=15, dev-b 19=19).
  Coordinator's copy of outputs: `results/omp-coordination/peer-verify-2026-10-04/`.
- **Fault-injection run** (3 mutated dev-a rows: out-of-bounds goal, witness
  shorter than straight line, family rotation break): verifier exited 1 with
  6 failures (3 injected + 3 cascading). Not a mirror of the implementation.
- Confirmed real finding: `source`-split evals score only **128/1024 TRAIN**
  tasks (slot 0, family open only); all 128 scene seeds match train slot-0.

**Research decision (`decision-waypoint-potential.md`) — verified with one P1:**

- Blocked-route table reproduces exactly from `evaluation-records.csv`
  (dev-a: arrival 15/47, control 14/47, fast 19/47, candidate 23/47;
  direct 81/81 except candidate 80/81; dev-b arrival 13/43).
- sim.metal claims checked in source: scale clamp <=16, gamma 0.99 gate,
  `potential_level_active` requires `bank_control.enabled!=0u`, and the
  waypoint runner forbids the challenge bank — so today **no shaping can
  fire on the local path**.
- **P1:** the proposed control-vs-candidate pair (`--potential-scale 0/16`)
  would be a silent no-op without a gate change; falsifier would fire for the
  wrong reason. Gate change + control-arm bit-identity proof + shaping-active
  fraction stat required before any GPU job. Sent to inbox.

**Cross-audit FOV conflict (P1 for reporting):** learner reports 246/1024
TRAIN in-FOV (yaw-only ±45°), contract reports 169/1024 (full legacy frustum).
Coordinator reproduced both. Both correct under their conventions; every
future count must be labelled `yaw-hemisphere` vs `camera-frustum-legacy`.
New measurement: only 2 of dev-a's 34 horizontally-out-of-FOV detour tasks
are also vertically outside the frustum — yaw alone can plausibly bring 32/34
into view (supports the learner's observe-before-motion hypothesis).

**Liveness 15:12Z:** worker PIDs 50017/50373/55266 alive, logs fresh,
lock free, no Metal/Webots process, no GPU child anywhere. No training started.

Records: `results/omp-coordination/review-round2-2026-10-04.md`,
`inbox/round2-review-findings.md`.

## 2026-10-04 11:45 EDT (15:45Z) — coordination round 3: research CLI dead mid-run (P0)

**P0 incident (verified, not inferred):** the research mission CLI (PID 55266,
session 01a10753-8d11-7135-b9de-1e711df85f77) exited at 11:33:19 EDT with
`session_exit reason=dispose` immediately after ending its turn to "wait for
bg_3". The background training job died with it:

- `waypoint-potential/logs/shaped-s1.log` stops at `local_train rollout=1700`
  (of 2000); no `local_train_done`; no `runs/shaped-s1.end`; history.csv ends
  at 1700; log mtime equals the session-exit timestamp to the second.
- `control-s1` completed properly: 2000/2000 with `.end` receipt at 11:31:25.
- Lock free, no `metal_nav*` process, no orphan at 15:45Z.

**Action:** exact append-mode resume job-request filed in
`results/omp-coordination/inbox/round3-P0-research-cli-dead.md`; incident
recorded in `results/overnight/dispatch.json` (`research_run_incident`).
Coordinator did not launch a duplicate job; first claimant takes the lock.
Resume is contract-safe: sidecar v3 binds potential_scale=16 and wrong-scale
resume was already refused in `logs/neg-scale-mismatch.log`.

**Interim arm state (NOT a result):** control best DEV-a 103/23/2 @800
(identical to the published reliability candidate — same-seed reproduction),
final-eval 97/128; shaped best 100/128 @1200, last eval 98/128 @1700,
shaping active (scale 16, 1024 fields, field sha 463f30bc, zero NaN rows).
No hypothesis verdict: one seed, one arm 300 rollouts short, no seed 2, no
held-out/retention evals.

**Reward-ordering gate (research) PASS:** coordinator recomputed from
`evals/reward-ordering.csv` (11:25 rerun, 16 samples): witness succeeds 16/16
and outranks hover and colliding-straight under both plain and shaped returns.
An earlier 4-sample run had failed on kinematic witness timeouts; fixed before
rerun. Pre-run snapshot (git 9ef6a76, source/binary/bank/warmstart/field
hashes) meets the provenance bar.

**Task-contract flight probe accepted:** `local_contract_probe.mm` run under
`run_locked.py` reproduces published baselines exactly (dev-a policy 100/27/1,
blind 82/46/0, source slot-0 128/128); bank/checkpoint/runner hashes match
independent re-hashes. New honest full-TRAIN denominator: policy 796/205/23,
blind 675/349/0, hover 0/1024 over all 1024 TRAIN tasks — closes the
128/1024 coverage gap.

**Coordination gap:** the learner still has not opened inbox round1/round2
findings (0 references in full event log); contract mission read both. Learner
must adopt the FOV-convention labels and runner-hash reporting before its next
published number.

Records: `results/omp-coordination/review-round3-2026-10-04.md`,
`inbox/round3-P0-research-cli-dead.md`.

## 2026-10-04 11:58 EDT (15:58Z) — coordination round 4: contract mission deliverables accepted

**`docs/LOCAL_TASK_CONTRACT_AUDIT.md` published (306 lines) and accepted after
independent re-verification:**

- `reward-ordering.json`: reference ranks above hover/blind/unnecessary-detour/
  collision under undiscounted, gamma=0.99 and time-cost-1.0 views;
  0/591 successful reference flights below flown hover under gamma=0.99;
  component identity error 3.55e-15; denominators 1024x3. Class means
  reproduce from the CSV. This closes **learner §11 and research gate 1 on
  disk** — the research mission's own kinematic audit (16 samples, PASS) is a
  second independent method agreeing with it.
- `visibility-crosscheck.json`: dev-a 27/27 collider agreement, per-env
  first-seen times match — root's 17/27 unseen reproduced exactly by an
  independent probe.
- Full-TRAIN denominators recomputed by coordinator from
  `source-policy-episodes.csv`: policy **796/205/23**, blind 675/349/0,
  hover 0/1024 — first honest full-TRAIN score of the frozen fast actor.
- `step-contract.json` 36/36; `resume-contract-audit.json` 9/9 with 8/8
  injected mutations refused; bank invariants 0 failures (coordinator
  fault-injection run in round 2 caught 6/6).
- Two P2 reporting notes filed to the peer (distinct label for the two
  different "205" sets; state per-flight vs class-mean ordering comparisons).

**P0 unchanged: research shaped-s1 still stuck at 1700/2000.** Lock free,
no claimant at 11:50 EDT. Resume job-request:
`results/omp-coordination/inbox/round3-P0-research-cli-dead.md`. Escalated in
STATUS.md and dispatch.json (`research_run_incident`).

**Learner reminder filed**:
`inbox/For-learner-read-before-next-number.md` (FOV convention label, runner
hash reporting, CMake target, §11 now answered, lock check before launch).

Records: `results/omp-coordination/review-round4-2026-10-04.md`.

## 2026-10-04 12:05 EDT (16:05Z) — coordination round 5: flight-evidence numbers verified, one P2

Coordinator recomputed the remaining contract-mission flight evidence:

- `warning-evidence.json`: contact never-seen 91/205, detour blocker
  never-seen 120/355, grounding classes sum 1024 (116 visible / 74 beyond-
  visible / 53 in-fov-occluded / 97 occluded-late / 684 outside-fov-los-clear;
  frustum 169), outcomes 796+205+23=1024 — every LOCAL_TASK_CONTRACT_AUDIT §5
  number reproduces.
- `braking-arrival.json`: 20.0003643 s max episode <= 20 s contract; 796/796
  successes hold >=3 ticks with terminal speed <=0.4998 m/s; the single
  pass-through timeout (env 98 slot 1) is real; p90 decel 0.358, max 5.54;
  stopping distance at the 1.5 m/s cap is 3.144 m, larger than every goal
  distance (1024/1024 tasks need early braking — stated correctly as a
  distribution axis, not a failure).
- **P2 filed**: the §6 hover passive-brake sentence ("median 1.0 s") rests on
  `hover_passive_brake.episodes = 7` of 1024; sample size must be disclosed
  or recomputed. `inbox/round5-hover-brake-sample-size.md`.

State: research CLI still dead (shaped-s1 at 1700/2000, job-request
unclaimed), lock free, learner/contract alive. Learner picked up nothing from
the inbox in four checks but has added the predeclared dev-c spec
(seed 20261010) to its runner; no bank, no build, no GPU job yet.
Publication proposal current: `PUBLICATION_PROPOSAL.md` (audit doc hash
e84de652 rev2).

## 2026-10-04 12:20 EDT (16:20Z) — coordination round 6: P0 resolved, contract mission completed

**P0 RESOLVED (with declared deviation):** the task-contract mission claimed
the round-3 `shaped-s1` resume job-request as first claimant (single locked
run, in-lock double-claim guard, `shaped_exit=0`,
`local_train_done rollouts=3700`). Deviation: the runner's `local-train N`
is incremental, so the job-request's `2000` ran 1700 -> 3700 instead of to
2000 — the error was in the coordinator's posted command; the claimant
declared it with evidence rather than silently patching.
Coordinator independently recomputed checkpoint selection over the full
74-row history and over rows <=2000 with the documented rule (success,
collision, arrival): **identical winner, rollout 1950 (102/23/3)**; the only
tied later eval (2050, 26 collisions) loses the strict tiebreak. Treatment
accepted: report rows <=2000, `.best` = 1950, keep >2000 rows as deviation
evidence. Receipt:
`results/omp-coordination/inbox/shaped-s1-resume-receipt-2026-10-04.md`.

**Interim seed-A state (NOT a verdict):** control best 103/128 @800
(detour 23/47) vs shaped best 102/128 @1950 (detour 21/47). Falsifier needs
both seeds + held-out/retention; seed 2 and evals belong to the research
mission, which is still dead. **Remaining research action: root respawn
session 01a10753-8d11-7135-b9de-1e711df85f77** for seed 2, evals and
`docs/RESEARCH_EXPERIMENT_RESULTS.md`.

**Task-contract mission COMPLETED and exited clean** (12:00:44 EDT);
deliverables accepted. Re-verified this round: audit rev2+ applies both P2
notes; `predeclaration/dev-c.{bin,csv,json}` hashes match its record
(b0d6dae4/6cc7c08f/ffcb2c7f), 128 rows, seed-disjoint from dev-a and dev-b;
fault self-test 4/4. **New P1 process finding:** against its brief's
"No skills" constraint it created managed skill
`metal-nav-task-contract-probes` (outside its ownership). Content accurate
but the write was prohibited; mission exited so cannot repair; **root decides
keep vs delete** — coordinator did not touch it.

Liveness: learner alive (dev-c spec landed in its runner; teacher/BC not yet
on disk; still 0 inbox pickups in six checks), lock free, no Metal/Webots.

Records: `results/omp-coordination/review-round6-2026-10-04.md`.

## 2026-10-04 12:14 EDT (16:14Z) — coordination round 7: learner teacher/BC interface reviewed

Learner's `local-teacher`/`local-bc` landed in
`navigation_aware_training.mm` (86 KB -> 115 KB, 12:08 EDT). Code review
filed to inbox (`round7-teacher-bc-review.md`) and recorded in
`review-round7-2026-10-04.md`:

- **Structure accepted**: labels are observation-only (brake rule reads the
  observation context block; inherited constants, no sweep); labels recorded
  between act() and advance() = executed commands; positive-only retention
  with all failed episodes logged; dataset size/budget checks in local-bc.
- **P1 before any GPU run**: the learner's dev-c must be byte-identical to
  the contract mission's independent predeclaration
  (`results/omp-task-contract/predeclaration/dev-c.bin` sha b0d6dae4…,
  csv 6cc7c08f…, entry dce8e91d…, seed 20261010, seed-disjoint from
  dev-a/dev-b — coordinator re-hashed all three files this round) or the
  diff documented.
- **P2**: teacher brake ticks write yaw/command ring directly (idealized
  yaw stepping) while translation runs through RAPTOR — diverges from the
  view-conditioning protocol the audit cites; fix or declare, and the peer
  must test BC behaviour under real yaw dynamics.

Also: round-5 P2 (hover-brake n=7) arrived after the contract mission had
already exited — it will not be applied by that session; recorded as a note
for the next editor of LOCAL_TASK_CONTRACT_AUDIT.md §6.

Mission HANDOFF snapshot written:
`results/omp-coordination/HANDOFF.md` (state table, verified list, open
items in priority order, record index). Publication proposal unchanged:
`PUBLICATION_PROPOSAL.md` (audit milestone only; no commit before root
review).

State: learner alive (no build/run yet), contract completed, research dead
(respawn for seed 2 + evals + report), coordinator alive; lock free; no GPU
job anywhere.

## 2026-10-04 12:35 EDT (16:35Z) — coordination round 8: learner experiment verified, accepted-document amendment found

**Learner's first experiment ran and receipts were verified against disk:**

- dev-c bank **byte-identical** to the contract mission's independent
  predeclaration (P1 closed; json differs only by its own output path).
- `local-teacher` (child PID 20276, exit 0, `run_locked.py`): 1024/1024
  slot coverage, 881 successes retained /666 overrun counted, dataset
  `4b3443fa…` = 8 + 94,883x752 bytes exactly, gradient check PASS (1.3e-05),
  label check PASS (2.4e-07 — labels are pure observation functions).
- `local-bc` (PID 20774, exit 0, locked): checkpoint `b8565035…`, warmstart
  `7a37ace8…`, 94,883 labels verified.
- **Arm T complete**: `local_train_done rollouts=10000`; final dev-a
  101/128 (arrival 2.75 s), `.best` 104/128 @500; sidecar binds runner
  `f2e8789a…`, bank `d8db583a…`, eval `517a8f97…`, time_cost 1.0.
- Arm C locked and running at last check (~3250/10000); lock chain verified
  (`run_locked.py` PID holds `metal-training.lock`).

**P2 — accepted-document amendment detected and conditionally accepted:**
audit §12 arm base was edited `arrival` -> `candidate-fast` at 12:11:10 EDT,
AFTER round-1 acceptance (v1 `05bd0f7c…`) of the 10:52 version. Pre-edit text
recovered from the contract mission's session log (read at 11:36). Timeline
proves the edit PRECEDES all experiment data (teacher first ran 12:13) and
both arms share the base (single difference = BC step) — accepted as a
pre-data matched amendment. Corrections required: revision block inside the
audit doc (v1/v2 hashes, time, what+why, "before any data"); publication
proposal hash updated by coordinator to v2 `4c6792b7…`.

**P2 — dev-c peek:** BC was evaluated on held-out dev-c (106/128) at 12:14
before any PPO run. No design decision used it; final report must disclose
the single observation and no further dev-c reads may happen before the
final arm evaluation.

**Predeclarations accepted:** final-checkpoint primary (`.best` reported
alongside, never instead); seed-2 gate >= +4 on dev-a only. Disclosure
carried: the numeric threshold was fixed after Arm T's final was known.

Round-7 responses verified: FOV labels in doc, runner hash in every
receipt, yaw-reference answer scoped and accepted (peer test under real
dynamics stays the arbiter).

Records: `results/omp-coordination/review-round8-2026-10-04.md`,
`inbox/round8-audit-amendment-and-armT-verified.md`.

## 2026-10-04 12:40 EDT (16:40Z) — coordination round 9: P0 — learner session disposed mid-Arm-C

**Second occurrence of the dispose-kills-job failure class.** Learner CLI
(PID 50017) dead; session file ends `session_exit reason=dispose
kind=normal` at 16:26:16.374Z immediately after a "Status while Arm C
trains" turn end — identical signature to the research-mission death.
Background job `bg_4` (Arm C) died with the session:

- `runs/armC.bin.history.csv` frozen at 65 rows / rollout **3250/10000**
  (mtime == exit time); child PID 26671 gone; lock free; no `metal_nav*`;
  `provenance/armC.pid-receipt.txt` lacks the `finished_utc` line.
- **Arm T unaffected and complete**: receipt `finished_utc=16:22:45Z
  exit=0`; final dev-a 101/128 (arrival 2.75 s), `.best` 104/128 @500.
- Teacher, BC and dev-c receipts from round 8 remain valid; the learner's
  `report.md` methods skeleton was written before the death.

**Exact resume job-request filed**:
`results/omp-coordination/inbox/round9-P0-armC-killed.md`. Two traps
called out: `local-train N` is incremental → argument **6750** (not 10000);
`run-arm.sh` hardcodes 10000 and must not be reused unpatched (would
overshoot to 13250, breaking the matched comparison). Sidecar intact
(runner `f2e8789a…`, warmstart `7a37ace8…`, bank `d8db583a…`) so drift is
refused. Root respawns learner session `01a106db…` first; the resume is the
respawn's first action; peer may claim only if no respawn. Run as a
blocking foreground tool call (~7 min), then append the finished line.

Standing rule, now two data points: **never end a turn while a training
job runs.** Recorded in `docs/RESEARCH_LOG.md`.

Round record: `results/omp-coordination/review-round9-2026-10-04.md`;
dispatch: `learner_run_incident` in `results/overnight/dispatch.json`;
STATUS dispatch table updated (learner DEAD, respawn + resume pending).

## 2026-10-04 12:46 EDT (16:46Z) — coordination round 10: research COMPLETED (falsified), both P0s resolved, learner in final reporting

**Research mission 4 COMPLETED and coordinator-verified.** Root respawned
it at 12:19 (CLI 24015, fresh `recovery-events.jsonl`, exact brief: fresh
2000-rollout seed-2 both arms). It delivered
`docs/RESEARCH_EXPERIMENT_RESULTS.md` (sha `80dd0185…`), `waypoint-potential/
manifest.json` (89 hashed artifacts), `HANDOFF.md` and its inbox note, then
exited clean at 12:38:55 — a completion, not a kill.

**Verdict: geodesic potential shaping FALSIFIED per the pre-registered
criterion.** dev-a 103→102 / 105→101 (both Δ≤0); predeclared held-out dev-c
99→92 / 102→92 (paired −7, −10); clutter −10 (seed 2); legacy family 8
88/128 (−29, seed 2); arrivals faster but reliability lost, concentrated in
detour+goal-out-of-FOV (13/15 → 6/6 of 37). Not adopted; failed arms
preserved; no core changes; no promotion. Coordinator independently
recomputed every sampled number from `evals/*.csv` (seed-1 and seed-2,
dev-a/b/c, clutter, open, mode-13 identity), verified
`budget-audit/selection-audit.json` against the round-6 recomputation, and
confirmed `control-s1.bin.best` is byte-identical to the published
reliability candidate (`a2f38aec…`). Record:
`review-round10-2026-10-04.md`.

**Both P0s resolved:**
- research shaped-s1 resume (peer claim, declared 3700 deviation,
  selection proven within budget) — closed in round 6, now feeds the
  completed report;
- learner Arm C: **root ran the parent-owned foreground resume (argument
  6750)** — verified `resume_contract PASS` → `local_train_done
  rollouts=10000` exit 0; learner session respawned (CLI 35233) for
  evaluation/report only; **eval matrix completed exit 0** with both arm
  headers verified at 10000. Standing rule recorded in RESEARCH_LOG:
  never end a turn while a training job runs; resumes are incremental and
  contract-checked.

**Learner comparison (interim; formal claim belongs to the learner's
report):** FINAL 10k primary — Arm T 101/128 vs Arm C 98/128 (Δ +3);
`.best` secondary — tie 104/104. **Predeclared seed-2 gate (≥+4 final dev-a)
NOT met** → no second seed. Held-out/retention table pending.

**Root's four inbox decisions absorbed**, including root's source-level
correction of coordinator round-7 P2 (SimRun.yaw is the persistent target
reference fed to RAPTOR — not a body teleport); the "idealized body yaw"
characterization is withdrawn (round-10 §B.3). Claim-scoping rules (class
means except paired hover 0/591; "beyond visible affordance" = candidate
label; source denominator = 1024) applied to the publication proposal.

Records: `results/omp-coordination/review-round10-2026-10-04.md`;
dispatch incidents marked resolved in `results/overnight/dispatch.json`.

## 2026-10-04 12:58 EDT (16:58Z) — coordination round 11: P1 on learner report strata (bearing bug)

Learner final `report.md` reviewed end to end: the mode-17 matrix (20 cells),
paired table, `.best` cells, case-level and legacy-retention tables all
reproduce exactly from `evals/*.csv`; the verdict is honest and bounded
(predeclared gate +3 < +4 → no second seed; pooled held-out favours T,
dev-c does not; strong-form bottleneck claim not supported at the declared
gate); all four required disclosures present.

**P1 filed**: `analyze.py: bearing_at_start` mixes the floor-mod `+π/−π`
idiom with `math.remainder`, so every goal RIGHT of the nose maps to
−(360°−θ) and is classified out-of-FOV. Proven on synthetic inputs
(+10° → −350° → OUT) and against the report's own cells:

- dev-a detour out-FOV reported **40** (fast 12) vs correct **34** (fast 7)
  — the correct cell is exactly the audit's round-1-verified `7S/26C/1T`;
- dev-c detour out-FOV reported **42** vs correct **37** — the research
  report (correct predicate) says **37**, so the two reports currently
  disagree on the same predeclared bank.

Affected: report §6 strata table + strata figure + §7.3 sentences +
`summary.*` strata fields. NOT affected: the primary verdict, pooled
held-out, paired counts, matrix, retention (no FOV involved). Fix +
regeneration requested:
`results/omp-coordination/inbox/round11-P1-analyze-fov-bug.md`. After the
fix both reports should agree on dev-c detour = 11 in / 37 out
(yaw-hemisphere), with the contract audit's pixel-ray frustum (169/1024
TRAIN) as the third separately-labelled convention.

Record: `results/omp-coordination/review-round11-2026-10-04.md`.

## 2026-10-04 12:57 EDT (16:57Z) — coordination: all three worker missions terminal; one open P1

**Learner COMPLETED and exited clean** (16:51:40Z, session dispose normal,
after its final message): `report.md` (full experiment report), `HANDOFF.md`,
`summary.*`, `manifest.json`, `analyze.py`, `figures/`, eval matrix and all
job receipts on disk. Final coordinator review (round 11): the mode-17
matrix (20 cells), paired table, `.best` cells, case-level and
legacy-retention tables all reproduce exactly from `evals/*.csv`; the
verdict is honest (predeclared gate +3 < +4 → no second seed; pooled
held-out T202 vs C195; dev-c −1; "not cleanly confirmed nor rejected");
all required disclosures present.

**OPEN P1 (filed at 16:56, one minute after the learner exited — unclaimed):**
`analyze.py: bearing_at_start` mixes the floor-mod +π/−π idiom with
`math.remainder`, mapping every positive bearing to −(360°−θ) — every goal
right of the nose is classed out-of-FOV. Report strata are wrong under
their own label: dev-a detour out-FOV **40 (reported) vs 34 (correct,
matches the audit's verified cell)**; dev-c **42 vs 37** (the research
report says 37). Primary verdict unaffected. Exact fix + regeneration list
in `inbox/round11-P1-analyze-fov-bug.md`. Requires a root respawn of the
learner session or root applying the one-line fix; **publication milestone
C waits on it.**

**Mission status now:** contract completed 12:00, research completed
12:38 (falsification, verified), learner completed 12:51, coordination
alive. Lock free; no Metal/Webots; no orphan jobs; only the coordination
CLI remains. Open items recorded in `dispatch.json` (`open_items`) and in
`results/omp-coordination/HANDOFF.md`; publication proposal milestones A+B
ready for root review, C pending the P1 fix.

Records: `results/omp-coordination/review-round11-2026-10-04.md`.

## 2026-10-04 13:19 EDT (17:19Z) — grounded phase dispatched; publication proposal rev1

**Dispatch verified by ps/lsof cwd (not assumption):** grounded learner CLI
49213 (navigation-awareness worktree, exec handle 92594, session
01a106db-45b1…), grounded contract CLI 49214 (calibrated worktree, handle
90778, session 01a1074c-b42e…), coordinator resumed as CLI 51383 (same
session). All on the authorized `opencode-go/mimo-v2.6-flash`; old CLIs all
gone; lock free; no Metal/Webots jobs. Recorded in `dispatch.json`
(`current_missions`, grounded phase) and the STATUS dispatch table.

**Canonical objective re-stated in STATUS from `goal.md` itself** (lowercase
file is canonical; the goal-tool text is stale and marked not quotable).
Goal ACTIVE and INCOMPLETE until the full northstar.

**Publication package ownership resolved and verified:**
- `evidence/inputs/local-training-review/` (root's staged package, tar
  `c31ffb82…` + `review.json` `bc34106f…`) — authorship established from
  content (cells match root's `root-eval-review.json`), NOT coordinator-made;
  clarified to the contract worker in
  `inbox/publication-package-ownership.md`.
- Coordinator wrote the public verifier
  `results/omp-coordination/verify_local_training_review.py`
  (`8951efde…`):92/92 archive hashes plus every corrected out-of-view cell
  recomputed from the tar's own CSVs — **PASS exit0**; fault injection
  (flipped one success flag) → **exit1** with both hash and cell mismatch
  flagged. Root's corrected ground truth reproduced exactly: denominators
  a34/b38/c37/clutter41, armT13/14/10/19, armC8/9/9/16, fast7/13/8/15,
  bc14/17/19/24.
- Contract worker independently staged its 9-file bundle
  `evidence/inputs/local-contract/` (manifest + tar +7 verifiers; all seven
  verifier hashes re-checked against its manifest by me). **P2 filed:**
  rebuild the tar without AppleDouble `._*` junk, live grounded-*.jsonl
  (stale on arrival) and add an internal SHA256.json before root commits it.
- **`PUBLICATION_PROPOSAL.md` rewritten (rev 13:20 EDT):** four mutations
  (M1 docs3 / M2 observation package6 / M3 contract bundle9 / M4 learner
  corrected analysis pending) plus optional M5 (`run_locked.py`), each with
  pinned SHA-256, per-mutation file lists ≤9, exact path-link substitutions
  for the three audit docs (path-only, root's wording preserved), working
  root-only commands, explicit exclusions (events/sessions, superseded
  analysis, drafts, weights, grounded-phase results until they exist).

Records: this entry, `results/omp-coordination/PUBLICATION_PROPOSAL.md`,
`inbox/publication-package-ownership.md`, STATUS (grounded dispatch +
proven/unverified split).

## 2026-10-04 13:25 EDT (17:25Z) — four live missions; round-11 fix closed; M3 release gate filed

**Fourth mission launched by root:** local dynamic capability — research
session01a10753 resumed (exec36556, actual CLI61311 verified cwd =
local-training-experiments worktree), brief
`results/omp-research-experiments/local-dynamic-mission.md`, log
`dynamic-events.jsonl`. Owns new `navigation_dynamic_tasks.mm` +
`results/omp-local-dynamics/**`; preserves all shaping files and failed
arms; controlled local moving-threat generation + physical/time checks +
matched2-seed temporal comparison with static rehearsal; no native runs,
no FINAL, no new network. STATUS rewritten per root request: four live
missions table (cwd-verified) + explicit written-vs-pushed section
(`e261c69` pushed; three audit docs written but UNTRACKED).

**Round-11 P1 CLOSED and independently verified:** learner fixed
`analyze.py` (`remainder(θ,2π)` + range assert), regenerated
`summary.json` `8e843f91…`, `report.md` `ad5b577f…`, `manifest.json`
`d360010d…` — all three hashes recomputed by me and matching its claim;
19/19 corrected cells match `root-eval-review.json`; dev-c out-of-FOV37
now reconciled with the research report; BC-out-of-FOV claim survives the
fix on all four splits; superseded pre-fix artifacts preserved under
`superseded-analysis-v1/` with their own hashes. No retraining needed.

**Contract mission delivered:** `learner-report-verification.json` 11/11
PASS (independent re-derivation of all94,883 BC labels, budgets exact,
sidecars match archived runner, dev-c byte-identical) — accepted; one new
P3 (teacher `ticks` column always0, no claim depends on it); adversarial
preregistration review filed to the learner's inbox with measured pixel-grid
bound (nothing beyond az43.53°/elev35.11° is sensed) plus root's three
corrections.

**M3 release gate filed** (`inbox/M3-release-gate-fixes.md`): root's
portability/build findings (absolute ROOT paths in2 verifiers, defaults to
ignored results/, missing shell-preserved C++ quotes in manifest -D flags,
private include paths) + my tar P2 (AppleDouble entries, live logs,
no SHA256.json) + root's ready bar (reconstruct into a fresh results dir,
CPU verifiers on that data, real step-probe build+execute, all hashes).
Contract worker was holding its bundle pending my word; instructed to
proceed, ≤9 files per mutation, pinned hashes follow its reply.

**Publication state:** `e261c69` verified HEAD==origin/main (root pushed:
LOCAL_TRAINING_REVIEW.md + local_training_review.py + tar/review.json +
plots). Proposal updated (rev13:30): M2 core published, M2b supplement
pending, M1 three untracked docs + path-link substitutions, M3 gated, M4
pending, M5 optional.

Learner preregistration order verified: archive13:11 → decision.md13:12 →
runner edits13:21 (prereg precedes code); no grounded banks exist yet.

## 2026-10-04 14:26 EDT (18:26Z) — pilot abort → v5 freeze → PASS receipt; arms next

Coordinator round (verified from files/ps/lsof, not status claims):

- **Root aborted the grounded pilot at preflight,13:33.** First generator used
  independent az/elev (72/1024 TRAIN +8+6 dev rows outside the true cone),
  no stopped-issue bucket, malformed labels.json (missing comma, all4 files),
  block-concat mix layout, and the learner launched the control arm before
  reading inbox findings. Root stopped old CLI49213 + training child:
  `armG-C-s1` exited241 at rollout≈4700/10000 (child SIGTERM; receipt
  `provenance/armG-C-s1.pid-receipt.txt` finished17:33:05Z). ~191s GPU wasted,
  no pilot outcome read, everything archived intact
  `results/omp-grounded-navigation/invalid-preflight-v1/` +
  `root-preflight-abort.json`. Coordinator independently confirmed exit241 =
  SIGTERM chain (run_locked sys.exit(-15) → 241) before finding root's record.
- **Corrected phase (CLI72113, `corrected-events.jsonl`):** dated
  `decision-revision-2026-10-04.md` (root's3 pretraining points, contract
  adversarial11/11, passage-frame P1, user behaviour-first + navigation-
  outcome clarifications); generator reworked (combined projected frustum,
  yaw-after-route, four visibility labels with raw-ray gate + pooled as
  diagnostic only, velocity buckets stopped_slow U[0,0.2] + stress
  U[0.2,1], side round-robin, schema v2 with `frozen_denominators`);
  **v5 banks frozen14:06** (hashes `inbox/grounded-v5-freeze-p1-response.md`,
  runner `784ca2f3…`, source byte-parity `d8db583a…`), self-validation all
  zeros; witness flights on v5 both outcomes retained (TRAIN918/1024,
  dev-g1 119/128, dev-g2 113/128 — failures retained, wording = script
  precision floor, not "physically impossible").
- **Fail-closed preflight:** `local-train --preflight RECEIPT` refuses
  grounded spec/selector without an independent PASS receipt (refusal tests
  recorded, no file mutation). Contract re-ran its independent checker on
  v5 bytes: **PASS0 fails/4 warns,14:16** — receipt at
  `results/omp-contract-preflight.json` (+ mirror), binding train entry
  `cd6c1b93…`, selector `423c2e33…`, runner `784ca2f3…`; passage frame
  re-derived exactly on all blocked rows; primary pooled blocked = **128**
  exact (frozen, not the withdrawn ≈ estimate).
- **Honest report skeleton:** `report.md` §0–5,9 written before results
  (§6–8 pending); no pilot outcomes read; distribution limit disclosed
  (grounded half24% blocked vs source35%).
- **GPU state18:25Z:** lock held by dynamic mission's
  `metal_nav_dynamic dynamic-test` (PID94720, ~14:08) with contract eval
  wrappers queued; **no armG2 training run started yet** — next evidence =
  valid-start smoke receipt, then four `armG2-{C,T}-s{1,2}` foreground runs
  (10000 each, seeds20261005/20261006, PID receipts, `completed_rollouts`
  header check each).
- Coordination filed `inbox/for-dynamic-mission-coordination-rules.md`
  (archive-before-edit, prereg-before-run, lock/incremental rules, known
  measurement facts). Dynamic mission still owes dated decision/prereg
  BEFORE its first training run; no archive of old shaping sources seen yet.
- State files updated: STATUS.md (mission table + required sequence +
  proven/unverified), dispatch.json (four missions, root abort record,
  open items), this log. Proven vs unverified per STATUS; no percentages.

Next evidence-producing action: verify smoke + each armG2 receipt as it
lands; require dynamic prereg in inbox; M3 tar sha + M4 copy when those
missions deliver; root still owns publication commits.

## 2026-10-04 14:57 EDT (18:57Z) — addendum: five missions, lock queue, M3 reply

- **Fifth mission confirmed (root-launched):** collision-reward learning,
  CLI36300, cwd `collision-reward-learning/RL`, exec72291. Coordinator
  verified prereg order: `results/omp-collision-reward/decision.md`
  14:36:52 BEFORE dev-r1/r2 bank generation14:45:19 and before any
  training; freeze-manifest14:46; source-parity bank present; first arm
  queued under the ABS lock (PID50327) behind contract's Webots flight.
  One fixed10vs50 contact-penalty contrast,4×5000,2 seeds, DEV-r1/r2
  pre-frozen, no sweep (root's brief + prereg in my inbox).
- **Dynamics prereg order verified in events:** first decision.md write
  (event17760) precedes first bank command (51780); pre-run generator
  corrections (crossing-only attempt1, stale attempt2) documented in
  §10 before training14:36; attempts preserved under `banks/attempt*/`.
  Arms running via5×1000 foreground chunks: full-s1 done, full-s2 chunk
  queued (PID49515), ablate arms next;4×5000 total, seeds20261012/13.
- **Learner CLI down since14:14** (ended while bg-waiting for the
  preflight receipt that landed14:16). Filed
  `results/omp-grounded-navigation/inbox/coordination-receipt-landed-resume-sequence.md`
  with the exact HANDOFF resume steps; root manages relaunch.
- **Contract relaunched CLI48595 at14:45** and holds the ABS lock running
  root's frozen BC-vs-fast native benchmark (Webots port23456; frozen BC
  `b8565035…`, NAV `9b4a1164…`). Also owed: warning-field investigation
  (root: `warning_s=-1` on all114 contact rows — export/analysis cause,
  real timestamp receipts, preserve originals) and the M3 tar rebuild.
  Filed reply `inbox/reply-to-bundle-delta-and-m3-p2.md`: portability
  receipt + in-place verifier updates accepted for M3; tar P2 restated
  (AppleDouble members, live logs → path+sha in manifest, internal
  SHA256.json); will re-pin M3 (still9 files) when new tar sha lands.
- State files: STATUS (five-branch table + queue), dispatch (5 missions,
  CLI changes, dynamic/collision states), this log. Proven vs unverified
  unchanged in kind: prereg/orders/hashes verified by coordinator above;
  all training outcomes, eval matrices, warning-field cause, M3 tar, M4
  copy remain unverified until receipts land. No percentages, no commits.

## 2026-10-04 15:12 EDT (19:12Z) — worker sweep: all four CLIs ended, resume map filed

- ps/lsof/flock sweep15:05-15:10: only coordinator CLI51383 alive. Ended:
  learner72113 (14:14, was bg-waiting for the preflight receipt), collision
  ~14:55 (was blocked on lock for its parity job), dynamic61311 ~14:57,
  contract48595 ~15:06 (its root-benchmark Webots battery completed14:55,
  ~692s, per dynamics' log observation of PARENT_NATIVE_BATCH_COMPLETE).
  All mission stderr.log files0 bytes; proxy PID1100 healthy; lock FREE;
  no GPU/Webots process; no orphan/duplicate job.
- One live-child casualty: dynamics `full-s2` chunk2 (1000->2000) was at
  rollout1500 when its session ended (log stops without
  `dynamic_train_done`/`chunk_exit`) - the known dispose-kills-job
  pattern (rounds3,9; root's13:33 abort). Resume-safe: `run_arm.sh`
  recomputes remaining from the per-rollout diag; nothing corrupted.
- Dynamics seed1 pair complete and honestly interim (both exit0,
 5000/5000, receipts): dev-dyn selected FULL112/128 (15 contacts) vs
  ABLATE104/128 (24) vs warmstart27/128 (101); paired net+16 at
  best-vs-best; explicitly NOT concluded until seed2 + pre-registered
  cross-probe (decision.md sections4-5 rule). Static guard held
  (99/98 vs100),66.7% static floor exact, exposure ratio ~2.0.
- Collision-reward verified: decision14:36:52 BEFORE dev-r banks14:45:19
  and training; `local_test_all PASS`; source-parity byte-match; banks
  frozen (freeze-manifest.json); no arm started; pristine parity job
  (PID50327) ended with session - no completion receipt found, must
  verify or re-run before arms.
- Filed consolidated resume map:
  `results/omp-coordination/inbox/worker-sweep-all-down-resume-points-1510.md`
  (exact per-mission resume commands/points; root owns respawns).
  Dispatch/STATUS updated to match. Proven vs unverified unchanged in
  kind; no percentages; no commits; this mission ran no GPU job.

## 2026-10-04 15:42 EDT (19:42Z) — root takes grounded-arm execution; paired-basis finding

- **Root owns the four grounded arms now** (`root-claims-grounded-arms.md`,
  15:31): `root-run-all.sh C1,T1,C2,T2` run separately under the ABS lock
  by root's parent exec, then the full matrix/analysis/plots. Verified
  running: `armG2-C-s1`, `local-train 10000`, warmstart candidate-fast,
  PID84145 under run_locked84143 since ~15:31. Directive recorded: NO
  external agent may launch duplicate arms or resume root-owned checkpoints
  while a job is live; learner does report-only after root's exec.
  Coordinator superseded its own learner resume note in place (banner at
  top of `results/omp-grounded-navigation/inbox/coordination-receipt-landed-resume-sequence.md`).
- **Role-specific preflight receipts verified:** `results/omp-contract-preflight-control.json`
  (PASS, train_spec=source, sel=dev-g1) and `-treatment.json` (PASS,
  train_spec=grounded-mix, sel=dev-g1), both14:48:30, checker
  task-contract; the earlier single `omp-contract-preflight.json` now
  reads verdict SUPERSEDED (consistent with root's note: stale launcher
  SHA text fixed, no algorithm change; live source re-verified784ca2f3).
- **Witness numbers re-verified from summary JSONs** (not just report
  prose): grounded918/1024 (entry984c3ebf), dev-g1 119/128 (423c2e33),
  dev-g2 113/128 (0b7660e1) — all match the freeze table.
- **Dynamics interim paired-basis finding filed**
  (`results/omp-local-dynamics/inbox/coordination-paired-basis-clarification.md`):
  headline counts reproduce exactly from `.best-dev.csv` (FULL112/15,
  ABLATE104/24@4750, warmstart27/101), but the posted paired
  "best-vs-best" full_only19/ablate_only3/net+16 reproduces ONLY from the
  FINAL `.dev.csv` files (ABLATE final96/32); true best-vs-best pairing is
  14/6/net+8. Strata (+10 approach/+6 crossing, crossing9vs3) reconcile on
  the final basis with threat_kind0=approach. Requested: label the basis,
  state which one decision.md §8/§4-5 binds on, disclose ABLATE
  selection instability (104@4750 → 96@5000, -8/+8 in the last250).
  Mission session down; finding waits for respawn.
- Collision parity job confirmed never ran: `logs/parity-pristine.log` is
  only "waiting for metal-training.lock" — it blocked, then the session
  died; must be re-run before its arms (already in the15:10 resume map).
- Dispatch/STATUS updated (root takeover, role-specific receipts, worker
  CLIs still down). Proven list now includes the witness JSONs and the
  receipt pair; still unverified = any armG2 outcome, dynamics seed2 +
  cross-probe, collision parity/arms, M3 tar, M4 copy. No percentages;
  no commits; this mission ran no GPU job.

## 2026-10-04 16:24 EDT (20:24Z) — grounded results complete: NEGATIVE per pre-registered falsifier (independently recomputed)

- Root's `root-run-all.sh` pipeline finished16:07 clean: all four
  `armG2-{C,T}-s{1,2}` exit0 with `local_train_done rollouts=10000`
  (receipts:19:31:44-19:38:08,19:38:08-19:46:45,19:46:45-19:56:10,
  19:56:10-20:07:13Z),75-eval matrix exit0, `summary-g.{json,md}` +
  figures + `root-pipeline.log`. Receipts bind runner784ca2f3, warmstart
  7a37ace8, source entry d8db583a, role-specific preflight per arm.
- **Coordinator recomputed every gate directly from the eval CSVs**
  (filed `inbox/grounded-results-independent-gate-recompute.md`):
  primary pooled blocked C79/T91 = **+12 ≥+10 MET** (s1+3, s2+9, both
  seeds positive); safety contacts C49/T37 (−12 ≤+3) and timeouts +0
  **MET**; retention dev-a +3, dev-b +0, open +0, clutter −3 met,
  **dev-c −12 below the −3 floor → pre-registered falsifier fires →
  honest NEGATIVE for the hypothesis at this budget, no sweeps, no
  seed3**. Blocked denominators confirmed30/34 per seed → pooled128 exact.
  Reading: the treatment's capability gain on the new grounded
  distribution costs −12 on the seed-disjoint dev-c beyond allowed
  loss — the "without losing prior navigation" conjunct is what fails.
- Disclosures queued for report §6–8: yaw/visibility table is all-zero
  (0.000 in-view, n/a first-view, all four arms — needs one-line
  interpretation, not silent publication); eval-matrix receipt landed
  with the stale `runner_sha256=1ceca094…` I flagged at15:52 (matches
  nothing; actual binary3a72ec8d, source784ca2f3 — disclose in §8);
  T-s2 wall11min vs others6.5 = environmental overlap, configs verified
  identical.
- Also this round: dynamics ownership moved to root (`root-claims-
  dynamic-completion.md`: header-read proved FULL/ABLATE s1=5000 each,
  FULL-s2 saved exactly1500 = my kill-point estimate; root-finish.sh
  resumed +3500 incremental then fresh ABLATE-s2, diagnostic rows
  beyond saved checkpoint to be preserved/disclosed; duplicate-on-resume
  note recorded). Contract mission closed its executable stages at15:06
  (report/HANDOFF: warning-field correction exact vs root,32/32 stress
  cells, two arm receipts, portability receipt; M3 tar NOT rebuilt —
  re-verified16:07 still `281fd7d6` with47 AppleDouble members, live
  `grounded-events.jsonl`, no internal SHA256.json → P2 open).
- Dispatch/STATUS/RESEARCH_LOG updated. Proven = the gate arithmetic
  above + receipts; unverified = dynamics eval/analysis/manifest,
  collision parity+arms, report §6–8 wording, M3 tar, M4 copy,
  publication commits. No percentages; no commits; no GPU jobs from
  this mission.

## 2026-10-04 18:06 EDT (22:06Z) — authoritative state restored from completed jobs

- New brief `results/omp-coordination/current-results-mission.md` (same
  session; old coordinator CLI51383 terminal, this CLI73330). STATUS.md
  rewritten compactly to CURRENT truth (old all-down/C1 claims removed);
  dispatch.json rebuilt. All five worker/root studies are COMPLETE and
  root-verified with real headers/optimizer counts — no reruns, no claim
  of coordinator CLI training: native256 (pushed3a3eb3e, BC113 vs fast105,
  BC slower6.166 vs3.615s); grounded4x10000 (+12 primary, dev-c-12 ->
  falsifier -> NEGATIVE/NOT ADOPTED, my independent recomputation stands);
  dynamic4x5000 (selector112/109 vs104/108, warm27; F2 cross0/3 and P3
  retention FAIL; source cache-history leak limits the ablation claim);
  penalty4x5000 (S201->214, C55->17, T0->25, time3.03->5.07 -> stall gate
  FAIL -> NOT ADOPTED); root parity/resume/driver fixes preserved with
  failed logs.
- Three SAME sessions verified live by ps+cwd: learner68335
  (grounded-finish-report-mission), dynamic61820
  (dynamic-completion-review-mission; decision-corrected-history.md
  already filed17:49, parity CSVs landing17:59), collision66890
  (finish-report-mission). Contract finish exec91094 terminal (role
  passes/stress32/warning correction done).
- Coordinator findings this round: yaw/visibility table unsupported by
  trace channels (world pose + target-reference yaw only — repair or
  retract); eval receipt/script still carry stale1ce sha (append
  correction note, don't rewrite evidence); M3 tar unchanged
  (281fd7d6, AppleDouble, live jsonl, no internal SHA256.json); native
  paired-results stale source timeouts[34] list; basis labels required
  everywhere; goal.md operator clarification canonical (out-of-view
  goals legitimate, frustum not universal).
- Next: review three mission preregs/patches; publish-proposal update;
  frozen parent-owned job requests. Written-vs-pushed state recorded in
  STATUS/dispatch; coordinator commits nothing.

## 2026-10-04 18:13 EDT (22:13Z) — reviews, proposal and frozen job requests delivered

- Deliverables filed (pointer `inbox/coordinator-round-1820-state-reviews-jrs.md`):
  `review-findings-2026-10-04-1815.md` (independent verification of all
  four completed studies + open defects + follow-up contract review);
  PUBLICATION_PROPOSAL rev18:15 (pushed set +3a3eb3e/fd0c5fc/1320612 with
  native reproduction command; new M6 grounded-negative / M7 penalty /
  M8 dynamic / M9 native-pin sections, each with full denominators,
  failures and pre-commit gates; exclusions updated);
  `job-requests/JR-000-parent-execution-contract.md` FROZEN (order of
  operations: prereg -> root review -> frozen JR -> parent execution
  under ABS lock with PID receipts + header verification -> gates as
  written -> milestone) and `JR-001-native-dynamic-transfer.md` FROZEN
  (zero-shot native moving-threat spec,2 PENDING pins: candidate sha +
  subset prereg).
- Worker milestones reviewed as they landed:
  * Learner: yaw/visibility claim RETRACTED and replaced by a
    channel-limited reference-alignment diagnostic (pre-tracefix
    summaries preserved as `.pre-tracefix.*`); report carries the
    NEGATIVE/NOT-ADOPTED verdict; `diagnosis-g.json` dev-c structure
    verified against my pooled recompute (14 lost/2 gained,13/14
    detour,14/14 tight, T outcomes11 contact+3 timeout,9/14 out-of-
    view); **G3 prereg** `decision-revision-g3-2026-10-04.md` filed18:09
    BEFORE `dev-h` bank build18:11 (seed20261071) - ONE fixed
    rehearsal-weighting mechanism, name-scoped (not PLR/failure
    replay),2 fresh arms x10000, gates with exact floors (dev-c>=193,
    new skill>=89, dev-h relative +5), falsifier = any miss, parent-owned
    execution. Order verified; compliant.
  * Dynamic: **JR-003 posted and coordinator-verified** -
    `inbox/local-dynamics-corrected-job-request.md` with sha-pinned
    corrected source/binary; I read the gate logs myself:
    `dynamic_test_all PASS`, history leak `legacy480 -> corrected0`,
    `full_history_present480`, `ablation_tick0_identity`, FULL per-flight
    parity `rows=256 mismatches=0`; new nonselector `dev-dyn2.bin`
    `8b2bc51c`; exact incremental run_arm.sh commands. Awaiting root
    code/gate review, then root executes2x5000. My basis + seed2 findings
    applied (tables.txt now labels best@rollout per arm).
  * Collision: stall classification underway on existing data
    (`audit/diag/trace-open-*.csv`, `audit-open-*.csv` for pen50/open
    failures) - report and ONE safe-progress prereg still owed.
- Queue: JR-002 awaits the learner's `parent-owned-job-request-g3.json`;
  JR-004 awaits collision's diagnosis + prereg; JR-001 awaits its two
  pins; M3 tar re-pin still blocked on rebuild. Written-vs-pushed and
  proven-vs-unverified restated in STATUS each round; no commits, no
  heavy runs, no adoption claims from this mission.

## 2026-10-04 18:22 EDT (22:22Z) — JR-002 verified, reports complete, queue pinned

- **Grounded milestone** (`inbox/grounded-g3-report-complete.md`): report
  finished s0-9 with the predeclared NOT-ADOPTED verdict; s6b diagnosis
  answers root's exact question — episode share is exactly50/50 by
  construction (slot = episodes mod16 round-robin) while duration coupling
  makes source ~55.4% of TRANSITIONS (measured, method stated); dev-c
  losses = the original hard cell (93% detour,100% tight,100% goal-
  directed starts,64% out-of-FOV,43% vertical_choices; C clean, T79%
  contact/21% timeout); trace claim withdrawn + reference-alignment table
  + sample-empty bug fixed (no FOV claim remains anywhere). Accidental
  unlocked probe disclosed and quarantined (source-spec local-train
  ~78 s unlocked18:11, killed PID78540, partial artifacts under
  `provenance/accidental-unlocked-smoke/`, lock was free — no contention;
  no claims from it).
- **JR-002 coordinator-verified**: `parent-owned-job-request-g3.json`
  reviewed line by line — runner `b696214e` recomputed from the live
  worktree (exact), dev-h denominators recomputed (n128, blocked33/
  direct95, buckets64/64, seed20261071), gate floors arithmetic-checked
  (dev-a≥190, dev-b≥195, dev-c≥193, open≥253, clutter≥186, new-skill≥89),
  exact build/smoke/arm/eval/analyze commands, sidecar-bound
  `rehearsal_weight` with conditional resume check, incremental resume
  note, disclosures complete. **Step0 dependency: contract mission is
  terminal — root must resume it to re-issue the treatment receipt bound
  to `b696214e` (`results/omp-contract-preflight-treatment-g3.json`);
  the launcher is fail-closed without it.**
- **Dynamics report reviewed** (26KB, s1-7.x): dev-dyn section labeled
  DEVELOPMENT selection evidence; paired numbers now on the SELECTED
  basis with labels (+8 seed1, +1 seed2 — my finding applied); cross-
  probe labeled contract-violation probe (drops0/3); contamination
  disclosed as root-reported + source-verified; corrected-ablation
  gates referenced with "no corrected-training outcome claimed";
  JR-003 already posted and verified (previous entry).
- Queue state: JR-001 frozen (2 pins), JR-002 received+verified (step0
  contract), JR-003 received+verified (awaiting root review/execution),
  JR-004 awaiting collision diagnosis + prereg (stall classification
  actively running: trace-open/audit-open CSVs). M3 tar still unrebuilt;
  M4 pending. No GPU job; lock free; no commits by this mission.
