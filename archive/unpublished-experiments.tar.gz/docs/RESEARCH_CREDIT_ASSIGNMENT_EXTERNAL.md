# Credit assignment on the source navigation objective

Date: 2026-10-03
Scope: `navigation_credit.mm`, `docs/RESEARCH_CREDIT_ASSIGNMENT_EXTERNAL.md`,
`results/omp-credit-assignment/**`. Read-only inputs: core files, assets, other
missions, README, root's reward audit.

This audit answers one question with evidence: **is the .99 return/GAE time scale
a defensible single-knob cause of the 0/30 corner failure, and is one isolated
`gamma=.995` PPO run the right way to test it?** It separates the *implemented
objective* from *what that objective optimizes*, uses only actor trajectories to
judge critic calibration, and defines a run that can falsify the hypothesis.

---

## 1. The objective exactly as implemented

Everything below is read from the current source, not from documentation.

**Reward** (`sim.metal::sim_advance`, per 20 Hz navigation tick = 5 physics substeps):

```
reward = 2*(before-after) - 0.01 - 0.1*clamp((0.6-step_clearance)/0.6, 0, 1)
         + 10*success - 10*collision
```

`before/after` are **straight-line** distances from the vehicle to the final
`world.goal`; there is no geodesic term, no route-node reward and no waypoint
signal. `step_clearance` is the minimum clearance over the tick. Success is
`after < 0.35 m`. Potential shaping is disabled (`potential_control.enabled==0`),
confirmed by the preserved source run and by the reward decomposition check in
`results/reward-audit/reward_audit.mm` (residual ≤ 1e-5). The observed corner
TRAIN episodes reproduce that decomposition exactly.

**Terminal/truncation** (`sim.metal`, same kernel):

```
terminated = collision || success
truncated  = timeout && !terminated      // timeout = steps >= 400
```

**GAE** (`ppo.hpp::compute_gae` and the identical `ppo.metal::ppo_gae`):

```
boundary = terminated || truncated
bootstrap = terminated ? 0 : next_value
delta = r + gamma*bootstrap - V
carry = delta + (boundary ? 0 : gamma*lambda*carry)
advantage = carry;  return = carry + V
```

This is textbook generalized advantage estimation [1] with the standard partial-
episode handling for time limits [2]: a real terminal does not bootstrap, a
timeout bootstraps from `V(s_T)` and then stops the carry so credit cannot cross
into the next episode. Rows are `[tick][env]`. `main.mm`'s `PPOTrainer`
initializes the GAE scalars `gamma_b=.99f, lambda_b=.95f` for every run; the MSL
kernel and the CPU reference are the same logic and already have a parity test
(`main.mm::ppo_tests`, tolerance 2e-5). **No implementation fault was found in the
reward, boundary or GAE code paths.**

**Optimizer/objective:** 128 envs, 32-tick rollout (1.6 s), 2 epochs, minibatch
256, clip 0.2, value coefficient 0.5, Adam LR 1e-4, entropy 5e-4, grad-norm cap
0.5, standardized-advantage normalization, advantage winsorization disabled,
actor anchor disabled, direction auxiliary disabled. The corner curriculum set
`risk_coef=0.1`.

### 1.1 What this objective actually rewards

With `gamma=.99` the discount half-life is 3.45 s and the GAE trace
`gamma*lambda = 0.9405` has a half-life of 0.565 s. From root's real-route
flights (`results/reward-audit/all-transitions.csv`, 27,222 transitions):

| quantity | value |
|---|---|
| teacher corner success tick (mean; range) | 243.5 ticks = 12.2 s (226–269 = 11.3–13.5 s) |
| actor corner collision tick (mean) | 54.2 ticks = 2.7 s |
| mean discounted **+10** success at `gamma=.99` | **+0.87** |
| mean discounted **−10** collision at `gamma=.99` | **−5.82** |
| ratio \|success\|/\|collision\| | **0.149** |
| same ratio at `gamma=.995` | **0.387** |
| rooms / vertical successful route length (DEV) | 5.87 s / 5.13 s |

Two facts follow directly. First, `gamma` rescales **every** discounted reward, not
only the terminal one; but because the success bonus is the reward furthest from
the decision that must be made, it is the term whose effective size changes most.
At `gamma=.99` it arrives at 5 % of nominal while the collision penalty arrives at
~60 %, so the objective is dominated by collision avoidance. Second, the
finite-trace return genuinely *inverts*: at `gamma=.99`, **2 of 24 successful
teacher flights score below a matched 20 s hover**; at `gamma=.995` that number is
**0/24**. So on the recorded physical flights the current time scale numerically
prefers a timeout to some real successes.

Two honest caveats keep this from being a proof:

- **Bootstrap matters.** Adding the frozen critic's timeout bootstrap leaves only
  **1/24** inversions at `gamma=.99` (`results/reward-audit/public-analysis.json`).
  The inversion is a property of the *finite trace return*, and PPO's objective
  is not exactly the finite trace return — it is the trace plus a critic
  bootstrap at the 32-tick boundary. The claim to defend is therefore “the
  terminal/value contrast is compressed”, not “PPO strictly prefers stalling”.
- **Long credit passes through the critic, not the trace.** The 32-tick GAE carry
  only directly reaches back ≤32 ticks (weight 0.14 at 32 ticks, 0.29 at 20);
  anything beyond that must be carried by `V`. So `gamma` cannot be “the reason
  credit cannot reach 13 s”. Its only lever is the size of the terminal/value
  contrast between a winning detour and a dead end.

## 2. Frozen-critic calibration on frozen-actor trajectories

Root's warning applies: privileged teacher returns are not the value of the frozen
policy. The measurement below uses the frozen actor's own trajectories from
`results/reward-audit/all-transitions.csv`, replayed as the **deterministic mode-17
deployment rollout** of that actor. That is not the stochastic mode-22 training
policy, so this is a **source distribution / value mismatch**, not a certified
on-policy value error for the training policy. It is still the right actor-only
comparison available from recorded data.

Per-transition Monte Carlo return-to-go `G_t = Σ_{k≥t} γ^{k−t} r_k` within each
episode (carry reset at the boundary; the timeout bootstrap is reported
separately):

| control | ticks | mean \|r\| | mean V | mean G | bias V−G | MAE | V(s₀)−G₀ | timeout boot |
|---|---|---|---|---|---|---|---|
| actor (frozen) | 1625 | 0.250 | −0.42 | −8.11 | **+7.70** | **7.73** | **+8.12** | 0.00 |
| route teacher | 6197 | 0.107 | +7.21 | +3.89 | +3.32 | 5.46 | +4.46 | 0.00 |
| 2 s scan + teacher | 7400 | 0.091 | +3.79 | +3.08 | +0.71 | 3.42 | +4.43 | 0.00 |
| hover | 12000 | 0.010 | −7.20 | −0.76 | −6.44 | 7.03 | +4.24 | −0.28 |

The mismatch is broad, not spawn-only: on the frozen actor the bias is +7.7 across
all transitions and +8.1 at `s₀`, and MAE is 7.7, i.e. comparable to a whole
success bonus. Its mean absolute TD residual (0.854) is 3.4× the per-tick reward
scale. Two consequences:

- the frozen critic is optimistic about corner states relative to what the frozen
  policy actually achieves, so the bootstrapped advantage contains a large
  constant-like error;
- `V(s₀)` is identical across controls because the spawn state is identical, so
  the spawn row alone would have been misleading — the per-transition table above
  is what shows the mismatch is not local to `s₀`.

Consequence for any `gamma` experiment: both arms inherit this mismatch and must
re-fit the critic online. `gamma` changes the target the critic fits and the value
contrast it can express; it does not remove the bias. This is why the experiment
below is a falsification test, not a guaranteed fix.

## 3. The demonstrated failure and its candidate causes

Frozen DEV facts: corners 0/30, rooms 25/30, vertical 29/30. The actor already
learns 5–6 s successful routes at `gamma=.99` but never survives past 2.0–4.0 s
on corners. Corner routes need 11.3–13.5 s. So the empirical pattern is:

```
rooms/vertical success  ~5.5 s   ≈ 1.6 discount half-lives   -> learned
corner success         ~12.2 s   ≈ 3.5 discount half-lives   -> not learned
```

Three causes are consistent with the evidence; the audit does not claim more
than it shows:

1. **Time-scale compression (testable by one knob).** The success-vs-timeout
   value contrast is compressed at `.99` and would grow ~3× in the terminal term
   at `.995`. Corners are the only family beyond ~2 half-lives, which is exactly
   the family that fails.
2. **Frozen-critic miscalibration (not fixed by `gamma`).** Section 2: TD error
   exceeds the reward scale by 3.4×.
3. **First-turn commitment / sensing (not fixed by `gamma`).** Preserved traces
   show the actor reaches the first wall with near-zero yaw, never scans, and
   oscillates laterally rather than committing to the opening. That decision sits
   ~30–50 ticks before contact. Direct GAE carry covers at most 32 ticks and is
   already down to weight 0.14 there, so the first-wall decision is only partly
   reachable by direct trace credit; the rest must come through the critic
   bootstrap. It is a policy/exploration and value-representation problem, not
   only a horizon problem.

Cause 1 is the only one addressable by a single scalar that does not change the
reward, the horizon, the action map or the curriculum. Causes 2 and 3 need
different machinery, so they are the fallback if cause 1 fails.

A secondary, already-documented limitation: per-tick progress uses straight-line
goal distance, so necessary detours are penalized (16.8 % of teacher corner ticks
have negative progress; net magnitude ≈ 3 % of the positive progress sum). This
is noted as a limitation, not changed — the mission forbids reward edits.

## 4. Decision: one isolated `gamma=.995` experiment is justified

**Justified**, because it is the minimal change that materially rescales the
terminal signal separating a long detour from a timeout (it rescales every
discounted reward, but the terminal term is furthest out so its relative change
is largest):

- terminal success credit ×3.2 relative to the collision penalty (0.149 → 0.387);
- critic-visible success/timeout contrast ×~2.5–3;
- **and** the `.99` finite-trace objective contains measured return inversions
  (2/24 successful flights below hover) that vanish at `.995`.

It is also cheap, cold, and falsifiable, which matters given repeated source
failures. It is **not** claimed as a fix, and the mission's constraint (gamma
only; no longer horizon, no new reward, no curriculum, no shaping) is honored by
construction.

### 4.1 The controlled run (`navigation_credit.mm`)

Two cold arms, identical in everything except `gamma_b`:

| item | value (both arms) |
|---|---|
| warmstart | `results/raw-depth-guidance/rooms-focused-rawlift.bin`, parameter-only, optimizer reset |
| bank | `evidence/inputs/challenge-bank-mirrored-v1.jsonl` (SHA `e2170fbe…`) |
| sampler | uniform bank, seed 42, family mix 43/43/42 |
| reset starts | **original** TRAIN starts (no translation) |
| envs / horizon / epochs / minibatch | 128 / 32 / 2 / 256 |
| LR / entropy / risk / speed cap / max steps | 1e-4 / 5e-4 / 0.1 / 1.5 m/s / 400 |
| lambda / clip / value coeff / anchor / adv-clip | 0.95 / 0.2 / 0.5 / 0 / off |
| budget per arm | ≤ 800 rollouts (≤ 3.28 M transitions) |
| DEV | all 90 **original-start** levels; FINAL never touched |
| `gamma` | arm `gamma0990` = 0.99, arm `gamma0995` = 0.995 |

The runner is cold-only: the checkpoint format does not store `gamma`, so there is
no resume path, and it refuses to write where a prior `provenance.json` exists.
Every evaluated checkpoint is retained as `arm-rollout-<N>.bin` (no earlier
eligible policy is overwritten), and each arm writes `provenance.json` with
`gamma`, the hashes of the exact runner source and binary that executed, and
`gamma_stored_in_checkpoint: false`.

**Acceptance / retention gate (comparative, paired against the matched control
arm):** treatment evidence requires `.995 dev_corners > .99 dev_corners` **and**
`dev_rooms ≥ 25/30` **and** `dev_vertical ≥ 29/30` on the all-90 original-start
DEV split. A gain of >0 corners in both arms is not evidence for `gamma`: the
`.99` control is a second cold run with the same warmstart and budget, so
equal-or-worse `.995` corners rejects this arm's time-scale hypothesis. Retention
is judged per arm against the shared baseline (54/90). Final generalization still
requires an independent Webots run on a frozen eligible candidate; DEV is not that
proof.

**Why this can falsify the hypothesis:** if `.995` corners exceed `.99` corners at
the retention gate, the discount time scale is a binding constraint on long-route
learning. If `.995` corners are equal to or below the matched `.99` arm, this
arm's hypothesis is rejected for this policy and the fallback (Section 5) is
required. A single negative result under one budget is not evidence that discount
horizon is globally wrong as a cause of long-horizon RL failure; it is evidence
that this particular change, at this budget, does not repair this failure.

### 4.2 Result

Both arms were run to the authorized budget: 800 cold rollouts each
(3,276,800 transitions), eval every 100, all-90 original-start DEV, under the
shared `results/metal-training.lock`.

| rollout | γ=.99 DEV (corner/rooms/vert) | γ=.995 DEV (corner/rooms/vert) |
|---|---|---|
| 0 (baseline) | 0 / 25 / 29 = 54 | 0 / 25 / 29 = 54 |
| 100 | 0 / 13 / 29 = 42 | 0 / 21 / 29 = 50 |
| 200 | 0 / 14 / 28 = 42 | 0 / 17 / 29 = 46 |
| 300 | 0 / 7 / 2 = 9 | 0 / 14 / 29 = 43 |
| 400 | 0 / 6 / 28 = 34 | 0 / 0 / 0 = 0 |
| 500 | 0 / 3 / 26 = 29 | 0 / 18 / 25 = 43 |
| 600 | 0 / 6 / 27 = 33 | 0 / 13 / 28 = 41 |
| 700 | 0 / 6 / 27 = 33 | 0 / 10 / 26 = 36 |
| 800 | 0 / 4 / 29 = 33 | 0 / 10 / 29 = 39 |

TRAIN episode outcomes by the transition's own family (validated each rollout
against the environment counters):

| arm | corner ep/succ | rooms ep/succ | vertical ep/succ |
|---|---|---|---|
| γ=.99 | 29,791 / **0** | 10,034 / 3,148 | 8,586 / 6,970 |
| γ=.995 | 30,387 / **0** | 8,773 / 3,928 | 9,749 / 6,978 |

**Conclusion: the time-scale hypothesis is rejected for this arm.** With the
success signal ~3× larger, neither arm scored a single corner success in
training (0/29,791 and 0/30,387) or in any all-90 DEV evaluation. Both arms lost
retention; γ=.995 retained slightly more rooms early and ended marginally higher
(39 vs 33 of 90), and even collapsed to 0/90 at rollout 400, so it is not
eligible and not promotable. Notably, γ=.995 *raised* TRAIN rooms/vertical success
(+780 rooms, +8 vertical) while still never solving a corner — consistent with
the failure being first-turn commitment/value representation rather than the size
of the terminal bonus. No coefficient search was started.

**Known confound, stated honestly:** the bank sampler advances its level stream
from the previous rollout's active ids, so the *realized env→world assignment*
can drift between arms once episode-completion ticks differ. The RNG stream and
the per-rollout multiset of newly sampled levels are identical at every rollout
index (slot 0 is the only carried value), and both arms share identical initial
schedules and initial physical states. `credit-runs.csv` records a per-rollout
schedule SHA-256 and family slots so any drift is visible. No arm-specific
curriculum exists.

## 5. Implementation status and receipts

`navigation_credit.mm` builds with the established 824-input command. Preflight
(`--check`, under `fcntl.flock` on `results/metal-training.lock`) verified that the
two arms are identical in **every explicitly compared initialized simulator,
optimizer and listed PPO scalar buffer except `gamma_b`** — warmstart weights,
bank worlds/schedule/control, post-reset states/runs/sensors/commands, epochs,
minibatch, lambda, clip, value coefficient, entropy coefficient, rows, envs,
horizon, log-std bounds, gradient-norm caps, advantage clip, anchor lambda, and
both optimizer-moment buffers. (It does not compare every internal workspace in
the trainer; the claim is limited to the enumerated buffers.) It also reproduced
the preserved **54/90** original-start DEV baseline (0 / 25 / 29) and ran one
matched 128×32 rollout per arm, confirming `gamma` reaches GAE/PPO.

The authorized 800-rollout matched two-arm run then executed (Section 4.2) under
the same shared lock. Receipts: `results/omp-credit-assignment/`
(`preflight/`, `arm-gamma0990/`, `arm-gamma0995/`, `two-arm-run.log`,
`trained-source-hashes.txt`, `audit/*.txt`, `handoff.json`).

**Next structural action (this arm stops here).** A single negative `gamma` result
rejects this specific intervention, not discounting as a cause in general. The
exploration/memory structural work is owned by the active native missions
(`navigation_exploration.mm`, `navigation_memory.mm`) and must not be duplicated
here. Within this mission's evidence the two remaining candidate causes are:

1. **Frozen-critic value mismatch** (Section 2: bias +7.7 over all transitions,
   MAE 7.7). A dedicated critic-calibration experiment — refit the value head on
   the frozen actor's own distribution before touching the discount — is the
   cheapest untested lever.
2. **First-turn commitment** (Section 3), whose agentic/sensing form is explicitly
   another mission's territory.

Neither is a `gamma` variant, and no coefficient search is warranted by this
result.

## 6. Sources

Primary literature used only where it constrains this audit:

1. Schulman, Moritz, Levine, Jordan, Abbeel. *High-Dimensional Continuous
   Control Using Generalized Advantage Estimation.* ICLR 2016. arXiv:1506.02438.
   (GAE form and the `gamma*lambda` trace decay.)
2. Pardo, Tavakoli, Levdik, Kormushev. *Time Limits in Reinforcement Learning.*
   ICML 2018. arXiv:1712.00378. (Partial-episode bootstrapping at time limits —
   matches the implemented `truncated` handling; timeout bootstraps, true
   terminal does not.)
3. Amit, Meir, Ciosek. *Discount Factor as a Regularizer in Reinforcement
   Learning.* ICML 2020. arXiv:2007.02040. (The discount is a solution-bias/
   regularization knob, so changing it changes the optimum — it is a legitimate
   isolated treatment, and it is not reward-shaping-invariant.)
4. Schulman, Wolski, Dhariwal, Radford, Klimov. *Proximal Policy Optimization
   Algorithms.* arXiv:1707.06347. (Bootstrapped value in the clipped objective.)

RAPTOR/L2F and the Metal engine are unchanged and were not re-derived here.
