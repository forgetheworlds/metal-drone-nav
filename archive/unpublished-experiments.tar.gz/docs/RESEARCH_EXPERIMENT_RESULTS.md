# Research experiment results — mission 4 (reward/sampler)

Owner: omp research mission (session `01a10753-8d11-7135-b9de-1e711df85f77`,
MiMo medium), worktree
`/Users/muadhsambul/.codex/worktrees/local-training-experiments/RL` @ `9ef6a76`
(+ this mission's uncommitted runner/sim changes, hashed below). Date: 2026-10-04.

**Headline: the single predeclared reward hypothesis is FALSIFIED.**
Training-only geodesic potential shaping (`Φ = −min(d_geo, 30 m)/30 m`,
`F = 16·(0.99·Φ(s') − Φ(s))`, terminal `Φ = 0`) added to the local waypoint
reward does **not** raise blocked-route success at matched PPO budget and
**regresses held-out performance consistently across two seeds** — worst on the
predeclared held-out bank dev-c (−7 and −10 /128) and on the out-of-FOV detour
stratum with high measured failure in the independent audits. Direct-route
performance, open-room retention, and the geometry-only prior are unchanged.
Shaping is NOT adopted; the failed arms are preserved as evidence.

Artifacts: `results/omp-research-experiments/waypoint-potential/`
(`report evidence`: `tables.txt`, `curves.png`, `logs/`, `runs/`, `evals/`,
`budget-audit/`, `manifest.json`, `HANDOFF.md`).
Decision written before coding:
`results/omp-research-experiments/decision-waypoint-potential.md`.

---

## 1. Primary-source verification (checked 2026-10-04 before coding)

| claim used | primary source | what the source actually says | status |
|---|---|---|---|
| Potential shaping preserves optimal policies under `γΦ(s')−Φ(s)`, `Φ(terminal)=0` | Ng, Harada, Russell, *Policy Invariance Under Reward Transformations*, ICML 1999 ([PDF](https://people.eecs.berkeley.edu/~russell/papers/icml99-shaping.pdf)) | Thm 1: policy invariance in the discounted formulation; **no** claim of faster learning or better exploration | VERIFIED; claim narrowed: we test credit *redistribution*, never offline-return improvement |
| GAE truncation bootstraps; potential must be non-terminal only at true terminals | Schulman et al., *GAE*, arXiv:1506.02438 (2015) | δ_t bootstraps `V(s_{t+1})` at truncations | VERIFIED; implemented as `Φ(truncated)=lookup(pre-reset state)`, `Φ(terminal)=0` |
| Privileged ToA field trains reactive navigation around large obstacles | Lee, Rathod, Goel, Stecklein, Tabib, *Quadrotor Navigation using RL with Privileged Information*, arXiv:2509.08177 (2025) | ToA (fast marching) used as privileged **loss supervision** + softplus clearance/collision losses; reactive policy at deployment; 86% success, 20 hardware flights | VERIFIED; queue-E wording corrected: their mechanism is a supervised loss, not reward shaping. The direction-aux analogue already exists in-repo (`evidence/geodesic-direction-aux`), so reward shaping was the untested lever |
| PLR scores levels by TD/L1-value-loss + staleness | Jiang, Grefenstette, Rocktäschel, *Prioritized Level Replay*, ICML 2021, arXiv:2010.03934 | Replay distribution mixes level scores with staleness; gains require **both** (ρ=0 or ρ=1 alone worse than uniform); γ,λ = PPO's GAE values; rank prioritization β=0.1 | VERIFIED from arXiv HTML; assumption "current failure-weighted sampler ≈ PLR" holds only up to the staleness mix |
| PLR⊥: probe episodes do not update the policy | Jiang, Dennis, Parker-Holder, Foerster, Grefenstette, Rocktäschel, *Replay-Guided Adversarial Environment Design*, NeurIPS 2021, arXiv:2110.02439 §4 Alg. 1; pseudocode in Jiang et al., *Grounding Aleatoric Uncertainty for UED*, NeurIPS 2022 app. A.1 | New-level episodes collected with stop-gradient ("suppress policy update"); only curated buffer levels drive updates | VERIFIED; queue claim corrected: PLR⊥ originates in Replay-Guided UED, not the original PLR paper |
| ALP-GMM: allocate training where absolute learning progress is largest | Portelas, Colas, Hofmann, Oudeyer, [*Teacher algorithms for curriculum learning of Deep RL in continuously parameterized environments*](https://proceedings.mlr.press/v100/portelas20a.html), CoRL 2019 / PMLR 100 (2020), arXiv:1910.07224 | Models absolute learning progress with Gaussian mixture models over continuous environment parameters; evaluated on BipedalWalker variants | VERIFIED by root against PMLR; corrects the initial misattribution to reverse curriculum learning |
| ACCEL edits frontier levels instead of fresh random draws | Parker-Holder et al., *Evolving Curricula with Regret-Based Environment Design*, ICML 2022, arXiv:2203.01302 (workshop precursor NeurIPS 2021) | ACCEL = Adversarially Compounding Complexity by Editing Levels | VERIFIED (PMLR v162) |

Decision: reward branch first (queue priority 1 + goal.md item 11), because the
waypoint path has **no adaptive sampler at all** (fixed round-robin bank install)
— a PLR-style comparison there requires building probe/staleness infrastructure
before any hypothesis can be tested, while blocked-route contacts are measured (51–70% failure under the published
actors vs 81/81 direct), and per-step credit is one hypothesis on this fixed bank with shaping infra already built but
gated off for this path.

## 2. Bottleneck → hypothesis → experiment → falsifier (pre-registered)

- **Bottleneck (measured, published evidence):** mode-17 DEV-a: direct routes
  81/81 for every published actor; blocked routes 14–23/47 with 22–35 contacts.
  The step reward pays `2.0/m · Δ(Euclidean distance)`; a correct detour earns
  ≈0 or negative progress while initiating, full reward until contact while
  going straight.
- **Hypothesis:** geodesic potential shaping adds within-episode credit for
  detour motion → higher blocked-route success at matched budget, no loss on
  direct/retention strata.
- **Smallest experiment:** two arms, one difference (`--potential-scale 0` vs
  `16`), published train-bank bytes, published warmstart, 2,000 rollouts ×
  128×32, seeds 20261004 and 20261006, selection on DEV-a (success→collision→
  arrival), held-out DEV-b + predeclared DEV-c + open/clutter retention.
- **Falsifier:** blocked-route DEV-a Δ≤0 on both seeds, or any equal/worse
  regression on direct routes, open, or clutter retention; or reward-ordering
  gate failure; or field build failure on any train entry.

## 3. Pre-learning gates (all passed; ordering audit is a gate, not a proof)

1. `local-reward-audit` (new command, CPU-only): kinematic reference vs hover
   vs blind-straight on 16 stratified train entries (8 direct + 8 blocked;
   plain stride aliased with the bank's class alternation — fixed to stratified
   sampling), both reward variants. Result: **PASS** — witness > hover and
   witness > colliding-straight for all 8 blocked entries under control and
   shaped rewards (e.g. entry 396: witness +14.83 shaped vs hover +2.06 vs
   colliding straight −7.17 undiscounted). CSV: `evals/reward-ordering.csv`.
   Independent cross-check: the task-contract auditor's flown-trajectory audit
   (`docs/LOCAL_TASK_CONTRACT_AUDIT.md` §7) ranks reference above hover/blind/
   detour/collision on all 1,024 TRAIN flights (0/591 inversions). Offline
   ordering is treated as a gate only; acceptance is learned performance.
2. Field build: all **1,024/1,024** train entries certified by the 0.2 m grid
   (start↔goal connectivity + witness-polyline coverage), 12.1 s cold /
   0.6 s cached, 439,934,976 bytes, `field_sha256=463f30bc…`; every Φ ∈ [−1, 0].
3. `local-test` full gate suite **PASS**, including the new field sanity check
   (obstacle-free task: value brackets Euclidean/Manhattan bounds, goal cell at
   radius, ascent direction points at the goal) and all reset/observation
   contract probes (`logs/local-test.log`).
4. Contract negatives: resuming a shaped checkpoint as control and vice versa
   are both refused on `potential_scale` before loading; shaped resume passes
   and continues (`logs/neg-scale-mismatch*.log`, `logs/resume-shaped.log`).

## 4. Code and tests (isolated to my scope)

| file | change |
|---|---|
| `training_potential.hpp` | `build_one_field` takes an explicit check-start (default = challenge `(0,0,1.5)`, byte-identical behaviour for existing challenge caches); family-range guard replaced by the existing static-world guard; `build_training_potential_fields` accepts optional per-level starts |
| `sim.metal` | activation gate now also allows the task path (`task_control.enabled` with `bank_control` disabled); invalid-level guard extended to the task path (fail-loud NaN instead of silent no-shaping). Challenge-path behaviour unchanged |
| `navigation_waypoint_training.mm` | `waypoint_task_apply` publishes the shaping level id to `bank_active_ids` (host mirrors the formula around resume — the buffer is not checkpointed); `--potential-scale/--potential-cache` options; sidecar schema **v3** with required `potential_scale`; field build + hash bound into PPO checkpoint v9/v10 (existing machinery); `local-reward-audit` command; field-sanity gate in `local-test`; stratified audit sampling |

Actor inputs, 184-dim observation, mode 22/17 action map, RAPTOR, arrival
contract (0.35 m / 0.5 m/s / 0.2 s), body clearance (0.18 m sphere, 0.30 m
endpoint body margin), 20 s budget, 1.5 m/s cap, γ=.99, λ=.95, PPO hyperparams,
network size — all untouched. Φ never enters any observation.

## 5. Budget accounting (ALL actual compute, including the declared deviation)

| run | rollouts | transitions | training wall | note |
|---|---|---|---|---|
| smoke control / shaped (+resume) | 5 + 5 + 5 | 61,440 | ~1.5 s total | contract/NaN smoke |
| control-s1 | **2,000** | 8,192,000 | 84.2 s | fresh, seed 20261004 |
| shaped-s1 | **1,700 + 2,000 = 3,700** | 15,155,200 | 78.0 s + 85.1 s = 163.2 s | CLI died at 1,700; peer executed my posted job-request verbatim but the runner is incremental (`finish = completed + requested`), producing 3,700. Deviation declared; selection budget 2,000 respected (see below) |
| control-s2 | **2,000** | 8,192,000 | 77.3 s | fresh, seed 20261006 |
| shaped-s2 | **2,000** | 8,192,000 | 86.0 s | fresh, seed 20261006 |
| evals (20 × mode17 + 8 comparators + blind + 8 legacy) | — | — | ~15 s | one lock section, `logs/eval-matrix.log`, `logs/legacy-retention.log` |
| tests / audit / field build | — | — | ~40 s | `logs/local-test.log`, `evals/reward-ordering.csv` |

Selector tie-break verified independently (`budget-audit/selection-audit.json`
+ my recomputation): the runner rule (success → strict-lower collision →
strict-lower arrival) selects **control-s1 @800 (103/128, 23 contacts)** and
**shaped-s1 @1950 (102/128, 23 contacts)**; the tie at 2050 (26 contacts) does
not displace shaped-s1, and the selector over rows ≤2000 equals the selector
over all 3,700 rows for both arms, so the bounded comparison is exact. Frozen
copies + hashes in `budget-audit/`. The 3,700-rollout checkpoint is NOT claimed
as a 2,000-rollout result; >2,000 history rows are kept on disk as the permanent
record of the deviation. `control-s1.bin.best` is **byte-identical** to the
published reliability candidate (`sha a2f38aec…`), which re-anchors this
experiment to the published baseline.

## 6. Results (mode 17 = deployed actor, 128 tasks per split, deterministic eval)

### 6.1 Selection (DEV-a) and held-out

| split | role | control-s1 | shaped-s1 | control-s2 | shaped-s2 |
|---|---|---|---|---|---|
| dev-a | selection | **103** (23c, 4.51 s) | 102 (23c, 2.98 s) | **105** (23c) | 101 (26c, 3.06 s) |
| dev-b | held-out | 101 | 104 | 103 | 100 |
| **dev-c** | **predeclared held-out** | **99** (26c) | **92** (33c) | **102** (26c) | **92** (35c) |
| open | retention | 128 | 128 | 128 | 128 |
| clutter | retention | 98 | 99 | 104 | 94 |

Paired per task (shaped-only vs control-only successes): dev-a −1 / −4;
dev-b +3 / −3; **dev-c −7 (2 wins vs 9 losses) and −10 (0 wins vs 10
losses)**; clutter +1 / −10. Direct routes are unchanged everywhere
(dev-a 80–81/81, dev-c 80/80, open 128/128); the entire held-out deficit sits
on blocked routes.

### 6.2 Stratum: blocked routes × goal-in-FOV (yaw-hemisphere ±45°)

| split | arm | in-FOV detour | out-FOV detour |
|---|---|---|---|
| dev-c | control-s1 / control-s2 | 6/11, 7/11 | 13/37, 15/37 |
| dev-c | shaped-s1 / shaped-s2 | 6/11, 6/11 | **6/37, 6/37** |
| dev-a | control-s1 / control-s2 | 12/13, 12/13 | 11/34, 12/34 |
| dev-a | shaped-s1 / shaped-s2 | 9/13, 9/13 | 12/34, 11/34 |

The regression concentrates exactly in the **detour + goal-outside-FOV** cell
(both audits' dominant failure mass: 246/1024 TRAIN in-FOV under the labelled
yaw-hemisphere convention, 175/1024 under my camera-frustum-angle predicate
(|bearing|≤atan 1.0, |pitch|≤atan 0.75); the contract audit's pixel-ray frustum
number is 169/1024 — predicates stated so the two audits are not read as
contradictory).

### 6.3 Geometry-only / actor / residual comparators (held-out)

| split | mode | control-s1 | shaped-s1 |
|---|---|---|---|
| dev-b | 13 geometry-only prior (weights ignored) | 88 | 88 |
| dev-b | 4 actor without prior | 101 | 102 |
| dev-b | 17 deployed prior+residual | 101 | 104 |
| dev-c | 13 geometry-only prior | 84 | 84 |
| dev-c | 4 actor without prior | 99 | 90 |
| dev-c | 17 deployed prior+residual | 99 | 92 |
| dev-c | 2 scripted blind goal-seeker | 81 | (actor-independent) |

Mode 13 is identical across arms — confirming it ignores weights. The shaped
deficit is present without the prior (mode 4: 99→90) and with it (99→92): it is
in the learned policy, not a prior-interaction artefact.

### 6.4 Legacy retention (production first-entry protocol: families 7/8,
mode 17, seed 800001, 1.5 m/s, 10 s — protocol recovered and anchor-verified)

| arm | family 7 | family 8 |
|---|---|---|
| control-s1 | **117/128** (== published candidate, exact) | **120/128** (== published candidate, exact) |
| shaped-s1 | 114/128 | 122/128 |
| control-s2 | 110/128 | 117/128 |
| shaped-s2 | 108/128 | **88/128 (−29 vs its control)** |

Note: the published `legacy-retention.log` lost its generating argv; I recovered
it by testing `distance=4` against the published candidate row — my control-s1
reproduces both published rows digit-for-digit, which validates this table's
protocol. The shaped-s2 family-8 collapse is the largest retention regression
observed.

### 6.5 Training telemetry

Training reward means are higher under shaping as designed (mean over rollouts
0.108→0.164 and 0.111→0.149), and shaped arrivals are consistently **faster**
(dev-a 2.98 vs 4.51 s; open 2.75 vs 5.11 s) — the shaping pushed speed and
directness — but held-out reliability falls. This is the designed credit
redistribution producing the intended local objective change and an unwanted
system outcome; per goal.md only the system outcome counts. Learning curves,
reward moments, contact curves: `waypoint-potential/curves.png`; full tables:
`tables.txt`; per-flight rows: `evals/*.csv`.

## 7. Verdict and regressions

**Falsified per the pre-registered criterion.** Δ(dev-a) = −1 and −4 (≤0 on
both seeds), with consistent held-out and retention losses:

1. dev-c −7 and −10 /128 (paired: shaped wins 2/9 then 0/10),
2. dev-c out-FOV detours 13/15 → 6/6 of 37,
3. clutter −10 at seed 2,
4. legacy family 8 −29 at seed 2,
5. dev-a arrivals faster but dev-c collisions up (26→33, 26→35).

Preserved failed arms: `runs/shaped-s1.bin*` (3,700-rollout deviation state),
`runs/shaped-s2.bin*`, all history/diag CSVs, `logs/shaped-s1.log` (both
segments), `logs/shaped-s2.log`. No checkpoint is promoted; no core/ROOT files
changed; no FINAL/production/ Webots claim.

**Interpretation (inference, not proof):** the privileged field rewards geodesic
progress at states where the deployed observation cannot yet disambiguate the
correct detour (75% of TRAIN starts have the goal outside the ±45° hemisphere;
blocker never seen in-rays in 34% of blocked flights per the contract audit).
The faster arrivals and contact regressions are consistent with premature
commitment, but do not establish its cause. Potential shaping redistributes
credit; privileged fields are allowed during training. These outcomes do not
show that fields necessarily encode information a student cannot learn to use,
or that all ToA losses and reward formulations would fail.

## 8. Limitations (explicit)

- Fixed bank isolates the **reward** variable; it says nothing about sampler
  arms (queue A/B) or generator changes (learner's mission).
- In-FOV/out-FOV labels: two declared conventions (mine: yaw-hemisphere 246,
  frustum-angle 175 on TRAIN; contract audit: pixel-ray 169) — always labelled.
- Evaluation is deterministic mode 17 at seed 700001 (one eval seed, matching
  every published local eval); training seeds are 2 (20261004/20261006).
- shaped-s1 ran 3,700 not 2,000 rollouts (declared deviation §5); selection
  proven within budget; final-2000 weights not retained and not claimed.
- dev-c bank bytes come from the task-contract auditor's predeclaration
  (sha `b0d6dae4…` verified before use); my runner only reads it via the
  WPBANK1 ABI (no generator rewrite, no dev-c spec added).
- The reward-ordering audit uses kinematic trajectories (explicitly not a
  dynamics claim); the contract auditor's flown-trajectory audit supplies the
  dynamics-side ordering evidence.
- 0.2 m grid quantisation makes Φ a Manhattan-bounded approximation of d_geo;
  identical infrastructure/quantisation to the previously published
  challenge-bank fields.

## 9. Specific next decision

1. **Do not adopt potential shaping** on the local waypoint path at any scale
   tested; keep `--potential-scale` default 0 and the field infra gated off.
   Re-opening requires a new pre-registered hypothesis (e.g. shaping restricted
   to in-FOV states), not a scale sweep — no coefficient sweep is planned.
2. **Highest-value next reward/selection test** given this falsification: the
   learner's pre-registered observe-before-motion BC+PPO arm (§12 of
   `docs/LOCAL_DISTRIBUTION_AUDIT.md`, accepted by coordinator) attacks the
   cell where this experiment's regression concentrated; my mission supports it
   with the audit tooling (`local-reward-audit`, FOV strata) rather than
   duplicating it.
3. If the sampler branch is next (queue A): PLR⊥ semantics are binding — probe
   episodes must not produce PPO updates (verified §1); the waypoint path has no
   sampler today, so the first sampler test should reuse the challenge-sampler
   pattern with a ≥0.5 uniform floor and a fixed bank/transition budget.

Peer contract auditor must independently check `runs/`, `evals/`, and
`budget-audit/` before any adoption decision; coordinator holds STATUS.
