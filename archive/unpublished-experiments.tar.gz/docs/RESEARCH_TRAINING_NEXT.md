# Next source-training experiment: an observability/exploration gap on the corner bank

**Date:** 2026-10-04 (revision 2, root-corrected) · **Owner:** OMP `opencode-go/deepseek-v4.1-flash` (mission `results/omp-training-research/`)
**Scope:** diagnosis + one recommendation. No training, no Webots, no FINAL evaluation, no edits outside this file and `results/omp-training-research/**`.

## 0. Scope breach and correction (read first)

An earlier pass of this mission's analysis script loaded the whole challenge bank and therefore read **FINAL-split geometry** (witness routes, goals, obstacles) and printed FINAL rows in two CSVs. No policy was evaluated on FINAL and no FINAL outcome exists, but the original final suite can no longer be claimed fully unseen by this mission. The statement "FINAL untouched" is withdrawn. The contaminated script and outputs are preserved unaltered and labelled under `results/omp-training-research/analysis/incident-final-included/`; the corrected analysis reads TRAIN and DEV only and stops before the first non-allowed record is parsed. A fresh sealed final suite will be required after candidate freeze for future blind proof.

**Primary sources read:** arXiv:2602.01266v1 (full), arXiv:1707.05300 (§3–4), arXiv:1711.06006v3 (§3–4); abstracts of arXiv:1709.10087, arXiv:2509.08177v2, arXiv:2605.14810, arXiv:2609.19850v1. Repository receipts and source as listed in Appendix A.

## 1. The measured question

The selected control scores DEV 54/90: **0/30 corners, 25/30 rooms, 29/30 vertical**. Privileged witness routes fly 30/30 corner levels within the 20 s budget at 1.5 m/s (`docs/BENCHMARKS.md`), so the route is feasible and the policy is not. Every recorded arm has produced **zero** corner successes: γ=.99 and γ=.995 PPO (0/29,791 and 0/30,387 TRAIN corner episodes), a 4-stage reset curriculum, behaviour cloning, a DAgger-style correction set, a recurrent residual, a held-scan macro option, and a sensor-map planner.

## 2. Diagnosis (TRAIN/DEV evidence only; ranked)

### D1 — the corner decision point is an instantaneous perceptual alias, and heading diversity is absent

`results/omp-training-research/analysis/corner_observability.csv` (TRAIN+DEV, 60 family-14 levels):

| quantity | TRAIN | DEV |
|---|---:|---:|
| first witness-segment bearing from spawn heading (+X) | mean \|69.7°\| | mean \|70.2°\| |
| levels with the first opening inside the 90° horizontal FOV | **0/30** | **0/30** |
| yaw to reach the FOV edge | mean 24.7° | mean 25.2° |
| forward partition distance (static geometry) | mean 1.86 m | mean 1.81 m |

`world.hpp::wcamera` is a 20-column pinhole with `-y*1.0` → **90° horizontal FOV (±45°)**. Spawn heading is the identity quaternion, so at the decision point the target is outside the instantaneous frustum and mirrored layouts are aliased: in the controlled same-goal mirror pairs the raw depth differs (all 15 pairs separate by >0.01), yet the live corrected learner reports `opposite_policy=0/15, correct_teacher_signs=0/15` with hidden-state deltas up to 0.354 (`results/omp-recurrent-training/handoff.json`). That is evidence that **this policy** does not resolve the alias at the decision point. It is **not** a proof that the action is unobservable: stored depth history, the goal channel and the geometric prior can in principle carry the information, and active sensing (a yaw scan) resolves it outright. The static time-to-wall numbers above ignore forward motion changing the bearing and RAPTOR tracking lag; they are an approximation, not a feasibility proof.

Supporting: the executed trace at these starts is 1.5 m/s cap-active near-straight with small measured yaw (D2), and measured exploration cannot produce the scan (iid max heading excursion 0.194 rad, AR(1) 0.221 rad, scripted held-scan 5/30 with 16/30 contacts; `results/temporal-exploration/report.md`).

The family dose–response is monotone in first-segment misalignment (`route_deception.csv`, TRAIN+DEV):

| family | misalignment | efficiency (straight/path) | frozen actor |
|---|---:|---:|---:|
| 16 vertical | 2.5° | 0.99 | 29/30 |
| 15 rooms | 43.5° | 0.78 | 25/30 |
| 14 corner | 70.2° | **0.51** | **0/30** |

### D2 — the deployed gate reduces the small-signal yaw gain, and the raw yaw latents are small

`sim.metal::sim_act` (mode 22, which trains the deployed mode-17 map) computes `deployed_scale = 0.25 + 0.75·(first 20 pooled cells > 2.5 m)/20` and then, in **latent** space, `executed_latent = prior + scale·(a[j] − prior)` for translation and `executed_latent = scale·a[3]` for yaw, followed by `command = tanh(executed_latent)` and `yaw += command·0.025` rad/tick. The gate therefore scales the **raw latent before `tanh`**: it reduces the small-signal yaw gain ~4× when the overhead view is blocked, but it does **not** impose a hard cap — an arbitrarily large raw yaw latent still approaches the physical 0.5 rad/s limit. Measured (`analysis/measure_gate_yaw.py`):

| trace | gate | executed yaw |
|---|---|---|
| frozen control, f14-dev-0000 (56 ticks) | min/median 0.250, max 0.475; 91 % blocked | \|cmd_yaw_rps\| max **0.1243**, mean 0.0518 |
| frozen control, f14-dev-0001 mirrored (59 ticks) | median 0.250; 93 % blocked | max **0.1351**, mean 0.0418 |
| mode-22 iid probe (1,200 ticks) | — | raw yaw latent max 1.904 (mean 0.437); \|cmd_yaw_rate\| max **0.1937** |
| same raw latent ungated | — | `tanh(1.904)·0.5 = 0.478` rad/s |

So the observed yaw suppression is a joint effect of small raw yaw latents **and** the gate; the correct statement is "reduced gain in practice", not "0.125 rad/s ceiling". The translation blend is likewise in latent space, and `guidance.hpp::nav_guidance_memory` scores goal alignment 1.4 against free space 0.20, so near the blocking partition the prior dominates and points at the goal. This is a structural contributor, not a proven sole cause.

### D3 — the measured objective inversion is a finite-horizon accounting defect, not a proven learning blocker

`sim.metal::sim_advance`: `reward = 2·ΔEuclidean − 0.01 − 0.1·clamp((0.6−clearance)/0.6,0,1) + 10·success − 10·contact`. On the 120 recorded teacher/hover flights (`docs/RESEARCH_CREDIT_ASSIGNMENT.md`) a successful corner route scores G(γ=.99) = −1.2416 versus −0.9690 for matched hovering; **2 of 24** finite traces invert, and **1 of 24** remains inverted after frozen-critic bootstrap. Components: progress +2.9291, clearance risk −3.9845, terminal +0.7405. Two caveats must be stated: this is a finite recorded-trace sum, not the policy's GAE advantage, and it does not by itself prove that a discovered success would be suppressed. The task imposes a 20 s deadline while training uses continuing/truncation semantics, which the audit already flags as the underlying design question ([Pardo et al., *Time Limits in RL*, arXiv:1712.00378](https://arxiv.org/abs/1712.00378)).

A mathematically important negative result: replacing the clearance penalty with a potential difference `γΦ(s')−Φ(s)`, `Φ=terminal 0`, telescopes to the constant `−Φ(s_0)` for every terminal trajectory, so it **removes the clearance preference from the objective entirely**. It is policy-invariant shaping, not a safety term. Replacing progress/risk changes the optimal policy and must be a separate matched arm with consistent timeout bootstrapping and critic-target transformation; adding invariant shaping to the base objective is a different intervention.

### D4 — the recorded failures have mixed causes

Zero corner successes across all arms is the hard fact. The recurrent prototype's failed runs are **not** attributable to memory alone: they also had a detached prefix gradient, a unit-cap inconsistency, a body-frame prelude, a stale step-39/40 capture and early-only supervision (`results/omp-recurrent-training/brief.md`). The live corrected learner (`handoff.json`, run-v2, 2,000-update arm in progress) has teacher-validated source flights of 26/30 corners, 28/30 rooms, 30/30 vertical, and a 200-update smoke of 0/30 corners with hidden-state deltas up to 0.354 but an output head that does not yet condition on them. The sensor-map planner failed on two control-flow defects. Neither is a falsification of memory or mapping.

## 3. What the primary sources say

Malczyk, Kulkarni & Alexis (NTNU), *RL for Active Perception in Autonomous Navigation*, arXiv:2602.01266v1 (2026-02-01, read in full): APPO+GRU on depth, a local 21³×0.1 m ego-centric occupancy grid and state; navigation reward augmented with `n_t = λ_G·#{voxels unknown→known}`; **initial yaw randomised U(−π/2,π/2) "to avoid bias toward straight-line trajectories."** Their T-shaped-corridor deployment is the closest published analogue: the policy "reorient[s] the sensor to scan the lateral branch … before committing to a turning manoeuvre," while the fixed-camera FOV-constrained baseline "fails … getting stuck at narrow regions." Ablations: local grid is the largest safety gain (crash 32.4 %→4.8 %); `n_t` raises exploration 43 %→63 % with no success loss (94.3 % vs 95 %). Caveat: their camera is actuated; ours is fixed, so active perception must be vehicle yaw. Code: `github.com/ntnu-arl/active-perception-RL-navigation`.

Supporting: Lee et al., arXiv:2509.08177v2, use privileged ToA maps plus a yaw-alignment loss for goals blocked by large walls (86 % vs 34 %). Florensa et al., arXiv:1707.05300, adapt the start-state distribution to states with success probability in `(R_min,R_max)`; the good-start band and Assumption 3 are what the fixed 4-stage schedule violated. Rajeswaran et al., arXiv:1709.10087 (DAPG) place demonstrations as a decaying auxiliary loss inside RL. Rauber et al., arXiv:1711.06006 relabel goals to achieved states and cannot create an unvisited region. GR2PO (arXiv:2609.19850v1) is real but its own tables give PPO higher final return on the tested tasks and no code was linked.

## 4. Rejections

| method | why not now |
|---|---|
| GR2PO / group-relative control as replacement | its own tables favour PPO; zero-tail returns truncate 2.5–15 s episodes at a 1.6 s rollout; no official code. Keep PPO as control. |
| γ-only horizon | one 800-rollout γ=.995 arm at a finite budget produced 0 corner episodes. That is not evidence that the horizon is irrelevant to the outcome, only that this arm did not fix it. |
| BC from privileged route | off-camera labels in 15/15 mirrored scenes; measured 0/30 and room loss. |
| DAgger-style corrections | measured 0/30; same label defect. |
| Geodesic potential alone | measured 0/30 in 2 seeds, but confounded by the alias and the gate; this did not falsify reward shaping in general. |
| Reset/start-shift curriculum alone | shifted starts reached ~79 % reset success, then the original start collapsed to 19/90, 0 corners. |
| Yaw-exploration alone (AR(1), macro scan) | measured 0/30; yaw latents small and gate active. |
| Frontier/map alone | unresolved implementation failure, not evidence against sensor memory. |
| HER/HPG alone | cannot visit the unseen opening. |
| Replacing the dense reward with potential shaping | telescopes to a constant; removes the clearance preference; changes the optimal policy. |
| Another reward-coefficient sweep | uninformative; no coefficient tuning is proposed. |

## 5. Recommendation — OD-1: heading diversity plus a bounded intrinsic sensing reward

One experiment, two matched arms, no FINAL. Warm start `results/raw-depth-guidance/rooms-focused-rawlift.bin` (sha `9e2923ed…`); bank `challenge-bank-mirrored-v1.jsonl` (sha `e2170fbe…`). Observation (184/824), mode-17/22 action map, RAPTOR/physics, 1.5 m/s cap, 400-step budget, and **the base dense reward and terminals are unchanged**. The anchor coefficient is held at the matched control's value (0 in the recent 800-rollout γ arms and the 300-rollout yaw arms); the λ3 retention result documented in `docs/RESEARCH_TRAINING.md` §4.5 is not assumed as a baseline here.

| contract | arm R (heading diversity) | arm R+I (adds sensing reward) |
|---|---|---|
| reset/state | family-14 TRAIN spawns set `NavigationTaskState.start_yaw_rad ~ U(−90°,+90°)` (field exists in `navigation_tasks.hpp`; applied via `navigation_task_apply_start` and `run.yaw`). DEV resets unchanged (yaw 0). Domain randomisation, not a benchmark change. | same |
| reward | unchanged | unchanged base **plus** `λ_G·#{voxels unknown→known}` from the agent's own local map, each voxel counted once per episode. Added term only; no replacement. |
| optimizer | 128 envs × 32 steps, 2 epochs, minibatch 256, lr 1e-4, entropy 5e-4, clip 0.2, grad cap 0.5, γ=.99, λ=.95, anchor as control | same |

**Rationale.** Heading randomisation creates episodes in which the first opening is inside the FOV, so the "turn into a visible opening" behaviour acquires positive examples; at eval (yaw 0) the policy must scan, and the bounded intrinsic term makes scanning self-reinforcing. The intrinsic term is an *addition* to a fixed objective, so the only policy change it can induce is via exploration; its contribution is measured directly against arm R.

**Predeclared gates.**
1. *Analytic*: report the fraction of sampled TRAIN resets with the first opening inside the 90° FOV, and the fraction of DEV resets where the *measured* (not static) yaw-rate trajectory could reach the FOV edge before contact. No tuning against these numbers.
2. *Discounted-return check, not undiscounted caps*: compute the actual discounted return and GAE advantage of successful versus hover trajectories under each arm's reward, and require that the intrinsic term does not make spin/hover the higher-advantage behaviour. Reject if mean path efficiency falls below arm R or mean speed drops >30 %.
3. *Training gate*: corner DEV ≥3/30 with rooms ≥25/30 and vertical ≥29/30 on 2 seeds, matched transitions and wall time, Wilson intervals reported. Adopt only if arm R+I beats arm R on corner DEV; otherwise report the randomisation-only result.
4. *Retention*: DEV evaluated every 100 rollouts; stop if rooms <25/30 twice consecutively.
5. *Deployment*: on adoption only, freeze weights, export the 184 actor, and run the independent Webots door/room/mixed matrix. FINAL is not read; a fresh sealed final suite is required post-freeze.

**Wallclock.** 800 PPO rollouts per arm (≈3.28 M transitions) complete in minutes on this M3; a 90-level DEV eval takes seconds. Two arms plus control are well under an hour, so design correctness is the binding constraint.

**Why not the recurrent proposal as the next step.** The live corrected recurrent learner is already running with a coherent repair (inverse-map latent residual objective, full post-prefix BPTT, teacher-validated flights) and has not yet reported a trained result; recommending a second memory design now would duplicate live work. OD-1 is orthogonal and cheap: it changes the reset distribution and adds one bounded intrinsic term, leaving the architecture and the base objective intact. Recurrence becomes the next justified change only if a scan is learned and then lost across the 0.4 s prior.

## Appendix A — sources actually read

| source | version/date | read | used for |
|---|---|---|---|
| Malczyk, Kulkarni, Alexis, *RL for Active Perception in Autonomous Navigation* | arXiv:2602.01266v1, 2026-02-01 | full HTML (reward Eq. 5–9, Table I, §III-D, §IV-C) | heading randomisation, information-gain reward, T-corridor precedent |
| Florensa et al., *Reverse Curriculum Generation* | arXiv:1707.05300, CoRL 2017 | abstract + §3–4 | good-start band; why fixed stages failed |
| Rauber et al., *Hindsight Policy Gradients* | arXiv:1711.06006v3, 2019 | abstract + §3–4 | rejected as primary remedy |
| Rajeswaran et al., *DAPG* | arXiv:1709.10087, 2017 | abstract | demonstration-augmented RL form |
| Lee et al., *Quadrotor Navigation with Privileged Information* | arXiv:2509.08177v2, 2026-03-05 | abstract | wall-blocked goal, yaw-alignment loss |
| Wang et al., *GR2PO* | arXiv:2609.19850v1, 2026-09-17 | abstract | rejection |
| CMRL | arXiv:2605.14810, 2026-05-14 | abstract | occlusion memory (follow-up) |
| Pardo et al., *Time Limits in RL* | arXiv:1712.00378 (via repo) | — | finite-horizon/deadline accounting |
| Ng et al., *Policy Invariance Under Reward Transformations* | ICML 1999 (via repo) | — | why potential shaping cannot encode a preference |

## Appendix B — analysis files (TRAIN/DEV only)

- `analysis/analyze_routes.py` — bank route/observability analysis; refuses to parse any non-TRAIN/DEV record.
- `analysis/route_deception.csv` (180 rows), `analysis/corner_observability.csv` (60 rows) — corrected outputs, sha256 recorded in `handoff.json`.
- `analysis/measure_gate_yaw.py` — measured deployed-gate and yaw-command distributions from recorded traces.
- `analysis/incident-final-included/` — frozen, labelled scope-breach receipt (contaminated script and outputs).
- Reproduction: `python3 results/omp-training-research/analysis/analyze_routes.py` and `python3 .../measure_gate_yaw.py`.

## Appendix C — handoff

- Scope breach recorded in §0 and in `analysis/incident-final-included/README.md`; "FINAL untouched" withdrawn; no further FINAL access.
- No training, Webots, git, or engine/source change; `results/metal-training.lock` not taken; other missions' files and processes untouched.
- Next owner action: authorise arms R and R+I with a fresh matched control, after the live recurrent mission reports its own result, so the two are not confounded.
