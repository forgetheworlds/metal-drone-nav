#!/usr/bin/env python3
"""Independent contract audit of the current local-waypoint task distribution.

Audits the published local-waypoint banks (source TRAIN, dev-a, dev-b) against
the deployment contract in goal.md: feasibility envelopes, TRAIN/DEV separation,
generator exclusions and full denominators, difficulty-axis inventory, and
goal visual-grounding from the selection pose. Everything here is derived from
bank records and retained build receipts, not from the generator code running
again: the checks are independent recomputations from the published CSV rows.

Outputs (under the root repository, mission-owned results directory):
  results/omp-task-contract/bank-invariants.json   every invariant, PASS/FAIL
  results/omp-task-contract/task-axes.csv          one row per audited task
  results/omp-task-contract/pretraining-record.json
      dated pre-training record of difficulty axes, generator exclusions and
      full-denominator scores (goal.md asks for this BEFORE new training)

Usage:  python3 local_contract_audit.py [--worktree ROOT] [--out DIR]
"""

import argparse
import csv
import hashlib
import json
import math
import os
import re
import sys
from collections import Counter, defaultdict
from datetime import datetime, timezone

# ---------------------------------------------------------------- constants
# From navigation_waypoint_training.mm (root, fc8c6d0) and sensor_profile.hpp
# as read during the audit; cited in LOCAL_TASK_CONTRACT_AUDIT.md.
K_ENDPOINT_CLEARANCE_M = 0.30
K_MIN_WITNESS_CLEARANCE_M = 0.02
SPEC_RATIO_MAX = {"source": 2.5, "dev-a": 2.5, "dev-b": 2.5, "open": 3.0, "clutter": 3.0}
SPEC_FAMILIES = {
    "source": [0, 1, 2, 4, 5, 14, 15, 16],
    "dev-a": [2, 4, 5, 14, 15, 16],
    "dev-b": [2, 4, 5, 14, 15, 16],
    "open": [0],
    "clutter": [1, 2, 4, 5, 14, 15, 16],
}
SPEC_PERIOD = {"source": 8, "dev-a": 1, "dev-b": 1, "open": 1, "clutter": 1}
SPEC_SEED = {"source": 20261004, "dev-a": 20261005, "dev-b": 20261007}
FAMILY_NAMES = {0: "open", 1: "boxes", 2: "poles", 4: "doorway", 5: "table",
                14: "bent_hallway", 15: "connected_rooms", 16: "vertical_choices"}
K_START_LOW = (-1.4, -3.0, 0.8)
K_START_HIGH = (1.0, 3.0, 2.6)
K_GOAL_LOW = (-1.7, -4.7, 0.3)
K_GOAL_HIGH = (13.7, 4.7, 4.7)
# Legacy camera profile (the one every published local bank/eval used):
# forward +X, tan_h 1.0, tan_v 0.75, mount offset 0, max range 12 m.
TAN_H = 1.0
TAN_V = 0.75
MAX_RANGE_M = 12.0
# navigation_task_step reward recipe (navigation_tasks.hpp defaults via
# navigation_training::task_settings, time cost overridden per arm).
RECIPE = {
    "progress_reward_per_m": 2.0,
    "time_cost_per_s_verified": 0.2,
    "time_cost_per_s_fast_arm": 1.0,
    "contact_penalty": 10.0,
    "stable_arrival_bonus": 10.0,
    "command_smoothness_weight": 0.05,
    "goal_radius_m": 0.35,
    "stable_speed_mps": 0.5,
    "stable_hold_s": 0.20,
    "nav_period_s": 0.05,
    "max_nav_steps": 400,
    "gamma_training": 0.99,
    "gae_lambda": 0.95,
}

EPS = 1e-5


def sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as handle:
        for chunk in iter(lambda: handle.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def load_rows(path):
    with open(path, newline="") as handle:
        return list(csv.DictReader(handle))


def f(row, key):
    return float(row[key])


def norm(v):
    return math.sqrt(v[0] * v[0] + v[1] * v[1] + v[2] * v[2])


def audit_spec(spec, csv_path, results):
    """Run every per-task invariant for one bank split. Returns task rows."""
    rows = load_rows(csv_path)
    families = SPEC_FAMILIES[spec]
    period = SPEC_PERIOD[spec]
    ratio_max = SPEC_RATIO_MAX[spec]
    failures = []
    task_rows = []
    fallback_detected = 0
    seen_seeds = Counter()
    for i, row in enumerate(rows):
        index = int(row["index"])
        env = int(row["env"])
        slot = int(row["slot"])
        family = int(row["family"])
        route_class = int(row["route_class"])
        attempts = int(row["attempts"])
        where = "%s[%d]" % (spec, index)

        def bad(what, detail=""):
            failures.append({"task": where, "check": what, "detail": detail})

        if index != i:
            bad("row_order", "index %d at position %d" % (index, i))
        if env != index // period or slot != index % period:
            bad("env_slot_layout", "env=%d slot=%d" % (env, slot))
        if family != families[index % len(families)]:
            bad("family_rotation", "family %d at index %d" % (family, index))
        seen_seeds[row["scene_seed"]] += 1

        start = (f(row, "start_x"), f(row, "start_y"), f(row, "start_z"))
        goal = (f(row, "goal_x"), f(row, "goal_y"), f(row, "goal_z"))
        velocity = (f(row, "start_velocity_x"), f(row, "start_velocity_y"),
                    f(row, "start_velocity_z"))
        distance = f(row, "initial_distance_m")
        yaw = f(row, "start_yaw")
        direct = f(row, "direct_clearance_m")
        witness_len = f(row, "witness_length_m")
        witness_clear = f(row, "witness_clearance_m")

        recomputed = norm(tuple(goal[a] - start[a] for a in range(3)))
        if abs(recomputed - distance) > 1e-4:
            bad("initial_distance_matches_endpoints",
                "%.6f vs %.6f" % (recomputed, distance))
        for axis in range(3):
            if not (K_START_LOW[axis] - EPS <= start[axis] <= K_START_HIGH[axis] + EPS):
                bad("start_inside_declared_bounds", "axis %d = %g" % (axis, start[axis]))
            if not (K_GOAL_LOW[axis] - EPS <= goal[axis] <= K_GOAL_HIGH[axis] + EPS):
                bad("goal_inside_declared_bounds", "axis %d = %g" % (axis, goal[axis]))
        if f(row, "clearance_start_m") <= K_ENDPOINT_CLEARANCE_M:
            bad("start_endpoint_clearance", row["clearance_start_m"])
        if f(row, "clearance_goal_m") <= K_ENDPOINT_CLEARANCE_M:
            bad("goal_endpoint_clearance", row["clearance_goal_m"])
        if distance < 1.0 - EPS or distance > 3.0 + EPS:
            bad("goal_distance_1_3m", "%.4f" % distance)
        if witness_len < distance - EPS:
            bad("witness_not_shorter_than_straight", "%.4f < %.4f" % (witness_len, distance))
        if witness_len > ratio_max * max(distance, 1e-3) + EPS:
            bad("route_ratio_within_spec", "%.4f > %.4f" % (witness_len / distance, ratio_max))
        if witness_clear <= K_MIN_WITNESS_CLEARANCE_M:
            bad("witness_clearance_floor", "%.4f" % witness_clear)
        blocked = direct <= K_MIN_WITNESS_CLEARANCE_M
        if route_class == 1 and not blocked:
            bad("route_class_matches_direct_clearance", "class 1 direct %.4f" % direct)
        if route_class == 0 and blocked:
            bad("route_class_matches_direct_clearance", "class 0 direct %.4f" % direct)
        if attempts != (2 if route_class == 1 else 1):
            bad("attempts_column_is_route_class_echo", "attempts %d class %d" % (attempts, route_class))
        speed = norm(velocity)
        if speed > 1.0 + EPS:
            bad("start_speed_envelope", "%.4f" % speed)
        # Start velocity is drawn parallel to the start->goal direction by
        # construction; verify it from the record (axis inventory evidence).
        toward = True
        if speed > 1e-6:
            unit = tuple((goal[a] - start[a]) / distance for a in range(3))
            dot = sum(velocity[a] * unit[a] for a in range(3))
            cross_vec = (velocity[1] * unit[2] - velocity[2] * unit[1],
                         velocity[2] * unit[0] - velocity[0] * unit[2],
                         velocity[0] * unit[1] - velocity[1] * unit[0])
            cross = norm(cross_vec)
            toward = cross <= 1e-6 * max(speed, 1e-6) and dot >= -1e-6
            if not toward:
                bad("start_velocity_points_at_goal", "cross residual %.6g" % cross)
        if not (-math.pi - EPS <= yaw <= math.pi + EPS):
            bad("start_yaw_range", "%.4f" % yaw)

        # Preferred route class by index cycle (generator's class preference).
        preferred = 2 if (index // len(families)) % 2 == 0 else 1
        # Fallback from the preferred detour class is recoverable per row;
        # direct-preference fallbacks are only visible in the build receipts.
        fallback = 1 if (preferred == 1 and route_class == 0) else 0
        fallback_detected += fallback

        # Goal grounding from the selection pose (legacy camera at body point,
        # yaw-only rotation about world +Z). LOS occlusion is added by the
        # flight probe (local_contract_probe.mm) and merged in the report.
        delta = tuple(goal[a] - start[a] for a in range(3))
        cy, sy = math.cos(yaw), math.sin(yaw)
        bx = cy * delta[0] + sy * delta[1]
        by = -sy * delta[0] + cy * delta[1]
        bz = delta[2]
        bearing = math.degrees(math.acos(max(-1.0, min(1.0, bx / max(recomputed, 1e-9)))))
        in_fov = bx > 0.0 and abs(by) <= TAN_H * bx and abs(bz) <= TAN_V * bx

        task_rows.append({
            "spec": spec, "index": index, "env": env, "slot": slot,
            "family": family, "family_name": FAMILY_NAMES.get(family, "other"),
            "scene_seed": row["scene_seed"], "route_class": route_class,
            "class_preference": preferred, "fallback_detected": fallback,
            "initial_distance_m": "%.4f" % distance,
            "witness_ratio": "%.4f" % (witness_len / max(distance, 1e-6)),
            "direct_clearance_m": "%.4f" % direct,
            "witness_clearance_m": "%.4f" % witness_clear,
            "clearance_start_m": "%.4f" % f(row, "clearance_start_m"),
            "clearance_goal_m": "%.4f" % f(row, "clearance_goal_m"),
            "start_speed_mps": "%.4f" % speed,
            "start_yaw_rad": "%.4f" % yaw,
            "goal_bearing_deg": "%.2f" % bearing,
            "goal_in_fov_t0": int(in_fov),
            "start_velocity_toward_goal": int(toward),
        })

    results[spec] = {
        "csv": csv_path,
        "sha256": sha256(csv_path),
        "tasks": len(rows),
        "declared_environments_times_period": None,
        "family_counts": dict(Counter(r["family_name"] for r in task_rows)),
        "route_class_counts": dict(Counter(int(r["route_class"]) for r in task_rows)),
        "class_preference_counts": dict(Counter(r["class_preference"] for r in task_rows)),
        "fallback_detected_rows": fallback_detected,
        "duplicate_scene_seeds": sorted(k for k, v in seen_seeds.items() if v > 1),
        "goal_in_fov_t0": sum(r["goal_in_fov_t0"] for r in task_rows),
        "start_velocity_toward_goal": sum(r["start_velocity_toward_goal"] for r in task_rows),
        "failures": failures,
    }
    return task_rows


def audit_receipts(log_paths):
    """Parse every retained bank_build receipt line; verify determinism and
    generator arithmetic (the exclusion/failure record that the bank CSVs do
    not carry)."""
    receipt_lines = defaultdict(set)
    for path in log_paths:
        try:
            with open(path, errors="replace") as handle:
                for line in handle:
                    if line.startswith("bank_build "):
                        receipt_lines[line.strip()].add(os.path.basename(path))
        except OSError:
            continue
    receipts = []
    problems = []
    by_spec = defaultdict(set)
    for line in sorted(receipt_lines):
        fields = dict(re.findall(r"(\w+)=([^\s]+)", line))
        by_spec[fields.get("spec", "?")].add(line)
        receipts.append({"line": line, "log_files": len(receipt_lines[line])})
    for spec, lines in by_spec.items():
        if len(lines) != 1:
            problems.append({"spec": spec, "check": "identical_receipt_across_rebuilds",
                             "detail": "%d distinct receipts" % len(lines)})
    parsed = {}
    for spec, lines in by_spec.items():
        line = next(iter(lines))
        fields = dict(re.findall(r"(\w+)=([^\s]+)", line))
        try:
            direct = int(fields["direct"]); detour = int(fields["detour"])
            class_direct = int(fields["class_direct"]); class_detour = int(fields["class_detour"])
            fallbacks = int(fields["fallbacks"]); tasks = int(fields["tasks"])
        except (KeyError, ValueError):
            problems.append({"spec": spec, "check": "receipt_fields_parse", "detail": line})
            continue
        if direct + detour != tasks:
            problems.append({"spec": spec, "check": "direct_plus_detour_equals_tasks", "detail": line})
        if class_direct + class_detour + fallbacks != tasks:
            problems.append({"spec": spec, "check": "class_counts_sum_to_tasks", "detail": line})
        if class_detour > detour:
            problems.append({"spec": spec, "check": "class_detour_within_detour", "detail": line})
        if class_direct > direct:
            problems.append({"spec": spec, "check": "class_direct_within_direct", "detail": line})
        parsed[spec] = {
            "tasks": tasks, "direct": direct, "detour": detour,
            "class_direct": class_direct, "class_detour": class_detour,
            "class_fallback": fallbacks, "fallbacks": fallbacks,
            "receipt": line,
        }
    return {"receipts": receipts, "per_spec": parsed, "problems": problems}


def audit_source_eval_coverage(eval_dir):
    """local-eval --spec SOURCE must not be mistaken for a full TRAIN score:
    the evaluator runs exactly one episode per environment, so a period-8 bank
    only flies slot 0 (family open) of each env. Verify from retained CSVs."""
    rows_out = []
    problems = []
    if not os.path.isdir(eval_dir):
        return {"eval_dir": eval_dir, "available": False}
    for name in sorted(os.listdir(eval_dir)):
        if not name.endswith(".csv") or "-source-" not in name:
            continue
        path = os.path.join(eval_dir, name)
        rows = load_rows(path)
        families = Counter(r["family_name"] for r in rows)
        classes = Counter(int(r["route_class"]) for r in rows)
        rec = {"file": name, "rows": len(rows), "families": dict(families),
               "route_class": dict(classes)}
        rows_out.append(rec)
        if len(rows) != 128:
            problems.append({"file": name, "check": "row_count_is_one_per_env",
                             "detail": str(len(rows))})
        if set(families) != {"open"}:
            problems.append({"file": name, "check": "slot0_family_is_open",
                             "detail": str(dict(families))})
    return {"eval_dir": eval_dir, "available": True, "source_eval_files": rows_out,
            "files_checked": len(rows_out),
            "finding": ("source-spec evals score 128/1024 TRAIN tasks "
                        "(slot 0 of each env, family open only)"), "problems": problems}


def audit_separation(banks):
    """TRAIN/DEV scene-seed and task-tuple separation, recomputed independently."""
    checks = []
    def seeds(spec):
        return set(r["scene_seed"] for r in banks[spec + "_rows"])
    def tuples(spec):
        out = set()
        for r in banks[spec + "_rows"]:
            out.add((r["scene_seed"], r["start_x"], r["start_y"], r["start_z"],
                     r["goal_x"], r["goal_y"], r["goal_z"]))
        return out
    for dev in ("dev-a", "dev-b"):
        overlap = seeds("source") & seeds(dev)
        checks.append({"check": "scene_seed_disjoint_source_%s" % dev,
                       "overlap": len(overlap), "pass": len(overlap) == 0})
        # Task tuples are compared on endpoints regardless of seed.
        t1 = {(r["start_x"], r["start_y"], r["start_z"], r["goal_x"], r["goal_y"], r["goal_z"])
              for r in banks["source_rows"]}
        t2 = {(r["start_x"], r["start_y"], r["start_z"], r["goal_x"], r["goal_y"], r["goal_z"])
              for r in banks[dev + "_rows"]}
        overlap_t = t1 & t2
        checks.append({"check": "start_goal_tuple_disjoint_source_%s" % dev,
                       "overlap": len(overlap_t), "pass": len(overlap_t) == 0})
    family_gap = sorted(set(SPEC_FAMILIES["source"]) - set(SPEC_FAMILIES["dev-a"]))
    checks.append({"check": "dev_family_coverage_note", "pass": True,
                   "detail": "DEV splits exclude TRAIN families %s by design; "
                             "separation is by scene seed, not family" % family_gap})
    return checks


def train_denominators(root):
    """Original full-denominator TRAIN/DEV scores, as recorded, before any new
    training. Taken from the published evidence tables (not recomputed)."""
    out = {"source": {}}
    headline = os.path.join(root, "evidence", "inputs", "local-waypoint",
                            "metrics-headline.csv")
    if os.path.exists(headline):
        rows = load_rows(headline)
        out["source"]["metrics-headline.csv"] = [
            {"actor": r["actor"], "split": r["split"], "tasks": int(r["tasks"]),
             "success": int(r["successes"]), "contact": int(r["contacts"]),
             "timeout": int(r["timeouts"])} for r in rows]
    behaviour = os.path.join(root, "evidence", "inputs", "local-waypoint",
                             "training", "rollout-behaviour.csv")
    if os.path.exists(behaviour):
        rows = load_rows(behaviour)
        per_run = defaultdict(lambda: {"rollouts": 0, "completed_episodes": 0,
                                       "successes": 0, "contacts": 0, "timeouts": 0})
        for r in rows:
            agg = per_run[r["run"]]
            agg["rollouts"] += 1
            agg["completed_episodes"] += int(float(r["completed_episodes"]))
            agg["successes"] += int(float(r["successes"]))
            agg["contacts"] += int(float(r["contacts"]))
            agg["timeouts"] += int(float(r["timeouts"]))
        out["source"]["training-rollout-behaviour.csv"] = dict(per_run)
    return out


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--worktree", default=os.path.dirname(os.path.abspath(__file__)))
    parser.add_argument("--root", default="/Users/muadhsambul/RL")
    parser.add_argument("--out", default=None)
    args = parser.parse_args()
    out_dir = args.out or os.path.join(args.root, "results", "omp-task-contract")
    os.makedirs(out_dir, exist_ok=True)
    bank_dir = os.path.join(args.worktree, "results", "omp-local-waypoints", "banks")
    evidence_banks = os.path.join(args.root, "evidence", "inputs", "local-waypoint", "banks")

    results = {}
    all_task_rows = []
    for spec in ("source", "dev-a", "dev-b"):
        path = os.path.join(bank_dir, spec + ".csv")
        all_task_rows.extend(audit_spec(spec, path, results))

    # Evidence copies must be byte-identical to the audited bank CSVs.
    evidence_map = {"source": "train-source-1024.csv", "dev-a": "dev-a-128.csv",
                    "dev-b": "dev-b-128.csv"}
    for spec, name in evidence_map.items():
        a = os.path.join(bank_dir, spec + ".csv")
        b = os.path.join(evidence_banks, name)
        same = os.path.exists(b) and sha256(a) == sha256(b)
        results[spec]["evidence_copy_identical"] = same
        if not same:
            results[spec]["failures"].append(
                {"task": name, "check": "evidence_copy_byte_identical", "detail": b})

    # Bank .bin sha must match its manifest (which training bound to).
    for spec in ("source", "dev-a", "dev-b"):
        bin_path = os.path.join(bank_dir, spec + ".bin")
        json_path = os.path.join(bank_dir, spec + ".json")
        if os.path.exists(json_path):
            manifest = json.load(open(json_path))
            digest = sha256(bin_path)
            ok = manifest.get("bank_sha256") == digest
            results[spec]["bin_sha256"] = digest
            results[spec]["bin_matches_manifest"] = ok
            results[spec]["manifest_bank_file"] = manifest.get("bank_file")
            if not ok:
                results[spec]["failures"].append(
                    {"task": spec, "check": "bin_matches_manifest", "detail": digest})

    # Generator receipts: determinism across every retained rebuild + arithmetic.
    receipt_logs = []
    for sub in ("checks", "probe-logs"):
        d = os.path.join(args.worktree, "results", "omp-local-waypoints", sub)
        if os.path.isdir(d):
            for name in sorted(os.listdir(d)):
                if name.endswith(".log"):
                    receipt_logs.append(os.path.join(d, name))
    receipts = audit_receipts(receipt_logs)

    # Published source-spec eval coverage (full-denominator trap).
    eval_coverage = audit_source_eval_coverage(
        os.path.join(args.worktree, "results", "omp-local-waypoints", "evals"))

    # TRAIN/DEV separation.
    banks_rows = {}
    for spec in ("source", "dev-a", "dev-b"):
        banks_rows[spec + "_rows"] = load_rows(os.path.join(bank_dir, spec + ".csv"))
    separation = audit_separation(banks_rows)

    # Fallback cross-check: rows detected vs receipt totals.
    fallback_cross = {}
    for spec, parsed in receipts["per_spec"].items():
        detected = results.get(spec, {}).get("fallback_detected_rows")
        if detected is None:
            continue
        fallback_cross[spec] = {
            "detected_from_rows": detected,
            "receipt_class_fallback": parsed["class_fallback"],
            "receipt_direct": parsed["direct"], "receipt_detour": parsed["detour"],
            "detected_equals_receipt": detected == parsed["class_fallback"],
        }

    invariants = {
        "generated_utc": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "audited_banks": results,
        "receipts": receipts,
        "fallback_cross_check": fallback_cross,
        "separation": separation,
        "source_spec_eval_coverage": eval_coverage,
        "failure_count": sum(len(r["failures"]) for r in results.values())
                         + len(receipts["problems"])
                         + sum(len(c.get("problems", [])) for c in [eval_coverage])
                         + sum(1 for c in separation if not c["pass"]),
    }
    with open(os.path.join(out_dir, "bank-invariants.json"), "w") as handle:
        json.dump(invariants, handle, indent=1, sort_keys=True)

    axes_path = os.path.join(out_dir, "task-axes.csv")
    with open(axes_path, "w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(all_task_rows[0].keys()))
        writer.writeheader()
        writer.writerows(all_task_rows)

    # ------------------------------------------------ pre-training record
    fov_by = defaultdict(lambda: [0, 0])
    for row in all_task_rows:
        key = "%s/%s/class%d" % (row["spec"], row["family_name"], row["route_class"])
        fov_by[key][1] += 1
        fov_by[key][0] += row["goal_in_fov_t0"]
    axes_inventory = {
        "recorded_per_task": [
            "family", "scene_seed", "route_class (direct vs blocked)", "start pose + yaw",
            "start velocity", "goal position", "initial distance", "endpoint clearances",
            "direct-segment clearance", "witness clearance + length (route ratio)",
            "generation attempt echo (route class only)",
        ],
        "derivable_from_records": [
            "required route ratio", "braking requirement (start speed, distance, "
            "toward-goal velocity)", "goal bearing / in-FoV at selection (this audit)",
            "goal horizon (1-3 m)",
        ],
        "missing_until_flight_probe": [
            "sensor warning time / first sighting of blocking or colliding geometry",
            "goal line-of-sight occlusion at selection",
            "minimum route clearance along the flown path", "observed deceleration budgets",
            "goal grounding beyond bearing (opening visibility)",
        ],
        "not_varied_in_current_distribution": [
            "start velocity away from or across the goal (all starts point at the goal)",
            "sensor/command delay (eval-only knobs, not task metadata)",
            "wind/disturbance and vehicle-parameter variation (nominal plant only)",
            "moving obstacles (static worlds enforced)",
        ],
    }
    record = {
        "generated_utc": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "purpose": ("pre-training contract record required by goal.md: difficulty "
                    "axes, generator exclusions and full denominators captured "
                    "before any new training run"),
        "banks": {spec: {
            "tasks": results[spec]["tasks"],
            "sha256_csv": results[spec]["sha256"],
            "sha256_bin": results[spec].get("bin_sha256"),
            "family_counts": results[spec]["family_counts"],
            "route_class_counts": results[spec]["route_class_counts"],
            "failures": results[spec]["failures"],
        } for spec in ("source", "dev-a", "dev-b")},
        "generator_exclusions": {
            "receipts": receipts["per_spec"],
            "cross_check": fallback_cross,
            "notes": [
                "The bank CSV 'attempts' column is an echo of route class "
                "(detour=2, direct=1), not a rejection count.",
                "Per-draw rejections (clearance, bounds, witness search) are not "
                "persisted per task; the build receipt totals are the only "
                "retained exclusion record.",
                "Detour-preference fallbacks are recoverable per row; direct-"
                "preference fallbacks are only visible in the receipt totals.",
            ],
        },
        "difficulty_axes": axes_inventory,
        "goal_grounding_bearing_only": {
            "profile": "legacy (tan_h 1.0, tan_v 0.75, mount 0)",
            "in_fov_by_class": {k: {"in_fov": v[0], "tasks": v[1]}
                                for k, v in sorted(fov_by.items())},
            "totals": {"in_fov": sum(r["goal_in_fov_t0"] for r in all_task_rows),
                       "tasks": len(all_task_rows)},
        },
        "reward_recipe": RECIPE,
        "full_denominators_before_new_training": train_denominators(args.root),
        "source_spec_eval_coverage_finding": eval_coverage.get("finding"),
        "invariants_file": os.path.join(out_dir, "bank-invariants.json"),
        "task_axes_file": axes_path,
    }
    record_path = os.path.join(out_dir, "pretraining-record.json")
    with open(record_path, "w") as handle:
        json.dump(record, handle, indent=1, sort_keys=True)

    failures = invariants["failure_count"]
    print("bank invariants: %s" % ("PASS" if failures == 0 else "FAIL (%d)" % failures))
    for spec in ("source", "dev-a", "dev-b"):
        print("  %s tasks=%d in_fov_t0=%d/%d failures=%d" % (
            spec, results[spec]["tasks"], results[spec]["goal_in_fov_t0"],
            results[spec]["tasks"], len(results[spec]["failures"])))
    print("  receipts: %d distinct bank_build lines across %d logs, problems=%d"
          % (len(receipts["receipts"]), len(receipt_logs), len(receipts["problems"])))
    print("  fallback cross-check: %s" % json.dumps(fallback_cross, sort_keys=True))
    print("  separation: %s" % ("PASS" if all(c["pass"] for c in separation) else "FAIL"))
    print("wrote %s" % record_path)
    return 0 if failures == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
