// Independent local task-contract flight probe.
//
// Purpose (goal.md / omp-task-contract brief):
//  * fly actual RAPTOR trajectories over the full source TRAIN bank (all
//    1024 tasks, all 8 period slots) with the frozen source actor, the
//    repository's blind mode-2 goal-seeker, and a zero-command hover;
//  * capture per-tick ground-truth rewards from the simulator reward buffer,
//    cross-checked tick-by-tick against an independent recomputation from the
//    documented navigation_task_step formula;
//  * capture sensor warning evidence: first sighting of the route-blocking
//    obstacle and of the contact obstacle in the actual 320 measured rays,
//    goal line-of-sight and in-field-of-view at selection, with the ray model
//    validated against the GPU sensor ranges;
//  * capture braking/arrival evidence per flight (speed profile, hold ticks,
//    terminal approach speed).
//
// It embeds the read-only root runner (WAYPOINT_EMBEDDED keeps its main out)
// and does not modify any existing file. The only additions are two tiny
// Metal kernels used by the hover controller (zero actor actions and zero the
// three geometry-prior observation latents, so the mode-17 action map yields
// exactly zero commanded velocity).
//
// Episode protocol: non-eval auto-reset cycling exactly as training sees it.
// `period` slots per environment fly in sequence (bank index = env*period +
// episode%period); a run of period*400 ticks completes every slot even if
// every episode times out. Cumulative SimRun counters survive auto-reset, so
// per-episode time/path/outcome come from their deltas; the terminal tick's
// post-state is the next episode's start, so state columns always come from
// the PRE-tick read and the terminal reward comes from the reward buffer row.
//
// Build:
//   clang++ -x objective-c++ -std=c++17 -O2 -fobjc-arc \
//     -framework Foundation -framework Metal -framework Accelerate \
//     -DSOURCE_DIR='"/Users/muadhsambul/RL"' -DFIXED_PPO_ACTOR_OBS_DIM=184 \
//     -DNAV_SENSOR_PROFILE=1 local_contract_probe.mm -o <out>
//
// Run under the shared GPU lock:
//   python3 /Users/muadhsambul/RL/results/mimo-learning-next/run_locked.py -- \
//     <out> contract-flight OUT_PREFIX --bank BANK.bin --mode 17 \
//     --controller policy --envs 128 --ticks 3200 --trace-envs 8

#define WAYPOINT_EMBEDDED
// Build-portability: override per checkout with
//   -DTASK_CONTRACT_RUNNER=\"/path/to/navigation_waypoint_training.mm\"
#ifndef TASK_CONTRACT_RUNNER
#define TASK_CONTRACT_RUNNER "/Users/muadhsambul/RL/navigation_waypoint_training.mm"
#endif
#include TASK_CONTRACT_RUNNER

#include <algorithm>
#include <array>
#include <cmath>
#include <fstream>
#include <string>
#include <vector>

namespace contract {

static const char* kContractKernels = R"MSL(
kernel void contract_zero_actions(device float* actions [[buffer(0)]],
                                  constant SimConfig& cfg [[buffer(1)]],
                                  uint i [[thread_position_in_grid]]) {
    if (i >= cfg.n * 4u) return;
    uint env = i >> 2u;
    uint row = cfg.tick * cfg.n + env;
    actions[row * 4u + (i & 3u)] = 0.0f;
}
kernel void contract_zero_prior(device float* observations [[buffer(0)]],
                                constant SimConfig& cfg [[buffer(1)]],
                                uint i [[thread_position_in_grid]]) {
    uint env = i / 3u, j = i % 3u;
    if (env >= cfg.n) return;
    uint row = cfg.tick * cfg.n + env;
    observations[row * PPO_ACTOR_OBS + (PPO_ACTOR_OBS - 3u) + j] = 0.0f;
}
)MSL";

// --------------------------------------------------- geometry diagnostics
// Obstacle ids are 0..count-1; room faces are 1000..1005 so they can never
// collide with an obstacle index (root's published audit used a packed 16+id
// scheme that assumes fewer than 16 obstacles).
static int first_hit(const WWorld& world, WVec origin, WVec direction, float time,
                     float& range) {
    range = 12.0f;
    int id = -1;
    const float wall = wray_box(origin, direction, wv(6, 0, 2.5f), wv(8, 5, 2.5f));
    if (wall < range) {
        range = wall;
        const WVec p = wa(origin, wm(direction, wall));
        const float distances[6] = {std::fabs(p.x + 2), std::fabs(p.x - 14),
                                    std::fabs(p.y + 5),  std::fabs(p.y - 5),
                                    std::fabs(p.z),      std::fabs(p.z - 5)};
        id = 1000 + int(std::min_element(distances, distances + 6) - distances);
    }
    for (uint j = 0; j < world.count; j++) {
        const auto& obstacle = world.obstacles[j];
        float distance = 1000;
        const WVec center = wc(obstacle, time);
        if (obstacle.kind == 0)
            distance = wray_box(origin, direction, center,
                                wv(obstacle.size[0], obstacle.size[1], obstacle.size[2]));
        else if (obstacle.kind == 1)
            distance = wray_sphere(origin, direction, center, obstacle.size[0]);
        else
            distance = wray_cylinder(origin, direction, center, obstacle.size[0],
                                     obstacle.size[2]);
        if (distance < range) {
            range = distance;
            id = int(j);
        }
    }
    return id;
}

static int nearest_contact(const WWorld& world, WVec position, float time) {
    const float bounds[6] = {position.x + 2, 14 - position.x, position.y + 5,
                             5 - position.y, position.z,      5 - position.z};
    int id = 1000 + int(std::min_element(bounds, bounds + 6) - bounds);
    float best = *std::min_element(bounds, bounds + 6) - .18f;
    for (uint j = 0; j < world.count; j++) {
        WWorld single = world;
        single.count = 1;
        single.obstacles[0] = world.obstacles[j];
        const float distance = wclearance(single, position, time);
        if (distance < best) {
            best = distance;
            id = int(j);
        }
    }
    return id;
}

// ----------------------------------------------------------- episode state
struct EpisodeAgg {
    bool active = false;
    uint32_t episode_index = 0;
    uint32_t start_tick = 0;
    double reward_sum = 0, discounted = 0, gamma_power = 1.0;
    double progress_sum = 0, time_sum = 0, smooth_sum = 0;
    double formula_max_error = 0;
    float prev_distance = -1;
    float prev_u[4] = {0, 0, 0, 0};
    bool prev_u_valid = false;
    float peak_speed = 0, min_clearance = 12, terminal_speed = -1;
    float goal_dist_min = 12;
    uint32_t hold_ticks = 0;
    uint32_t ticks_observed = 0;
    // visibility, per episode
    std::vector<float> first_seen;   // obstacle ids
    std::array<float, 6> first_face_seen{};
    int blocker_id = -1, collider_id = -1;
    float blocker_first_seen = -1, collider_first_seen = -1;
    float blocker_pooled_first_seen = -1;
    float goal_first_seen_blocker_ray = -1;  // LOS ray hit distance at t0, -1 clear
    void reset(uint32_t index, uint32_t tick, uint32_t obstacles) {
        active = true;
        episode_index = index;
        start_tick = tick;
        reward_sum = 0; discounted = 0; gamma_power = 1.0;
        progress_sum = 0; time_sum = 0; smooth_sum = 0; formula_max_error = 0;
        prev_distance = -1; prev_u_valid = false;
        peak_speed = 0; min_clearance = 12; terminal_speed = -1;
        goal_dist_min = 12; hold_ticks = 0; ticks_observed = 0;
        first_seen.assign(obstacles, -1.0f);
        first_face_seen.fill(-1.0f);
        blocker_id = -1; collider_id = -1;
        blocker_first_seen = -1; collider_first_seen = -1;
        blocker_pooled_first_seen = -1;
        goal_first_seen_blocker_ray = -1;
    }
};

struct FlightOptions {
    std::string bank_path;
    std::string out_prefix = "contract-flight";
    uint32_t mode = 17;
    std::string controller = "policy";  // policy | blind | hover | witness
    uint32_t envs = 128;
    uint32_t ticks = 3200;
    uint32_t trace_envs = 8;
    uint32_t seed = 700001;
    float speed = 1.5f;
    float time_cost = 0.2f;
    float gamma = 0.99f;
    std::string checkpoint;
    std::string opening_csv;   // witness controller: per-(env,slot) first bend
};

static FlightOptions parse_options(int argc, char** argv, int first) {
    FlightOptions options;
    options.checkpoint = argv[first];
    options.out_prefix = argv[first + 1];
    for (int i = first + 2; i < argc; i++) {
        const std::string key = argv[i];
        auto value = [&]() -> std::string {
            require(i + 1 < argc, "missing value for " + key);
            return argv[++i];
        };
        if (key == "--bank") options.bank_path = value();
        else if (key == "--mode") options.mode = uint32_t(std::stoul(value()));
        else if (key == "--controller") options.controller = value();
        else if (key == "--envs") options.envs = uint32_t(std::stoul(value()));
        else if (key == "--ticks") options.ticks = uint32_t(std::stoul(value()));
        else if (key == "--trace-envs") options.trace_envs = uint32_t(std::stoul(value()));
        else if (key == "--seed") options.seed = uint32_t(std::stoul(value()));
        else if (key == "--speed") options.speed = std::stof(value());
        else if (key == "--time-cost") options.time_cost = std::stof(value());
        else if (key == "--gamma") options.gamma = std::stof(value());
        else if (key == "--opening-csv") options.opening_csv = value();
        else throw std::runtime_error("unknown contract-flight option " + key);
    }
    require(!options.bank_path.empty(), "--bank is required (kept bank file)");
    require(options.controller == "policy" || options.controller == "blind" ||
                options.controller == "hover" || options.controller == "witness",
            "--controller must be policy|blind|hover|witness");
    if (options.controller == "witness" && !options.opening_csv.empty())
        require(std::filesystem::exists(options.opening_csv),
                "opening csv not found: " + options.opening_csv);
    return options;
}

// First-bend labels for the witness controller, one row per (env, slot) for
// blocked tasks: env,slot,opening_x,opening_y,opening_z. Direct tasks and
// absent rows fall back to targeting the goal directly.
struct OpeningBend { float xyz[3]; bool valid = false; };

static std::vector<OpeningBend> load_openings(const std::string& path,
                                              uint32_t envs, uint32_t period) {
    std::vector<OpeningBend> bends(size_t(envs) * period);
    if (path.empty()) return bends;
    std::ifstream file(path);
    require(bool(file), "cannot open opening csv " + path);
    std::string line;
    require(bool(std::getline(file, line)), "empty opening csv");
    std::vector<std::string> header;
    std::stringstream ss(line);
    std::string cell;
    while (std::getline(ss, cell, ',')) header.push_back(cell);
    auto col = [&](const std::string& name) -> int {
        for (size_t i = 0; i < header.size(); i++)
            if (header[i] == name) return int(i);
        return -1;
    };
    const int c_env = col("env"), c_slot = col("slot");
    const int c_x = col("opening_x"), c_y = col("opening_y"), c_z = col("opening_z");
    require(c_env >= 0 && c_slot >= 0 && c_x >= 0 && c_y >= 0 && c_z >= 0,
            "opening csv must declare env,slot,opening_x,opening_y,opening_z");
    size_t rows = 0;
    while (std::getline(file, line)) {
        if (line.empty()) continue;
        std::stringstream rs(line);
        std::vector<std::string> fields;
        while (std::getline(rs, cell, ',')) fields.push_back(cell);
        if (fields.size() < header.size()) continue;
        const uint32_t env = uint32_t(std::stoul(fields[c_env]));
        const uint32_t slot = uint32_t(std::stoul(fields[c_slot]));
        if (env >= envs || slot >= period) continue;
        OpeningBend& bend = bends[size_t(env) * period + slot];
        bend.xyz[0] = std::stof(fields[c_x]);
        bend.xyz[1] = std::stof(fields[c_y]);
        bend.xyz[2] = std::stof(fields[c_z]);
        bend.valid = true;
        rows++;
    }
    std::cout << "opening_csv " << path << " rows=" << rows << "\n";
    return bends;
}

static float distance_to(const waypoint::BankEntry& entry, const float* position) {
    float d2 = 0;
    for (int axis = 0; axis < 3; axis++) {
        const float delta = entry.goal_position[axis] - position[axis];
        d2 += delta * delta;
    }
    return std::sqrt(d2);
}

// Goal grounding at the selection pose (yaw-only orientation from the bank).
static bool goal_in_fov(const waypoint::BankEntry& entry, float& bearing_deg) {
    const float delta[3] = {entry.goal_position[0] - entry.start_position[0],
                            entry.goal_position[1] - entry.start_position[1],
                            entry.goal_position[2] - entry.start_position[2]};
    const float distance = std::max(entry.initial_distance, 1e-6f);
    const float cy = std::cos(entry.start_yaw), sy = std::sin(entry.start_yaw);
    const float bx = cy * delta[0] + sy * delta[1];
    const float by = -sy * delta[0] + cy * delta[1];
    const float bz = delta[2];
    bearing_deg = std::acos(std::max(-1.0f, std::min(1.0f, bx / distance))) * 57.2957795f;
    return bx > 0 && std::fabs(by) <= NAV_SENSOR_TAN_H * bx &&
           std::fabs(bz) <= NAV_SENSOR_ACTIVE_TAN_V * bx;
}

static int command_flight(int argc, char** argv) {
    FlightOptions options = parse_options(argc, argv, 2);
    const bool hover = options.controller == "hover";
    const bool blind = options.controller == "blind";
    const bool witness = options.controller == "witness";
    std::vector<OpeningBend> opening_bends;

    waypoint::BankControl control{};
    std::string bank_hash;
    const auto bank = waypoint::read_bank(options.bank_path, control, bank_hash);
    require(control.count == size_t(options.envs) * control.period,
            "bank count does not match --envs * period");
    require(control.count % control.period == 0, "bank count not a multiple of period");
    if (witness)
        opening_bends = load_openings(options.opening_csv, options.envs, control.period);
    for (const auto& entry : bank)
        for (uint j = 0; j < entry.world.count; j++)
            for (float velocity : entry.world.obstacles[j].velocity)
                require(velocity == 0, "contract flight probe requires static geometry");

    Metal metal;
    metal.compile(base_source() + PPO_TRAINER_MSL + waypoint::kWaypointKernels +
                  kContractKernels);
    auto zero_actions = metal.pipeline("contract_zero_actions");
    auto zero_prior = metal.pipeline("contract_zero_prior");

    SimConfig config;
    config.n = options.envs;
    config.mode = hover ? 17 : options.mode;  // hover zeroes the mode-17 map
    config.family = 0;
    config.eval = 0;  // auto-reset cycling so every bank slot flies
    config.seed = options.seed;
    config.speed = options.speed;
    config.distance = 4;
    config.max_steps = 400;
    config.geometry_memory = 1;
    Sim sim(metal, config, 32);
    navigation_training::load_actor(sim, options.checkpoint, false);

    waypoint::LocalRun run = waypoint::make_local_run(
        sim, bank, control, metal.pipeline("waypoint_task_apply"), options.time_cost);
    auto probe = [metal.queue commandBuffer];
    waypoint::local_probe(run, probe);
    metal.finish(probe);
    waypoint::verify_reset(run, bank, control, true);
    const NavigationTaskConfig& recipe =
        ((const NavigationTaskControl*)sim.task_control.contents)->config;

    const std::filesystem::path destination(options.out_prefix);
    if (destination.has_parent_path())
        std::filesystem::create_directories(destination.parent_path());
    std::ofstream episodes_csv(options.out_prefix + "-episodes.csv");
    require(bool(episodes_csv), "cannot write " + options.out_prefix + "-episodes.csv");
    episodes_csv << std::setprecision(9);
    episodes_csv << "spec,controller,mode,env,episode_index,slot,family,family_name,"
                    "scene_seed,route_class,success,collision,timeout,time_s,path_m,"
                    "mean_speed_mps,peak_speed_mps,min_clearance_m,terminal_speed_pre,"
                    "hold_ticks_observed,ticks_observed,reward_sum,reward_disc099,"
                    "reward_progress,reward_time,reward_smooth,formula_max_err,"
                    "goal_dist_min_m,goal_fov_t0,goal_bearing_deg,"
                    "goal_los_blocker_id,blocker_id,blocker_first_seen_s,"
                    "blocker_pooled_first_seen_s,collider_id,collider_first_seen_s,"
                    "warning_s,start_speed_mps\n";
    std::ofstream ticks_csv;
    if (options.trace_envs > 0) {
        ticks_csv.open(options.out_prefix + "-ticks.csv");
        require(bool(ticks_csv), "cannot write " + options.out_prefix + "-ticks.csv");
        ticks_csv << std::setprecision(9);
        ticks_csv << "tick,env,episode_index,slot,steps,time_s,x,y,z,vx,vy,vz,speed,yaw,"
                     "goal_distance_m,clearance_m,reward,stable_time_s,terminal\n";
    }

    const auto* worlds = (const WWorld*)sim.worlds.contents;
    std::vector<EpisodeAgg> aggs(options.envs);
    for (uint32_t env = 0; env < options.envs; env++) {
        const waypoint::BankEntry& entry = bank[size_t(env) * control.period];
        aggs[env].reset(0, 0, entry.world.count);
        aggs[env].prev_distance = entry.initial_distance;
        aggs[env].prev_u[0] = entry.start_velocity[0];
        aggs[env].prev_u[1] = entry.start_velocity[1];
        aggs[env].prev_u[2] = entry.start_velocity[2];
        aggs[env].prev_u[3] = 0;
        aggs[env].prev_u_valid = true;
        if (entry.route_class == 1) {
            const float goal_vec[3] = {entry.goal_position[0] - entry.start_position[0],
                                       entry.goal_position[1] - entry.start_position[1],
                                       entry.goal_position[2] - entry.start_position[2]};
            const float d = std::max(entry.initial_distance, 1e-6f);
            float range;
            aggs[env].blocker_id = first_hit(
                entry.world, wv(entry.start_position[0], entry.start_position[1],
                                entry.start_position[2]),
                wv(goal_vec[0] / d, goal_vec[1] / d, goal_vec[2] / d), 0.0f, range);
        }
    }

    double wall_started = seconds();
    float max_ray_error = 0;
    std::string max_ray_detail;
    double max_formula_error = 0;
    uint64_t episodes_done = 0, successes = 0, collisions = 0, timeouts = 0;
    uint32_t min_env_episodes = 0xffffffffu;

    const uint32_t horizon = sim.horizon;
    for (uint32_t step = 0; step < options.ticks; step++) {
        const uint32_t tick = sim.cfg.tick + step;
        // Pre-tick snapshot: state of the currently flying episode.
        const auto* runs_before = (const SimRun*)sim.runs.contents;
        const auto* states_before = (const RLPhysicsState*)sim.states.contents;
        std::vector<uint32_t> ep_before(options.envs), steps_before(options.envs);
        std::vector<float> elapsed_before(options.envs), path_before(options.envs);
        std::vector<uint32_t> succ_before(options.envs), coll_before(options.envs),
            timeout_before(options.envs);
        std::vector<float> total_time_before(options.envs), total_path_before(options.envs);
        for (uint32_t env = 0; env < options.envs; env++) {
            ep_before[env] = runs_before[env].episodes;
            steps_before[env] = runs_before[env].steps;
            elapsed_before[env] = runs_before[env].elapsed;
            path_before[env] = runs_before[env].path;
            succ_before[env] = runs_before[env].successes;
            coll_before[env] = runs_before[env].collisions;
            timeout_before[env] = runs_before[env].timeouts;
            total_time_before[env] = runs_before[env].total_elapsed;
            total_path_before[env] = runs_before[env].total_path;
        }
        const std::vector<WWorld> worlds_before(
            (const WWorld*)sim.worlds.contents,
            (const WWorld*)sim.worlds.contents + options.envs);
        const std::vector<RLPhysicsState> states_snapshot(
            states_before, states_before + options.envs);

        // One navigation tick; hover inserts zero-command kernels, the
        // witness controller runs host-side (no actor/act path).
        auto cb = [metal.queue commandBuffer];
        if (!hover && !witness) {
            waypoint::local_tick(run, cb, tick, step == 0);
        } else if (hover) {
            Sim& sim_ref = run.sim;
            auto c = sim_ref.configs[tick % sim_ref.horizon];
            if (step == 0)
                sim_ref.m.dispatch(cb, run.apply_pipeline, sim_ref.cfg.n,
                                   {sim_ref.states, sim_ref.runs, sim_ref.worlds,
                                    sim_ref.task_states, run.bank, run.bank_control,
                                    sim_ref.task_control, c},
                                   64);
            sim_ref.m.dispatch(cb, sim_ref.depth_p, sim_ref.cfg.n * 320,
                               {sim_ref.states, sim_ref.runs, sim_ref.worlds,
                                sim_ref.sensors, sim_ref.physics, c, sim_ref.poses});
            if (sim_ref.cfg.geometry_memory) {
                sim_ref.m.dispatch(cb, sim_ref.memory_points_p, sim_ref.cfg.n * 640,
                                   {sim_ref.states, sim_ref.runs, sim_ref.sensors,
                                    sim_ref.poses, sim_ref.memory_points,
                                    sim_ref.physics, c});
                sim_ref.m.dispatch(cb, sim_ref.memory_candidates_p, sim_ref.cfg.n * 85,
                                   {sim_ref.states, sim_ref.worlds,
                                    sim_ref.memory_points, sim_ref.memory_clearances, c});
            }
            sim_ref.m.dispatch(cb, sim_ref.observe_p, sim_ref.cfg.n,
                               {sim_ref.states, sim_ref.runs, sim_ref.worlds,
                                sim_ref.sensors, sim_ref.obs, sim_ref.co, sim_ref.physics,
                                c, sim_ref.poses, sim_ref.memory_clearances},
                               64);
            const size_t row_offset = size_t(tick % sim_ref.horizon) * sim_ref.cfg.n;
            encode(sim_ref.m, cb,
                   sim_ref.simd_actor ? "ppo_actor_forward_simd_fused"
                                      : "ppo_actor_forward",
                   sim_ref.simd_actor ? ((size_t(sim_ref.cfg.n) + 7) / 8) * 256
                                      : sim_ref.cfg.n,
                   {{sim_ref.obs, row_offset * fixed_ppo::actor_obs_dim * 4},
                    {sim_ref.actor, 0},
                    {sim_ref.actor_workspace, 0},
                    {sim_ref.actions, row_offset * fixed_ppo::action_dim * 4},
                    {sim_ref.env_count, 0}},
                   sim_ref.simd_actor ? 256 : 64);
            sim_ref.m.dispatch(cb, zero_actions, sim_ref.cfg.n * 4,
                               {sim_ref.actions, c}, 64);
            sim_ref.m.dispatch(cb, zero_prior, sim_ref.cfg.n * 3,
                               {sim_ref.obs, c}, 64);
            sim_ref.m.dispatch(cb, sim_ref.act_p, sim_ref.cfg.n,
                               {sim_ref.states, sim_ref.runs, sim_ref.worlds,
                                sim_ref.obs, sim_ref.co, sim_ref.actor, sim_ref.critic,
                                sim_ref.actions, sim_ref.logp, sim_ref.values,
                                sim_ref.commands, sim_ref.physics, c},
                               64);
            sim_ref.m.dispatch(cb, sim_ref.advance_p, sim_ref.cfg.n,
                               {sim_ref.states, sim_ref.runs, sim_ref.worlds,
                                sim_ref.sensors, sim_ref.commands, sim_ref.raptor,
                                sim_ref.critic, sim_ref.rewards, sim_ref.next_values,
                                sim_ref.terminated, sim_ref.truncated, sim_ref.physics, c,
                                sim_ref.bank_worlds, sim_ref.bank_schedule,
                                sim_ref.bank_control, sim_ref.bank_active_ids,
                                sim_ref.bank_transition_ids, sim_ref.environment_physics,
                                sim_ref.runtime_control, sim_ref.task_states,
                                sim_ref.task_control, sim_ref.potential_fields,
                                sim_ref.potential_spec, sim_ref.potential_control},
                               64);
            sim_ref.m.dispatch(cb, run.apply_pipeline, sim_ref.cfg.n,
                               {sim_ref.states, sim_ref.runs, sim_ref.worlds,
                                sim_ref.task_states, run.bank, run.bank_control,
                                sim_ref.task_control, c},
                               64);
        } else {
            // Witness controller (independent physical/time feasibility
            // probe): sense for visibility records, then compute a
            // two-segment proportional follower on the host from the
            // pre-tick state and write the executed command the way the
            // learner's teacher override does: previous_nav (body
            // fractions), desired_velocity (world), yaw reference and the
            // command ring. Target = first bend (blocked tasks, from the
            // opening CSV) until within the goal radius of it, then the
            // goal; speed = clamp(1.2 * distance, 0, 1.5); yaw command =
            // clamp(4 * bearing, +-1) -> +-0.5 rad/s reference rate.
            // Command fractions use the yaw-reference frame (roll/pitch
            // ignored); the plant receives desired_velocity exactly, so the
            // frame note affects records only.
            Sim& sim_ref = run.sim;
            auto c = sim_ref.configs[tick % sim_ref.horizon];
            if (step == 0)
                sim_ref.m.dispatch(cb, run.apply_pipeline, sim_ref.cfg.n,
                                   {sim_ref.states, sim_ref.runs, sim_ref.worlds,
                                    sim_ref.task_states, run.bank, run.bank_control,
                                    sim_ref.task_control, c},
                                   64);
            sim_ref.m.dispatch(cb, sim_ref.depth_p, sim_ref.cfg.n * 320,
                               {sim_ref.states, sim_ref.runs, sim_ref.worlds,
                                sim_ref.sensors, sim_ref.physics, c, sim_ref.poses});
            // Finish before host writes to SimRun: the depth kernel reads it.
            metal.finish(cb);
            SimRun* runs_host = (SimRun*)sim.runs.contents;
            float* ring_all = (float*)sim.commands.contents;
            for (uint32_t env = 0; env < options.envs; env++) {
                const uint32_t slot = ep_before[env] % control.period;
                const waypoint::BankEntry& entry =
                    bank[size_t(env) * control.period + slot];
                float target[3] = {entry.goal_position[0], entry.goal_position[1],
                                   entry.goal_position[2]};
                if (entry.route_class == 1) {
                    const OpeningBend& bend =
                        opening_bends[size_t(env) * control.period + slot];
                    if (bend.valid) {
                        float to_bend[3] = {bend.xyz[0] - states_snapshot[env].position[0],
                                            bend.xyz[1] - states_snapshot[env].position[1],
                                            bend.xyz[2] - states_snapshot[env].position[2]};
                        const float bend_distance =
                            std::sqrt(to_bend[0] * to_bend[0] + to_bend[1] * to_bend[1] +
                                      to_bend[2] * to_bend[2]);
                        if (bend_distance > 0.35f)
                            std::copy(bend.xyz, bend.xyz + 3, target);
                    }
                }
                float delta[3] = {target[0] - states_snapshot[env].position[0],
                                  target[1] - states_snapshot[env].position[1],
                                  target[2] - states_snapshot[env].position[2]};
                const float distance =
                    std::sqrt(delta[0] * delta[0] + delta[1] * delta[1] + delta[2] * delta[2]);
                const float speed_t = std::max(0.0f, std::min(1.5f, 1.2f * distance));
                float world_v[3] = {0, 0, 0};
                if (distance > 1e-6f)
                    for (int axis = 0; axis < 3; axis++)
                        world_v[axis] = delta[axis] / distance * speed_t;
                const float yaw_now = runs_host[env].yaw;
                const float target_yaw =
                    std::atan2(target[1] - states_snapshot[env].position[1],
                               target[0] - states_snapshot[env].position[0]);
                const float bearing = std::remainder(target_yaw - yaw_now, 2 * M_PI);
                const float yaw_cmd = std::max(-1.0f, std::min(1.0f, 4.0f * bearing));
                const float cy = std::cos(yaw_now), sy = std::sin(yaw_now);
                const float body[4] = {
                    (cy * world_v[0] + sy * world_v[1]) / options.speed,
                    (-sy * world_v[0] + cy * world_v[1]) / options.speed,
                    world_v[2] / options.speed, yaw_cmd};
                for (int axis = 0; axis < 3; axis++) {
                    runs_host[env].previous_nav[axis] = body[axis];
                    runs_host[env].desired_velocity[axis] = world_v[axis];
                }
                runs_host[env].previous_nav[3] = yaw_cmd;
                runs_host[env].yaw = yaw_now + yaw_cmd * 0.025f;
                float* ring = ring_all + (size_t(env) * 8 + runs_host[env].steps % 8) * 4;
                for (int axis = 0; axis < 4; axis++) ring[axis] = body[axis];
            }
            // A finished command buffer cannot be appended to; advance runs
            // in a fresh one.
            cb = [metal.queue commandBuffer];
            sim_ref.m.dispatch(cb, sim_ref.advance_p, sim_ref.cfg.n,
                               {sim_ref.states, sim_ref.runs, sim_ref.worlds,
                                sim_ref.sensors, sim_ref.commands, sim_ref.raptor,
                                sim_ref.critic, sim_ref.rewards, sim_ref.next_values,
                                sim_ref.terminated, sim_ref.truncated, sim_ref.physics, c,
                                sim_ref.bank_worlds, sim_ref.bank_schedule,
                                sim_ref.bank_control, sim_ref.bank_active_ids,
                                sim_ref.bank_transition_ids, sim_ref.environment_physics,
                                sim_ref.runtime_control, sim_ref.task_states,
                                sim_ref.task_control, sim_ref.potential_fields,
                                sim_ref.potential_spec, sim_ref.potential_control},
                               64);
            sim_ref.m.dispatch(cb, run.apply_pipeline, sim_ref.cfg.n,
                               {sim_ref.states, sim_ref.runs, sim_ref.worlds,
                                sim_ref.task_states, run.bank, run.bank_control,
                                sim_ref.task_control, c},
                               64);
        }
        metal.finish(cb);

        const auto* runs_after = (const SimRun*)sim.runs.contents;
        const auto* states_after = (const RLPhysicsState*)sim.states.contents;
        const auto* tasks_after = (const NavigationTaskState*)sim.task_states.contents;
        const float* rewards = (const float*)sim.rewards.contents;
        const float* sensors = (const float*)sim.sensors.contents;
        const float* poses = (const float*)sim.poses.contents;
        const uint32_t reward_row = (tick % horizon) * options.envs;

        for (uint32_t env = 0; env < options.envs; env++) {
            EpisodeAgg& agg = aggs[env];
            const uint32_t episode_index = ep_before[env];
            const bool flying = episode_index < control.period;
            const float reward = rewards[reward_row + env];
            const bool terminal = runs_after[env].episodes != episode_index;

            // ---- sensor evidence while the episode is flying (rays were cast
            // at the pre-tick pose with frame = pre-tick steps % 8). Terminal
            // ticks are excluded: sim_reset_one overwrites all sensor frames
            // with 12 m inside the same command buffer, so the terminal tick's
            // measured rays are already destroyed when the host reads them.
            // Warning times are therefore conservative by at most one tick.
            if (flying && agg.active && !terminal) {
                const uint32_t frame = steps_before[env] % 8;
                const float* pose = poses + (env * 8 + frame) * 12;
                const float* ranges = sensors + (env * 8 + frame) * 320;
                const float time = float(steps_before[env]) * 0.05f;
                std::array<int, 320> ids{};
                for (uint32_t pixel = 0; pixel < 320; pixel++) {
                    const WVec ray = nav_sensor_pixel_ray(NAV_SENSOR_TAN_H,
                                                          NAV_SENSOR_ACTIVE_TAN_V, pixel);
                    const WVec direction =
                        wv(pose[3] * ray.x + pose[4] * ray.y + pose[5] * ray.z,
                           pose[6] * ray.x + pose[7] * ray.y + pose[8] * ray.z,
                           pose[9] * ray.x + pose[10] * ray.y + pose[11] * ray.z);
                    float expected;
                    ids[pixel] = first_hit(worlds_before[env],
                                           wv(pose[0], pose[1], pose[2]), direction, time,
                                           expected);
                    const float ray_error = std::fabs(expected - ranges[pixel]);
                    if (ray_error > max_ray_error) {
                        max_ray_error = ray_error;
                        std::ostringstream detail;
                        detail << std::setprecision(9)
                               << "env=" << env << " tick=" << tick
                               << " steps=" << steps_before[env]
                               << " episode=" << episode_index << " pixel=" << pixel
                               << " frame=" << (steps_before[env] % 8)
                               << " expected=" << expected
                               << " host_wray="
                               << wray(worlds_before[env],
                                       wv(pose[0], pose[1], pose[2]), direction, time)
                               << " measured=" << ranges[pixel]
                               << " count=" << worlds_before[env].count
                               << " pos=" << pose[0] << "," << pose[1] << "," << pose[2]
                               << " dir=" << direction.x << "," << direction.y << ","
                               << direction.z;
                        for (uint j = 0; j < worlds_before[env].count; j++) {
                            const auto& o = worlds_before[env].obstacles[j];
                            detail << " o" << j << "(k" << o.kind << ",c" << o.center[0]
                                   << "," << o.center[1] << "," << o.center[2] << ",s"
                                   << o.size[0] << "," << o.size[1] << "," << o.size[2]
                                   << ")";
                        }
                        max_ray_detail = detail.str();
                    }
                    if (ids[pixel] < 0) continue;
                    const float seen = float(steps_before[env]) * 0.05f;
                    if (ids[pixel] >= 1000) {
                        int face = ids[pixel] - 1000;
                        if (agg.first_face_seen[face] < 0) agg.first_face_seen[face] = seen;
                    } else if (size_t(ids[pixel]) < agg.first_seen.size() &&
                               agg.first_seen[ids[pixel]] < 0) {
                        agg.first_seen[ids[pixel]] = seen;
                    }
                    if (ids[pixel] == agg.blocker_id && agg.blocker_first_seen < 0)
                        agg.blocker_first_seen = seen;
                }
                // pooled 80-bin view: min measured range in each 2x2 block
                for (uint32_t cell = 0; cell < 80; cell++) {
                    const uint32_t pixel = (cell / 10) * 40 + (cell % 10) * 2;
                    uint32_t hit = pixel;
                    for (uint32_t candidate : {pixel + 1u, pixel + 20u, pixel + 21u})
                        if (ranges[candidate] < ranges[hit]) hit = candidate;
                    if (ids[hit] == agg.blocker_id && agg.blocker_pooled_first_seen < 0)
                        agg.blocker_pooled_first_seen = float(steps_before[env]) * 0.05f;
                }
            }

            // ---- trace rows for the declared representative subset (state
            // from the pre-tick snapshot, valid also on the terminal tick).
            if (ticks_csv.is_open() && env < options.trace_envs && flying) {
                const RLPhysicsState& state = states_snapshot[env];
                float distance = distance_to(bank[size_t(env) * control.period +
                                                  (episode_index % control.period)],
                                             state.position);
                float speed2 = 0;
                for (int axis = 0; axis < 3; axis++)
                    speed2 += state.linear_velocity[axis] * state.linear_velocity[axis];
                const float clearance =
                    wclearance(worlds_before[env],
                               wv(state.position[0], state.position[1], state.position[2]),
                               runs_before[env].elapsed);
                ticks_csv << tick << ',' << env << ',' << agg.episode_index << ','
                          << (episode_index % control.period) << ','
                          << steps_before[env] << ',' << runs_before[env].elapsed;
                for (int axis = 0; axis < 3; axis++) ticks_csv << ',' << state.position[axis];
                for (int axis = 0; axis < 3; axis++)
                    ticks_csv << ',' << state.linear_velocity[axis];
                ticks_csv << ',' << std::sqrt(speed2) << ',' << runs_before[env].yaw;
                ticks_csv << ',' << distance << ',' << clearance << ',' << reward << ','
                          << tasks_after[env].stable_time_s << ',' << (terminal ? 1 : 0)
                          << '\n';
            }

            if (!flying || !agg.active) continue;

            // ---- ground-truth reward every tick (simulator reward buffer).
            agg.reward_sum += reward;
            agg.discounted += agg.gamma_power * reward;
            agg.gamma_power *= options.gamma;
            agg.ticks_observed++;
            // Time cost is state-independent, so it accumulates on every tick
            // including the terminal one: time-cost reweighting in later
            // analysis then only has to replace the single terminal time term
            // inside terminal_reward (= reward_sum - components).
            agg.time_sum += -double(recipe.time_cost_per_s) * recipe.nav_period_s;

            if (terminal) {
                // The post-tick state belongs to the next episode. Keep the
                // pre-tick approach speed; the terminal tick's progress and
                // smoothness split stays folded into terminal_reward, which
                // the analysis derives exactly from reward_sum - components.
                const RLPhysicsState& before_state = states_snapshot[env];
                float terminal_speed2 = 0;
                for (int axis = 0; axis < 3; axis++)
                    terminal_speed2 += before_state.linear_velocity[axis] *
                                       before_state.linear_velocity[axis];
                agg.terminal_speed = std::sqrt(terminal_speed2);
            } else {
                // The contract evaluates progress, hold and clearance against
                // the POST-advance state; use it so the reconstruction is
                // tick-aligned with navigation_task_step.
                const RLPhysicsState& state = states_after[env];
                const waypoint::BankEntry& entry =
                    bank[size_t(env) * control.period +
                         (episode_index % control.period)];
                const float distance_now = distance_to(entry, state.position);
                float speed2 = 0;
                for (int axis = 0; axis < 3; axis++)
                    speed2 += state.linear_velocity[axis] * state.linear_velocity[axis];
                const float speed_now = std::sqrt(speed2);
                const float clearance_now =
                    wclearance(worlds_before[env],
                               wv(state.position[0], state.position[1],
                                  state.position[2]),
                               runs_after[env].elapsed);

                agg.peak_speed = std::max(agg.peak_speed, speed_now);
                agg.min_clearance = std::min(agg.min_clearance, clearance_now);
                agg.goal_dist_min = std::min(agg.goal_dist_min, distance_now);
                if (distance_now <= recipe.goal_radius_m &&
                    speed_now <= recipe.stable_speed_mps)
                    agg.hold_ticks++;
                const float progress = agg.prev_distance - distance_now;
                const float u_now[4] = {
                    runs_after[env].desired_velocity[0],
                    runs_after[env].desired_velocity[1],
                    runs_after[env].desired_velocity[2],
                    runs_after[env].previous_nav[3] * 0.5f};
                float du2 = 0;
                if (agg.prev_u_valid)
                    for (int axis = 0; axis < 4; axis++) {
                        const float d = u_now[axis] - agg.prev_u[axis];
                        du2 += d * d;
                    }
                const double progress_term = recipe.progress_reward_per_m * progress;
                const double time_term =
                    -double(recipe.time_cost_per_s) * recipe.nav_period_s;
                const double smooth_term =
                    -double(recipe.command_smoothness_weight) * du2 *
                    recipe.nav_period_s;
                const double formula = progress_term + time_term + smooth_term;
                agg.progress_sum += progress_term;
                agg.smooth_sum += smooth_term;
                agg.formula_max_error =
                    std::max(agg.formula_max_error, std::fabs(formula - reward));
                max_formula_error = std::max(max_formula_error, agg.formula_max_error);
                for (int axis = 0; axis < 4; axis++) agg.prev_u[axis] = u_now[axis];
                agg.prev_u_valid = true;
                agg.prev_distance = distance_now;
            }

            // ---- terminal: close the episode from cumulative deltas.
            if (terminal) {
                const waypoint::BankEntry& entry =
                    bank[size_t(env) * control.period + (episode_index % control.period)];
                const bool success = runs_after[env].successes != succ_before[env];
                const bool collision = runs_after[env].collisions != coll_before[env];
                const bool timeout = runs_after[env].timeouts != timeout_before[env];
                const float time_s =
                    runs_after[env].total_elapsed - total_time_before[env];
                const float path_m = runs_after[env].total_path - total_path_before[env];
                const int collider =
                    collision ? nearest_contact(worlds_before[env],
                                                wv(states_snapshot[env].position[0],
                                                   states_snapshot[env].position[1],
                                                   states_snapshot[env].position[2]),
                                                runs_before[env].elapsed)
                              : -1;
                float collider_first = -1;
                if (collider >= 0) {
                    if (collider >= 1000)
                        collider_first = agg.first_face_seen[collider - 1000];
                    else if (size_t(collider) < agg.first_seen.size())
                        collider_first = agg.first_seen[collider];
                }
                float bearing = -1;
                const bool fov = goal_in_fov(entry, bearing);
                const float start[3] = {entry.start_position[0], entry.start_position[1],
                                        entry.start_position[2]};
                const float goal_vec[3] = {entry.goal_position[0] - start[0],
                                           entry.goal_position[1] - start[1],
                                           entry.goal_position[2] - start[2]};
                const float goal_distance =
                    std::max(entry.initial_distance, 1e-6f);
                const WVec direction = wv(goal_vec[0] / goal_distance,
                                          goal_vec[1] / goal_distance,
                                          goal_vec[2] / goal_distance);
                float los_range;
                const int los_blocker =
                    first_hit(worlds_before[env], wv(start[0], start[1], start[2]),
                              direction, 0.0f, los_range);
                const int blocker =
                    entry.route_class == 1
                        ? first_hit(worlds_before[env],
                                    wv(start[0], start[1], start[2]), direction, 0.0f,
                                    los_range)
                        : -1;
                (void)los_blocker;
                const float warning =
                    collider >= 0 && agg.collider_first_seen >= 0
                        ? time_s - agg.collider_first_seen
                        : -1;
                episodes_csv << "contract," << options.controller << ',' << options.mode
                             << ',' << env << ',' << agg.episode_index << ','
                             << (episode_index % control.period) << ',' << entry.family
                             << ',' << waypoint::family_name(entry.family) << ','
                             << entry.scene_seed << ',' << entry.route_class << ','
                             << (success ? 1 : 0) << ',' << (collision ? 1 : 0) << ','
                             << (timeout ? 1 : 0) << ',' << time_s << ',' << path_m
                             << ',' << (time_s > 1e-6 ? path_m / time_s : 0) << ','
                             << agg.peak_speed << ',' << agg.min_clearance << ','
                             << agg.terminal_speed << ',' << agg.hold_ticks << ','
                             << agg.ticks_observed << ',' << agg.reward_sum << ','
                             << agg.discounted << ',' << agg.progress_sum << ','
                             << agg.time_sum << ',' << agg.smooth_sum << ','
                             << agg.formula_max_error << ',' << agg.goal_dist_min << ','
                             << (fov ? 1 : 0) << ',' << bearing << ','
                             << (los_range < goal_distance - 0.05f && los_blocker >= 0
                                     ? los_blocker
                                     : -1)
                             << ',' << blocker << ',' << agg.blocker_first_seen << ','
                             << agg.blocker_pooled_first_seen << ',' << collider << ','
                             << collider_first << ','
                             << warning << ','
                             << std::sqrt(entry.start_velocity[0] * entry.start_velocity[0] +
                                          entry.start_velocity[1] * entry.start_velocity[1] +
                                          entry.start_velocity[2] * entry.start_velocity[2])
                             << '\n';
                episodes_done++;
                successes += success;
                collisions += collision;
                timeouts += timeout;
                const uint32_t next_index = episode_index + 1;
                const waypoint::BankEntry& next_entry =
                    bank[size_t(env) * control.period + (next_index % control.period)];
                agg.reset(next_index, tick, next_entry.world.count);
                // Seed the contract-formula reconstruction for the next episode.
                agg.prev_distance = next_entry.initial_distance;
                agg.prev_u[0] = next_entry.start_velocity[0];
                agg.prev_u[1] = next_entry.start_velocity[1];
                agg.prev_u[2] = next_entry.start_velocity[2];
                agg.prev_u[3] = 0;
                agg.prev_u_valid = true;
                if (next_entry.route_class == 1) {
                    const float nv[3] = {
                        next_entry.goal_position[0] - next_entry.start_position[0],
                        next_entry.goal_position[1] - next_entry.start_position[1],
                        next_entry.goal_position[2] - next_entry.start_position[2]};
                    const float nd = std::max(next_entry.initial_distance, 1e-6f);
                    float range;
                    agg.blocker_id = first_hit(
                        next_entry.world,
                        wv(next_entry.start_position[0], next_entry.start_position[1],
                           next_entry.start_position[2]),
                        wv(nv[0] / nd, nv[1] / nd, nv[2] / nd), 0.0f, range);
                }
            }
        }

        // Track completion coverage once every env has flown its slots.
        if (step + 1 == options.ticks) {
            for (uint32_t env = 0; env < options.envs; env++)
                min_env_episodes =
                    std::min(min_env_episodes, runs_after[env].episodes);
        }
    }

    const double wall = seconds() - wall_started;
    episodes_csv.flush();
    if (ticks_csv.is_open()) ticks_csv.flush();
    require(max_ray_error < 2e-4f,
            "ray attribution does not match measured GPU sensor (max err " +
                std::to_string(max_ray_error) + ") at " + max_ray_detail);
    require(min_env_episodes >= control.period,
            "not every environment completed all bank slots (min episodes " +
                std::to_string(min_env_episodes) + " of " +
                std::to_string(control.period) + ")");

    std::ostringstream summary;
    summary << std::setprecision(9);
    summary << "{\n"
            << " \"probe\": \"local_contract_probe\",\n"
            << " \"controller\": \"" << options.controller << "\",\n"
            << " \"mode\": " << options.mode << ",\n"
            << " \"bank\": \"" << options.bank_path << "\",\n"
            << " \"bank_entry_sha256\": \"" << bank_hash << "\",\n"
            << " \"checkpoint\": \"" << options.checkpoint << "\",\n"
            << " \"checkpoint_sha256\": \""
            << challenge_evaluation::sha256_file(options.checkpoint) << "\",\n"
            << " \"runner_sha256\": \"" << waypoint::contract_runner_sha256() << "\",\n"
            << " \"core_source_sha256\": \"" << waypoint::contract_core_sha256()
            << "\",\n"
            << " \"envs\": " << options.envs << ",\n"
            << " \"period\": " << control.period << ",\n"
            << " \"ticks\": " << options.ticks << ",\n"
            << " \"time_cost_per_s\": " << options.time_cost << ",\n"
            << " \"gamma\": " << options.gamma << ",\n"
            << " \"episodes_completed\": " << episodes_done << ",\n"
            << " \"successes\": " << successes << ",\n"
            << " \"collisions\": " << collisions << ",\n"
            << " \"timeouts\": " << timeouts << ",\n"
            << " \"min_episodes_per_env\": " << min_env_episodes << ",\n"
            << " \"max_ray_error_m\": " << max_ray_error << ",\n"
            << " \"max_formula_error\": " << max_formula_error << ",\n"
            << " \"wall_s\": " << wall << "\n}\n";
    {
        std::ofstream out(options.out_prefix + "-summary.json");
        require(bool(out), "cannot write summary");
        out << summary.str();
    }
    std::cout << "contract_flight controller=" << options.controller
              << " mode=" << options.mode << " episodes=" << episodes_done
              << " success=" << successes << " collision=" << collisions
              << " timeout=" << timeouts << " ray_err=" << max_ray_error
              << " formula_err=" << max_formula_error << " wall_s=" << wall << "\n";
    return 0;
}

}  // namespace contract

int main(int argc, char** argv) {
    try {
        std::setvbuf(stdout, nullptr, _IONBF, 0);
        if (argc < 3) {
            std::cerr << "usage: contract-flight CHECKPOINT OUT_PREFIX [--bank PATH ...]\n";
            return 2;
        }
        const std::string command = argv[1];
        if (command == "contract-flight") return contract::command_flight(argc, argv);
        std::cerr << "unknown command " << command << "\n";
        return 2;
    } catch (const std::exception& error) {
        std::cerr << "ERROR: " << error.what() << "\n";
        return 1;
    }
}
