#!/usr/bin/env python3
"""Independent flight-evidence verifier for the local task contract.

Consumes the per-flight and per-tick records written by
local_contract_probe.mm (actual RAPTOR flights) and produces:

  visibility-crosscheck.json  collider/first-sighting agreement with root's
                              published dev-a visibility audit (independent
                              protocol, independent code path)
  warning-evidence.json       TRAIN warning times, blocker/collider
                              observability classes, goal grounding at
                              selection (goal.md observability questions)
  braking-arrival.json        observed deceleration capability, stable-arrival
                              evidence, pass-through-without-hold instances,
                              time-budget margins

Every classification is derived from recorded fields only; thresholds are
declared in the output. Exit code 1 if a hard invariant fails.

Usage: python3 local_flight_evidence.py [--flights DIR] [--root DIR] [--out DIR]
"""

import argparse
import csv
import json
import math
import os
import statistics
from collections import Counter, defaultdict
from datetime import datetime, timezone

HARD_FAILURES = []


def fail(name, detail):
    HARD_FAILURES.append({"check": name, "detail": detail})
    print("flight_evidence FAIL %s %s" % (name, detail))


def ok(name, detail=""):
    print("flight_evidence PASS %s %s" % (name, detail))


def load(path):
    with open(path, newline="") as handle:
        return list(csv.DictReader(handle))


def fnum(row, key):
    try:
        return float(row[key])
    except (KeyError, ValueError):
        return float("nan")


def percentile(values, q):
    if not values:
        return float("nan")
    ordered = sorted(values)
    index = min(len(ordered) - 1, max(0, int(round(q * (len(ordered) - 1)))))
    return ordered[index]


# --------------------------------------------------------------- crosscheck
def visibility_crosscheck(flights, root_dir, out_dir):
    mine_path = os.path.join(flights, "deva-policy-episodes.csv")
    theirs_path = os.path.join(root_dir, "results", "navigation-visibility",
                               "public-results.csv")
    if not (os.path.exists(mine_path) and os.path.exists(theirs_path)):
        fail("visibility_inputs", "%s / %s" % (mine_path, theirs_path))
        return {}
    mine = {int(r["env"]): r for r in load(mine_path)}
    theirs = {int(r["env"]): r for r in load(theirs_path)}

    def their_geom(value):
        value = int(value)
        return value + 1000 if value >= 16 else value

    outcome_match = 0
    collider_match = 0
    first_seen_match = 0
    contact_rows = []
    for env in sorted(theirs):
        a, b = mine.get(env), theirs[env]
        if a is None:
            fail("crosscheck_env_present", "env %d missing in probe records" % env)
            continue
        same_outcome = ((a["success"], a["collision"], a["timeout"]) ==
                        (b["success"], b["collision"], b["timeout"]))
        outcome_match += same_outcome
        if int(b["contact_geometry_id"]) >= 0:
            same_geom = int(a["collider_id"]) == their_geom(b["contact_geometry_id"])
            collider_match += same_geom
            first_a, first_b = fnum(a, "collider_first_seen_s"), fnum(b, "first_raw_seen_s")
            same_first = abs(first_a - first_b) <= 0.051 or (first_a < 0 and first_b < 0)
            first_seen_match += same_first
            contact_rows.append({
                "env": env,
                "probe_collider": int(a["collider_id"]),
                "root_geometry": their_geom(b["contact_geometry_id"]),
                "probe_first_seen_s": first_a,
                "root_first_seen_s": first_b,
                "first_seen_match": same_first,
                "probe_unseen": first_a < 0,
                "root_unseen": first_b < 0,
            })
    unseen_mine = sum(1 for r in contact_rows if r["probe_unseen"])
    unseen_theirs = sum(1 for r in contact_rows if r["root_unseen"])
    result = {
        "generated_utc": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "mine": mine_path, "theirs": theirs_path,
        "tasks": len(theirs),
        "outcome_agreement": "%d/%d" % (outcome_match, len(theirs)),
        "contact_rows": len(contact_rows),
        "collider_agreement": "%d/%d" % (collider_match, len(contact_rows)),
        "first_seen_agreement": "%d/%d" % (first_seen_match, len(contact_rows)),
        "unseen_contacts_probe": unseen_mine,
        "unseen_contacts_root": unseen_theirs,
        "contacts": contact_rows,
        "protocol_note": ("probe uses non-eval auto-reset cycling and a "
                          "pre-terminal state snapshot; root's audit used eval "
                          "mode and the preserved final state"),
    }
    if outcome_match != len(theirs):
        fail("crosscheck_outcomes", result["outcome_agreement"])
    if collider_match != len(contact_rows):
        fail("crosscheck_colliders", result["collider_agreement"])
    if unseen_mine != unseen_theirs:
        fail("crosscheck_unseen_count", "%d vs %d" % (unseen_mine, unseen_theirs))
    if not HARD_FAILURES:
        ok("visibility_crosscheck", "%s outcomes, %s colliders, unseen %d"
           % (result["outcome_agreement"], result["collider_agreement"], unseen_mine))
    path = os.path.join(out_dir, "visibility-crosscheck.json")
    json.dump(result, open(path, "w"), indent=1, sort_keys=True)
    return result


# ------------------------------------------------------- warning + grounding
def warning_evidence(flights, out_dir, late_s=0.5, early_s=1.0):
    rows = load(os.path.join(flights, "source-policy-episodes.csv"))
    if len(rows) != 1024:
        fail("train_denominator", "%d rows, expected 1024" % len(rows))

    contacts = [r for r in rows if int(r["collision"]) == 1]
    detours = [r for r in rows if int(r["route_class"]) == 1]
    directs = [r for r in rows if int(r["route_class"]) == 0]

    def sighting_class(first_seen, duration):
        if first_seen < 0:
            return "never_seen"
        if first_seen > duration - late_s:
            return "seen_within_%.2fs_of_end" % late_s
        if first_seen >= early_s:
            return "seen_with_%+.1fs_warning" % early_s
        return "seen_but_under_%.1fs_warning" % early_s

    contact_classes = Counter()
    contact_detail = []
    for row in contacts:
        first = fnum(row, "collider_first_seen_s")
        duration = fnum(row, "time_s")
        cls = sighting_class(first, duration)
        contact_classes[cls] += 1
        contact_detail.append({
            "env": row["env"], "slot": row["slot"], "family": row["family_name"],
            "collider_id": int(row["collider_id"]), "first_seen_s": first,
            "warning_s": fnum(row, "warning_s"), "class": cls,
        })

    blocker_classes = Counter()
    blocker_seen = []
    for row in detours:
        first = fnum(row, "blocker_first_seen_s")
        if first < 0:
            blocker_classes["never_seen"] += 1
        elif first <= 0.25:
            blocker_classes["seen_from_start(<=0.25s)"] += 1
        else:
            blocker_classes["seen_later(>0.25s)"] += 1
        blocker_seen.append(first)
    pooled_unseen = sum(1 for r in detours if fnum(r, "blocker_pooled_first_seen_s") < 0)
    raw_unseen = sum(1 for r in detours if fnum(r, "blocker_first_seen_s") < 0)

    # Goal grounding at selection: in-FOV AND line-of-sight from the start pose.
    grounding = Counter()
    by_family = defaultdict(Counter)
    beyond_visible = 0
    occluded_unknown = 0
    for row in rows:
        fov = int(row["goal_fov_t0"]) == 1
        los_blocked = int(row["goal_los_blocker_id"]) >= 0
        blocker_first = fnum(row, "blocker_first_seen_s")
        if fov and not los_blocked:
            cls = "goal_visible_at_selection"
        elif fov and los_blocked:
            cls = "in_fov_but_occluded"
        elif los_blocked:
            # "just beyond a visible opening": the goal itself is hidden by
            # geometry on the goal bearing, but that geometry's first surface
            # is already inside the measured rays from the selection pose.
            if 0 <= blocker_first <= 0.25:
                cls = "beyond_visible_geometry_at_selection"
                beyond_visible += 1
            else:
                cls = "occluded_geometry_not_yet_visible"
                occluded_unknown += 1
        else:
            cls = "outside_fov_los_clear"
        grounding[cls] += 1
        by_family[row["family_name"]][cls] += 1

    result = {
        "generated_utc": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "thresholds": {"late_warning_s": late_s, "early_warning_s": early_s,
                       "blocker_from_start_s": 0.25},
        "train_tasks": len(rows),
        "outcomes": {
            "success": sum(int(r["success"]) for r in rows),
            "contact": len(contacts),
            "timeout": sum(int(r["timeout"]) for r in rows),
        },
        "contact_observability": dict(contact_classes),
        "contact_detail": contact_detail,
        "detour_blocker_observability": dict(blocker_classes),
        "detour_blocker_unseen_raw": raw_unseen,
        "detour_blocker_unseen_pooled": pooled_unseen,
        "detour_blocker_seen_median_s": (
            statistics.median(v for v in blocker_seen if v >= 0)
            if any(v >= 0 for v in blocker_seen) else None),
        "goal_grounding_at_selection": dict(grounding),
        "goal_grounding_classes": {
            "goal_visible_at_selection": "in camera frustum, line of sight clear",
            "in_fov_but_occluded": "in frustum but the goal-bearing ray is blocked",
            "beyond_visible_geometry_at_selection":
                "goal occluded but the goal-bearing blocking surface is already "
                "visible (<=0.25 s) at selection — the 'just beyond a visible "
                "opening' candidate class",
            "occluded_geometry_not_yet_visible":
                "goal occluded and the blocking surface never/late visible — "
                "requires look-around or memory",
            "outside_fov_los_clear":
                "goal outside the frustum with a clear goal-bearing ray",
        },
        "goal_grounding_by_family": {k: dict(v) for k, v in sorted(by_family.items())},
        "notes": [
            "first-seen times exclude the terminal tick (sim_reset_one "
            "overwrites sensor frames inside the command buffer), so warning "
            "times are conservative by at most one 0.05 s tick",
            "collider attribution uses the pre-terminal state snapshot; "
            "room faces are ids >= 1000, obstacles are 0..count-1",
            "grounding is computed from the selection pose with the legacy "
            "camera model (tan_h 1.0, tan_v 0.75, mount 0)",
        ],
    }
    unseen = contact_classes.get("never_seen", 0)
    print("flight_evidence contacts=%d never_seen=%d detour_blockers_never_seen=%d/%d"
          % (len(contacts), unseen, raw_unseen, len(detours)))
    print("flight_evidence grounding=%s" % json.dumps(dict(grounding)))
    path = os.path.join(out_dir, "warning-evidence.json")
    json.dump(result, open(path, "w"), indent=1, sort_keys=True)
    return result


# ---------------------------------------------------------- braking/arrival
def braking_arrival(flights, out_dir):
    policy_rows = load(os.path.join(flights, "source-policy-episodes.csv"))
    hover_rows = load(os.path.join(flights, "source-hover-episodes.csv"))
    policy_ticks = load(os.path.join(flights, "source-policy-ticks.csv"))
    hover_ticks = load(os.path.join(flights, "source-hover-ticks.csv"))

    # --- observed deceleration capability: max sustained speed drop over a
    # 3-tick (0.15 s) window inside a single flight.
    decels = []
    by_episode = defaultdict(list)
    for row in policy_ticks:
        by_episode[("p", row["env"], row["episode_index"])].append(row)
    for row in hover_ticks:
        by_episode[("h", row["env"], row["episode_index"])].append(row)
    for key, series in by_episode.items():
        series.sort(key=lambda r: int(r["tick"]))
        speeds = [fnum(r, "speed") for r in series]
        for i in range(len(speeds) - 3):
            drop = speeds[i] - speeds[i + 3]
            if drop > 0:
                decels.append(drop / 0.15)

    # --- hover: passive brake from the initial toward-goal velocity to rest.
    hover_brake = []
    hover_series = defaultdict(list)
    for row in hover_ticks:
        hover_series[row["env"]].append(row)
    for env, series in hover_series.items():
        series.sort(key=lambda r: int(r["tick"]))
        initial = fnum(series[0], "speed")
        if initial < 0.3:
            continue
        settle = None
        for row in series:
            if fnum(row, "speed") <= 0.05:
                settle = fnum(row, "time_s")
                break
        if settle is not None:
            hover_brake.append({"env": int(env), "initial_speed": initial,
                                "settle_time_s": settle,
                                "mean_decel": initial / settle})

    # --- stable-arrival evidence and pass-through-without-hold instances.
    success_hold = [int(r["hold_ticks_observed"]) for r in policy_rows
                    if int(r["success"]) == 1]
    bad_hold = sum(1 for h in success_hold if h < 3)
    if bad_hold:
        fail("stable_arrival_hold_evidence",
             "%d/%d successes lack >=3 observed hold ticks" % (bad_hold, len(success_hold)))
    else:
        ok("stable_arrival_hold_evidence", "%d successes with >=3 hold ticks"
           % len(success_hold))
    success_speeds = [fnum(r, "terminal_speed_pre") for r in policy_rows
                      if int(r["success"]) == 1]
    radius_no_hold = [r for r in policy_rows
                      if int(r["timeout"]) == 1 and fnum(r, "goal_dist_min_m") <= 0.35]
    entered_radius = sum(1 for r in policy_rows if fnum(r, "goal_dist_min_m") <= 0.35)

    times = [fnum(r, "time_s") for r in policy_rows]
    if times and max(times) > 20.05:
        fail("time_budget", "max episode time %.3f s exceeds 20 s budget" % max(times))
    else:
        ok("time_budget", "max episode time %.4f s within 20 s" % max(times))

    # --- required braking axis: distance needed to stop at the command cap,
    # against the straight-line distance available before the goal radius.
    # Goal distances come from the audited task-axes table (spec=source).
    axes_path = os.path.join(out_dir, "task-axes.csv")
    task_distance = {}
    if os.path.exists(axes_path):
        for row in load(axes_path):
            if row["spec"] == "source":
                task_distance[(row["env"], row["slot"])] = float(row["initial_distance_m"])
    cap = 1.5
    p90_decel = percentile(decels, 0.90)
    stop_distance = cap * cap / (2 * max(p90_decel, 1e-3))
    tasks_need_early_brake = 0
    tasks_measured = 0
    for row in policy_rows:
        available = task_distance.get((row["env"], row["slot"]))
        if available is None:
            continue
        tasks_measured += 1
        if available - 0.35 < stop_distance:
            tasks_need_early_brake += 1
    if not task_distance:
        fail("task_axes_merge", "task-axes.csv missing for braking budget axis")

    result = {
        "generated_utc": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "observed_decel_mps2": {
            "samples": len(decels),
            "p50": percentile(decels, 0.50),
            "p90": p90_decel,
            "max": max(decels) if decels else None,
            "definition": "max speed drop over any 3-tick (0.15 s) window, "
                          "20 Hz sampled, policy+hover TRAIN flights",
        },
        "hover_passive_brake": {
            "episodes": len(hover_brake),
            "settle_time_median_s": (statistics.median(
                [b["settle_time_s"] for b in hover_brake]) if hover_brake else None),
            "mean_decel_median": (statistics.median(
                [b["mean_decel"] for b in hover_brake]) if hover_brake else None),
            "definition": "bank start velocity (toward goal, <=1 m/s) to <=0.05 m/s "
                          "under zero commanded velocity (RAPTOR tracking only)",
        },
        "stable_arrival": {
            "successes": len(success_hold),
            "hold_ticks_min": min(success_hold) if success_hold else None,
            "hold_ticks_median": (statistics.median(success_hold)
                                  if success_hold else None),
            "terminal_speed_pre_max": max(success_speeds) if success_speeds else None,
            "terminal_speed_pre_median": (statistics.median(success_speeds)
                                          if success_speeds else None),
        },
        "pass_through_without_hold": {
            "definition": "timed-out flights whose goal distance ever reached "
                          "<=0.35 m without a stable hold",
            "count": len(radius_no_hold),
            "radius_entered_any_outcome": entered_radius,
            "examples": [{"env": r["env"], "slot": r["slot"],
                          "goal_dist_min_m": fnum(r, "goal_dist_min_m")}
                         for r in radius_no_hold[:20]],
        },
        "braking_budget": {
            "command_cap_mps": cap,
            "stopping_distance_at_cap_m": stop_distance,
            "tasks_measured": tasks_measured,
            "tasks_with_less_straight_distance_than_stopping": tasks_need_early_brake,
            "note": ("early braking before the goal line is required whenever "
                     "the straight distance is shorter than the stopping "
                     "distance; this is a distribution axis, not a failure"),
        },
        "episode_time_s": {
            "max": max(times) if times else None,
            "p99": percentile(times, 0.99),
            "budget_s": 20.0,
        },
    }
    path = os.path.join(out_dir, "braking-arrival.json")
    json.dump(result, open(path, "w"), indent=1, sort_keys=True)
    print("flight_evidence braking: decel p90=%.2f max=%.2f m/s^2, hover settle "
          "median=%s s, radius-no-hold=%d, max_time=%.3f s"
          % (p90_decel, max(decels) if decels else -1,
             result["hover_passive_brake"]["settle_time_median_s"],
             len(radius_no_hold), max(times) if times else -1))
    return result


def main():
    parser = argparse.ArgumentParser()
    here = os.path.dirname(os.path.abspath(__file__))
    parser.add_argument("--flights",
                        default="/Users/muadhsambul/RL/results/omp-task-contract/flights")
    parser.add_argument("--root", default="/Users/muadhsambul/RL")
    parser.add_argument("--out",
                        default="/Users/muadhsambul/RL/results/omp-task-contract")
    args = parser.parse_args()
    os.makedirs(args.out, exist_ok=True)
    visibility_crosscheck(args.flights, args.root, args.out)
    warning_evidence(args.flights, args.out)
    braking_arrival(args.flights, args.out)
    if HARD_FAILURES:
        print("flight_evidence RESULT FAIL %d" % len(HARD_FAILURES))
        return 1
    print("flight_evidence RESULT PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
