#!/usr/bin/env python3
"""Independent fault-injection audit of the local training resume contract.

This is NOT a rerun of the runner author's own resume checks: it builds its
own mutation set against the published v2 typed sidecar contract and the
on-disk bank binding, runs the real `local-train` resume path for each
mutation, and asserts two things black-box:

  1. the run refuses (non-zero exit, error on stderr) — a mutated contract
     must never silently train;
  2. every artifact in the run directory is byte-identical before and after
     the refusal and no new file appears — refusal happens before any write
     or checkpoint load side effect.

First a one-rollout smoke run creates a genuine v2 sidecar; every case then
restores the pristine sidecar (or the pristine bank) before applying exactly
one mutation.

Usage (GPU lock required, wrap with run_locked.py):
  python3 local_resume_contract_audit.py [--run-dir DIR] [--out JSON]
"""

import argparse
import hashlib
import json
import os
import shutil
import subprocess
import sys
from datetime import datetime, timezone

ROOT = "/Users/muadhsambul/RL"
WORKTREE = os.path.dirname(os.path.abspath(__file__))
BINARY = os.path.join(WORKTREE, "build", "omp-task-contract", "metal_nav_waypoint")
WARMSTART = os.path.join(ROOT, "assets", "checkpoints",
                         "arrival-open-domain-experimental.bin.best")


def sha256(path):
    digest = hashlib.sha256()
    with open(path, "rb") as handle:
        for chunk in iter(lambda: handle.read(1 << 20), b""):
            digest.update(chunk)
    return digest.hexdigest()


def snapshot(directory):
    state = {}
    for name in sorted(os.listdir(directory)):
        path = os.path.join(directory, name)
        if os.path.isfile(path):
            state[name] = sha256(path)
    return state


def flip_json(path, key, transform):
    with open(path) as handle:
        payload = json.load(handle)
    assert key in payload, "sidecar field %s missing" % key
    payload[key] = transform(payload[key])
    with open(path, "w") as handle:
        json.dump(payload, handle, indent=1)


def flip_bank_byte(path):
    with open(path, "r+b") as handle:
        size = handle.seek(0, os.SEEK_END)
        handle.seek(size // 2)          # inside the entry array
        byte = handle.read(1)
        handle.seek(size // 2)
        handle.write(bytes([byte[0] ^ 0x5A]))


def run_train(run_dir, log_path):
    checkpoint = os.path.join(run_dir, "smoke.bin")
    command = [BINARY, "local-train", "1", checkpoint, WARMSTART,
               "--spec", "source", "--eval-spec", "dev-a"]
    result = subprocess.run(command, capture_output=True, text=True, cwd=WORKTREE)
    with open(log_path, "w") as handle:
        handle.write("$ " + " ".join(command) + "\n")
        handle.write(result.stdout)
        handle.write(result.stderr)
    return result.returncode, (result.stdout + result.stderr)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--run-dir",
                        default=os.path.join(ROOT, "results", "omp-task-contract",
                                             "resume-audit"))
    parser.add_argument("--out",
                        default=os.path.join(ROOT, "results", "omp-task-contract",
                                             "resume-contract-audit.json"))
    args = parser.parse_args()
    run_dir = args.run_dir
    checkpoint = os.path.join(run_dir, "smoke.bin")
    sidecar = checkpoint + ".train.json"
    bank = checkpoint + ".bank.bin"
    for path in (checkpoint, sidecar, bank, WARMSTART):
        if not os.path.exists(path):
            print("resume_audit missing prerequisite: " + path)
            return 2

    pristine_sidecar = open(sidecar, "rb").read()
    pristine_bank = open(bank, "rb").read()

    cases = [
        ("time_cost_mutated",
         lambda: flip_json(sidecar, "time_cost_per_s", lambda v: v + 0.05)),
        ("learning_rate_mutated",
         lambda: flip_json(sidecar, "learning_rate", lambda v: v * 2)),
        ("speed_cap_mutated",
         lambda: flip_json(sidecar, "speed_cap_mps", lambda v: v - 0.1)),
        ("bank_entries_mutated",
         lambda: flip_json(sidecar, "bank_entries", lambda v: v - 1)),
        ("eval_spec_mutated",
         lambda: flip_json(sidecar, "eval_spec", lambda v: "dev-b")),
        ("warmstart_hash_mutated",
         lambda: flip_json(sidecar, "warmstart_sha256",
                           lambda v: ("1" if v[0] != "1" else "2") + v[1:])),
        ("bank_bytes_mutated", lambda: flip_bank_byte(bank)),
        ("sidecar_removed", lambda: os.remove(sidecar)),
    ]

    results = []
    all_pass = True

    # Non-vacuity control: with the pristine sidecar the same harness must
    # SUCCEED, so the mutations below are what causes each refusal.
    open(sidecar, "wb").write(pristine_sidecar)
    open(bank, "wb").write(pristine_bank)
    code, output = run_train(run_dir, os.path.join(run_dir, "control.log"))
    control_ok = code == 0
    all_pass = all_pass and control_ok
    results.append({"case": "control_pristine", "exit_code": code,
                    "expected": "succeed",
                    "result": "PASS" if control_ok else "FAIL"})
    print("resume_audit %s control_pristine exit=%d (expect 0)"
          % ("PASS" if control_ok else "FAIL", code))
    # The successful control rewrites artifacts; restore pristine bytes so
    # every mutation case starts from the same known state.
    open(sidecar, "wb").write(pristine_sidecar)
    open(bank, "wb").write(pristine_bank)

    for name, mutate in cases:
        # Restore pristine inputs, apply exactly one mutation, snapshot, run.
        open(sidecar, "wb").write(pristine_sidecar)
        open(bank, "wb").write(pristine_bank)
        mutate()
        before = snapshot(run_dir)
        code, output = run_train(run_dir, os.path.join(run_dir, name + ".log"))
        after = snapshot(run_dir)
        # The per-case log is created by this script after the run and is
        # not part of the pre-run snapshot; control.log predates the snapshot
        # and stays byte-identical, so it is compared normally.
        after.pop(name + ".log", None)
        refused = code != 0 and "ERROR" in output
        unchanged = before == after
        passed = refused and unchanged
        all_pass = all_pass and passed
        results.append({
            "case": name,
            "exit_code": code,
            "refused_with_error": refused,
            "artifacts_byte_identical": unchanged,
            "result": "PASS" if passed else "FAIL",
            "error_line": next((line for line in output.splitlines()
                                if line.startswith("ERROR")), ""),
        })
        print("resume_audit %s %s exit=%d unchanged=%s"
              % ("PASS" if passed else "FAIL", name, code, unchanged))

        # Restore for the next case.
        open(sidecar, "wb").write(pristine_sidecar)
        open(bank, "wb").write(pristine_bank)

    summary = {
        "generated_utc": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "binary": BINARY,
        "binary_sha256": sha256(BINARY),
        "sidecar_sha256_pristine": hashlib.sha256(pristine_sidecar).hexdigest(),
        "bank_sha256_pristine": hashlib.sha256(pristine_bank).hexdigest(),
        "warmstart_sha256": sha256(WARMSTART),
        "cases": results,
        "result": "PASS" if all_pass else "FAIL",
        "note": ("independent mutation set: does not repeat the runner "
                 "author's 13 published refusal cases"),
    }
    with open(args.out, "w") as handle:
        json.dump(summary, handle, indent=1, sort_keys=True)
    print("resume_audit RESULT %s (%d/%d)" % (
        summary["result"], sum(1 for r in results if r["result"] == "PASS"),
        len(results)))
    return 0 if all_pass else 1


if __name__ == "__main__":
    sys.exit(main())
