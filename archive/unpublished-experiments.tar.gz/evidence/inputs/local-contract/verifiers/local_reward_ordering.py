#!/usr/bin/env python3
"""Reward-ordering verifier for the local task contract (goal.md item 4).

Ranks actual flown behaviours under the real navigation_task_step objective,
using ground-truth per-tick rewards captured from the simulator reward buffer
by local_contract_probe.mm:

  valid reference flights   (frozen actor successes, detour and direct strata)
  hovering                  (zero-command flights, 1024 real timeouts)
  blindly straight flight   (repository mode-2 goal-seeker, real flights)
  unnecessary detours       (successes whose path is >=1.5x the straight line)
  unsafe shortcuts/contacts (all contact terminations)
  timeouts

Ordering is evaluated three ways:
  undiscounted   sum of task rewards at the verified recipe (0.2 time cost)
  discounted      sum gamma^t * r_t with the training gamma 0.99
  time-cost 1.0  the fast arm's training time cost, reward reweighted exactly
                 from the recorded components (terminal time term replaced)

Every ordering claim is a comparison of class means/medians plus paired
per-task wins where the same task flew under two controllers. Inversions are
reported, not hidden: the discounted objective is known to compress late
bonuses, and this script quantifies that on local tasks.

Usage: python3 local_reward_ordering.py [--flights DIR] [--out DIR]
Exit code 1 if a hard invariant (record integrity) fails; ordering inversions
are findings, recorded in the JSON, not script failures.
"""

import argparse
import csv
import json
import math
import os
from collections import Counter, defaultdict
from datetime import datetime, timezone

HARD_FAILURES = []


def fail(name, detail):
    HARD_FAILURES.append({"check": name, "detail": detail})
    print("reward_ordering FAIL %s %s" % (name, detail))


def load(path):
    with open(path, newline="") as handle:
        return list(csv.DictReader(handle))


def f(row, key):
    return float(row[key])


def mean(values):
    return sum(values) / len(values) if values else float("nan")


def median(values):
    if not values:
        return float("nan")
    ordered = sorted(values)
    mid = len(ordered) // 2
    return (ordered[mid] if len(ordered) % 2
            else 0.5 * (ordered[mid - 1] + ordered[mid]))


RECIPE_TIME_COST = 0.2
FAST_TIME_COST = 1.0
GAMMA = 0.99
NAV_PERIOD = 0.05
UNNECESSARY_PATH_RATIO = 1.5


def reweight_time_cost(row, new_cost):
    """Exact reweighting from recorded components: progress and smoothness are
    independent of the time cost; every tick's time term scales linearly; the
    terminal tick's time term is folded inside terminal_reward and is replaced
    by arithmetic."""
    progress = f(row, "reward_progress")
    smooth = f(row, "reward_smooth")
    time_sum = f(row, "reward_time")           # all ticks at RECIPE_TIME_COST
    reward_sum = f(row, "reward_sum")
    terminal_reward = reward_sum - progress - time_sum - smooth
    # terminal_reward embeds -RECIPE_TIME_COST * NAV_PERIOD; replace it.
    terminal_adjusted = (terminal_reward + RECIPE_TIME_COST * NAV_PERIOD
                         - new_cost * NAV_PERIOD)
    scaled_time = time_sum * (new_cost / RECIPE_TIME_COST)
    return progress + smooth + scaled_time + terminal_adjusted


def classify_policy(row, straight_distance):
    success = int(row["success"]) == 1
    collision = int(row["collision"]) == 1
    timeout = int(row["timeout"]) == 1
    detour = int(row["route_class"]) == 1
    path = f(row, "path_m")
    distance = straight_distance.get((row["env"], row["slot"]))
    ratio = path / max(distance - 0.35, 1e-6) if distance else float("nan")
    if success:
        if not detour and ratio >= UNNECESSARY_PATH_RATIO:
            # route class 0: the straight line was verified clear, yet the
            # flight used >=1.5x the straight distance. Detour-class successes
            # are NOT unnecessary by definition (their detour is required).
            return "reference_success_unnecessary_detour"
        return ("reference_success_detour" if detour
                else "reference_success_direct")
    if collision:
        return "contact_detour" if detour else "contact_direct"
    if timeout:
        return "timeout_detour" if detour else "timeout_direct"
    return "unknown"


def class_table(rows, value_keys):
    grouped = defaultdict(lambda: defaultdict(list))
    for label, row in rows:
        for key in value_keys:
            grouped[label][key].append(float(row[key]))
    table = {}
    for label in sorted(grouped):
        table[label] = {"n": len(grouped[label][value_keys[0]])}
        for key in value_keys:
            values = grouped[label][key]
            table[label][key + "_mean"] = mean(values)
            table[label][key + "_median"] = median(values)
    return table


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--flights",
                        default="/Users/muadhsambul/RL/results/omp-task-contract/flights")
    parser.add_argument("--out",
                        default="/Users/muadhsambul/RL/results/omp-task-contract")
    args = parser.parse_args()
    os.makedirs(args.out, exist_ok=True)

    policy = load(os.path.join(args.flights, "source-policy-episodes.csv"))
    blind = load(os.path.join(args.flights, "source-blind-episodes.csv"))
    hover = load(os.path.join(args.flights, "source-hover-episodes.csv"))
    if not (len(policy) == len(blind) == len(hover) == 1024):
        fail("full_train_denominator",
             "policy=%d blind=%d hover=%d, expected 1024"
             % (len(policy), len(blind), len(hover)))

    # Straight-line distances for the unnecessary-detour axis.
    axes_path = os.path.join(args.out, "task-axes.csv")
    straight_distance = {}
    if os.path.exists(axes_path):
        for row in load(axes_path):
            if row["spec"] == "source":
                straight_distance[(row["env"], row["slot"])] = float(
                    row["initial_distance_m"])
    else:
        fail("task_axes_present", axes_path)

    # --- integrity: reconstruction identity at the recipe time cost.
    worst_identity = 0
    for row in policy + blind + hover:
        rebuilt = reweight_time_cost(row, RECIPE_TIME_COST)
        worst_identity = max(worst_identity, abs(rebuilt - f(row, "reward_sum")))
    if worst_identity > 1e-3:
        fail("component_identity",
             "reward_sum reconstruction off by %g" % worst_identity)
    else:
        print("reward_ordering PASS component_identity max_err=%g" % worst_identity)

    value_keys = ["reward_sum", "reward_disc099", "reward_fast"]

    def decorate(rows, classifier):
        out = []
        for row in rows:
            row = dict(row)
            row["reward_fast"] = reweight_time_cost(row, FAST_TIME_COST)
            out.append((classifier(row), row))
        return out

    labeled = []
    labeled += decorate(policy, lambda r: classify_policy(r, straight_distance))
    for row in blind:
        row = dict(row)
        row["reward_fast"] = reweight_time_cost(row, FAST_TIME_COST)
        label = "blind_" + ("success" if int(row["success"]) == 1
                            else "contact" if int(row["collision"]) == 1
                            else "timeout")
        labeled.append((label, row))
    for row in hover:
        row = dict(row)
        row["reward_fast"] = reweight_time_cost(row, FAST_TIME_COST)
        labeled.append(("hover", row))
    for _, row in labeled:
        row["reward_sum"] = float(row["reward_sum"])
        row["reward_disc099"] = float(row["reward_disc099"])

    table = class_table(labeled, value_keys)

    # --- verdicts: every goal.md undesirable must rank below the reference.
    def cls_mean(label, key):
        return table.get(label, {}).get(key + "_mean", float("nan"))

    reference_labels = ["reference_success_detour", "reference_success_direct"]
    reference_rows = [r for l, r in labeled if l in reference_labels]

    def reference_mean(key):
        return mean([r[key] for r in reference_rows])

    def behavior_mean(name, key):
        selectors = {
            "hover": lambda l: l == "hover",
            "blindly_straight": lambda l: l.startswith("blind_"),
            "unnecessary_detour": lambda l: l == "reference_success_unnecessary_detour",
            "unsafe_shortcut_or_collision": lambda l: l.startswith("contact_"),
            "collision": lambda l: l.startswith("contact_"),
        }
        rows = [r for l, r in labeled if selectors[name](l)]
        return mean([r[key] for r in rows])

    verdicts = {}
    undesirable = ["hover", "blindly_straight", "unnecessary_detour",
                   "unsafe_shortcut_or_collision", "collision"]
    for metric in value_keys:
        ref = reference_mean(metric)
        per_metric = {}
        for name in undesirable:
            value = behavior_mean(name, metric)
            per_metric[name] = {
                "reference_mean": ref,
                "behavior_mean": value,
                "reference_ranks_above": bool(ref > value),
            }
        verdicts[metric] = per_metric

    # Subclass detail for the blind behavior: successes on direct tasks fly
    # legitimately; the behavior verdict above uses the aggregate.
    blind_subclasses = {label: {key + "_mean": table[label][key + "_mean"]
                                for key in value_keys}
                        for label in table if label.startswith("blind_")}

    # --- paired policy-vs-blind on the same task (same task, two controllers).
    blind_by_key = {(r["env"], r["slot"]): r for r in blind}
    paired = Counter()
    paired_by_route = defaultdict(Counter)
    paired_deltas = []
    for row in policy:
        other = blind_by_key.get((row["env"], row["slot"]))
        if not other:
            continue
        a = f(row, "reward_sum")
        b = f(other, "reward_sum")
        route = row["route_class"]
        if a > b + 1e-6:
            paired["policy_wins"] += 1
            paired_by_route[route]["policy_wins"] += 1
        elif a < b - 1e-6:
            paired["policy_losses"] += 1
            paired_by_route[route]["policy_losses"] += 1
        else:
            paired["ties"] += 1
            paired_by_route[route]["ties"] += 1
        paired_deltas.append(a - b)

    # --- discounted inversion audit: how often a SUCCESS ranks below the mean
    # flown hover under the training discount (the known credit issue).
    hover_disc = table.get("hover", {}).get("reward_disc099_mean", float("nan"))
    success_disc = [f(r, "reward_disc099") for r in reference_rows]
    inversion_count = sum(1 for v in success_disc if v < hover_disc)
    # Bonus weight actually delivered by the discount at arrival time.
    bonus_weights = []
    for row in reference_rows:
        ticks = int(row["ticks_observed"])
        bonus_weights.append(GAMMA ** max(ticks - 1, 0))

    # --- success/hover separation in the undiscounted contract (hard check:
    # a valid reference must beat a hover on average under the recipe).
    if not (reference_mean("reward_sum") > cls_mean("hover", "reward_sum")):
        fail("reference_beats_hover_undiscounted",
             "reference %g <= hover %g"
             % (reference_mean("reward_sum"), cls_mean("hover", "reward_sum")))
    else:
        print("reward_ordering PASS reference_beats_hover_undiscounted "
              "(%g > %g)" % (reference_mean("reward_sum"),
                             cls_mean("hover", "reward_sum")))

    result = {
        "generated_utc": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "scope_notes": [
            "verdicts below are CLASS-MEAN comparisons over full TRAIN "
            "denominators",
            "per-flight evidence: paired_policy_vs_blind and "
            "discount_audit.reference_successes_below_hover_disc099",
            "contact flights (n=205) and reference_success_unnecessary_detour "
            "(n=205) are disjoint sets that coincidentally share a count",
        ],
        "objective": {
            "recipe_time_cost": RECIPE_TIME_COST,
            "fast_arm_time_cost": FAST_TIME_COST,
            "gamma": GAMMA,
            "nav_period_s": NAV_PERIOD,
            "undesirable_threshold_path_ratio": UNNECESSARY_PATH_RATIO,
            "reward_source": ("simulator reward buffer per tick, ground truth; "
                              "component identity verified against reward_sum"),
        },
        "denominators": {"policy": len(policy), "blind": len(blind),
                         "hover": len(hover)},
        "class_table": table,
        "verdicts": verdicts,
        "paired_policy_vs_blind": {
            "wins": paired["policy_wins"], "losses": paired["policy_losses"],
            "ties": paired["ties"],
            "by_route_class": {k: dict(v) for k, v in paired_by_route.items()},
            "delta_mean": mean(paired_deltas),
            "delta_min": min(paired_deltas) if paired_deltas else None,
        },
        "blind_subclasses": blind_subclasses,
        "discount_audit": {
            "hover_mean_disc099": hover_disc,
            "reference_successes_below_hover_disc099": inversion_count,
            "reference_successes": len(success_disc),
            "bonus_weight_gamma_pow_ticks": {
                "mean": mean(bonus_weights), "min": min(bonus_weights),
                "max": max(bonus_weights),
            },
            "note": ("inversions here are a property of gamma=0.99 with "
                     "20 Hz steps over 20 s episodes, reported for the local "
                     "task distribution; the step-contract probe shows the "
                     "undiscounted contract itself is ordered correctly"),
        },
        "worst_component_identity_error": worst_identity,
    }
    out_path = os.path.join(args.out, "reward-ordering.json")
    json.dump(result, open(out_path, "w"), indent=1, sort_keys=True)

    csv_path = os.path.join(args.out, "reward-ordering.csv")
    with open(csv_path, "w", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow(["class", "n"] + [k for key in value_keys
                                          for k in (key + "_mean", key + "_median")])
        for label in sorted(table):
            row = [label, table[label]["n"]]
            for key in value_keys:
                row += [table[label].get(key + "_mean"),
                        table[label].get(key + "_median")]
            writer.writerow(row)

    for metric in value_keys:
        line = " ".join(
            "%s:%s" % (name, "OK" if per["reference_ranks_above"] else "INVERSION")
            for name, per in verdicts[metric].items())
        print("reward_ordering %s -> %s" % (metric, line))
    print("reward_ordering discounted success-below-hover: %d/%d"
          % (inversion_count, len(success_disc)))
    print("reward_ordering paired policy vs blind: %s" % dict(paired))
    if HARD_FAILURES:
        print("reward_ordering RESULT FAIL %d" % len(HARD_FAILURES))
        return 1
    print("reward_ordering RESULT PASS (inversions above are findings)")
    print("wrote %s and %s" % (out_path, csv_path))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
