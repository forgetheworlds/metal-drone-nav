// Executable contract check for navigation_task_step, the reward/termination
// function every local task runs through. This probe is host-only: no GPU, no
// simulator, no re-implementation. It drives the real contract function with
// adversarial state sequences and asserts the semantics goal.md asks us to
// verify: pass-through vs stable hold, penalty/bonus/terminal precedence,
// finite-horizon termination, progress telescoping and reward linearity.
//
// Build (root sources are read-only inputs, compiled here):
//   clang++ -x objective-c++ -std=c++17 -O2 -framework Foundation \
//     -framework Metal -framework Accelerate \
//     -DSOURCE_DIR='"/Users/muadhsambul/RL"' -DFIXED_PPO_ACTOR_OBS_DIM=184 \
//     -DNAV_SENSOR_PROFILE=1 local_step_contract_check.mm -o <out>
//
// Output: one line per assertion plus a JSON summary (argv[1] or
// results/omp-task-contract/step-contract.json).

#define main step_contract_reserved_main
// Build-portability: the include root is overridable per checkout, e.g.
//   -DTASK_CONTRACT_MAIN_MM=\"/path/to/main.mm\"   (default = this machine's
// root tree, the path root used for the published receipt).
#ifndef TASK_CONTRACT_MAIN_MM
#define TASK_CONTRACT_MAIN_MM "/Users/muadhsambul/RL/main.mm"
#endif
#include TASK_CONTRACT_MAIN_MM
#undef main

#include <cstdio>
#include <sstream>

namespace contract {

static int g_checks = 0;
static int g_failures = 0;

static void check(bool ok, const std::string& name, const std::string& detail) {
    g_checks++;
    if (!ok) g_failures++;
    std::printf("step_contract %s %s %s\n", ok ? "PASS" : "FAIL", name.c_str(),
                detail.c_str());
}

static NavigationTaskControl make_control() {
    NavigationTaskControl control =
        navigation_training::task_settings(NAV_TASK_STAGE_OPEN_GOAL, 0u);
    return control;
}

// Fixture mirroring waypoint_task_apply's task installation: goal at
// (0,0,1.5), goal distance recorded, counters zeroed. Positions passed to
// step() are constructed so that |goal - position| equals the intended
// distance (position on the x axis at the goal height).
static NavigationTaskState make_task(const NavigationTaskConfig& cfg,
                                     float initial_distance) {
    NavigationTaskState task{};
    task.generation_status = NAV_TASK_GENERATION_READY;
    task.valid = 1;
    task.family = 0;
    task.stage = cfg.stage;
    task.objective = cfg.objective;
    task.max_nav_steps = cfg.max_nav_steps;
    task.goal_position[0] = 0.0f;
    task.goal_position[1] = 0.0f;
    task.goal_position[2] = 1.5f;
    task.initial_distance_m = initial_distance;
    task.previous_distance_m = initial_distance;
    task.stable_time_s = 0.0f;
    return task;
}

static NavigationTaskStep step_at(NavigationTaskControl& control,
                                  NavigationTaskState& task, float distance,
                                  float speed, float contact = 0,
                                  float forced_timeout = 0,
                                  bool nan_position = false,
                                  const float* executed = nullptr) {
    float position[3] = {distance, 0.0f, 1.5f};
    if (nan_position) position[0] = std::nanf("");
    float velocity[3] = {speed, 0.0f, 0.0f};
    const float still[4] = {0, 0, 0, 0};
    const float* command = executed ? executed : still;
    return navigation_task_step(task, control.config, position, velocity, command,
                                uint32_t(contact != 0), uint32_t(forced_timeout != 0));
}

static bool close(float a, float b, float tol) { return std::fabs(a - b) <= tol; }

static void test_speed_crossing_never_succeeds() {
    auto control = make_control();
    auto task = make_task(control.config, 2.0f);
    // Inside the radius at 1 m/s: no success, no stable accumulation.
    bool terminal = false;
    float reward_sum = 0;
    for (int i = 0; i < 5 && !terminal; i++) {
        auto outcome = step_at(control, task, 0.30f, 1.0f);
        reward_sum += outcome.reward;
        terminal = outcome.episode_done != 0;
        check(outcome.stable_success == 0 && outcome.episode_done == 0,
              "final_hold_speed_crossing_not_terminal",
              "tick=" + std::to_string(i) + " stable_time=" +
                  std::to_string(task.stable_time_s));
    }
    check(!terminal && close(task.stable_time_s, 0.0f, 1e-9f),
          "final_hold_fast_loiter_never_accumulates",
          "stable_time=" + std::to_string(task.stable_time_s) +
              " reward_sum=" + std::to_string(reward_sum));
}

static void test_stable_hold_success_once() {
    auto control = make_control();
    auto task = make_task(control.config, 2.0f);
    auto away = step_at(control, task, 2.0f, 0.0f);
    (void)away;
    auto approach = step_at(control, task, 1.0f, 0.3f);
    check(approach.episode_done == 0, "approach_outside_no_success",
          "reward=" + std::to_string(approach.reward));
    float expected_progress = control.config.progress_reward_per_m * (2.0f - 1.0f);
    check(close(approach.reward, expected_progress -
                                     control.config.time_cost_per_s *
                                         control.config.nav_period_s, 1e-5f),
          "reward_is_progress_minus_time",
          "reward=" + std::to_string(approach.reward) + " expected=" +
              std::to_string(expected_progress -
                              control.config.time_cost_per_s *
                                  control.config.nav_period_s));
    int ticks_to_success = 0;
    bool success = false;
    float bonus_ticks = 0;
    while (ticks_to_success < 10 && !success) {
        auto outcome = step_at(control, task, 0.30f, 0.3f);
        ticks_to_success++;
        success = outcome.stable_success != 0;
        if (success) bonus_ticks = outcome.reward;
        check(success || outcome.episode_done == 0,
              "stable_hold_nonterminal_until_200ms",
              "tick=" + std::to_string(ticks_to_success) +
                  " stable_time=" + std::to_string(task.stable_time_s) +
                  " stable_ticks=" + std::to_string(task.stable_ticks));
    }
    check(success && ticks_to_success == 4,
          "stable_success_at_exactly_200ms",
          "ticks=" + std::to_string(ticks_to_success) +
              " stable_time=" + std::to_string(task.stable_time_s));
    check(close(bonus_ticks,
                control.config.progress_reward_per_m * (0.30f - 0.30f) -
                    control.config.time_cost_per_s * control.config.nav_period_s +
                    control.config.stable_arrival_bonus, 1e-5f),
          "arrival_bonus_paid_exactly_once",
          "reward=" + std::to_string(bonus_ticks));
    // Post-terminal steps are inert: done, no reward, no state change.
    float stable_before = task.stable_time_s;
    auto after = step_at(control, task, 0.30f, 0.3f);
    check(after.episode_done == 1 && after.reward == 0.0f &&
              close(task.stable_time_s, stable_before, 1e-9f),
          "post_terminal_step_is_inert",
          "reward=" + std::to_string(after.reward));
}

static void test_waypoint_pass_through() {
    auto control = make_control();
    control.config.objective = NAV_TASK_OBJECTIVE_WAYPOINT;
    auto task = make_task(control.config, 2.0f);
    (void)step_at(control, task, 2.0f, 0.0f);
    auto cross = step_at(control, task, 0.30f, 0.3f);
    check(cross.waypoint_passed == 1 && cross.episode_done == 0 &&
              cross.stable_success == 0,
          "waypoint_pass_through_latched_nonterminal",
          "passed=" + std::to_string(cross.waypoint_passed));
    float expected_no_bonus = control.config.progress_reward_per_m * (2.0f - 0.30f) -
                              control.config.time_cost_per_s *
                                  control.config.nav_period_s;
    check(close(cross.reward, expected_no_bonus, 1e-5f),
          "pass_through_has_no_arrival_bonus",
          "reward=" + std::to_string(cross.reward) + " expected=" +
              std::to_string(expected_no_bonus));
    for (int i = 0; i < 3; i++) {
        auto again = step_at(control, task, 0.30f, 0.3f);
        check(again.waypoint_passed == 0 && again.episode_done == 0,
              "waypoint_event_fires_once",
              "tick=" + std::to_string(i));
    }
    check(close(task.stable_time_s, 0.0f, 1e-9f),
          "waypoint_objective_never_accumulates_hold",
          "stable_time=" + std::to_string(task.stable_time_s));
    // Pass-through episodes end only via timeout/contact: force the timeout.
    task.step_count = control.config.max_nav_steps - 1;
    auto last = step_at(control, task, 0.30f, 0.3f);
    check(last.timeout == 1 && last.episode_done == 1,
          "waypoint_episode_finite_by_timeout",
          "timeout=" + std::to_string(last.timeout));
}

static void test_contact_beats_bonus() {
    auto control = make_control();
    auto task = make_task(control.config, 2.0f);
    (void)step_at(control, task, 2.0f, 0.0f);
    (void)step_at(control, task, 1.0f, 0.3f);
    (void)step_at(control, task, 0.30f, 0.3f);
    (void)step_at(control, task, 0.30f, 0.3f);
    (void)step_at(control, task, 0.30f, 0.3f);
    // Fourth inside-slow tick would succeed, but contact lands on the same tick.
    auto outcome = step_at(control, task, 0.30f, 0.3f, /*contact=*/1);
    check(outcome.collision == 1 && outcome.episode_done == 1 &&
              outcome.stable_success == 1,
          "contact_terminates_episode",
          "collision=" + std::to_string(outcome.collision) +
              " stable_success=" + std::to_string(outcome.stable_success));
    float expected = control.config.progress_reward_per_m * 0.0f -
                     control.config.time_cost_per_s * control.config.nav_period_s -
                     control.config.contact_penalty;
    check(close(outcome.reward, expected, 1e-5f),
          "contact_same_tick_as_hold_pays_penalty_not_bonus",
          "reward=" + std::to_string(outcome.reward) + " expected=" +
              std::to_string(expected));
}

static void test_finite_horizon_timeout() {
    auto control = make_control();
    auto task = make_task(control.config, 2.0f);
    int ticks = 0;
    bool done = false;
    while (ticks < int(control.config.max_nav_steps) + 5 && !done) {
        auto outcome = step_at(control, task, 2.0f, 0.0f);
        ticks++;
        done = outcome.episode_done != 0;
        if (done)
            check(outcome.timeout == 1 && outcome.stable_success == 0,
                  "timeout_terminates_without_bonus",
                  "tick=" + std::to_string(ticks) +
                      " reward=" + std::to_string(outcome.reward));
    }
    check(done && ticks == int(control.config.max_nav_steps),
          "episode_ends_at_max_nav_steps",
          "ticks=" + std::to_string(ticks));
}

static void test_progress_telescoping() {
    auto control = make_control();
    control.config.time_cost_per_s = 0.0f;
    control.config.command_smoothness_weight = 0.0f;
    auto task = make_task(control.config, 2.0f);
    const float distances[] = {2.0f, 1.6f, 0.9f, 0.4f, 0.36f};
    float sum = 0;
    for (float d : distances) {
        auto outcome = step_at(control, task, d, 0.8f);
        sum += outcome.reward;
        check(outcome.episode_done == 0, "telescoping_sequence_nonterminal",
              "d=" + std::to_string(d));
    }
    float expected = control.config.progress_reward_per_m * (2.0f - 0.36f);
    check(close(sum, expected, 1e-4f),
          "progress_terms_telescope_to_2x_net_distance",
          "sum=" + std::to_string(sum) + " expected=" + std::to_string(expected));
}

static void test_time_cost_linearity() {
    auto slow = make_control();
    auto fast = make_control();
    fast.config.time_cost_per_s = 1.0f;
    auto task_slow = make_task(slow.config, 2.0f);
    auto task_fast = make_task(fast.config, 2.0f);
    (void)step_at(slow, task_slow, 2.0f, 0.0f);
    (void)step_at(fast, task_fast, 2.0f, 0.0f);
    auto a = step_at(slow, task_slow, 1.9f, 0.0f);
    auto b = step_at(fast, task_fast, 1.9f, 0.0f);
    float diff = a.reward - b.reward;
    float expected = (1.0f - 0.2f) * slow.config.nav_period_s;
    check(close(diff, expected, 1e-6f),
          "time_cost_scales_reward_linearly",
          "diff=" + std::to_string(diff) + " expected=" + std::to_string(expected));
}

static void test_smoothness_term() {
    auto control = make_control();
    control.config.time_cost_per_s = 0.0f;
    auto task = make_task(control.config, 2.0f);
    const float still[4] = {0, 0, 0, 0};
    (void)step_at(control, task, 2.0f, 0.0f, 0, 0, false, still);
    const float jump[4] = {1, 0, 0, 0};
    auto outcome = step_at(control, task, 2.0f, 0.0f, 0, 0, false, jump);
    float expected = -control.config.command_smoothness_weight * 1.0f *
                     control.config.nav_period_s;
    check(close(outcome.reward, expected, 1e-7f),
          "smoothness_penalty_is_weight_times_du2_times_period",
          "reward=" + std::to_string(outcome.reward) + " expected=" +
              std::to_string(expected));
}

static void test_away_motion_and_nan() {
    auto control = make_control();
    auto task = make_task(control.config, 1.0f);
    (void)step_at(control, task, 1.0f, 0.0f);
    auto away = step_at(control, task, 1.3f, 0.3f);
    float floor = -control.config.time_cost_per_s * control.config.nav_period_s;
    check(away.reward < floor,
          "moving_away_costs_more_than_time",
          "reward=" + std::to_string(away.reward) + " floor=" +
              std::to_string(floor));
    auto nan = step_at(control, task, 0.5f, 0.3f, 0, 0, /*nan_position=*/true);
    check(nan.collision == 1 && nan.episode_done == 1,
          "nonfinite_state_becomes_collision_terminal",
          "collision=" + std::to_string(nan.collision));
}

static int run_all(const std::string& out_path) {
    test_speed_crossing_never_succeeds();
    test_stable_hold_success_once();
    test_waypoint_pass_through();
    test_contact_beats_bonus();
    test_finite_horizon_timeout();
    test_progress_telescoping();
    test_time_cost_linearity();
    test_smoothness_term();
    test_away_motion_and_nan();
    std::ostringstream json;
    json << "{\n"
         << " \"probe\": \"local_step_contract_check\",\n"
         << " \"contract_source\": \"navigation_tasks.hpp::navigation_task_step\",\n"
         << " \"checks\": " << g_checks << ",\n"
         << " \"failures\": " << g_failures << ",\n"
         << " \"result\": \"" << (g_failures == 0 ? "PASS" : "FAIL") << "\"\n}\n";
    FILE* handle = std::fopen(out_path.c_str(), "w");
    if (handle) {
        std::fputs(json.str().c_str(), handle);
        std::fclose(handle);
    }
    std::printf("step_contract_summary checks=%d failures=%d result=%s out=%s\n",
                g_checks, g_failures, g_failures == 0 ? "PASS" : "FAIL",
                out_path.c_str());
    return g_failures == 0 ? 0 : 1;
}

}  // namespace contract

int main(int argc, char** argv) {
    std::string out = argc > 1 ? argv[1]
                               : "/Users/muadhsambul/RL/results/omp-task-contract/"
                                 "step-contract.json";
    return contract::run_all(out);
}
