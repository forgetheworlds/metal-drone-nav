#!/usr/bin/env python3
"""Fault-injection self-test for the flight-evidence and reward-ordering
verifiers.

Round-1 review requires every published verifier to REJECT injected faults
(mirroring the implementation is not a check). The coordinator already ran
clean + fault-injection passes over `local_contract_audit.py`; this script
completes the set for the other two Python verifiers by copying their inputs,
applying single-field mutations, and asserting that the verifier exits
non-zero with the expected named failure.

Mutations:
  flight_evidence:
    1. flip one outcome bit in the dev-a probe records
       -> visibility cross-check must fail on outcome agreement
    2. delete one TRAIN episode row
       -> full-TRAIN denominator check must fail
  reward_ordering:
    3. perturb one reward_sum
       -> component identity check must fail
    4. delete one TRAIN episode row
       -> full-TRAIN denominator check must fail

Usage: python3 verifier_fault_selftest.py
Output: results/omp-task-contract/fault-selftest.log (+ exit 1 on any
verifier that fails to reject its fault).
"""

import csv
import json
import os
import shutil
import subprocess
import sys
import tempfile

ROOT = "/Users/muadhsambul/RL"
WORKTREE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(ROOT, "results", "omp-task-contract")
FLIGHTS = os.path.join(OUT, "flights")

LINES = []
FAILURES = []


def log(line):
    print(line)
    LINES.append(line)


def run(script, args):
    result = subprocess.run([sys.executable, os.path.join(WORKTREE, script)] + args,
                            capture_output=True, text=True)
    return result.returncode, result.stdout + result.stderr


def make_copy(tmp, case):
    """Symlink every flight file, so mutations can replace individual ones."""
    directory = os.path.join(tmp, "flights-" + case)
    os.makedirs(directory)
    for name in os.listdir(FLIGHTS):
        os.symlink(os.path.join(FLIGHTS, name), os.path.join(directory, name))
    return directory


def replace_row(directory, filename, mutate):
    source = os.path.join(FLIGHTS, filename)
    target = os.path.join(directory, filename)
    os.unlink(target)
    with open(source, newline="") as handle:
        rows = list(csv.DictReader(handle))
        fields = list(rows[0].keys())
    mutate(rows)
    with open(target, "w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def expect_reject(tag, code, output, needle):
    rejected = code != 0 and needle in output
    if not rejected:
        FAILURES.append(tag)
    log("fault_selftest %s %s (exit=%d, needle=%r)"
        % ("PASS" if rejected else "FAIL", tag, code, needle))
    if not rejected:
        log("  tail: " + output.strip().splitlines()[-1][:200])


def main():
    with tempfile.TemporaryDirectory() as tmp:
        # 1. dev-a outcome flip -> cross-check must fail
        directory = make_copy(tmp, "outcome")

        def flip_outcome(rows):
            row = rows[0]
            row["success"] = "0" if row["success"] == "1" else "1"
        replace_row(directory, "deva-policy-episodes.csv", flip_outcome)
        code, output = run("local_flight_evidence.py",
                           ["--flights", directory,
                            "--out", os.path.join(tmp, "out1")])
        expect_reject("flight_evidence_outcome_flip", code, output,
                      "crosscheck_outcomes")

        # 2. drop one TRAIN row -> denominator must fail
        directory = make_copy(tmp, "denominator1")

        def drop_row(rows):
            rows.pop()
        replace_row(directory, "source-policy-episodes.csv", drop_row)
        code, output = run("local_flight_evidence.py",
                           ["--flights", directory,
                            "--out", os.path.join(tmp, "out2")])
        expect_reject("flight_evidence_denominator", code, output,
                      "train_denominator")

        # 3. perturb one reward_sum -> component identity must fail
        directory = make_copy(tmp, "identity")

        def perturb_reward(rows):
            rows[0]["reward_sum"] = str(float(rows[0]["reward_sum"]) + 1.0)
        replace_row(directory, "source-policy-episodes.csv", perturb_reward)
        code, output = run("local_reward_ordering.py",
                           ["--flights", directory,
                            "--out", os.path.join(tmp, "out3")])
        expect_reject("reward_ordering_identity", code, output,
                      "component_identity")

        # 4. drop one TRAIN row -> denominator must fail
        directory = make_copy(tmp, "denominator2")
        replace_row(directory, "source-policy-episodes.csv", drop_row)
        code, output = run("local_reward_ordering.py",
                           ["--flights", directory,
                            "--out", os.path.join(tmp, "out4")])
        expect_reject("reward_ordering_denominator", code, output,
                      "full_train_denominator")

    result = "PASS" if not FAILURES else "FAIL"
    log("fault_selftest RESULT %s (%d faults injected, %d not rejected)"
        % (result, 4, len(FAILURES)))
    with open(os.path.join(OUT, "fault-selftest.log"), "w") as handle:
        handle.write("\n".join(LINES) + "\n")
    return 0 if not FAILURES else 1


if __name__ == "__main__":
    sys.exit(main())
