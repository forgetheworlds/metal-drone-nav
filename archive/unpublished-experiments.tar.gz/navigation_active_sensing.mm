// Test a shared, route-independent sensing prefix, then collect/train only if
// the prefix is safe and gives the actor a real depth-history cue.
#define NAVIGATION_IMITATION_EMBEDDED
#include "navigation_imitation.mm"
#include <memory>

namespace navigation_active_sensing {
using namespace navigation_imitation;
static_assert(fixed_ppo::actor_obs_dim==824,"active raw-depth probe must use the version-2 actor input");
struct ProbeRow {
    std::array<float,fixed_ppo::actor_obs_dim> obs{};
    std::array<float,320> depth{};
    std::array<float,320> previous_depth{};
    std::array<float,12> pose{};
    std::array<float,12> previous_pose{};
    RLPhysicsState state{};
    SimRun run{};
    uint frame=0,previous_frame=0;
};

static float yaw_from_quaternion(const float q[4]) {
    return std::atan2(2.f*(q[0]*q[3]+q[1]*q[2]),1.f-2.f*(q[2]*q[2]+q[3]*q[3]));
}
static ProbeRow observe(Sim& sim,const ProbeRow* prior) {
    observe_student(sim); ProbeRow row;
    std::memcpy(row.obs.data(),sim.obs.contents,sizeof(row.obs));
    const auto& run=*static_cast<SimRun*>(sim.runs.contents);
    require(sim.cfg.sensor_period==1&&sim.cfg.sensor_delay==0,"probe expects the current zero-delay sensor frame");
    const uint absolute_frame=run.steps/sim.cfg.sensor_period;
    const uint frame=absolute_frame%8;
    const uint previous_frame=absolute_frame>0?(absolute_frame-1)%8:frame;
    row.frame=frame;row.previous_frame=previous_frame;
    const float* sensor_frames=static_cast<const float*>(sim.sensors.contents);
    std::memcpy(row.depth.data(),sensor_frames+size_t(frame)*320,row.depth.size()*sizeof(float));
    std::memcpy(row.previous_depth.data(),sensor_frames+size_t(previous_frame)*320,row.previous_depth.size()*sizeof(float));
    const float* pose_frames=static_cast<const float*>(sim.poses.contents);
    std::memcpy(row.pose.data(),pose_frames+size_t(frame)*12,row.pose.size()*sizeof(float));
    std::memcpy(row.previous_pose.data(),pose_frames+size_t(previous_frame)*12,row.previous_pose.size()*sizeof(float));
    std::memcpy(&row.state,sim.states.contents,sizeof(row.state));
    std::memcpy(&row.run,sim.runs.contents,sizeof(row.run));
    for(uint axis=0;axis<3;axis++)require(std::fabs(row.pose[axis]-row.state.position[axis])<1e-5f,"current sensor pose does not match physics state");
    float current_rotation[9];cpu_reference::rotation(row.state.orientation_wxyz,current_rotation);
    for(uint element=0;element<9;element++)require(std::fabs(row.pose[element+3]-current_rotation[element])<1e-5f,"current sensor orientation does not match physics state");
    if(prior){
        require(previous_frame==prior->frame,"previous sensor frame index did not advance by one");
        for(uint axis=0;axis<3;axis++)require(std::fabs(row.previous_pose[axis]-prior->state.position[axis])<1e-5f,"previous sensor pose was not captured at the preceding navigation step");
        float previous_rotation[9];cpu_reference::rotation(prior->state.orientation_wxyz,previous_rotation);
        for(uint element=0;element<9;element++)require(std::fabs(row.previous_pose[element+3]-previous_rotation[element])<1e-5f,"previous sensor orientation was not captured at the preceding navigation step");
        float previous_depth_error=0;
        for(uint pixel=0;pixel<320;pixel++)previous_depth_error=std::max(previous_depth_error,std::fabs(row.previous_depth[pixel]-prior->depth[pixel]));
        require(previous_depth_error<1e-6f,"previous sensor ring frame was not captured at the preceding navigation step");
    }
    return row;
}
static double max_abs(const float* a,const float* b,size_t n,size_t* arg=nullptr) {
    double best=0;for(size_t i=0;i<n;i++){double d=std::fabs(double(a[i])-b[i]);if(d>best){best=d;if(arg)*arg=i;}}
    return best;
}
static WWorld mirror_y(WWorld world) {
    for(uint i=0;i<world.count;i++){
        world.obstacles[i].center[1]=-world.obstacles[i].center[1];
        world.obstacles[i].velocity[1]=-world.obstacles[i].velocity[1];
    }
    world.goal[1]=0.f;return world;
}
static WWorld same_goal(WWorld world) { world.goal[1]=0.f;return world; }
static std::unique_ptr<Sim> make_sim(Metal& metal,const WWorld& world,uint seed) {
    SimConfig cfg;cfg.n=1;cfg.eval=1;cfg.mode=17;cfg.family=14;cfg.speed=1.5f;cfg.max_steps=400;cfg.seed=seed;cfg.geometry_memory=1;cfg.velocity_contract=1;
    auto sim=std::make_unique<Sim>(metal,cfg,1);*static_cast<WWorld*>(sim->worlds.contents)=world;
    return sim;
}
static int probe(Metal& metal,const std::string& bank,const std::string& output,uint pair_limit,uint scan_steps,float yaw_command,float lateral_mps) {
    std::string hash;const auto levels=challenge_evaluation::load_split(bank,"train",challenge_evaluation::sha256_file(std::string(SOURCE_DIR)+"/world.hpp"),hash);
    require(hash=="e2170fbe8e8c2d074ffb08de4269175a6de0bdcd410c3b60bd699ee7b5fc491e","active sensing bank hash mismatch");
    std::ofstream csv(output+"/prefix-probe.csv");require(bool(csv),"cannot open prefix-probe.csv");
    csv<<"failure_id,stage,steps,seconds,route_turn_y,pooled_depth_history_delta_max,pooled_feature_index,pooled_feature_original,pooled_feature_mirror,pooled_feature_signed_difference,raw_actor_current_delta_max,raw_actor_current_feature,raw_actor_previous_delta_max,raw_actor_previous_feature,actor_context_delta_max,hint_delta_max,raw_sensor_depth_delta_max_m,raw_sensor_depth_argmax_pixel,body_yaw_rad,position_drift_m,collisions,minimum_clearance_m\n";
    uint pairs=0;double max_delta[7]={};constexpr uint hint_offset=fixed_ppo::actor_obs_dim-3;
    for(const auto& level:levels){
        if(level.family!=14||level.failure_id.find("-mirror-y")!=std::string::npos)continue;
        if(pair_limit&&pairs>=pair_limit)break;
        WWorld first=same_goal(level.world),second=mirror_y(level.world);
        auto a=make_sim(metal,first,level.seed),b=make_sim(metal,second,level.seed);
        const auto& route=level.witness_route;require(route.size()>1,"witness route missing");
        const float turn=float(route[1][1]-route[0][1]);require(std::fabs(turn)>1e-4f,"first witness segment has no lateral direction");
        const auto emit=[&](uint step,const ProbeRow& x,const ProbeRow& y){
            size_t depth_index=0,raw_current_index=0,raw_previous_index=0,raw_sensor_index=0;
            const double d=max_abs(x.obs.data(),y.obs.data(),160,&depth_index);
            const double raw_current=max_abs(x.obs.data()+181,y.obs.data()+181,320,&raw_current_index);
            const double raw_previous=max_abs(x.obs.data()+501,y.obs.data()+501,320,&raw_previous_index);
            const double c=max_abs(x.obs.data()+160,y.obs.data()+160,21);
            size_t hint_index=0;
            const double h=max_abs(x.obs.data()+hint_offset,y.obs.data()+hint_offset,3,&hint_index);
            const double r=max_abs(x.depth.data(),y.depth.data(),320,&raw_sensor_index);
            const double drift=std::max(std::sqrt(x.state.position[0]*x.state.position[0]+x.state.position[1]*x.state.position[1]+(x.state.position[2]-1.5f)*(x.state.position[2]-1.5f)),
                                        std::sqrt(y.state.position[0]*y.state.position[0]+y.state.position[1]*y.state.position[1]+(y.state.position[2]-1.5f)*(y.state.position[2]-1.5f)));
            const double clear=std::min(x.run.min_clearance,y.run.min_clearance);
            csv<<level.failure_id<<",snapshot,"<<step<<','<<step*.05f<<','<<turn<<','<<d<<','<<depth_index<<','<<x.obs[depth_index]<<','<<y.obs[depth_index]<<','<<(x.obs[depth_index]-y.obs[depth_index])<<','
               <<raw_current<<','<<(181+raw_current_index)<<','<<raw_previous<<','<<(501+raw_previous_index)<<','<<c<<','<<h<<','<<r<<','<<raw_sensor_index<<','
               <<yaw_from_quaternion(x.state.orientation_wxyz)<<','<<drift<<','<<(x.run.collisions+y.run.collisions)<<','<<clear<<'\n';csv.flush();
            max_delta[0]=std::max(max_delta[0],d);max_delta[1]=std::max(max_delta[1],raw_current);max_delta[2]=std::max(max_delta[2],raw_previous);
            max_delta[3]=std::max(max_delta[3],c);max_delta[4]=std::max(max_delta[4],h);max_delta[5]=std::max(max_delta[5],r);max_delta[6]=std::max(max_delta[6],drift);
        };
        ProbeRow x=observe(*a,nullptr),y=observe(*b,nullptr);uint sensed_frames=1;
        emit(0,x,y);
        for(uint i=1;i<=scan_steps;i++){
            const ProbeRow previous_x=x,previous_y=y;
            advance_teacher(*a,navigation_imitation::Point{0,lateral_mps,0},yaw_command);
            advance_teacher(*b,navigation_imitation::Point{0,lateral_mps,0},yaw_command);
            if(static_cast<SimRun*>(a->runs.contents)->episodes||static_cast<SimRun*>(b->runs.contents)->episodes)break;
            x=observe(*a,&previous_x);y=observe(*b,&previous_y);++sensed_frames;
            if(i%10==0||i==scan_steps)emit(i,x,y);
        }
        require(sensed_frames==scan_steps+1,"sensor/render frame count did not match every executed navigation step");
        ++pairs;
    }
    std::cout<<"active_sensing_probe pairs="<<pairs<<" scan_steps="<<scan_steps<<" sensed_frames_per_pair="<<scan_steps+1<<" yaw_command="<<yaw_command<<" common_lateral_mps="<<lateral_mps
             <<" max_pooled_depth_delta="<<max_delta[0]<<" max_raw_actor_current_delta="<<max_delta[1]<<" max_raw_actor_previous_delta="<<max_delta[2]
             <<" max_context_delta="<<max_delta[3]<<" max_hint_delta="<<max_delta[4]
             <<" max_raw_sensor_depth_delta_m="<<max_delta[5]<<" max_position_drift_m="<<max_delta[6]
             <<" output="<<output<<" bank_sha256="<<hash<<std::endl;
    return 0;
}

static void write_dataset(const std::string& path,const std::vector<Demonstration>& rows) {
    std::ofstream file(path,std::ios::binary);require(bool(file),"cannot open demonstration file");
    const uint64_t count=rows.size();file.write(reinterpret_cast<const char*>(&count),sizeof(count));
    if(count)file.write(reinterpret_cast<const char*>(rows.data()),std::streamsize(rows.size()*sizeof(Demonstration)));
    require(bool(file),"demonstration file write failed");
}

static void verify_row(const Demonstration& row) {
    require(std::all_of(row.observation.begin(),row.observation.end(),[](float x){return std::isfinite(x);}),"non-finite actor observation");
    require(std::all_of(row.command.begin(),row.command.end(),[](float x){return std::isfinite(x);}),"non-finite command label");
    require(std::sqrt(row.command[0]*row.command[0]+row.command[1]*row.command[1]+row.command[2]*row.command[2])<=1.001f,"velocity label exceeds normalized cap");
    require(std::fabs(row.command[3])<=1.001f,"yaw label exceeds normalized cap");
}

struct CameraTarget {
    float bearing_rad=0;
    float elevation_rad=0;
    bool visible=false;
};
static CameraTarget target_camera_view(const RLPhysicsState& state,navigation_imitation::Point position,
                                       navigation_imitation::Point target) {
    const auto delta=navigation_imitation::difference(target,position);
    float rotation[9];cpu_reference::rotation(state.orientation_wxyz,rotation);
    navigation_imitation::Point body{
        rotation[0]*delta[0]+rotation[3]*delta[1]+rotation[6]*delta[2],
        rotation[1]*delta[0]+rotation[4]*delta[1]+rotation[7]*delta[2],
        rotation[2]*delta[0]+rotation[5]*delta[1]+rotation[8]*delta[2]};
    CameraTarget result;
    result.bearing_rad=std::atan2(body[1],body[0]);
    result.elevation_rad=std::atan2(body[2],std::hypot(body[0],body[1]));
    result.visible=body[0]>0&&std::fabs(result.bearing_rad)<=.70f&&std::fabs(result.elevation_rad)<=.40f;
    return result;
}

static int collect_training_data(Metal& metal,const std::string& bank,const std::string& warm,const std::string& output) {
    std::string bank_hash;const auto levels=challenge_evaluation::load_split(bank,"train",challenge_evaluation::sha256_file(std::string(SOURCE_DIR)+"/world.hpp"),bank_hash);
    require(bank_hash=="e2170fbe8e8c2d074ffb08de4269175a6de0bdcd410c3b60bd699ee7b5fc491e","active-sensing collection bank mismatch");
    std::ifstream checkpoint(warm,std::ios::binary);const auto header=read_checkpoint_header(checkpoint);
    require(bool(checkpoint)&&header.actor_count==fixed_ppo::actor_param_count&&header.critic_count==fixed_ppo::critic_param_count,"retention checkpoint dimensions");
    std::vector<float> checkpoint_actor(header.actor_count),checkpoint_critic(header.critic_count);
    checkpoint.read(reinterpret_cast<char*>(checkpoint_actor.data()),std::streamsize(checkpoint_actor.size()*sizeof(float)));
    checkpoint.read(reinterpret_cast<char*>(checkpoint_critic.data()),std::streamsize(checkpoint_critic.size()*sizeof(float)));
    require(bool(checkpoint),"retention checkpoint parameter read failed");
    struct CornerEpisode {
        std::string failure_id;
        uint environment_index=0;
        bool success=false;
        uint prefix_ticks=0;
        uint yaw_only_ticks=0;
        bool branch_target_visible=false;
        float branch_route_y=0,branch_target_bearing=0;
        double elapsed_s=0,path_m=0,minimum_clearance_m=0;
        std::vector<Demonstration> prefix,route;
        std::array<float,observation_count> branch_observation{};
    };
    std::vector<CornerEpisode> corner_episodes;
    std::unordered_map<std::string,size_t> corner_episode_index;
    std::vector<Demonstration> prefix_rows,corner_route_rows,room_rows,vertical_rows;
    std::ofstream episodes(output+"/collection.csv");require(bool(episodes),"cannot open collection.csv");
    episodes<<"failure_id,family,source,success,collision,timeout,elapsed_s,path_m,minimum_clearance_m,prefix_ticks,route_yaw_only_steps,first_target_bearing_deg,first_target_in_fov,rows_saved,bank_sha256\n";
    constexpr uint prefix_steps=40,retention_stride=2;constexpr float scan_y_mps=.15f,scan_yaw=1.0f;
    uint corner_count=0,room_count=0,vertical_count=0,corner_success=0,room_success=0,vertical_success=0;
    for(const auto& level:levels) {
        if(level.family!=14)continue;
        SimConfig cfg;cfg.n=1;cfg.eval=1;cfg.mode=17;cfg.family=14;cfg.speed=1.5f;cfg.max_steps=400;cfg.seed=level.seed;cfg.geometry_memory=1;cfg.velocity_contract=1;
        Sim sim(metal,cfg,1);*static_cast<WWorld*>(sim.worlds.contents)=level.world;
        auto& run=*static_cast<SimRun*>(sim.runs.contents);auto& state=*static_cast<RLPhysicsState*>(sim.states.contents);
        const WWorld source_world=level.world;
        run.initial_distance=length(difference({source_world.goal[0],source_world.goal[1],source_world.goal[2]},{state.position[0],state.position[1],state.position[2]}));
        CornerEpisode episode;episode.failure_id=level.failure_id;episode.environment_index=level.environment_index;
        episode.prefix.reserve(prefix_steps);episode.route.reserve(360);
        for(uint step=0;step<prefix_steps&&!run.episodes;step++) {
            observe_student(sim);
            Demonstration row;std::memcpy(row.observation.data(),sim.obs.contents,sizeof(row.observation));
            float r[9];cpu_reference::rotation(state.orientation_wxyz,r);
            navigation_imitation::Point common{0,scan_y_mps,0};
            for(uint axis=0;axis<3;axis++)row.command[axis]=(r[axis]*common[0]+r[3+axis]*common[1]+r[6+axis]*common[2])/cfg.speed;
            row.command[3]=scan_yaw;verify_row(row);episode.prefix.push_back(row);
            require(std::memcmp(static_cast<WWorld*>(sim.worlds.contents)->goal,source_world.goal,sizeof(source_world.goal))==0,"scan prefix changed final goal");
            advance_teacher(sim,common,scan_yaw);
        }
        episode.prefix_ticks=run.steps;
        if(episode.prefix_ticks==prefix_steps&&!run.episodes) {
            bool branch_saved=false;
            while(!run.episodes&&run.steps<cfg.max_steps) {
                observe_student(sim);
                if(!branch_saved) {
                    std::memcpy(episode.branch_observation.data(),sim.obs.contents,sizeof(episode.branch_observation));
                    episode.branch_route_y=float(level.witness_route[1][1]-level.witness_route[0][1]);branch_saved=true;
                }
                navigation_imitation::Point position{state.position[0],state.position[1],state.position[2]};
                auto target=route_target(source_world,level.witness_route,position,run.elapsed);
                navigation_imitation::Point velocity=difference(target,position);const float magnitude=length(velocity);
                const float scale=std::min(1.f,1.49f/std::max(magnitude,1e-8f));for(float& v:velocity)v*=scale;
                const CameraTarget camera=target_camera_view(state,position,target);
                if(!episode.yaw_only_ticks&&!episode.route.size()) {
                    episode.branch_target_visible=camera.visible;
                    episode.branch_target_bearing=camera.bearing_rad;
                }
                // The route teacher may target a point outside the current
                // camera view. This is privileged TRAIN supervision after the
                // raw paired input is measured; record the view for review.
                // Do not claim that an off-camera route point is observable.
                const float yaw_command=0.f;
                Demonstration row;std::memcpy(row.observation.data(),sim.obs.contents,sizeof(row.observation));
                float r[9];cpu_reference::rotation(state.orientation_wxyz,r);
                for(uint axis=0;axis<3;axis++)row.command[axis]=(r[axis]*velocity[0]+r[3+axis]*velocity[1]+r[6+axis]*velocity[2])/cfg.speed;
                row.command[3]=yaw_command;verify_row(row);episode.route.push_back(row);
                require(std::memcmp(static_cast<WWorld*>(sim.worlds.contents)->goal,source_world.goal,sizeof(source_world.goal))==0,"route teacher changed final goal");
                if(yaw_command!=0)episode.yaw_only_ticks++;
                advance_teacher(sim,velocity,yaw_command);
            }
        }
        const bool success=run.successes>0&&!run.collisions&&!run.timeouts;
        episode.success=success;episode.elapsed_s=run.elapsed;episode.path_m=run.path;episode.minimum_clearance_m=run.min_clearance;
        corner_episode_index[episode.failure_id]=corner_episodes.size();corner_episodes.push_back(std::move(episode));
        if(success)++corner_success;
        ++corner_count;
        const auto& saved=corner_episodes.back();
        episodes<<level.failure_id<<",14,active_route_teacher,"<<success<<','<<bool(run.collisions)<<','<<bool(run.timeouts)<<','<<run.elapsed<<','<<run.path<<','<<run.min_clearance<<','<<saved.prefix_ticks<<','<<saved.yaw_only_ticks<<','<<saved.branch_target_bearing*57.29578f<<','<<saved.branch_target_visible<<','<<(success?saved.prefix.size()+saved.route.size():0)<<','<<bank_hash<<'\n';episodes.flush();
        std::cout<<"corner_teacher "<<corner_count<<"/30 success="<<success<<" prefix_ticks="<<saved.prefix_ticks<<" route_yaw_steps="<<saved.yaw_only_ticks<<" first_bearing_deg="<<saved.branch_target_bearing*57.29578f<<" first_in_fov="<<saved.branch_target_visible<<" rows="<<(success?saved.prefix.size()+saved.route.size():0)<<" t="<<run.elapsed<<std::endl;
    }

    std::ofstream pairs(output+"/branch-pair-deltas.csv");require(bool(pairs),"cannot write paired route observation table");
    pairs<<"failure_id,mirror_id,route_y_original,route_y_mirror,branch_target_visible_original,branch_target_visible_mirror,branch_bearing_original_deg,branch_bearing_mirror_deg,pooled_delta,raw_current_delta,raw_previous_delta,context_delta,hint_delta,route_labels_enabled\n";
    uint paired=0,raw_separated=0;
    for(const auto& level:levels)if(level.family==14&&level.environment_index%2==0) {
        const challenge_evaluation::Level* mirror=nullptr;
        for(const auto& candidate:levels)if(candidate.family==14&&candidate.environment_index==level.environment_index+1){mirror=&candidate;break;}
        require(mirror!=nullptr&&mirror->failure_id.find("-mirror-y")!=std::string::npos,"cannot resolve actual mirror partner");
        const auto left=corner_episode_index.find(level.failure_id),right=corner_episode_index.find(mirror->failure_id);
        require(left!=corner_episode_index.end()&&right!=corner_episode_index.end(),"missing collected branch observation for mirror pair");
        auto& original=corner_episodes[left->second];auto& reflected=corner_episodes[right->second];
        const auto& x=original.branch_observation;const auto& y=reflected.branch_observation;
        require(original.branch_route_y*reflected.branch_route_y<0,"mirror pair route turns are not opposite");
        const double pooled=max_abs(x.data(),y.data(),160),rawc=max_abs(x.data()+181,y.data()+181,320),rawp=max_abs(x.data()+501,y.data()+501,320);
        const double context=max_abs(x.data()+160,y.data()+160,21),hint=max_abs(x.data()+821,y.data()+821,3);
        const bool cue=std::max(rawc,rawp)>.01;
        pairs<<level.failure_id<<','<<mirror->failure_id<<','<<original.branch_route_y<<','<<reflected.branch_route_y<<','
             <<original.branch_target_visible<<','<<reflected.branch_target_visible<<','<<original.branch_target_bearing*57.29578f<<','<<reflected.branch_target_bearing*57.29578f<<','
             <<pooled<<','<<rawc<<','<<rawp<<','<<context<<','<<hint<<','<<cue<<'\n';
        if(cue){raw_separated++;if(original.success)corner_route_rows.insert(corner_route_rows.end(),original.route.begin(),original.route.end());
            if(reflected.success)corner_route_rows.insert(corner_route_rows.end(),reflected.route.begin(),reflected.route.end());}
        if(original.success)prefix_rows.insert(prefix_rows.end(),original.prefix.begin(),original.prefix.end());
        if(reflected.success)prefix_rows.insert(prefix_rows.end(),reflected.prefix.begin(),reflected.prefix.end());
        ++paired;
    }
    require(paired==15,"expected15 actual mirrored branch pairs after the common prefix");

    for(const auto& level:levels) {
        if(level.family!=15&&level.family!=16)continue;
        const bool room=level.family==15;
        SimConfig cfg;cfg.n=1;cfg.eval=1;cfg.mode=17;cfg.family=level.family;cfg.speed=1.5f;cfg.max_steps=400;cfg.seed=level.seed;cfg.geometry_memory=1;cfg.velocity_contract=header.config.velocity_contract;
        Sim sim(metal,cfg,1);navigation_training::load_actor(sim,warm,true);
        *static_cast<WWorld*>(sim.worlds.contents)=level.world;
        auto& run=*static_cast<SimRun*>(sim.runs.contents);auto& state=*static_cast<RLPhysicsState*>(sim.states.contents);
        const WWorld source_world=level.world;
        run.initial_distance=length(difference({source_world.goal[0],source_world.goal[1],source_world.goal[2]},{state.position[0],state.position[1],state.position[2]}));
        std::vector<Demonstration> episode;episode.reserve(200);
        while(!run.episodes&&run.steps<cfg.max_steps) {
            RLPhysicsState state_before=state;
            auto cb=[metal.queue commandBuffer];sim.collect(cb,1);metal.finish(cb);
            const bool terminal=run.episodes!=0;
            if(!terminal) {
                Demonstration row;std::memcpy(row.observation.data(),sim.obs.contents,sizeof(row.observation));
                float rotation[9];cpu_reference::rotation(state_before.orientation_wxyz,rotation);
                for(uint axis=0;axis<3;axis++)row.command[axis]=(rotation[axis]*run.desired_velocity[0]+rotation[3+axis]*run.desired_velocity[1]+rotation[6+axis]*run.desired_velocity[2])/cfg.speed;
                row.command[3]=run.previous_nav[3];verify_row(row);
                if((run.steps-1)%retention_stride==0)episode.push_back(row);
                require(std::memcmp(static_cast<WWorld*>(sim.worlds.contents)->goal,source_world.goal,sizeof(source_world.goal))==0,"retention policy changed final goal");
            }
        }
        const bool success=run.successes>0&&!run.collisions&&!run.timeouts;
        if(success){if(room){room_rows.insert(room_rows.end(),episode.begin(),episode.end());++room_success;}else{vertical_rows.insert(vertical_rows.end(),episode.begin(),episode.end());++vertical_success;}}
        if(room)++room_count;else ++vertical_count;
        episodes<<level.failure_id<<','<<level.family<<",rooms_focused_policy,"<<success<<','<<bool(run.collisions)<<','<<bool(run.timeouts)<<','<<run.elapsed<<','<<run.path<<','<<run.min_clearance<<",0,"<<(success?episode.size():0)<<','<<bank_hash<<'\n';episodes.flush();
        std::cout<<(room?"room_retention ":"vertical_retention ")<<(room?room_count:vertical_count)<<"/30 success="<<success<<" kept_rows="<<(success?episode.size():0)<<" t="<<run.elapsed<<std::endl;
    }

    const size_t rows_total=prefix_rows.size()+corner_route_rows.size()+room_rows.size()+vertical_rows.size();
    require(rows_total<=20000,"active-sensing dataset exceeded the 20,000 row budget");
    require(!prefix_rows.empty()&&!corner_route_rows.empty()&&!room_rows.empty()&&!vertical_rows.empty(),"one or more successful demonstration groups are empty");
    write_dataset(output+"/corner-prefix.bin",prefix_rows);write_dataset(output+"/corner-route.bin",corner_route_rows);
    write_dataset(output+"/room-retention.bin",room_rows);write_dataset(output+"/vertical-retention.bin",vertical_rows);
    std::cout<<"collection_complete corner_success="<<corner_success<<"/"<<corner_count<<" room_success="<<room_success<<"/"<<room_count
             <<" vertical_success="<<vertical_success<<"/"<<vertical_count<<" prefix_rows="<<prefix_rows.size()<<" corner_route_rows="<<corner_route_rows.size()
             <<" room_rows="<<room_rows.size()<<" vertical_rows="<<vertical_rows.size()<<" total_rows="<<rows_total
             <<" actual_pair_raw_current_separation_gt_0.01="<<raw_separated<<"/"<<paired<<std::endl;
    return 0;
}

static std::vector<Demonstration> read_dataset(const std::string& path) {
    std::ifstream file(path,std::ios::binary);require(bool(file),"cannot open imitation dataset: "+path);
    uint64_t count=0;file.read(reinterpret_cast<char*>(&count),sizeof(count));
    require(bool(file)&&count>0&&count<=20000,"invalid imitation dataset count: "+path);
    require(std::filesystem::file_size(path)==sizeof(count)+count*sizeof(Demonstration),"imitation dataset observation version/size mismatch: "+path);
    std::vector<Demonstration> rows(static_cast<size_t>(count));
    file.read(reinterpret_cast<char*>(rows.data()),std::streamsize(rows.size()*sizeof(Demonstration)));
    require(bool(file),"truncated imitation dataset: "+path);
    for(const auto& row:rows)verify_row(row);
    return rows;
}

// Build source corrections on states visited by the actual warm-start actor.
// A common, route-independent prefix exposes the branch cue before the actor
// takes control. The witness route supplies a turn label while its next point
// is outside horizontal view, then velocity labels once that point is visible.
// It never changes the student's observation or command stream.
static int collect_recovery_data(Metal& metal,const std::string& bank,const std::string& warm,const std::string& output) {
    std::string bank_hash;const auto levels=challenge_evaluation::load_split(bank,"train",challenge_evaluation::sha256_file(std::string(SOURCE_DIR)+"/world.hpp"),bank_hash);
    require(bank_hash=="e2170fbe8e8c2d074ffb08de4269175a6de0bdcd410c3b60bd699ee7b5fc491e","recovery bank hash mismatch");
    std::ifstream checkpoint(warm,std::ios::binary);const auto header=read_checkpoint_header(checkpoint);
    require(bool(checkpoint)&&header.actor_count==fixed_ppo::actor_param_count,"recovery checkpoint dimensions");
    fixed_ppo::ActorParams actor{};checkpoint.read(reinterpret_cast<char*>(actor.values.data()),std::streamsize(actor.values.size()*sizeof(float)));
    require(bool(checkpoint),"recovery checkpoint actor read failed");

    std::vector<Demonstration> prefix_rows,route_rows;
    std::ofstream steps(output+"/learner-states.csv");require(bool(steps),"cannot write learner-states.csv");
    steps<<"failure_id,phase,step,time_s,observation_x,observation_y,observation_z,observation_yaw,teacher_target_bearing_deg,target_in_fov,teacher_label_feasible,label_vx,label_vy,label_vz,label_yaw,executed_vx,executed_vy,executed_vz,executed_yaw,speed_mps,collision,success,bank_sha256\n";
    std::ofstream episodes(output+"/rollout-summary.csv");require(bool(episodes),"cannot write rollout-summary.csv");
    episodes<<"failure_id,seed,success,collision,timeout,elapsed_s,path_m,peak_speed_mps,minimum_clearance_m,prefix_ticks,student_route_ticks,visible_route_rows,saved_prefix_rows,saved_route_rows,bank_sha256\n";
    constexpr uint prefix_steps=40;constexpr float scan_y_mps=.15f,scan_yaw=.9f;
    uint scene_count=0,prefix_count=0,visible_rows=0,collision_count=0,success_count=0;
    for(const auto& level:levels) {
        if(level.family!=14)continue;
        SimConfig cfg;cfg.n=1;cfg.eval=1;cfg.mode=17;cfg.family=14;cfg.speed=1.5f;cfg.max_steps=400;cfg.seed=level.seed;cfg.geometry_memory=1;cfg.velocity_contract=header.config.velocity_contract;
        Sim sim(metal,cfg,1);navigation_training::load_actor(sim,warm,true);*static_cast<WWorld*>(sim.worlds.contents)=level.world;
        auto& run=*static_cast<SimRun*>(sim.runs.contents);auto& state=*static_cast<RLPhysicsState*>(sim.states.contents);
        const WWorld source_world=level.world;
        run.initial_distance=length(difference({source_world.goal[0],source_world.goal[1],source_world.goal[2]},{state.position[0],state.position[1],state.position[2]}));
        uint saved_prefix=0,saved_route=0,route_ticks=0,visible_for_episode=0;
        for(uint tick=0;tick<prefix_steps&&!run.episodes;tick++) {
            observe_student(sim);Demonstration row;std::memcpy(row.observation.data(),sim.obs.contents,sizeof(row.observation));
            float rotation[9];cpu_reference::rotation(state.orientation_wxyz,rotation);
            const navigation_imitation::Point scan{0,scan_y_mps,0};
            for(uint axis=0;axis<3;axis++)row.command[axis]=(rotation[axis]*scan[0]+rotation[3+axis]*scan[1]+rotation[6+axis]*scan[2])/cfg.speed;
            row.command[3]=scan_yaw;verify_row(row);prefix_rows.push_back(row);++saved_prefix;
            require(std::memcmp(static_cast<WWorld*>(sim.worlds.contents)->goal,source_world.goal,sizeof(source_world.goal))==0,"scan prefix changed final goal");
            advance_teacher(sim,scan,scan_yaw);
        }
        require(run.steps==prefix_steps&&!run.episodes,"common sensing prefix did not finish in 40 ticks");
        while(!run.episodes&&run.steps<cfg.max_steps) {
            observe_student(sim);
            const navigation_imitation::Point position{state.position[0],state.position[1],state.position[2]};
            const auto target=route_target(source_world,level.witness_route,position,run.elapsed);
            const auto camera=target_camera_view(state,position,target);
            auto velocity=difference(target,position);const float magnitude=length(velocity);
            if(magnitude>1.49f)for(float& component:velocity)component*=1.49f/magnitude;
            Demonstration label;std::memcpy(label.observation.data(),sim.obs.contents,sizeof(label.observation));
            float rotation[9];cpu_reference::rotation(state.orientation_wxyz,rotation);
            const bool can_turn_to_target=!camera.visible&&std::fabs(camera.bearing_rad)>.70f&&std::fabs(camera.elevation_rad)<=.40f;
            const RLPhysicsState observation_state=state;
            if(camera.visible||can_turn_to_target) {
                if(camera.visible) {
                    for(uint axis=0;axis<3;axis++)label.command[axis]=(rotation[axis]*velocity[0]+rotation[3+axis]*velocity[1]+rotation[6+axis]*velocity[2])/cfg.speed;
                    label.command[3]=0.f;++visible_for_episode;++visible_rows;
                } else {
                    label.command[0]=label.command[1]=label.command[2]=0.f;
                    label.command[3]=std::copysign(.8f,camera.bearing_rad);
                }
                verify_row(label);route_rows.push_back(label);++saved_route;
            }
            require(std::memcmp(static_cast<WWorld*>(sim.worlds.contents)->goal,source_world.goal,sizeof(source_world.goal))==0,"student goal changed during recovery rollout");
            auto cb=[metal.queue commandBuffer];sim.collect(cb,1);metal.finish(cb);++route_ticks;
            const auto& current=*static_cast<RLPhysicsState*>(sim.states.contents);
            const auto& current_run=*static_cast<SimRun*>(sim.runs.contents);
            float yaw=yaw_from_quaternion(observation_state.orientation_wxyz);
            steps<<level.failure_id<<",student,"<<current_run.steps<<','<<current_run.elapsed<<','<<observation_state.position[0]<<','<<observation_state.position[1]<<','<<observation_state.position[2]<<','<<yaw<<','
                 <<camera.bearing_rad*57.29578f<<','<<camera.visible<<','<<(camera.visible||can_turn_to_target)<<','<<label.command[0]<<','<<label.command[1]<<','<<label.command[2]<<','<<label.command[3]<<','
                 <<current_run.previous_nav[0]<<','<<current_run.previous_nav[1]<<','<<current_run.previous_nav[2]<<','<<current_run.previous_nav[3]<<','<<length({current.linear_velocity[0],current.linear_velocity[1],current.linear_velocity[2]})<<','
                 <<bool(current_run.collisions)<<','<<bool(current_run.successes)<<','<<bank_hash<<'\n';steps.flush();
        }
        const bool success=run.successes>0&&!run.collisions&&!run.timeouts;
        success_count+=uint(success);collision_count+=uint(bool(run.collisions));++scene_count;
        episodes<<level.failure_id<<','<<level.seed<<','<<success<<','<<bool(run.collisions)<<','<<bool(run.timeouts)<<','<<run.elapsed<<','<<run.path<<','<<run.peak_speed<<','<<run.min_clearance<<','
                <<saved_prefix<<','<<route_ticks<<','<<visible_for_episode<<','<<saved_prefix<<','<<saved_route<<','<<bank_hash<<'\n';episodes.flush();
        std::cout<<"recovery_rollout "<<scene_count<<"/30 id="<<level.failure_id<<" success="<<success<<" collision="<<bool(run.collisions)
                 <<" prefix="<<saved_prefix<<" actor_ticks="<<route_ticks<<" visible_route_rows="<<visible_for_episode<<" correction_rows="<<saved_route<<" elapsed="<<run.elapsed
                 <<" path="<<run.path<<" peak_speed="<<run.peak_speed<<" clearance="<<run.min_clearance<<std::endl;
    }
    require(scene_count==30&&!prefix_rows.empty()&&!route_rows.empty(),"recovery rollout data is incomplete");
    require(prefix_rows.size()+route_rows.size()<=20000,"recovery correction rows exceed limit");
    write_dataset(output+"/corner-prefix.bin",prefix_rows);write_dataset(output+"/corner-route.bin",route_rows);
    std::cout<<"recovery_collection_complete train="<<scene_count<<" success="<<success_count<<" collision="<<collision_count
             <<" prefix_rows="<<prefix_rows.size()<<" on_policy_visible_route_rows="<<route_rows.size()<<" visible_rows="<<visible_rows
             <<" bank_sha256="<<bank_hash<<std::endl;
    return 0;
}

struct DevCounts {
    std::array<uint32_t,3> episodes{},success{},collision{},timeout{};
};
static std::vector<std::string> split_csv_line(const std::string& line) {
    std::vector<std::string> fields;std::string field;bool quoted=false;
    for(size_t i=0;i<line.size();i++) {
        const char c=line[i];
        if(c=='"') {
            if(quoted&&i+1<line.size()&&line[i+1]=='"'){field.push_back('"');++i;}
            else quoted=!quoted;
        } else if(c==','&&!quoted) {fields.push_back(field);field.clear();}
        else field.push_back(c);
    }
    fields.push_back(field);return fields;
}
static DevCounts read_dev_counts(const std::string& path) {
    std::ifstream file(path);require(bool(file),"cannot open evaluation CSV: "+path);
    std::string line;std::getline(file,line);const auto header=split_csv_line(line);
    const auto column=[&](const std::string& name){auto it=std::find(header.begin(),header.end(),name);require(it!=header.end(),"missing evaluation CSV column: "+name);return size_t(it-header.begin());};
    const size_t family_column=column("family"),success_column=column("success"),collision_column=column("collision"),timeout_column=column("timeout");
    DevCounts result;
    while(std::getline(file,line)) {
        const auto fields=split_csv_line(line);
        require(fields.size()>std::max({family_column,success_column,collision_column,timeout_column}),"evaluation CSV row has too few columns");
        const uint family=uint(std::stoul(fields[family_column]));if(family<14||family>16)continue;
        const uint slot=family-14;result.episodes[slot]++;
        result.success[slot]+=uint(std::stoul(fields[success_column]));
        result.collision[slot]+=uint(std::stoul(fields[collision_column]));
        result.timeout[slot]+=uint(std::stoul(fields[timeout_column]));
    }
    return result;
}

static void train_balanced(Metal& metal,const std::string& bank,const std::string& warm,
                           const std::string& output,uint updates) {
    require(updates>=1&&updates<=1500,"active-sensing imitation budget must be1..1500 updates");
    auto prefix=read_dataset(output+"/corner-prefix.bin");
    auto corner=read_dataset(output+"/corner-route.bin");
    auto rooms=read_dataset(output+"/room-retention.bin");
    auto vertical=read_dataset(output+"/vertical-retention.bin");
    const size_t total_rows=prefix.size()+corner.size()+rooms.size()+vertical.size();
    require(total_rows<=20000,"active-sensing training dataset exceeded row budget");
    require(fixed_ppo::actor_obs_dim==824,"active sensing training requires the version2 raw-depth actor");

    constexpr uint batch=256,per_group=batch/4;
    SimConfig cfg;cfg.n=1;cfg.mode=22;cfg.geometry_memory=1;cfg.speed=1.5f;cfg.max_steps=400;cfg.seed=42;
    cfg.velocity_contract=1;
    Sim policy(metal,cfg,1);navigation_training::load_actor(policy,warm,true);PPOTrainer checkpoint(policy);
    const auto evaluate=[&](const std::string& checkpoint_path,const std::string& csv_path) {
        auto score=raw_depth_bank_evaluate(metal,checkpoint_path,bank,"dev",csv_path,17,1.5f,400);
        auto counts=read_dev_counts(csv_path);
        require(score.episodes==90&&counts.episodes[0]==30&&counts.episodes[1]==30&&counts.episodes[2]==30,
                "raw DEV evaluation must include all90 unchanged mirrored levels");
        return counts;
    };
    const std::string candidate=output+"/candidate-current.bin";
    checkpoint.save_checkpoint(candidate,14,42,0);
    const auto baseline=evaluate(candidate,output+"/baseline-dev.csv");
    require(baseline.success[0]==0&&baseline.success[1]==25&&baseline.success[2]==29,
            "rawlift warmstart differs from required54/90 original DEV baseline");
    std::ofstream history(output+"/training-history.csv");require(bool(history),"cannot write training history");
    history<<"update,command_mse,prefix_mse,corner_route_mse,room_mse,vertical_mse,total_dev_f14,total_dev_f15,total_dev_f16,total_dev,collision14,collision15,collision16,timeout14,timeout15,timeout16,wall_s\n";
    history<<"0,0,0,0,0,0,0,25,29,54,30,5,1,0,0,0,0\n";history.flush();

    auto observations=metal.buffer(size_t(batch)*observation_count*sizeof(float));
    auto targets=metal.buffer(size_t(batch)*4*sizeof(float));
    auto hidden=metal.buffer(size_t(batch)*fixed_ppo::hidden_dim*sizeof(float));
    auto means=metal.buffer(size_t(batch)*4*sizeof(float));
    auto dmean=metal.buffer(size_t(batch)*4*sizeof(float));
    auto dstd=metal.buffer(size_t(batch)*4*sizeof(float));
    auto delta=metal.buffer(size_t(batch)*fixed_ppo::hidden_dim*sizeof(float));
    auto gradient=metal.buffer(fixed_ppo::actor_param_count*sizeof(float));
    auto first=metal.buffer(fixed_ppo::actor_param_count*sizeof(float));
    auto second=metal.buffer(fixed_ppo::actor_param_count*sizeof(float));
    auto losses=metal.buffer(size_t(batch)*sizeof(float));
    auto count=PPOTrainer::scalar(metal,batch),parameter_count=PPOTrainer::scalar(metal,uint(fixed_ppo::actor_param_count));
    auto norm_limit=PPOTrainer::scalar(metal,.5f),factor=metal.buffer(sizeof(float)),optimizer=metal.buffer(sizeof(PpoAdamHostConfig));
    std::memset(first.contents,0,first.length);std::memset(second.contents,0,second.length);std::memset(dstd.contents,0,dstd.length);
    std::mt19937 rng(42);
    std::uniform_int_distribution<size_t> sample_prefix(0,prefix.size()-1),sample_corner(0,corner.size()-1),sample_rooms(0,rooms.size()-1),sample_vertical(0,vertical.size()-1);
    const std::array<const std::vector<Demonstration>*,4> groups{{&prefix,&corner,&rooms,&vertical}};
    const double start=seconds();uint32_t best_corner=0;bool best_saved=false;
    for(uint step=1;step<=updates;step++){@autoreleasepool{
        for(uint n=0;n<batch;n++) {
            const uint group=n/per_group;const std::vector<Demonstration>* rows=groups[group];size_t index=0;
            if(group==0)index=sample_prefix(rng);else if(group==1)index=sample_corner(rng);else if(group==2)index=sample_rooms(rng);else index=sample_vertical(rng);
            const auto& sample=(*rows)[index];
            std::memcpy(static_cast<float*>(observations.contents)+size_t(n)*observation_count,sample.observation.data(),observation_count*sizeof(float));
            std::memcpy(static_cast<float*>(targets.contents)+size_t(n)*4,sample.command.data(),4*sizeof(float));
        }
        PpoAdamHostConfig settings{.0003f,.9f,.999f,1e-8f,0,step};std::memcpy(optimizer.contents,&settings,sizeof(settings));
        auto cb=[metal.queue commandBuffer];
        metal.dispatch(cb,metal.pipeline("ppo_actor_forward"),batch,{observations,policy.actor,hidden,means,count},64);
        metal.dispatch(cb,metal.pipeline("imitation_gradient"),batch,{observations,means,targets,dmean,losses,count},64);
        metal.dispatch(cb,metal.pipeline("ppo_actor_hidden_delta"),batch*fixed_ppo::hidden_dim,{policy.actor,dmean,hidden,delta,count},128);
        metal.dispatch(cb,metal.pipeline("ppo_actor_grad_direct"),fixed_ppo::actor_param_count,{observations,hidden,dmean,dstd,delta,gradient,count},128);
        metal.dispatch(cb,metal.pipeline("ppo_grad_scale_factor"),256,{gradient,factor,parameter_count,norm_limit},256);
        metal.dispatch(cb,metal.pipeline("ppo_apply_grad_scale"),fixed_ppo::actor_param_count,{gradient,factor,parameter_count},128);
        metal.dispatch(cb,metal.pipeline("ppo_adam_update"),fixed_ppo::actor_param_count,{policy.actor,gradient,first,second,parameter_count,optimizer},128);
        metal.finish(cb);
        if(step%100==0||step==updates) {
            double group_loss[4]={};for(uint n=0;n<batch;n++)group_loss[n/per_group]+=static_cast<float*>(losses.contents)[n];
            for(double& value:group_loss)value/=per_group;
            checkpoint.save_checkpoint(candidate,14,42,step);
            const auto counts=evaluate(candidate,output+"/dev-current.csv");
            const uint total=counts.success[0]+counts.success[1]+counts.success[2];
            history<<step<<','<<(group_loss[0]+group_loss[1]+group_loss[2]+group_loss[3])/4<<','<<group_loss[0]<<','<<group_loss[1]<<','<<group_loss[2]<<','<<group_loss[3]
                   <<','<<counts.success[0]<<','<<counts.success[1]<<','<<counts.success[2]<<','<<total
                   <<','<<counts.collision[0]<<','<<counts.collision[1]<<','<<counts.collision[2]
                   <<','<<counts.timeout[0]<<','<<counts.timeout[1]<<','<<counts.timeout[2]<<','<<seconds()-start<<'\n';history.flush();
            if(counts.success[0]>best_corner&&counts.success[1]>=25&&counts.success[2]>=29) {
                best_corner=uint32_t(counts.success[0]);best_saved=true;
                std::filesystem::copy_file(candidate,output+"/candidate-eligible-best.bin",std::filesystem::copy_options::overwrite_existing);
                std::filesystem::copy_file(output+"/dev-current.csv",output+"/candidate-eligible-best-dev.csv",std::filesystem::copy_options::overwrite_existing);
            }
            std::cout<<"balanced_imitation update="<<step<<" mse="<<(group_loss[0]+group_loss[1]+group_loss[2]+group_loss[3])/4
                     <<" prefix="<<group_loss[0]<<" corner="<<group_loss[1]<<" room="<<group_loss[2]<<" vertical="<<group_loss[3]
                     <<" dev="<<counts.success[0]<<'/'<<counts.success[1]<<'/'<<counts.success[2]<<"/"<<total
                     <<" eligible_best="<<best_saved<<" wall_s="<<seconds()-start<<std::endl;
        }
    }}
}

static float student_yaw_command(const Demonstration& row,const fixed_ppo::ActorParams& actor) {
    float hidden[fixed_ppo::hidden_dim],mean[4];fixed_ppo::actor_forward(row.observation.data(),actor,hidden,mean);
    float open=0;for(uint k=0;k<20;k++)open+=row.observation[k]*12>2.5f;
    const float gate=.25f+.75f*open/20;
    return std::tanh(gate*mean[3]);
}

static int diagnose_candidate(Metal& metal,const std::string& bank,const std::string& checkpoint_path,const std::string& output) {
    std::string bank_hash;const auto levels=challenge_evaluation::load_split(bank,"train",challenge_evaluation::sha256_file(std::string(SOURCE_DIR)+"/world.hpp"),bank_hash);
    std::ifstream checkpoint(checkpoint_path,std::ios::binary);const auto header=read_checkpoint_header(checkpoint);
    require(bool(checkpoint)&&header.actor_count==fixed_ppo::actor_param_count&&header.critic_count==fixed_ppo::critic_param_count,"candidate checkpoint dimensions");
    fixed_ppo::ActorParams actor{};checkpoint.read(reinterpret_cast<char*>(actor.values.data()),std::streamsize(actor.values.size()*sizeof(float)));
    require(bool(checkpoint),"candidate actor read failed");
    std::ofstream csv(output+"/trajectory-diagnostic.csv");require(bool(csv),"cannot write trajectory-diagnostic.csv");
    csv<<"failure_id,mirror_id,route_y,teacher_prefix_yaw_rad,teacher_prefix_x,teacher_prefix_y,student_initial_x,student_initial_y,student_initial_z,student_initial_yaw,student_first_action_x,student_first_action_y,student_first_action_z,student_first_action_yaw,teacher_branch_x,teacher_branch_y,teacher_branch_z,teacher_branch_yaw,student_branch_x,student_branch_y,student_branch_z,student_branch_yaw,teacher_target_bearing_deg,teacher_target_in_fov,student_branch_action_x,student_branch_action_y,student_branch_action_z,student_branch_action_yaw,student_branch_cosine,student_branch_turn_sign,first_contact_time_s,success,collision,timeout,elapsed_s,path_m,min_clearance_m,progress\n";
    const std::set<uint> selected_environment_pairs{0,4,14,28};
    uint written=0;
    for(const auto& level:levels) {
        if(level.family!=14||level.environment_index%2!=0||!selected_environment_pairs.count(level.environment_index))continue;
        const challenge_evaluation::Level* mirror=nullptr;
        for(const auto& candidate:levels)if(candidate.family==14&&candidate.environment_index==level.environment_index+1){mirror=&candidate;break;}
        require(mirror!=nullptr,"diagnostic pair missing mirror TRAIN level");
        for(const auto* scene:{&level,mirror}) {
            SimConfig cfg;cfg.n=1;cfg.eval=1;cfg.mode=17;cfg.family=14;cfg.speed=1.5f;cfg.max_steps=400;cfg.seed=scene->seed;cfg.geometry_memory=1;cfg.velocity_contract=header.config.velocity_contract;
            Sim teacher(metal,cfg,1),student(metal,cfg,1);navigation_training::load_actor(student,checkpoint_path,true);
            *static_cast<WWorld*>(teacher.worlds.contents)=scene->world;*static_cast<WWorld*>(student.worlds.contents)=scene->world;
            auto& teacher_run=*static_cast<SimRun*>(teacher.runs.contents);auto& teacher_state=*static_cast<RLPhysicsState*>(teacher.states.contents);
            auto& run=*static_cast<SimRun*>(student.runs.contents);auto& state=*static_cast<RLPhysicsState*>(student.states.contents);
            const WWorld source_world=scene->world;
            const auto initial_distance=length(difference({source_world.goal[0],source_world.goal[1],source_world.goal[2]},{state.position[0],state.position[1],state.position[2]}));
            teacher_run.initial_distance=run.initial_distance=initial_distance;
            observe_student(student);
            Demonstration initial_row;std::memcpy(initial_row.observation.data(),student.obs.contents,sizeof(initial_row.observation));
            const auto initial_command=student_velocity(initial_row,actor,state);
            const float initial_yaw=student_yaw_command(initial_row,actor);
            navigation_imitation::Point first_actual{0,0,0};float first_actual_yaw=0;
            for(uint step=0;step<40&&!run.episodes;step++) {
                auto cb=[metal.queue commandBuffer];student.collect(cb,1);metal.finish(cb);
                if(step==0){for(uint axis=0;axis<3;axis++)first_actual[axis]=run.desired_velocity[axis];first_actual_yaw=run.previous_nav[3];}
            }
            for(uint step=0;step<40&&!teacher_run.episodes;step++) {
                observe_student(teacher);advance_teacher(teacher,navigation_imitation::Point{0,.15f,0},1.f);
            }
            const bool reached_branch=!run.episodes&&run.steps==40&&!teacher_run.episodes&&teacher_run.steps==40;
            float teacher_bearing=std::numeric_limits<float>::quiet_NaN();bool teacher_target_visible=false;
            navigation_imitation::Point teacher_target{0,0,0},student_branch_command{0,0,0};float student_branch_yaw=0,branch_cosine=std::numeric_limits<float>::quiet_NaN();
            navigation_imitation::Point student_actual_branch{0,0,0};float student_actual_branch_yaw=0;
            if(reached_branch) {
                observe_student(teacher);observe_student(student);
                navigation_imitation::Point teacher_position{teacher_state.position[0],teacher_state.position[1],teacher_state.position[2]};
                teacher_target=route_target(source_world,scene->witness_route,teacher_position,teacher_run.elapsed);
                const auto view=target_camera_view(teacher_state,teacher_position,teacher_target);teacher_bearing=view.bearing_rad;teacher_target_visible=view.visible;
                Demonstration branch_row;std::memcpy(branch_row.observation.data(),student.obs.contents,sizeof(branch_row.observation));
                student_branch_command=student_velocity(branch_row,actor,state);student_branch_yaw=student_yaw_command(branch_row,actor);
                navigation_imitation::Point route_velocity=difference(teacher_target,teacher_position);const float route_norm=length(route_velocity);
                if(route_norm>1e-8f)for(float& v:route_velocity)v*=1.49f/ std::max(route_norm,1.49f);
                const float command_norm=length(student_branch_command),teacher_norm=length(route_velocity);
                if(command_norm>1e-6f&&teacher_norm>1e-6f)
                    branch_cosine=(student_branch_command[0]*route_velocity[0]+student_branch_command[1]*route_velocity[1]+student_branch_command[2]*route_velocity[2])/(command_norm*teacher_norm);
                auto cb=[metal.queue commandBuffer];student.collect(cb,1);metal.finish(cb);
                for(uint axis=0;axis<3;axis++)student_actual_branch[axis]=run.desired_velocity[axis];student_actual_branch_yaw=run.previous_nav[3];
            }
            while(!run.episodes&&run.steps<cfg.max_steps) {auto cb=[metal.queue commandBuffer];student.collect(cb,1);metal.finish(cb);}
            const float first_contact=run.collisions?run.elapsed:-1.f;
            const float final_progress=initial_distance>1e-6f?1.f-length(navigation_imitation::difference(
                {source_world.goal[0],source_world.goal[1],source_world.goal[2]},
                {state.position[0],state.position[1],state.position[2]}))/initial_distance:0.f;
            csv<<scene->failure_id<<','<<mirror->failure_id<<','<<scene->witness_route[1][1]-scene->witness_route[0][1]<<",0.5,0,0.225,"
               <<initial_command[0]<<','<<initial_command[1]<<','<<initial_command[2]<<','<<initial_yaw<<','
               <<first_actual[0]<<','<<first_actual[1]<<','<<first_actual[2]<<','<<first_actual_yaw<<',';
            if(reached_branch)csv<<teacher_state.position[0]<<','<<teacher_state.position[1]<<','<<teacher_state.position[2]<<','<<yaw_from_quaternion(teacher_state.orientation_wxyz)<<','
                                 <<state.position[0]<<','<<state.position[1]<<','<<state.position[2]<<','<<yaw_from_quaternion(state.orientation_wxyz)<<','
                                 <<teacher_bearing*57.29578f<<','<<teacher_target_visible<<','<<student_branch_command[0]<<','<<student_branch_command[1]<<','<<student_branch_command[2]<<','<<student_branch_yaw<<','
                                 <<branch_cosine<<','<<(scene->witness_route[1][1]-scene->witness_route[0][1])*student_actual_branch[1]<<',';
            else csv<<",,,,,,,,,,,,,,,,";
            csv<<first_contact<<','<<run.successes<<','<<run.collisions<<','<<run.timeouts<<','<<run.elapsed<<','<<run.path<<','<<run.min_clearance<<','<<final_progress<<'\n';csv.flush();
            std::cout<<"trajectory_diagnostic "<<scene->failure_id<<" reached_branch="<<reached_branch<<" success="<<run.successes<<" collision="<<run.collisions<<" elapsed="<<run.elapsed<<" contact_s="<<first_contact<<" init_y="<<initial_command[1]<<" init_yaw="<<initial_yaw<<" branch_cos="<<branch_cosine<<std::endl;
            ++written;
        }
    }
    require(written==8,"expected4 selected TRAIN mirror pairs for trajectory diagnostic");
    return 0;
}

static int diagnose_camera_yaw(Metal& metal,const std::string& bank,const std::string& output) {
    std::string hash;const auto levels=challenge_evaluation::load_split(bank,"train",challenge_evaluation::sha256_file(std::string(SOURCE_DIR)+"/world.hpp"),hash);
    const challenge_evaluation::Level *original=nullptr,*mirror=nullptr;
    for(const auto& level:levels)if(level.family==14&&level.environment_index==0)original=&level;else if(level.family==14&&level.environment_index==1)mirror=&level;
    require(original&&mirror,"camera yaw check needs the first family14 mirrored pair");
    std::ofstream csv(output+"/camera-yaw-check.csv");require(bool(csv),"cannot write camera-yaw-check.csv");
    csv<<"failure_id,phase,step,actual_yaw_rad,reference_yaw_rad,target_bearing_deg,in_fov,x,y,z,route_target_x,route_target_y,route_target_z\n";
    for(const auto* level:{original,mirror}) {
        SimConfig cfg;cfg.n=1;cfg.eval=1;cfg.mode=17;cfg.family=14;cfg.speed=1.5f;cfg.max_steps=400;cfg.seed=level->seed;cfg.geometry_memory=1;cfg.velocity_contract=1;
        Sim sim(metal,cfg,1);*static_cast<WWorld*>(sim.worlds.contents)=level->world;
        auto& run=*static_cast<SimRun*>(sim.runs.contents);auto& state=*static_cast<RLPhysicsState*>(sim.states.contents);
        const WWorld world=level->world;run.initial_distance=length(difference({world.goal[0],world.goal[1],world.goal[2]},{state.position[0],state.position[1],state.position[2]}));
        for(uint i=0;i<40;i++){observe_student(sim);advance_teacher(sim,navigation_imitation::Point{0,.15f,0},1.f);}
        for(uint step=0;step<300&&!run.episodes;step++) {
            observe_student(sim);navigation_imitation::Point position{state.position[0],state.position[1],state.position[2]};
            auto target=route_target(world,level->witness_route,position,run.elapsed);const auto camera=target_camera_view(state,position,target);
            const float yaw=yaw_from_quaternion(state.orientation_wxyz);
            csv<<level->failure_id<<",orient,"<<step<<','<<yaw<<','<<run.yaw<<','<<camera.bearing_rad*57.29578f<<','<<camera.visible<<','<<state.position[0]<<','<<state.position[1]<<','<<state.position[2]<<','<<target[0]<<','<<target[1]<<','<<target[2]<<'\n';csv.flush();
            if(camera.visible)break;
            const float yaw_command=camera.bearing_rad>=0?.8f:-.8f;
            advance_teacher(sim,navigation_imitation::Point{0,0,0},yaw_command);
        }
    }
    std::cout<<"camera_yaw_check pair="<<original->failure_id<<"|"<<mirror->failure_id<<" output="<<output<<" bank_sha256="<<hash<<std::endl;
    return 0;
}
}

int main(int argc,char** argv){@autoreleasepool{try{
    Metal metal;metal.compile(base_source()+PPO_TRAINER_MSL+navigation_imitation::imitation_kernel);
    if(argc==4&&std::string(argv[1])=="--yaw-check") {
        std::filesystem::create_directories(argv[3]);return navigation_active_sensing::diagnose_camera_yaw(metal,argv[2],argv[3]);
    }
    if(argc==5&&std::string(argv[1])=="--collect") {
        std::filesystem::create_directories(argv[3]);return navigation_active_sensing::collect_training_data(metal,argv[2],argv[4],argv[3]);
    }
    if(argc==5&&std::string(argv[1])=="--collect-recovery") {
        std::filesystem::create_directories(argv[3]);return navigation_active_sensing::collect_recovery_data(metal,argv[2],argv[4],argv[3]);
    }
    if(argc==6&&std::string(argv[1])=="--train") {
        const uint updates=std::stoul(argv[5]);std::filesystem::create_directories(argv[3]);
        navigation_active_sensing::train_balanced(metal,argv[2],argv[4],argv[3],updates);return 0;
    }
    require((argc==7||argc==8)&&std::string(argv[1])=="--probe","navigation_active_sensing --probe BANK OUTPUT_DIR PAIRS SCAN_STEPS NORMALIZED_YAW [COMMON_LATERAL_MPS]");
    std::filesystem::create_directories(argv[3]);const uint pairs=std::stoul(argv[4]),steps=std::stoul(argv[5]);const float yaw=std::stof(argv[6]),lateral=argc==8?std::stof(argv[7]):0.f;
    require(pairs>=1&&pairs<=15&&steps>=1&&steps<=100&&std::isfinite(yaw)&&std::fabs(yaw)<=1&&std::isfinite(lateral)&&std::fabs(lateral)<=.3f,"invalid probe bounds");
    return navigation_active_sensing::probe(metal,argv[2],argv[3],pairs,steps,yaw,lateral);
}catch(const std::exception& error){std::cerr<<error.what()<<'\n';return 1;}}}
