// The temporal exploration policy and PPO runner live here. This narrow
// declaration starts with the conditional Gaussian contract test.
#define main embedded_navigation_main
#include "main.mm"
#undef main

namespace temporal_exploration {

constexpr uint32_t kEnvironmentCount = 128;
constexpr uint32_t kHorizon = 32;
constexpr uint32_t kFamilyCorner = 14;
constexpr uint32_t kRolloutsPerStage = 100;
constexpr float kYawCorrelation = 0.95f;
constexpr uint32_t kPreviousNoiseStride = 4;
constexpr float kSpeedCapMps = 1.5f;
constexpr float kTemporalEntropy = 0.0005f;
constexpr float kLearningRate = 0.0001f;
constexpr float kClearanceRisk = 0.1f;
constexpr uint32_t kMaxSteps = 400;

static const char* temporal_msl = R"MSL(
constant uint TEMPORAL_PREVIOUS_NOISE_STRIDE=4;
constant float TEMPORAL_SIGN_PROBABILITY_EPSILON=1.0e-6f;
inline float temporal_normal_cdf(float x) {
    const float magnitude=abs(x)*0.70710678118f;
    const float t=1.0f/(1.0f+0.3275911f*magnitude);
    const float erf_magnitude=1.0f-(((((1.061405429f*t-1.453152027f)*t+
        1.421413741f)*t-0.284496736f)*t+0.254829592f)*t)*exp(-magnitude*magnitude);
    return 0.5f*(1.0f+(x<0.0f?-erf_magnitude:erf_magnitude));
}
kernel void sim_act_temporal(device RLPhysicsState* states [[buffer(0)]],
                             device SimRun* runs [[buffer(1)]],
                             device const WWorld* worlds [[buffer(2)]],
                             device const float* observations [[buffer(3)]],
                             device const float* critic_obs [[buffer(4)]],
                             device const float* actor [[buffer(5)]],
                             device const float* critic [[buffer(6)]],
                             device float* actions [[buffer(7)]],
                             device float* logp [[buffer(8)]],
                             device float* values [[buffer(9)]],
                             device float* commands [[buffer(10)]],
                             constant RLPhysicsParams& p [[buffer(11)]],
                             constant SimConfig& cfg [[buffer(12)]],
                             device float* exploration_state [[buffer(13)]],
                             device float* previous_noise_rows [[buffer(14)]],
                             constant float& configured_rho [[buffer(15)]],
                             uint n [[thread_position_in_grid]]) {
    if(n>=cfg.n || (cfg.eval && runs[n].episodes)) return;
    const uint row=cfg.tick*cfg.n+n;
    float co[32],hidden[64],mean[4],sample[4];
    for(uint j=0;j<32;j++) co[j]=critic_obs[row*32+j];
    for(uint j=0;j<4;j++) mean[j]=actions[row*4+j];
    values[row]=ppo_critic_value(critic,co,hidden);

    float deployed_scale=1.0f;
    if(cfg.mode==22 && SIM_HAS_GEOMETRY_PRIOR) {
        float overhead=0.0f;
        for(uint k=0;k<20;k++) overhead+=observations[row*PPO_ACTOR_OBS+k]*12.0f>2.5f;
        deployed_scale=.25f+.75f*(overhead/20.0f);
    }

    const uint state_stride=uint(sizeof(NavigationTaskState)/sizeof(float));
    const float rho=(runs[n].steps==0u)?0.0f:configured_rho;
    const float previous_yaw_noise=(runs[n].steps==0u)?0.0f:exploration_state[n*state_stride];
    previous_noise_rows[row*TEMPORAL_PREVIOUS_NOISE_STRIDE]=previous_yaw_noise;
    previous_noise_rows[row*TEMPORAL_PREVIOUS_NOISE_STRIDE+1]=rho;

    uint rng=runs[n].rng;
    float log_probability=0.0f;
    float current_yaw_noise=0.0f;
    for(uint j=0;j<4;j++) {
        const float log_std=actor[PPO_ACTOR_LOG_STD+j];
        const float sigma=exp(log_std);
        const float innovation=sim_normal(rng);
        const float rho_axis=(j==3u)?rho:0.0f;
        const float previous_noise=(j==3u)?previous_yaw_noise:0.0f;
        const float noise=rho_axis*previous_noise+sqrt(1.0f-rho_axis*rho_axis)*innovation;
        if(j==3u) current_yaw_noise=noise;
        sample[j]=mean[j]+sigma*noise;
        actions[row*4+j]=sample[j];

        const float normalized_residual=(sample[j]-mean[j])/sigma;
        const float conditional_residual=(normalized_residual-rho_axis*previous_noise)/
                                         sqrt(1.0f-rho_axis*rho_axis);
        log_probability+=-0.5f*(conditional_residual*conditional_residual+
            2.0f*log_std+log(1.0f-rho_axis*rho_axis)+PPO_LOG_TWO_PI);

        float executed_latent=sample[j];
        if(cfg.mode==22 && SIM_HAS_GEOMETRY_PRIOR) {
            if(j<3u) {
                const float prior=observations[row*PPO_ACTOR_OBS+PPO_ACTOR_OBS-3+j];
                executed_latent=prior+deployed_scale*(sample[j]-prior);
            } else {
                executed_latent=deployed_scale*sample[j];
            }
        }
        commands[(n*8+runs[n].steps%8)*4+j]=tanh(executed_latent);
    }
    exploration_state[n*state_stride]=current_yaw_noise;
    previous_noise_rows[row*TEMPORAL_PREVIOUS_NOISE_STRIDE+2]=current_yaw_noise;
    previous_noise_rows[row*TEMPORAL_PREVIOUS_NOISE_STRIDE+3]=log_probability;
    logp[row]=log_probability;
    runs[n].rng=rng;

    const uint command_delay=sim_command_delay(cfg,n);
    const uint applied=runs[n].steps>command_delay?runs[n].steps-command_delay:0;
    for(uint j=0;j<4;j++)
        runs[n].previous_nav[j]=runs[n].steps<command_delay?0.0f:
            commands[(n*8+applied%8)*4+j];
    RLPhysicsState state=states[n];
    float rotation[9];
    sim_rotation(state.orientation_wxyz,rotation);
    float velocity[3]={runs[n].previous_nav[0]*cfg.speed,
                       runs[n].previous_nav[1]*cfg.speed,
                       runs[n].previous_nav[2]*cfg.speed*(cfg.velocity_contract==0?0.5f:1.0f)};
    if(cfg.velocity_contract==1) {
        const float scale=min(1.0f,cfg.speed/max(length(float3(velocity[0],velocity[1],velocity[2])),1e-8f));
        for(uint j=0;j<3;j++) velocity[j]*=scale;
    }
    for(uint j=0;j<3;j++)
        runs[n].desired_velocity[j]=rotation[j*3]*velocity[0]+
                                    rotation[j*3+1]*velocity[1]+
                                    rotation[j*3+2]*velocity[2];
    runs[n].yaw+=runs[n].previous_nav[3]*p.dt*cfg.substeps*0.5f;
}

kernel void sim_act_held_scan(device RLPhysicsState* states [[buffer(0)]],device SimRun* runs [[buffer(1)]],device const WWorld* worlds [[buffer(2)]],device const float* observations [[buffer(3)]],device const float* critic_obs [[buffer(4)]],device const float* actor [[buffer(5)]],device const float* critic [[buffer(6)]],device float* actions [[buffer(7)]],device float* logp [[buffer(8)]],device float* values [[buffer(9)]],device float* commands [[buffer(10)]],constant RLPhysicsParams& p [[buffer(11)]],constant SimConfig& cfg [[buffer(12)]],device float* scan_direction [[buffer(13)]],device float* action_masks [[buffer(14)]],uint n [[thread_position_in_grid]]) {
    if(n>=cfg.n||(cfg.eval&&runs[n].episodes))return;
    const uint row=cfg.tick*cfg.n+n,base=row*4;
    float co[32],hidden[64],mean[4],sample[4];
    for(uint j=0;j<32;j++)co[j]=critic_obs[row*32+j];
    for(uint j=0;j<4;j++)mean[j]=actions[base+j];
    values[row]=ppo_critic_value(critic,co,hidden);
    uint rng=runs[n].rng;
    for(uint j=0;j<4;j++) {
        sample[j]=mean[j]+exp(actor[PPO_ACTOR_LOG_STD+j])*sim_normal(rng);
        actions[base+j]=sample[j];action_masks[base+j]=1.0f;
    }
    const bool held_scan=worlds[n].family==14u&&runs[n].steps<40u;
    float log_probability=0.0f;
    if(held_scan) {
        const bool decision_tick=runs[n].steps==0u;
        float direction=scan_direction[n];
        action_masks[base+3]=0.0f;
        if(decision_tick) {
            const float log_std=actor[PPO_ACTOR_LOG_STD+3];
            const float sigma=exp(log_std);
            const float x=mean[3]/sigma;
            const float p_raw=temporal_normal_cdf(x);
            const float p_positive=clamp(p_raw,TEMPORAL_SIGN_PROBABILITY_EPSILON,
                                         1.0f-TEMPORAL_SIGN_PROBABILITY_EPSILON);
            direction=wurand(rng)<p_positive?1.0f:-1.0f;
            scan_direction[n]=direction;
            const float chosen=direction>0.0f?p_positive:1.0f-p_positive;
            actions[base+3]=direction;
            log_probability=log(chosen);
            action_masks[base+3]=2.0f;
        }
        // Hold only yaw for the two-second scan option. Translation remains a
        // sampled, trainable policy action with its standard Gaussian density.
        float overhead=0.0f;
        for(uint k=0;k<20;k++)overhead+=observations[row*PPO_ACTOR_OBS+k]*12.0f>2.5f;
        const float gate=.25f+.75f*(overhead/20.0f);
        for(uint j=0;j<3;j++) {
            const float prior=observations[row*PPO_ACTOR_OBS+PPO_ACTOR_OBS-3+j];
            const float latent=prior+gate*(sample[j]-prior);
            commands[(n*8+runs[n].steps%8)*4+j]=tanh(latent);
            const float z=(sample[j]-mean[j])*exp(-actor[PPO_ACTOR_LOG_STD+j]);
            log_probability+=-0.5f*(z*z+2.0f*actor[PPO_ACTOR_LOG_STD+j]+PPO_LOG_TWO_PI);
        }
        commands[(n*8+runs[n].steps%8)*4+3]=0.80f*direction;
    } else {
        float overhead=0.0f;
        for(uint k=0;k<20;k++)overhead+=observations[row*PPO_ACTOR_OBS+k]*12.0f>2.5f;
        const float gate=.25f+.75f*(overhead/20.0f);
        for(uint j=0;j<3;j++) {
            const float prior=observations[row*PPO_ACTOR_OBS+PPO_ACTOR_OBS-3+j];
            const float latent=prior+gate*(sample[j]-prior);
            commands[(n*8+runs[n].steps%8)*4+j]=tanh(latent);
            const float z=(sample[j]-mean[j])*exp(-actor[PPO_ACTOR_LOG_STD+j]);
            log_probability+=-0.5f*(z*z+2.0f*actor[PPO_ACTOR_LOG_STD+j]+PPO_LOG_TWO_PI);
        }
        commands[(n*8+runs[n].steps%8)*4+3]=tanh(gate*sample[3]);
        const float z=(sample[3]-mean[3])*exp(-actor[PPO_ACTOR_LOG_STD+3]);
        log_probability+=-0.5f*(z*z+2.0f*actor[PPO_ACTOR_LOG_STD+3]+PPO_LOG_TWO_PI);
    }
    logp[row]=log_probability;runs[n].rng=rng;
    const uint delay=sim_command_delay(cfg,n);
    const uint applied=runs[n].steps>delay?runs[n].steps-delay:0;
    for(uint j=0;j<4;j++)runs[n].previous_nav[j]=runs[n].steps<delay?0.0f:
        commands[(n*8+applied%8)*4+j];
    RLPhysicsState state=states[n];float rotation[9];sim_rotation(state.orientation_wxyz,rotation);
    float velocity[3]={runs[n].previous_nav[0]*cfg.speed,runs[n].previous_nav[1]*cfg.speed,
                       runs[n].previous_nav[2]*cfg.speed*(cfg.velocity_contract==0?0.5f:1.0f)};
    if(cfg.velocity_contract==1) {
        const float scale=min(1.0f,cfg.speed/max(length(float3(velocity[0],velocity[1],velocity[2])),1e-8f));
        for(uint j=0;j<3;j++)velocity[j]*=scale;
    }
    for(uint j=0;j<3;j++)runs[n].desired_velocity[j]=rotation[j*3]*velocity[0]+
        rotation[j*3+1]*velocity[1]+rotation[j*3+2]*velocity[2];
    runs[n].yaw+=runs[n].previous_nav[3]*p.dt*cfg.substeps*0.5f;
}

kernel void ppo_sample_loss_grad_masked(device const float* actions [[buffer(0)]],
                                        device const float* means [[buffer(1)]],
                                        device const float* log_std [[buffer(2)]],
                                        device const float* old_logp [[buffer(3)]],
                                        device const float* values [[buffer(4)]],
                                        device const float* old_values [[buffer(5)]],
                                        device const float* advantages [[buffer(6)]],
                                        device const float* target_returns [[buffer(7)]],
                                        device float* d_means [[buffer(8)]],
                                        device float* d_log_stds [[buffer(9)]],
                                        device float* d_values [[buffer(10)]],
                                        device float* losses [[buffer(11)]],
                                        constant uint& batch_size [[buffer(12)]],
                                        constant float& clip_epsilon [[buffer(13)]],
                                        constant float& value_coefficient [[buffer(14)]],
                                        constant float& entropy_coefficient [[buffer(15)]],
                                        device const float* action_masks [[buffer(16)]],
                                        uint n [[thread_position_in_grid]]) {
    if(n>=batch_size)return;
    const uint base=n*PPO_ACTIONS;
    float log_probability=0.0f,entropy_loss=0.0f;
    float score_mean[PPO_ACTIONS],score_log_std[PPO_ACTIONS];
    float entropy_d_mean[PPO_ACTIONS],entropy_d_log_std[PPO_ACTIONS];
    for(uint a=0;a<PPO_ACTIONS;a++) {
        const float mask=action_masks[base+a];
        score_mean[a]=score_log_std[a]=0.0f;
        entropy_d_mean[a]=entropy_d_log_std[a]=0.0f;
        if(mask==1.0f) {
            const float difference=actions[base+a]-means[base+a];
            const float sigma=exp(log_std[a]);
            const float inverse_sigma=1.0f/sigma;
            const float z=difference*inverse_sigma;
            log_probability+=-0.5f*(z*z+2.0f*log_std[a]+PPO_LOG_TWO_PI);
            score_mean[a]=difference*inverse_sigma*inverse_sigma;
            score_log_std[a]=z*z-1.0f;
            entropy_loss+=-entropy_coefficient*(log_std[a]+0.5f*(1.0f+PPO_LOG_TWO_PI));
            entropy_d_log_std[a]=1.0f;
        } else if(mask==2.0f) {
            const float sigma=exp(log_std[a]);
            const float x=means[base+a]/sigma;
            const float p_raw=temporal_normal_cdf(x);
            const float p_positive=clamp(p_raw,TEMPORAL_SIGN_PROBABILITY_EPSILON,
                                         1.0f-TEMPORAL_SIGN_PROBABILITY_EPSILON);
            const float p_negative=1.0f-p_positive;
            const float sign=actions[base+a];
            const float chosen=sign>0.0f?p_positive:p_negative;
            const float density=exp(-0.5f*x*x)*0.3989422804f;
            log_probability+=log(chosen);
            const bool cdf_active=p_raw>TEMPORAL_SIGN_PROBABILITY_EPSILON&&
                p_raw<1.0f-TEMPORAL_SIGN_PROBABILITY_EPSILON;
            score_mean[a]=cdf_active?sign*density/(sigma*chosen):0.0f;
            score_log_std[a]=cdf_active?-sign*x*density/chosen:0.0f;
            const float log_odds=log(p_positive/p_negative);
            const float entropy=-p_positive*log(p_positive)-p_negative*log(p_negative);
            const float h_d_mean=cdf_active?-density/sigma*log_odds:0.0f;
            const float h_d_log_std=cdf_active?x*density*log_odds:0.0f;
            entropy_loss+=-entropy_coefficient*entropy;
            entropy_d_mean[a]=h_d_mean;
            entropy_d_log_std[a]=h_d_log_std;
        }
    }
    const float raw_log_ratio=log_probability-old_logp[n];
    const float ratio=exp(ppo_clamp(raw_log_ratio,-20.0f,20.0f));
    const float advantage=advantages[n];
    const float clipped_ratio=ppo_clamp(ratio,1.0f-clip_epsilon,1.0f+clip_epsilon);
    const float chosen=min(ratio*advantage,clipped_ratio*advantage);
    const bool valid=raw_log_ratio>=-20.0f&&raw_log_ratio<=20.0f;
    const bool active=valid&&(advantage>=0.0f?ratio<=1.0f+clip_epsilon:ratio>=1.0f-clip_epsilon);
    const float scale=1.0f/float(max(batch_size,1u));
    for(uint a=0;a<PPO_ACTIONS;a++) {
        if(action_masks[base+a]>0.0f) {
            const float d_policy=active?-ratio*advantage*scale:0.0f;
            d_means[base+a]=d_policy*score_mean[a]-
                entropy_coefficient*entropy_d_mean[a]*scale;
            d_log_stds[base+a]=d_policy*score_log_std[a]-
                entropy_coefficient*entropy_d_log_std[a]*scale;
        } else {
            d_means[base+a]=0.0f;
            d_log_stds[base+a]=0.0f;
        }
    }
    const float value_difference=values[n]-target_returns[n];
    d_values[n]=value_coefficient*value_difference*scale;
    losses[n*4]= -chosen*scale;
    losses[n*4+1]=0.5f*value_coefficient*value_difference*value_difference*scale;
    losses[n*4+2]=entropy_loss*scale;
    losses[n*4+3]=ratio;
    (void)old_values;
}

kernel void ppo_sample_loss_grad_temporal(device const float* actions [[buffer(0)]],
                                          device const float* means [[buffer(1)]],
                                          device const float* log_std [[buffer(2)]],
                                          device const float* old_logp [[buffer(3)]],
                                          device const float* values [[buffer(4)]],
                                          device const float* old_values [[buffer(5)]],
                                          device const float* advantages [[buffer(6)]],
                                          device const float* target_returns [[buffer(7)]],
                                          device float* d_means [[buffer(8)]],
                                          device float* d_log_stds [[buffer(9)]],
                                          device float* d_values [[buffer(10)]],
                                          device float* losses [[buffer(11)]],
                                          constant uint& batch_size [[buffer(12)]],
                                          constant float& clip_epsilon [[buffer(13)]],
                                          constant float& value_coefficient [[buffer(14)]],
                                          constant float& entropy_coefficient [[buffer(15)]],
                                          device const float* previous_noise_rows [[buffer(16)]],
                                          uint n [[thread_position_in_grid]]) {
    if(n>=batch_size) return;
    const float previous_yaw_noise=previous_noise_rows[n*TEMPORAL_PREVIOUS_NOISE_STRIDE];
    const float rho=previous_noise_rows[n*TEMPORAL_PREVIOUS_NOISE_STRIDE+1];
    float log_probability=0.0f;
    float entropy=0.0f;
    const uint base=n*PPO_ACTIONS;
    float residuals[PPO_ACTIONS],independent_residuals[PPO_ACTIONS],variance_factors[PPO_ACTIONS];
    for(uint a=0;a<PPO_ACTIONS;a++) {
        const float rho_axis=(a==3u)?rho:0.0f;
        const float previous_noise=(a==3u)?previous_yaw_noise:0.0f;
        const float variance_factor=1.0f-rho_axis*rho_axis;
        const float sigma=exp(log_std[a]);
        const float independent=(actions[base+a]-means[base+a])/sigma;
        const float conditional=(independent-rho_axis*previous_noise)/sqrt(variance_factor);
        independent_residuals[a]=independent;
        residuals[a]=conditional;
        variance_factors[a]=variance_factor;
        log_probability+=-0.5f*(conditional*conditional+2.0f*log_std[a]+
            log(variance_factor)+PPO_LOG_TWO_PI);
    }
    const float raw_log_ratio=log_probability-old_logp[n];
    const float clipped_log_ratio=ppo_clamp(raw_log_ratio,-20.0f,20.0f);
    const float ratio=exp(clipped_log_ratio);
    const float advantage=advantages[n];
    const float clipped_ratio=ppo_clamp(ratio,1.0f-clip_epsilon,1.0f+clip_epsilon);
    const float chosen=min(ratio*advantage,clipped_ratio*advantage);
    const bool ratio_in_range=raw_log_ratio>=-20.0f&&raw_log_ratio<=20.0f;
    const bool policy_active=ratio_in_range&&(advantage>=0.0f?ratio<=1.0f+clip_epsilon:
                                                               ratio>=1.0f-clip_epsilon);
    const float scale=1.0f/float(max(batch_size,1u));
    for(uint a=0;a<PPO_ACTIONS;a++) {
        const float rho_axis=(a==3u)?rho:0.0f;
        const float previous_noise=(a==3u)?previous_yaw_noise:0.0f;
        const float variance_factor=variance_factors[a];
        const float independent=independent_residuals[a];
        const float conditional_numerator=independent-rho_axis*previous_noise;
        const float d_log_probability=-ratio*advantage*scale;
        if(policy_active) {
            d_means[base+a]=d_log_probability*residuals[a]/
                (exp(log_std[a])*sqrt(variance_factor));
            d_log_stds[base+a]=d_log_probability*
                (independent*conditional_numerator/variance_factor-1.0f);
        } else {
            d_means[base+a]=0.0f;
            d_log_stds[base+a]=0.0f;
        }
        d_log_stds[base+a]-=entropy_coefficient*scale;
        entropy+=-entropy_coefficient*(log_std[a]+0.5f*(1.0f+PPO_LOG_TWO_PI+
            log(variance_factor)))*scale;
    }
    const float value_difference=values[n]-target_returns[n];
    d_values[n]=value_coefficient*value_difference*scale;
    losses[n*4]= -chosen*scale;
    losses[n*4+1]=0.5f*value_coefficient*value_difference*value_difference*scale;
    losses[n*4+2]=entropy;
    losses[n*4+3]=ratio;
    (void)old_values;
}
)MSL";
static id<MTLBuffer> temporal_rho_buffer(Metal& metal, float rho) {
    require(std::isfinite(rho) && rho>=0.0f && rho<0.999f,
            "temporal yaw correlation must be in [0,0.999)");
    return metal.buffer(sizeof(rho),&rho);
}

static id<MTLBuffer> temporal_previous_noise_buffer(Metal& metal, const Sim& sim) {
    const size_t rows=size_t(sim.cfg.n)*sim.horizon;
    return metal.buffer(rows*kPreviousNoiseStride*sizeof(float));
}

// Keep Sim's verified sensor, observation, actor, RAPTOR, and 100 Hz advance
// sequence. Only sim_act is replaced with a stateful yaw-noise sampler.
static void collect_temporal_rollout(Sim& sim, Metal& metal,
                                     id<MTLCommandBuffer> commands,
                                     id<MTLBuffer> exploration_state,
                                     id<MTLBuffer> previous_noise_rows,
                                     id<MTLBuffer> rho_buffer) {
    require(sim.cfg.mode==22,
            "temporal exploration collection requires the mode22 action contract");
    require(!sim.direction_aux_enabled,
            "temporal exploration does not combine with direction auxiliary updates");
    const char* actor_pipeline=sim.simd_actor
        ? "ppo_actor_forward_simd_fused" : "ppo_actor_forward";
    for(uint32_t tick=0;tick<sim.horizon;tick++) {
        const auto config=sim.configs[tick];
        metal.dispatch(commands,sim.depth_p,sim.cfg.n*320,
                       {sim.states,sim.runs,sim.worlds,sim.sensors,sim.physics,config,sim.poses});
        if(sim.cfg.geometry_memory) {
            metal.dispatch(commands,sim.memory_points_p,sim.cfg.n*640,
                           {sim.states,sim.runs,sim.sensors,sim.poses,sim.memory_points,sim.physics,config});
            metal.dispatch(commands,sim.memory_candidates_p,sim.cfg.n*85,
                           {sim.states,sim.worlds,sim.memory_points,sim.memory_clearances,config});
        }
        metal.dispatch(commands,sim.observe_p,sim.cfg.n,
                       {sim.states,sim.runs,sim.worlds,sim.sensors,sim.obs,sim.co,
                        sim.physics,config,sim.poses,sim.memory_clearances},64);
        const size_t row_offset=size_t(tick)*sim.cfg.n;
        encode(metal,commands,actor_pipeline,
               sim.simd_actor?((size_t(sim.cfg.n)+7)/8)*256:sim.cfg.n,
               {{sim.obs,row_offset*fixed_ppo::actor_obs_dim*sizeof(float)},
                {sim.actor,0},{sim.actor_workspace,0},
                {sim.actions,row_offset*fixed_ppo::action_dim*sizeof(float)},
                {sim.env_count,0}},sim.simd_actor?256:64);
        metal.dispatch(commands,metal.pipeline("sim_act_temporal"),sim.cfg.n,
            {sim.states,sim.runs,sim.worlds,sim.obs,sim.co,sim.actor,sim.critic,
             sim.actions,sim.logp,sim.values,sim.commands,sim.physics,config,
             exploration_state,previous_noise_rows,rho_buffer},64);
        metal.dispatch(commands,sim.advance_p,sim.cfg.n,
            {sim.states,sim.runs,sim.worlds,sim.sensors,sim.commands,sim.raptor,sim.critic,
             sim.rewards,sim.next_values,sim.terminated,sim.truncated,sim.physics,config,
             sim.bank_worlds,sim.bank_schedule,sim.bank_control,sim.bank_active_ids,
             sim.bank_transition_ids,sim.environment_physics,sim.runtime_control,
             sim.task_states,sim.task_control,sim.potential_fields,sim.potential_spec,
             sim.potential_control},64);
    }
}

static id<MTLBuffer> held_scan_state_buffer(Metal& metal,const Sim& sim) {
    auto state=metal.buffer(size_t(sim.cfg.n)*sizeof(float));
    std::memset(state.contents,0,state.length);
    return state;
}

static id<MTLBuffer> held_scan_action_mask_buffer(Metal& metal,const Sim& sim) {
    const size_t rows=size_t(sim.cfg.n)*sim.horizon;
    return metal.buffer(rows*fixed_ppo::action_dim*sizeof(float));
}

static void collect_held_scan_rollout(Sim& sim,Metal& metal,
                                      id<MTLCommandBuffer> commands,
                                      id<MTLBuffer> scan_state,
                                      id<MTLBuffer> action_masks) {
    require(sim.cfg.mode==22&&!sim.direction_aux_enabled,
            "held scan requires the standard mode22 PPO actor and action map");
    const char* actor_pipeline=sim.simd_actor
        ?"ppo_actor_forward_simd_fused":"ppo_actor_forward";
    for(uint32_t tick=0;tick<sim.horizon;tick++) {
        const auto config=sim.configs[tick];
        metal.dispatch(commands,sim.depth_p,sim.cfg.n*320,
            {sim.states,sim.runs,sim.worlds,sim.sensors,sim.physics,config,sim.poses});
        if(sim.cfg.geometry_memory) {
            metal.dispatch(commands,sim.memory_points_p,sim.cfg.n*640,
                {sim.states,sim.runs,sim.sensors,sim.poses,sim.memory_points,sim.physics,config});
            metal.dispatch(commands,sim.memory_candidates_p,sim.cfg.n*85,
                {sim.states,sim.worlds,sim.memory_points,sim.memory_clearances,config});
        }
        metal.dispatch(commands,sim.observe_p,sim.cfg.n,
            {sim.states,sim.runs,sim.worlds,sim.sensors,sim.obs,sim.co,
             sim.physics,config,sim.poses,sim.memory_clearances},64);
        const size_t row_offset=size_t(tick)*sim.cfg.n;
        encode(metal,commands,actor_pipeline,
            sim.simd_actor?((size_t(sim.cfg.n)+7)/8)*256:sim.cfg.n,
            {{sim.obs,row_offset*fixed_ppo::actor_obs_dim*sizeof(float)},
             {sim.actor,0},{sim.actor_workspace,0},
             {sim.actions,row_offset*fixed_ppo::action_dim*sizeof(float)},
             {sim.env_count,0}},sim.simd_actor?256:64);
        metal.dispatch(commands,metal.pipeline("sim_act_held_scan"),sim.cfg.n,
            {sim.states,sim.runs,sim.worlds,sim.obs,sim.co,sim.actor,sim.critic,
             sim.actions,sim.logp,sim.values,sim.commands,sim.physics,config,
             scan_state,action_masks},64);
        metal.dispatch(commands,sim.advance_p,sim.cfg.n,
            {sim.states,sim.runs,sim.worlds,sim.sensors,sim.commands,sim.raptor,sim.critic,
             sim.rewards,sim.next_values,sim.terminated,sim.truncated,sim.physics,config,
             sim.bank_worlds,sim.bank_schedule,sim.bank_control,sim.bank_active_ids,
             sim.bank_transition_ids,sim.environment_physics,sim.runtime_control,
             sim.task_states,sim.task_control,sim.potential_fields,sim.potential_spec,
             sim.potential_control},64);
    }
}

static void rollout_update_temporal(PPOTrainer& trainer, Sim& sim,
                                    Metal& metal,
                                    id<MTLCommandBuffer> commands,
                                    uint32_t rollout_index,
                                    id<MTLBuffer> previous_noise_rows) {
    require(trainer.anchor_lambda==0.0f && trainer.direction_aux_coefficient==0.0f,
            "temporal rollout uses the standard unanchored PPO objective");
    trainer.dispatch(commands,trainer.gae_p,sim.cfg.n,
        {{sim.rewards,0},{sim.values,0},{sim.next_values,0},{sim.terminated,0},
         {sim.truncated,0},{sim.advantages,0},{sim.returns,0},{trainer.horizon_b,0},
         {trainer.envs_b,0},{trainer.gamma_b,0},{trainer.lambda_b,0}},64);
    trainer.dispatch(commands,trainer.normalize_p,1,
        {{sim.advantages,0},{trainer.rows_b,0},{trainer.gae_epsilon_b,0},
         {trainer.adv_clip_b,0}},1);
    for(uint32_t batch=0;batch<trainer.starts.size();batch++)
        trainer.starts[batch]=batch*trainer.minibatch;
    std::mt19937 rng(0x9e3779b9u+rollout_index*0x85ebca6bu);
    std::shuffle(trainer.starts.begin(),trainer.starts.end(),rng);
    uint32_t update=0;
    for(uint32_t epoch=0;epoch<trainer.epochs;epoch++) {
        if(epoch==1)std::shuffle(trainer.starts.begin(),trainer.starts.end(),rng);
        for(uint32_t begin:trainer.starts) {
            const uint32_t batch=std::min(trainer.minibatch,trainer.rows-begin);
            const size_t obs_offset=size_t(begin)*fixed_ppo::actor_obs_dim*sizeof(float);
            const size_t critic_offset=size_t(begin)*fixed_ppo::critic_obs_dim*sizeof(float);
            const size_t action_offset=size_t(begin)*fixed_ppo::action_dim*sizeof(float);
            const size_t row_offset=size_t(begin)*sizeof(float);
            const size_t noise_offset=size_t(begin)*kPreviousNoiseStride*sizeof(float);
            const auto batch_size=trainer.batch_size_buffers[batch];
            trainer.dispatch(commands,trainer.actor_forward_p,
                sim.simd_actor?((size_t(batch)+7)/8)*256:batch,
                {{sim.obs,obs_offset},{sim.actor,0},{trainer.actor_hidden,0},
                 {trainer.actor_means,0},{batch_size,0}},sim.simd_actor?256:64);
            trainer.dispatch(commands,trainer.critic_forward_p,batch,
                {{sim.co,critic_offset},{sim.critic,0},{trainer.critic_hidden,0},
                 {trainer.predicted_values,0},{batch_size,0}},64);
            trainer.dispatch(commands,metal.pipeline("ppo_sample_loss_grad_temporal"),batch,
                {{sim.actions,action_offset},{trainer.actor_means,0},
                 {sim.actor,fixed_ppo::actor_log_std_offset*sizeof(float)},
                 {sim.logp,row_offset},{trainer.predicted_values,0},{sim.values,row_offset},
                 {sim.advantages,row_offset},{sim.returns,row_offset},
                 {trainer.d_means,0},{trainer.d_log_stds,0},{trainer.d_values,0},
                 {trainer.losses,0},{batch_size,0},{trainer.clip_b,0},
                 {trainer.value_coef_b,0},{trainer.entropy_coef_b,0},
                 {previous_noise_rows,noise_offset}},64);
            trainer.dispatch(commands,trainer.metric_batch_p,1,
                {{trainer.losses,0},{trainer.metric_rows,size_t(update)*4*4},
                 {batch_size,0}},1);
            trainer.dispatch(commands,trainer.actor_hidden_delta_p,
                size_t(batch)*fixed_ppo::hidden_dim,
                {{sim.actor,0},{trainer.d_means,0},{trainer.actor_hidden,0},
                 {trainer.actor_hidden_delta,0},{batch_size,0}},128);
            trainer.dispatch(commands,trainer.actor_grad_direct_p,fixed_ppo::actor_param_count,
                {{sim.obs,obs_offset},{sim.actor,0},{trainer.d_means,0},
                 {trainer.d_log_stds,0},{trainer.actor_hidden_delta,0},
                 {trainer.actor_grad,0},{batch_size,0}},128);
            trainer.dispatch(commands,trainer.critic_hidden_delta_p,
                size_t(batch)*fixed_ppo::hidden_dim,
                {{sim.critic,0},{trainer.d_values,0},{trainer.critic_hidden,0},
                 {trainer.critic_hidden_delta,0},{batch_size,0}},128);
            trainer.dispatch(commands,trainer.critic_grad_direct_p,fixed_ppo::critic_param_count,
                {{sim.co,critic_offset},{sim.critic,0},{trainer.d_values,0},
                 {trainer.critic_hidden_delta,0},{trainer.critic_grad,0},
                 {batch_size,0}},128);
            require(trainer.optimizer_step<uint64_t(std::numeric_limits<uint32_t>::max()),
                    "temporal PPO Adam step overflow");
            const uint32_t optimizer_step=uint32_t(++trainer.optimizer_step);
            PpoAdamHostConfig adam{sim.cfg.learning_rate,.9f,.999f,1.0e-8f,0.0f,optimizer_step};
            std::memcpy(trainer.adam_configs[update].contents,&adam,sizeof(adam));
            trainer.dispatch(commands,trainer.norm_factor_p,256,
                {{trainer.actor_grad,0},{trainer.actor_scale,0},
                 {trainer.actor_count_b,0},{trainer.actor_max_norm_b,0}},256);
            trainer.dispatch(commands,trainer.scale_grad_p,fixed_ppo::actor_param_count,
                {{trainer.actor_grad,0},{trainer.actor_scale,0},{trainer.actor_count_b,0}},128);
            trainer.dispatch(commands,trainer.norm_factor_p,256,
                {{trainer.critic_grad,0},{trainer.critic_scale,0},
                 {trainer.critic_count_b,0},{trainer.critic_max_norm_b,0}},256);
            trainer.dispatch(commands,trainer.scale_grad_p,fixed_ppo::critic_param_count,
                {{trainer.critic_grad,0},{trainer.critic_scale,0},{trainer.critic_count_b,0}},128);
            trainer.dispatch(commands,trainer.adam_p,fixed_ppo::actor_param_count,
                {{sim.actor,0},{trainer.actor_grad,0},{trainer.actor_m,0},
                 {trainer.actor_v,0},{trainer.actor_count_b,0},
                 {trainer.adam_configs[update],0}},128);
            trainer.dispatch(commands,trainer.adam_p,fixed_ppo::critic_param_count,
                {{sim.critic,0},{trainer.critic_grad,0},{trainer.critic_m,0},
                 {trainer.critic_v,0},{trainer.critic_count_b,0},
                 {trainer.adam_configs[update],0}},128);
            trainer.dispatch(commands,trainer.clip_logstd_p,fixed_ppo::action_dim,
                {{sim.actor,0},{trainer.logstd_count_b,0},{trainer.logstd_lo_b,0},
                 {trainer.logstd_hi_b,0}},4);
            update++;
        }
    }
    require(update==trainer.updates_per_rollout,"temporal PPO update count mismatch");
    trainer.dispatch(commands,trainer.metric_mean_p,1,
        {{trainer.metric_rows,0},{trainer.metric_mean,0},{trainer.metric_count_b,0}},1);
}

static void rollout_update_held_scan(PPOTrainer& trainer,Sim& sim,Metal& metal,
                                     id<MTLCommandBuffer> commands,
                                     uint32_t rollout_index,id<MTLBuffer> action_masks) {
    require(trainer.anchor_lambda==0.0f&&trainer.direction_aux_coefficient==0.0f,
            "held-scan rollout uses the standard unanchored PPO objective");
    trainer.dispatch(commands,trainer.gae_p,sim.cfg.n,
        {{sim.rewards,0},{sim.values,0},{sim.next_values,0},{sim.terminated,0},
         {sim.truncated,0},{sim.advantages,0},{sim.returns,0},{trainer.horizon_b,0},
         {trainer.envs_b,0},{trainer.gamma_b,0},{trainer.lambda_b,0}},64);
    trainer.dispatch(commands,trainer.normalize_p,1,
        {{sim.advantages,0},{trainer.rows_b,0},{trainer.gae_epsilon_b,0},
         {trainer.adv_clip_b,0}},1);
    for(uint32_t batch=0;batch<trainer.starts.size();batch++)
        trainer.starts[batch]=batch*trainer.minibatch;
    std::mt19937 rng(0x9e3779b9u+rollout_index*0x85ebca6bu);
    std::shuffle(trainer.starts.begin(),trainer.starts.end(),rng);
    uint32_t update=0;
    for(uint32_t epoch=0;epoch<trainer.epochs;epoch++) {
        if(epoch==1)std::shuffle(trainer.starts.begin(),trainer.starts.end(),rng);
        for(uint32_t begin:trainer.starts) {
            const uint32_t batch=std::min(trainer.minibatch,trainer.rows-begin);
            const size_t obs_offset=size_t(begin)*fixed_ppo::actor_obs_dim*sizeof(float);
            const size_t critic_offset=size_t(begin)*fixed_ppo::critic_obs_dim*sizeof(float);
            const size_t action_offset=size_t(begin)*fixed_ppo::action_dim*sizeof(float);
            const size_t row_offset=size_t(begin)*sizeof(float);
            const auto batch_size=trainer.batch_size_buffers[batch];
            trainer.dispatch(commands,trainer.actor_forward_p,
                sim.simd_actor?((size_t(batch)+7)/8)*256:batch,
                {{sim.obs,obs_offset},{sim.actor,0},{trainer.actor_hidden,0},
                 {trainer.actor_means,0},{batch_size,0}},sim.simd_actor?256:64);
            trainer.dispatch(commands,trainer.critic_forward_p,batch,
                {{sim.co,critic_offset},{sim.critic,0},{trainer.critic_hidden,0},
                 {trainer.predicted_values,0},{batch_size,0}},64);
            trainer.dispatch(commands,metal.pipeline("ppo_sample_loss_grad_masked"),batch,
                {{sim.actions,action_offset},{trainer.actor_means,0},
                 {sim.actor,fixed_ppo::actor_log_std_offset*sizeof(float)},
                 {sim.logp,row_offset},{trainer.predicted_values,0},{sim.values,row_offset},
                 {sim.advantages,row_offset},{sim.returns,row_offset},
                 {trainer.d_means,0},{trainer.d_log_stds,0},{trainer.d_values,0},
                 {trainer.losses,0},{batch_size,0},{trainer.clip_b,0},
                 {trainer.value_coef_b,0},{trainer.entropy_coef_b,0},
                 {action_masks,action_offset}},64);
            trainer.dispatch(commands,trainer.metric_batch_p,1,
                {{trainer.losses,0},{trainer.metric_rows,size_t(update)*4*4},
                 {batch_size,0}},1);
            trainer.dispatch(commands,trainer.actor_hidden_delta_p,
                size_t(batch)*fixed_ppo::hidden_dim,
                {{sim.actor,0},{trainer.d_means,0},{trainer.actor_hidden,0},
                 {trainer.actor_hidden_delta,0},{batch_size,0}},128);
            trainer.dispatch(commands,trainer.actor_grad_direct_p,fixed_ppo::actor_param_count,
                {{sim.obs,obs_offset},{sim.actor,0},{trainer.d_means,0},
                 {trainer.d_log_stds,0},{trainer.actor_hidden_delta,0},
                 {trainer.actor_grad,0},{batch_size,0}},128);
            trainer.dispatch(commands,trainer.critic_hidden_delta_p,
                size_t(batch)*fixed_ppo::hidden_dim,
                {{sim.critic,0},{trainer.d_values,0},{trainer.critic_hidden,0},
                 {trainer.critic_hidden_delta,0},{batch_size,0}},128);
            trainer.dispatch(commands,trainer.critic_grad_direct_p,fixed_ppo::critic_param_count,
                {{sim.co,critic_offset},{sim.critic,0},{trainer.d_values,0},
                 {trainer.critic_hidden_delta,0},{trainer.critic_grad,0},
                 {batch_size,0}},128);
            require(trainer.optimizer_step<uint64_t(std::numeric_limits<uint32_t>::max()),
                    "held-scan PPO Adam step overflow");
            const uint32_t optimizer_step=uint32_t(++trainer.optimizer_step);
            PpoAdamHostConfig adam{sim.cfg.learning_rate,.9f,.999f,1.0e-8f,0.0f,optimizer_step};
            std::memcpy(trainer.adam_configs[update].contents,&adam,sizeof(adam));
            trainer.dispatch(commands,trainer.norm_factor_p,256,
                {{trainer.actor_grad,0},{trainer.actor_scale,0},
                 {trainer.actor_count_b,0},{trainer.actor_max_norm_b,0}},256);
            trainer.dispatch(commands,trainer.scale_grad_p,fixed_ppo::actor_param_count,
                {{trainer.actor_grad,0},{trainer.actor_scale,0},{trainer.actor_count_b,0}},128);
            trainer.dispatch(commands,trainer.norm_factor_p,256,
                {{trainer.critic_grad,0},{trainer.critic_scale,0},
                 {trainer.critic_count_b,0},{trainer.critic_max_norm_b,0}},256);
            trainer.dispatch(commands,trainer.scale_grad_p,fixed_ppo::critic_param_count,
                {{trainer.critic_grad,0},{trainer.critic_scale,0},{trainer.critic_count_b,0}},128);
            trainer.dispatch(commands,trainer.adam_p,fixed_ppo::actor_param_count,
                {{sim.actor,0},{trainer.actor_grad,0},{trainer.actor_m,0},
                 {trainer.actor_v,0},{trainer.actor_count_b,0},
                 {trainer.adam_configs[update],0}},128);
            trainer.dispatch(commands,trainer.adam_p,fixed_ppo::critic_param_count,
                {{sim.critic,0},{trainer.critic_grad,0},{trainer.critic_m,0},
                 {trainer.critic_v,0},{trainer.critic_count_b,0},
                 {trainer.adam_configs[update],0}},128);
            trainer.dispatch(commands,trainer.clip_logstd_p,fixed_ppo::action_dim,
                {{sim.actor,0},{trainer.logstd_count_b,0},{trainer.logstd_lo_b,0},
                 {trainer.logstd_hi_b,0}},4);
            update++;
        }
    }
    require(update==trainer.updates_per_rollout,"held-scan PPO update count mismatch");
    trainer.dispatch(commands,trainer.metric_mean_p,1,
        {{trainer.metric_rows,0},{trainer.metric_mean,0},{trainer.metric_count_b,0}},1);
}

struct ConditionalGaussian {
    float action, mean, log_std, previous_noise, rho;
};
struct ConditionalGaussianResult {
    float log_probability, d_mean, d_log_std;
};
struct MacroSignResult {
    float log_probability, d_mean, d_log_std;
    float entropy, d_entropy_mean, d_entropy_log_std;
};
static float normal_cdf_approximation(float value) {
    const float magnitude=std::fabs(value)*0.70710678118f;
    const float t=1.0f/(1.0f+0.3275911f*magnitude);
    const float erf_magnitude=1.0f-(((((1.061405429f*t-1.453152027f)*t+
        1.421413741f)*t-0.284496736f)*t+0.254829592f)*t)*std::exp(-magnitude*magnitude);
    return 0.5f*(1.0f+(value<0.0f?-erf_magnitude:erf_magnitude));
}
static MacroSignResult macro_sign_likelihood(float mean,float log_std,float direction) {
    require(std::isfinite(mean)&&std::isfinite(log_std)&&
            (direction==1.0f||direction==-1.0f),
            "invalid Gaussian sign macro sample");
    const float sigma=std::exp(log_std);
    const float x=mean/sigma;
    const float p_raw=normal_cdf_approximation(x);
    const float epsilon=1.0e-6f;
    const float p_positive=std::clamp(p_raw,epsilon,1.0f-epsilon);
    const float p_negative=1.0f-p_positive;
    const float selected=direction>0.0f?p_positive:p_negative;
    const float density=std::exp(-0.5f*x*x)*0.3989422804f;
    const float log_odds=std::log(p_positive/p_negative);
    const float entropy=-p_positive*std::log(p_positive)-p_negative*std::log(p_negative);
    const bool cdf_active=p_raw>epsilon&&p_raw<1.0f-epsilon;
    return {std::log(selected),cdf_active?direction*density/(sigma*selected):0.0f,
        cdf_active?-direction*x*density/selected:0.0f,entropy,
        cdf_active?-density/sigma*log_odds:0.0f,
        cdf_active?x*density*log_odds:0.0f};
}
static ConditionalGaussianResult conditional_gaussian(const ConditionalGaussian& sample) {
    require(std::isfinite(sample.action) && std::isfinite(sample.mean) &&
            std::isfinite(sample.log_std) && std::isfinite(sample.previous_noise) &&
            std::isfinite(sample.rho) && std::fabs(sample.rho) < 1.0f,
            "invalid conditional Gaussian sample");
    const float sigma = std::exp(sample.log_std);
    const float innovation_variance = 1.0f - sample.rho * sample.rho;
    const float previous_center = sample.mean + sigma * sample.rho * sample.previous_noise;
    const float conditional_sigma = sigma * std::sqrt(innovation_variance);
    const float normalized = (sample.action - previous_center) / conditional_sigma;
    const float independent_residual = (sample.action - sample.mean) / sigma;
    const float correlated_residual = independent_residual - sample.rho * sample.previous_noise;
    const float log_probability = -0.5f * (
        normalized * normalized + 2.0f * sample.log_std +
        std::log(innovation_variance) + fixed_ppo::log_two_pi);
    const float d_mean = normalized / conditional_sigma;
    const float d_log_std = independent_residual * correlated_residual /
        innovation_variance - 1.0f;
    return {log_probability, d_mean, d_log_std};
}

static std::vector<float> load_actor_weights(const std::string& checkpoint,
                                             Sim& sim) {
    std::ifstream file(checkpoint,std::ios::binary);
    require(bool(file),"cannot open temporal PPO parameter warmstart: "+checkpoint);
    const auto header=read_checkpoint_header(file);
    require(header.actor_count==fixed_ppo::actor_param_count&&
            header.critic_count==fixed_ppo::critic_param_count,
            "temporal PPO warmstart dimensions differ from raw824 build");
    std::vector<float> actor(header.actor_count);
    file.read(reinterpret_cast<char*>(actor.data()),actor.size()*sizeof(float));
    file.read(static_cast<char*>(sim.critic.contents),sim.critic.length);
    require(bool(file),"temporal PPO warmstart is truncated");
    std::memcpy(sim.actor.contents,actor.data(),actor.size()*sizeof(float));
    return actor;
}

static float max_difference(const float* first,const float* second,size_t count) {
    float maximum=0.0f;
    for(size_t i=0;i<count;i++) {
        require(std::isfinite(first[i])&&std::isfinite(second[i]),
                "white-noise parity encountered a nonfinite value");
        maximum=std::max(maximum,std::fabs(first[i]-second[i]));
    }
    return maximum;
}

static float verify_white_noise_rollout(Metal& metal,const std::string& warmstart) {
    SimConfig config;
    config.n=8;config.family=kFamilyCorner;config.mode=22;config.eval=0;config.seed=42;
    config.speed=kSpeedCapMps;config.distance=8.0f;config.max_steps=kMaxSteps;
    config.geometry_memory=1;config.risk_coef=kClearanceRisk;
    config.entropy_coef=kTemporalEntropy;config.learning_rate=kLearningRate;
    Sim independent(metal,config,8),temporal(metal,config,8);
    load_actor_weights(warmstart,independent);
    load_actor_weights(warmstart,temporal);
    auto exploration_state=metal.buffer(size_t(config.n)*sizeof(float));
    std::memset(exploration_state.contents,0,exploration_state.length);
    auto history=temporal_previous_noise_buffer(metal,temporal);
    auto rho=temporal_rho_buffer(metal,0.0f);
    auto white=[metal.queue commandBuffer];
    independent.collect(white,8);metal.finish(white);
    auto colored=[metal.queue commandBuffer];
    collect_temporal_rollout(temporal,metal,colored,exploration_state,history,rho);metal.finish(colored);
    const float observation_error=max_difference(
        static_cast<const float*>(independent.obs.contents),
        static_cast<const float*>(temporal.obs.contents),independent.obs.length/sizeof(float));
    const float critic_error=max_difference(
        static_cast<const float*>(independent.co.contents),
        static_cast<const float*>(temporal.co.contents),independent.co.length/sizeof(float));
    const float action_error=max_difference(
        static_cast<const float*>(independent.actions.contents),
        static_cast<const float*>(temporal.actions.contents),independent.actions.length/sizeof(float));
    const float logp_error=max_difference(
        static_cast<const float*>(independent.logp.contents),
        static_cast<const float*>(temporal.logp.contents),independent.logp.length/sizeof(float));
    const float reward_error=max_difference(
        static_cast<const float*>(independent.rewards.contents),
        static_cast<const float*>(temporal.rewards.contents),independent.rewards.length/sizeof(float));
    const float maximum=std::max({observation_error,critic_error,action_error,logp_error,reward_error});
    std::cout<<"rho0_parity obs="<<observation_error<<" critic="<<critic_error
             <<" action="<<action_error<<" logp="<<logp_error
             <<" reward="<<reward_error<<"\n";
    require(maximum<1.0e-5f,"rho=0 temporal collector differs from verified white-noise PPO");
    return maximum;
}

static float verify_temporal_loss_gradient(Metal& metal) {
    constexpr float entropy_coefficient=0.0005f;
    const float means[4]={0.1f,-0.1f,0.2f,0.1f};
    const float log_std_value=std::log(0.3f);
    const float log_stds[4]={log_std_value,log_std_value,log_std_value,log_std_value};
    const float actions[4]={0.16f,0.01f,0.5f,0.355f};
    float previous[4]={0.5f,0.8f,0.0f,0.0f};
    float old_log_probability=0.0f;
    std::array<ConditionalGaussianResult,4> reference{};
    for(uint32_t action=0;action<4;action++) {
        const float rho=action==3?previous[1]:0.0f;
        const float previous_noise=action==3?previous[0]:0.0f;
        reference[action]=conditional_gaussian({actions[action],means[action],log_std_value,
                                                previous_noise,rho});
        old_log_probability+=reference[action].log_probability;
    }
    const float old_logp[1]={old_log_probability},values[1]={0.0f},old_values[1]={0.0f};
    const float advantages[1]={1.0f},returns[1]={0.0f};
    const uint32_t batch_size=1;
    const float clip=.2f,value_coefficient=.5f;
    auto action_buffer=metal.buffer(sizeof(actions),actions);
    auto mean_buffer=metal.buffer(sizeof(means),means);
    auto log_std_buffer=metal.buffer(sizeof(log_stds),log_stds);
    auto old_logp_buffer=metal.buffer(sizeof(old_logp),old_logp);
    auto value_buffer=metal.buffer(sizeof(values),values);
    auto old_value_buffer=metal.buffer(sizeof(old_values),old_values);
    auto advantage_buffer=metal.buffer(sizeof(advantages),advantages);
    auto return_buffer=metal.buffer(sizeof(returns),returns);
    auto d_mean=metal.buffer(sizeof(means));auto d_log_std=metal.buffer(sizeof(means));
    auto d_value=metal.buffer(sizeof(float));auto losses=metal.buffer(4*sizeof(float));
    auto count=metal.buffer(sizeof(batch_size),&batch_size);auto clip_buffer=metal.buffer(sizeof(clip),&clip);
    auto value_coefficient_buffer=metal.buffer(sizeof(value_coefficient),&value_coefficient);
    auto entropy_buffer=metal.buffer(sizeof(entropy_coefficient),&entropy_coefficient);
    auto history=metal.buffer(sizeof(previous),previous);
    auto commands=[metal.queue commandBuffer];
    metal.dispatch(commands,metal.pipeline("ppo_sample_loss_grad_temporal"),1,
        {action_buffer,mean_buffer,log_std_buffer,old_logp_buffer,value_buffer,old_value_buffer,
         advantage_buffer,return_buffer,d_mean,d_log_std,d_value,losses,count,clip_buffer,
         value_coefficient_buffer,entropy_buffer,history},1);
    metal.finish(commands);
    const float* actual_mean=static_cast<const float*>(d_mean.contents);
    const float* actual_log_std=static_cast<const float*>(d_log_std.contents);
    float maximum=0.0f;
    for(uint32_t action=0;action<4;action++) {
        const float expected_mean=-reference[action].d_mean;
        const float expected_log_std=-reference[action].d_log_std-entropy_coefficient;
        maximum=std::max(maximum,std::fabs(actual_mean[action]-expected_mean));
        maximum=std::max(maximum,std::fabs(actual_log_std[action]-expected_log_std));
    }
    const float ratio=static_cast<const float*>(losses.contents)[3];
    maximum=std::max(maximum,std::fabs(ratio-1.0f));
    require(maximum<2.0e-5f,
            "Metal conditional-likelihood PPO gradient differs from scalar reference");
    return maximum;
}

static float verify_masked_macro_gradient(Metal& metal) {
    constexpr float entropy_coefficient=0.0005f;
    const float means[4]={0.1f,-0.1f,0.2f,0.2f};
    const float log_std_value=std::log(0.3f);
    const float log_stds[4]={log_std_value,log_std_value,log_std_value,log_std_value};
    const float actions[4]={0.4f,-0.2f,0.1f,1.0f};
    const float masks[4]={1.0f,1.0f,1.0f,2.0f};
    const auto reference=macro_sign_likelihood(means[3],log_std_value,1.0f);
    float decision_logp=reference.log_probability;
    for(uint32_t axis=0;axis<3;axis++) {
        const float z=(actions[axis]-means[axis])*std::exp(-log_std_value);
        decision_logp+=-0.5f*(z*z+2.0f*log_std_value+fixed_ppo::log_two_pi);
    }
    const float old_logp[1]={decision_logp};
    const float values[1]={0.0f},old_values[1]={0.0f},advantages[1]={1.0f},returns[1]={0.0f};
    const uint32_t batch_size=1;
    const float clip=.2f,value_coefficient=.5f;
    auto action_buffer=metal.buffer(sizeof(actions),actions);
    auto mean_buffer=metal.buffer(sizeof(means),means);
    auto log_std_buffer=metal.buffer(sizeof(log_stds),log_stds);
    auto old_logp_buffer=metal.buffer(sizeof(old_logp),old_logp);
    auto value_buffer=metal.buffer(sizeof(values),values);
    auto old_value_buffer=metal.buffer(sizeof(old_values),old_values);
    auto advantage_buffer=metal.buffer(sizeof(advantages),advantages);
    auto return_buffer=metal.buffer(sizeof(returns),returns);
    auto mean_gradient=metal.buffer(sizeof(means));
    auto log_std_gradient=metal.buffer(sizeof(means));
    auto value_gradient=metal.buffer(sizeof(float));
    auto losses=metal.buffer(4*sizeof(float));
    auto count=metal.buffer(sizeof(batch_size),&batch_size);
    auto clip_buffer=metal.buffer(sizeof(clip),&clip);
    auto value_coefficient_buffer=metal.buffer(sizeof(value_coefficient),&value_coefficient);
    auto entropy_buffer=metal.buffer(sizeof(entropy_coefficient),&entropy_coefficient);
    auto mask_buffer=metal.buffer(sizeof(masks),masks);
    auto commands=[metal.queue commandBuffer];
    metal.dispatch(commands,metal.pipeline("ppo_sample_loss_grad_masked"),1,
        {action_buffer,mean_buffer,log_std_buffer,old_logp_buffer,value_buffer,old_value_buffer,
         advantage_buffer,return_buffer,mean_gradient,log_std_gradient,value_gradient,
         losses,count,clip_buffer,value_coefficient_buffer,entropy_buffer,mask_buffer},1);
    metal.finish(commands);
    const float* actual_mean=static_cast<const float*>(mean_gradient.contents);
    const float* actual_log_std=static_cast<const float*>(log_std_gradient.contents);
    float maximum=0.0f;
    for(uint32_t action=0;action<3;action++) {
        const float difference=actions[action]-means[action];
        const float z=difference*std::exp(-log_std_value);
        maximum=std::max(maximum,std::fabs(actual_mean[action]+difference*std::exp(-2.0f*log_std_value)));
        maximum=std::max(maximum,std::fabs(actual_log_std[action]+
                                             (z*z-1.0f)+entropy_coefficient));
    }
    maximum=std::max(maximum,std::fabs(actual_mean[3]+
        reference.d_mean+entropy_coefficient*reference.d_entropy_mean));
    maximum=std::max(maximum,std::fabs(actual_log_std[3]+
        reference.d_log_std+entropy_coefficient*reference.d_entropy_log_std));
    maximum=std::max(maximum,std::fabs(static_cast<const float*>(losses.contents)[3]-1.0f));
    require(maximum<2.0e-5f,
            "Metal categorical macro likelihood/gradient differs from Gaussian sign reference");
    return maximum;
}

static std::array<float,4> run_masked_loss_case(
        Metal& metal,const std::array<float,4>& actions,
        const std::array<float,4>& means,const std::array<float,4>& log_stds,
        const std::array<float,4>& masks,float old_logp,float entropy_coefficient,
        uint32_t action_axis=3) {
    const float values[1]={0.0f},old_values[1]={0.0f},advantages[1]={1.0f},returns[1]={0.0f};
    const uint32_t batch_size=1;const float clip=.2f,value_coefficient=.5f;
    const float old_logp_rows[1]={old_logp};
    auto action_buffer=metal.buffer(sizeof(actions),actions.data());
    auto mean_buffer=metal.buffer(sizeof(means),means.data());
    auto log_std_buffer=metal.buffer(sizeof(log_stds),log_stds.data());
    auto old_logp_buffer=metal.buffer(sizeof(old_logp_rows),old_logp_rows);
    auto value_buffer=metal.buffer(sizeof(values),values);
    auto old_value_buffer=metal.buffer(sizeof(old_values),old_values);
    auto advantage_buffer=metal.buffer(sizeof(advantages),advantages);
    auto return_buffer=metal.buffer(sizeof(returns),returns);
    auto mean_gradient=metal.buffer(sizeof(means));auto log_std_gradient=metal.buffer(sizeof(means));
    auto value_gradient=metal.buffer(sizeof(float));auto losses=metal.buffer(4*sizeof(float));
    auto count=metal.buffer(sizeof(batch_size),&batch_size);auto clip_buffer=metal.buffer(sizeof(clip),&clip);
    auto value_coefficient_buffer=metal.buffer(sizeof(value_coefficient),&value_coefficient);
    auto entropy_buffer=metal.buffer(sizeof(entropy_coefficient),&entropy_coefficient);
    auto mask_buffer=metal.buffer(sizeof(masks),masks.data());
    auto commands=[metal.queue commandBuffer];
    metal.dispatch(commands,metal.pipeline("ppo_sample_loss_grad_masked"),1,
        {action_buffer,mean_buffer,log_std_buffer,old_logp_buffer,value_buffer,old_value_buffer,
         advantage_buffer,return_buffer,mean_gradient,log_std_gradient,value_gradient,
         losses,count,clip_buffer,value_coefficient_buffer,entropy_buffer,mask_buffer},1);
    metal.finish(commands);
    require(action_axis<4,"masked loss probe action axis outside the contract");
    return {static_cast<const float*>(mean_gradient.contents)[action_axis],
            static_cast<const float*>(log_std_gradient.contents)[action_axis],
            static_cast<const float*>(losses.contents)[3],
            static_cast<const float*>(losses.contents)[0]+
                static_cast<const float*>(losses.contents)[2]};
}

static float verify_clipped_entropy_gradients(Metal& metal) {
    constexpr float entropy_coefficient=.001f;
    constexpr float step=.001f;
    const float log_std=std::log(.3f);
    float maximum=0.0f;

    // The Gaussian policy ratio is kept above the positive-advantage clip.
    std::array<float,4> gaussian_actions{{.4f,0,0,0}};
    std::array<float,4> gaussian_means{{.1f,0,0,0}};
    std::array<float,4> gaussian_log_stds{{log_std,log_std,log_std,log_std}};
    std::array<float,4> gaussian_masks{{1,0,0,0}};
    const float gaussian_z=(gaussian_actions[0]-gaussian_means[0])*std::exp(-log_std);
    const float gaussian_logp=-.5f*(gaussian_z*gaussian_z+2.0f*log_std+fixed_ppo::log_two_pi);
    const auto gaussian=run_masked_loss_case(metal,gaussian_actions,gaussian_means,
        gaussian_log_stds,gaussian_masks,gaussian_logp-std::log(1.5f),entropy_coefficient,0);
    const auto gaussian_logstd_plus=run_masked_loss_case(metal,gaussian_actions,gaussian_means,
        {{log_std+step,log_std,log_std,log_std}},gaussian_masks,
        gaussian_logp-std::log(1.5f),entropy_coefficient,0);
    const auto gaussian_logstd_minus=run_masked_loss_case(metal,gaussian_actions,gaussian_means,
        {{log_std-step,log_std,log_std,log_std}},gaussian_masks,
        gaussian_logp-std::log(1.5f),entropy_coefficient,0);
    maximum=std::max(maximum,std::fabs(gaussian[0]));
    maximum=std::max(maximum,std::fabs(gaussian[1]+entropy_coefficient));
    maximum=std::max(maximum,std::fabs((gaussian_logstd_plus[3]-gaussian_logstd_minus[3])/
                                       (2.0f*step)-gaussian[1]));
    maximum=std::max(maximum,std::fabs(gaussian[2]-1.5f));

    // The categorical scan-sign ratio is clipped too; entropy gradients must
    // still flow through both its mean and standard deviation.
    const std::array<float,4> macro_actions{{0,0,0,1}};
    const std::array<float,4> macro_means{{0,0,0,.2f}};
    const std::array<float,4> macro_log_stds{{log_std,log_std,log_std,log_std}};
    const std::array<float,4> macro_masks{{0,0,0,2}};
    const auto macro_reference=macro_sign_likelihood(.2f,log_std,1.0f);
    const auto macro=run_masked_loss_case(metal,macro_actions,macro_means,
        macro_log_stds,macro_masks,macro_reference.log_probability-std::log(1.5f),
        entropy_coefficient);
    const auto macro_mean_plus=run_masked_loss_case(metal,macro_actions,
        {{0,0,0,.2f+step}},macro_log_stds,macro_masks,
        macro_reference.log_probability-std::log(1.5f),entropy_coefficient);
    const auto macro_mean_minus=run_masked_loss_case(metal,macro_actions,
        {{0,0,0,.2f-step}},macro_log_stds,macro_masks,
        macro_reference.log_probability-std::log(1.5f),entropy_coefficient);
    const auto macro_std_plus=run_masked_loss_case(metal,macro_actions,macro_means,
        {{log_std,log_std,log_std,log_std+step}},macro_masks,
        macro_reference.log_probability-std::log(1.5f),entropy_coefficient);
    const auto macro_std_minus=run_masked_loss_case(metal,macro_actions,macro_means,
        {{log_std,log_std,log_std,log_std-step}},macro_masks,
        macro_reference.log_probability-std::log(1.5f),entropy_coefficient);
    maximum=std::max(maximum,std::fabs(macro[0]+entropy_coefficient*macro_reference.d_entropy_mean));
    maximum=std::max(maximum,std::fabs(macro[1]+entropy_coefficient*macro_reference.d_entropy_log_std));
    maximum=std::max(maximum,std::fabs((macro_mean_plus[3]-macro_mean_minus[3])/
                                       (2.0f*step)-macro[0]));
    maximum=std::max(maximum,std::fabs((macro_std_plus[3]-macro_std_minus[3])/
                                       (2.0f*step)-macro[1]));
    maximum=std::max(maximum,std::fabs(macro[2]-1.5f));
    std::cout<<"clipped_entropy_check gaussian_dmu="<<gaussian[0]
             <<" dls="<<gaussian[1]<<" fdls="
             <<(gaussian_logstd_plus[3]-gaussian_logstd_minus[3])/(2.0f*step)
             <<" macro_dmu="<<macro[0]<<" macro_dls="<<macro[1]
             <<" fdmu="<<(macro_mean_plus[3]-macro_mean_minus[3])/(2.0f*step)
             <<" fdls="<<(macro_std_plus[3]-macro_std_minus[3])/(2.0f*step)
             <<" max_error="<<maximum<<"\n";
    require(maximum<2.0e-4f,
            "clipped PPO entropy gradient differs from finite differences");
    return maximum;
}

static float verify_normal_cdf_approximation() {
    float maximum=0.0f;
    for(int32_t step=0;step<=12000;step++) {
        const float x=-6.0f+float(step)*0.001f;
        const float reference=0.5f*std::erfc(-x*0.70710678118f);
        maximum=std::max(maximum,std::fabs(normal_cdf_approximation(x)-reference));
    }
    std::cout<<"normal_cdf_polynomial_max_error="<<maximum<<"\n";
    require(maximum<1.0e-6f,
            "shared macro sign CDF approximation exceeds its numeric error bound");
    return maximum;
}

static double verify_ar1_statistics(float rho) {
    std::mt19937 generator(1776);
    std::normal_distribution<float> normal(0.0f,1.0f);
    constexpr uint32_t count=200000;
    double mean=0.0,variance=0.0,cross=0.0;
    float previous=normal(generator);
    for(uint32_t sample=0;sample<count;sample++) {
        const float current=rho*previous+std::sqrt(1.0f-rho*rho)*normal(generator);
        mean+=current;
        variance+=double(current)*current;
        cross+=double(previous)*current;
        previous=current;
    }
    mean/=count;variance=variance/count-mean*mean;
    const double lag_one=cross/(count-1);
    require(std::fabs(mean)<0.02&&std::fabs(variance-1.0)<0.025&&
            std::fabs(lag_one-rho)<0.015,
            "AR(1) yaw noise did not retain unit variance and configured lag correlation");
    return lag_one;
}

static void verify_temporal_canaries(const std::string& warmstart,float rho) {
    require(fixed_ppo::actor_obs_dim==824,
            "temporal canary requires the raw-depth824 actor build");
    Metal metal;
    metal.compile(base_source()+PPO_TRAINER_MSL+temporal_msl);
    const float gradient_error=verify_temporal_loss_gradient(metal);
    const float macro_gradient_error=verify_masked_macro_gradient(metal);
    const float clipped_entropy_error=verify_clipped_entropy_gradients(metal);
    const float cdf_error=verify_normal_cdf_approximation();
    const float white_noise_error=verify_white_noise_rollout(metal,warmstart);
    const double measured_rho=verify_ar1_statistics(rho);
    std::cout<<"temporal_canaries conditional_loss_gradient_max_error="<<gradient_error
             <<" macro_likelihood_gradient_max_error="<<macro_gradient_error
             <<" clipped_entropy_finite_difference_max_error="<<clipped_entropy_error
             <<" normal_cdf_max_error="<<cdf_error
             <<" rho0_white_rollout_max_error="<<white_noise_error
             <<" ar1_sample_lag1="<<measured_rho<<" target_rho="<<rho
             <<" logprob=exact_conditional_yaw_AR1\n";
}

static std::string exploration_config_text(const std::string& arm,
                                           const std::string& bank_hash,
                                           const std::string& warmstart_hash) {
    std::ostringstream config;
    config<<"schema=2\narm="<<arm<<"\n"
          <<"macro_ticks="<<(arm=="held-scan"?40:0)
          <<"\nmacro_translation_policy=mode22_actor_gaussian"
          <<"\nmacro_yaw_normalized="<<(arm=="held-scan"?0.80f:0.0f)
          <<"\nmacro_decision_likelihood="<<(arm=="held-scan"?"exact_gaussian_sign_bernoulli_once":"none")
          <<"\nnoise_state=standalone_per_environment_scan_sign_buffer\n"
          <<"noise_state_checkpoint_sidecar=true\nactor_features="<<fixed_ppo::actor_obs_dim
          <<"\nmode=22\nspeed_cap_mps="<<kSpeedCapMps
          <<"\nrollout_horizon="<<kHorizon<<"\nenvironments="<<kEnvironmentCount
          <<"\nseed=42\nbank_sha256="<<bank_hash
          <<"\nwarmstart_sha256="<<warmstart_hash<<"\n";
    return config.str();
}

static void write_text_file(const std::string& path,const std::string& content) {
    const std::string temporary=path+".tmp";
    std::ofstream file(temporary,std::ios::binary|std::ios::trunc);
    require(bool(file),"cannot write temporal metadata: "+temporary);
    file.write(content.data(),std::streamsize(content.size()));
    file.flush();require(bool(file),"temporal metadata write failed: "+temporary);
    file.close();
    require(std::rename(temporary.c_str(),path.c_str())==0,
            "cannot replace temporal metadata: "+path);
}

static std::string read_text_file(const std::string& path) {
    std::ifstream file(path,std::ios::binary);
    require(bool(file),"cannot open temporal metadata: "+path);
    return std::string(std::istreambuf_iterator<char>(file),{});
}

static void save_exploration_state(id<MTLBuffer> exploration_state,const std::string& path) {
    const std::string temporary=path+".tmp";
    std::ofstream file(temporary,std::ios::binary|std::ios::trunc);
    require(bool(file),"cannot write temporal exploration state: "+temporary);
    file.write(static_cast<const char*>(exploration_state.contents),exploration_state.length);
    file.flush();require(bool(file),"temporal exploration state write failed");
    file.close();
    require(std::rename(temporary.c_str(),path.c_str())==0,
            "cannot replace temporal exploration state: "+path);
}

static void load_exploration_state(id<MTLBuffer> exploration_state,const std::string& path) {
    require(std::filesystem::file_size(path)==exploration_state.length,
            "temporal exploration sidecar size differs from this simulator");
    std::ifstream file(path,std::ios::binary);
    require(bool(file),"cannot open temporal exploration state: "+path);
    file.read(static_cast<char*>(exploration_state.contents),exploration_state.length);
    require(bool(file),"temporal exploration sidecar is truncated");
}

static void write_temporal_checkpoint(PPOTrainer& trainer,Sim& sim,
                                      challenge_training::ChallengeTraining& sampler,
                                      id<MTLBuffer> exploration_state,
                                      const std::string& checkpoint,
    const std::string& arm,
                                      const std::string& bank_hash,
                                      const std::string& warmstart_hash) {
    trainer.save_checkpoint(checkpoint,kFamilyCorner,42,trainer.completed_rollouts);
    if(arm=="held-scan")save_exploration_state(exploration_state,checkpoint+".macro-state");
    write_text_file(checkpoint+".exploration",
        exploration_config_text(arm,bank_hash,warmstart_hash));
    const auto* ids=static_cast<const uint32_t*>(sim.bank_active_ids.contents);
    sampler.save_state(checkpoint+".replay.state",
        challenge_evaluation::sha256_file(checkpoint),trainer.completed_rollouts,
        std::vector<uint32_t>(ids,ids+kEnvironmentCount));
}

static void train_arm(const std::string& bank_path,const std::string& warmstart,
                      const std::string& output_dir,const std::string& arm,
                      uint32_t rollout_count,const std::string& resume_checkpoint="") {
    require(fixed_ppo::actor_obs_dim==824,
            "temporal exploration training requires the verified raw-depth824 actor");
    require(arm=="iid"||arm=="held-scan","training arm must be iid or held-scan");
    require(rollout_count>0&&rollout_count<=300,
            "each temporal exploration invocation is limited to1..300 PPO rollouts");
    const std::string bank_hash=challenge_evaluation::sha256_file(bank_path);
    require(bank_hash=="e2170fbe8e8c2d074ffb08de4269175a6de0bdcd410c3b60bd699ee7b5fc491e",
            "temporal PPO requires the preserved mirrored challenge bank");
    const std::string warmstart_hash=resume_checkpoint.empty()
        ? challenge_evaluation::sha256_file(warmstart)
        : challenge_evaluation::sha256_file(warmstart);
    const std::string expected_config=exploration_config_text(arm,bank_hash,warmstart_hash);

    Metal metal;
    metal.compile(base_source()+PPO_TRAINER_MSL+temporal_msl);
    challenge_training::Settings settings;
    settings.environment_count=kEnvironmentCount;settings.horizon=kHorizon;
    settings.sampler_seed=42;settings.selection=challenge_training::SelectionMode::UniformBank;
    settings.rehearsal_environments=0;settings.focus_family=0;
    const std::string world_hash=challenge_evaluation::sha256_file(
        std::string(SOURCE_DIR)+"/world.hpp");
    challenge_training::ChallengeTraining sampler(bank_path,world_hash,settings);
    require(sampler.levels().size()==90,"temporal train sampler must load 90 TRAIN levels");

    SimConfig config;
    config.n=kEnvironmentCount;config.family=kFamilyCorner;config.seed=42;
    config.mode=22;config.distance=8.0f;config.speed=kSpeedCapMps;
    config.max_steps=kMaxSteps;config.geometry_memory=1;
    config.risk_coef=kClearanceRisk;config.entropy_coef=kTemporalEntropy;
    config.learning_rate=kLearningRate;
    Sim sim(metal,config,kHorizon);
    auto exploration_state=metal.buffer(kEnvironmentCount*sizeof(float));
    std::memset(exploration_state.contents,0,exploration_state.length);
    const auto bank_control=sampler.control();
    std::memcpy(sim.bank_control.contents,&bank_control,sizeof(bank_control));
    sim.bank_worlds=metal.buffer(sampler.worlds().size()*sizeof(WWorld),sampler.worlds().data());
    const auto initial_schedule=sampler.initial_schedule();
    std::memcpy(sim.bank_schedule.contents,initial_schedule.data(),initial_schedule.size()*sizeof(uint32_t));
    sim.reset();
    const auto initial_ids=static_cast<const uint32_t*>(sim.bank_active_ids.contents);
    std::array<uint32_t,3> family_slots{};
    for(uint32_t env=0;env<kEnvironmentCount;env++) {
        const auto family=sampler.levels().at(initial_ids[env]).family;
        family_slots[family-kFamilyCorner]++;
    }
    require(family_slots[0]==43&&family_slots[1]==43&&family_slots[2]==42,
            "initial train schedule must balance corner, room and vertical levels");
    PPOTrainer trainer(sim,2);
    auto action_masks=held_scan_action_mask_buffer(metal,sim);
    const std::string arm_dir=output_dir+"/"+arm;
    std::filesystem::create_directories(arm_dir);
    const std::string meta_path=arm_dir+"/run.exploration";

    bool schedule_ready=true;
    if(resume_checkpoint.empty()) {
        load_actor_weights(warmstart,sim);
        write_text_file(meta_path,expected_config);
        std::cout<<"parameter_warmstart="<<warmstart
                 <<" optimizer_state=reset arm="<<arm<<" actor_features=824\n";
    } else {
        require(read_text_file(resume_checkpoint+".exploration")==expected_config,
                "checkpoint exploration likelihood/rho config differs from this resume");
        require(read_text_file(meta_path)==expected_config,
                "arm run config differs from requested temporal resume");
        trainer.load_checkpoint(resume_checkpoint,kFamilyCorner,kHorizon,kEnvironmentCount,42);
        if(arm=="held-scan")load_exploration_state(exploration_state,resume_checkpoint+".macro-state");
        const auto active=sampler.load_state(resume_checkpoint+".replay.state",
            challenge_evaluation::sha256_file(resume_checkpoint),trainer.completed_rollouts);
        std::memcpy(sim.bank_active_ids.contents,active.data(),active.size()*sizeof(uint32_t));
        const auto next_schedule=sampler.next_schedule(active,trainer.completed_rollouts);
        std::memcpy(sim.bank_schedule.contents,next_schedule.data(),next_schedule.size()*sizeof(uint32_t));
        schedule_ready=true;
        std::cout<<"ppo_resume arm="<<arm<<" checkpoint="<<resume_checkpoint
                 <<" rollouts="<<trainer.completed_rollouts
                 <<" optimizer_step="<<trainer.optimizer_step
                 <<" exploration_state="<<(arm=="held-scan"?"restored":"none")<<"\n";
    }

    const std::string rollout_path=arm_dir+"/rollouts.csv";
    const bool append=trainer.completed_rollouts>0;
    std::ofstream rollouts(rollout_path,append?std::ios::app:std::ios::trunc);
    require(bool(rollouts),"cannot write temporal PPO rollouts CSV");
    if(!append)rollouts<<"rollout,transitions,gpu_s,train_episodes,train_success,train_collision,train_timeout,corner_episodes,corner_success,corner_collision,corner_timeout,room_episodes,room_success,room_collision,room_timeout,vertical_episodes,vertical_success,vertical_collision,vertical_timeout,mean_speed_mps,min_clearance_m,policy_loss,value_loss,entropy_loss,ratio\n";
    const std::string stage_path=arm_dir+"/stages.csv";
    std::ofstream stages(stage_path,append?std::ios::app:std::ios::trunc);
    require(bool(stages),"cannot write temporal PPO stage CSV");
    if(!append)stages<<"rollout,train_corner_episodes,train_corner_success,train_corner_collision,train_corner_timeout,train_room_episodes,train_room_success,train_room_collision,train_room_timeout,train_vertical_episodes,train_vertical_success,train_vertical_collision,train_vertical_timeout,dev_corner,dev_rooms,dev_vertical,dev_total,dev_collision,dev_timeout,checkpoint_sha256,dev_csv_sha256\n";

    std::vector<SimRun> previous_runs(kEnvironmentCount);
    std::memcpy(previous_runs.data(),sim.runs.contents,sizeof(SimRun)*kEnvironmentCount);
    std::array<uint64_t,3> stage_source_episodes{},stage_source_successes{},
        stage_source_collisions{},stage_source_timeouts{};
    const uint32_t starting_rollout=trainer.completed_rollouts;
    const uint32_t finish_rollout=starting_rollout+rollout_count;
    std::cout<<"temporal_train arm="<<arm
             <<" macro_ticks="<<(arm=="held-scan"?40:0)
             <<" macro_yaw_rps=0.4 macro_translation=actor"
             <<" n_env=128 horizon=32 episodes=400 mode22 speed_cap=1.5"
             <<" family_slots=43/43/42 begin="<<starting_rollout
             <<" finish="<<finish_rollout<<"\n";
    for(uint32_t rollout=starting_rollout;rollout<finish_rollout;rollout++) {
        if(!schedule_ready) {
            const auto* active_data=static_cast<const uint32_t*>(sim.bank_active_ids.contents);
            const std::vector<uint32_t> active(active_data,active_data+kEnvironmentCount);
            const auto schedule=sampler.next_schedule(active,rollout);
            std::memcpy(sim.bank_schedule.contents,schedule.data(),schedule.size()*sizeof(uint32_t));
        }
        schedule_ready=false;
        auto commands=[metal.queue commandBuffer];
        if(arm=="held-scan")
            collect_held_scan_rollout(sim,metal,commands,exploration_state,action_masks);
        else
            sim.collect(commands,kHorizon);
        const double rollout_gpu=metal.finish(commands);
        commands=[metal.queue commandBuffer];
        if(arm=="held-scan")
            rollout_update_held_scan(trainer,sim,metal,commands,rollout,action_masks);
        else
            trainer.rollout_update(commands,rollout);
        const double update_gpu=metal.finish(commands);
        trainer.completed_rollouts=rollout+1;

        std::array<uint64_t,3> source_episodes{},source_successes{},
            source_collisions{},source_timeouts{};
        const auto* terminated=static_cast<const uint8_t*>(sim.terminated.contents);
        const auto* truncated=static_cast<const uint8_t*>(sim.truncated.contents);
        const auto* rewards=static_cast<const float*>(sim.rewards.contents);
        const auto* transition_ids=static_cast<const uint32_t*>(sim.bank_transition_ids.contents);
        for(size_t row=0;row<size_t(kEnvironmentCount)*kHorizon;row++) {
            if(!terminated[row]&&!truncated[row])continue;
            const uint32_t level_id=transition_ids[row];
            require(level_id<sampler.levels().size(),
                    "completed TRAIN transition lost its bank level id");
            const size_t family_slot=sampler.levels()[level_id].family-kFamilyCorner;
            require(family_slot<3,"TRAIN transition family is outside the three-family bank");
            source_episodes[family_slot]++;
            if(truncated[row])source_timeouts[family_slot]++;
            else if(rewards[row]>0.0f)source_successes[family_slot]++;
            else source_collisions[family_slot]++;
        }
        for(size_t family=0;family<3;family++) {
            stage_source_episodes[family]+=source_episodes[family];
            stage_source_successes[family]+=source_successes[family];
            stage_source_collisions[family]+=source_collisions[family];
            stage_source_timeouts[family]+=source_timeouts[family];
        }

        const auto* current=static_cast<const SimRun*>(sim.runs.contents);
        uint64_t episodes=0,successes=0,collisions=0,timeouts=0;
        double path_delta=0.0,elapsed_delta=0.0;
        float minimum_clearance=12.0f;
        for(uint32_t env=0;env<kEnvironmentCount;env++) {
            const auto& now=current[env];const auto& before=previous_runs[env];
            require(now.episodes>=before.episodes&&now.successes>=before.successes&&
                    now.collisions>=before.collisions&&now.timeouts>=before.timeouts,
                    "temporal PPO episode counters moved backwards");
            episodes+=now.episodes-before.episodes;
            successes+=now.successes-before.successes;
            collisions+=now.collisions-before.collisions;
            timeouts+=now.timeouts-before.timeouts;
            path_delta+=now.total_path-before.total_path;
            elapsed_delta+=now.total_elapsed-before.total_elapsed;
            minimum_clearance=std::min(minimum_clearance,now.min_clearance);
        }
        std::memcpy(previous_runs.data(),current,sizeof(SimRun)*kEnvironmentCount);
        const float* metrics=static_cast<const float*>(trainer.metric_mean.contents);
        rollouts<<trainer.completed_rollouts<<','
                <<uint64_t(trainer.completed_rollouts)*kEnvironmentCount*kHorizon<<','
                <<rollout_gpu+update_gpu<<','<<episodes<<','<<successes<<','<<collisions<<','
                <<timeouts;
        for(size_t family=0;family<3;family++)
            rollouts<<','<<source_episodes[family]<<','<<source_successes[family]
                    <<','<<source_collisions[family]<<','<<source_timeouts[family];
        rollouts<<','<<(elapsed_delta?path_delta/elapsed_delta:0.0)<<','
                <<minimum_clearance<<','<<metrics[0]<<','<<metrics[1]<<','<<metrics[2]<<','
                <<metrics[3]<<'\n';
        if(trainer.completed_rollouts%25==0) {
            rollouts.flush();
            std::cout<<"temporal_rollout arm="<<arm<<" rollout="<<trainer.completed_rollouts
                     <<" episodes="<<episodes
                     <<" success="<<(episodes?double(successes)/episodes:0.0)
                     <<" collision="<<(episodes?double(collisions)/episodes:0.0)
                     <<" train_corner="<<source_successes[0]<<'/'<<source_episodes[0]
                     <<" mean_speed="<<(elapsed_delta?path_delta/elapsed_delta:0.0)<<"\n";
        }
        if(trainer.completed_rollouts%100==0||trainer.completed_rollouts==finish_rollout) {
            const std::string checkpoint=arm_dir+"/rollout-"+
                std::to_string(trainer.completed_rollouts)+".bin";
            write_temporal_checkpoint(trainer,sim,sampler,exploration_state,
                                      checkpoint,arm,bank_hash,warmstart_hash);
            const std::string dev_csv=arm_dir+"/rollout-"+
                std::to_string(trainer.completed_rollouts)+"-dev.csv";
            const auto score=run_navigation_bank_evaluation(
                metal,checkpoint,bank_path,"dev",dev_csv,17,kSpeedCapMps,kMaxSteps);
            require(score.episodes==90,"temporal checkpoint DEV scoring must include all90 levels");
            std::ostringstream stage_source_row;
            for(size_t family=0;family<3;family++)
                stage_source_row<<','<<stage_source_episodes[family]<<','
                    <<stage_source_successes[family]<<','<<stage_source_collisions[family]
                    <<','<<stage_source_timeouts[family];
            stages<<trainer.completed_rollouts<<stage_source_row.str()<<','
                  <<score.family_successes[0]<<','<<score.family_successes[1]<<','
                  <<score.family_successes[2]<<','<<score.successes<<','<<score.collisions<<','
                  <<score.timeouts<<','<<challenge_evaluation::sha256_file(checkpoint)<<','
                  <<challenge_evaluation::sha256_file(dev_csv)<<'\n';
            stages.flush();require(bool(stages),"temporal stage row write failed");
            std::cout<<"temporal_stage_end arm="<<arm<<" rollout="<<trainer.completed_rollouts
                     <<" source_corner_success="<<stage_source_successes[0]<<'/'<<stage_source_episodes[0]
                     <<" dev="<<score.family_successes[0]<<"/30,"
                     <<score.family_successes[1]<<"/30,"
                     <<score.family_successes[2]<<"/30 total="<<score.successes<<"/90"
                     <<" checkpoint_sha256="<<challenge_evaluation::sha256_file(checkpoint)
                     <<" dev_sha256="<<challenge_evaluation::sha256_file(dev_csv)<<"\n";
            stage_source_episodes={};stage_source_successes={};
            stage_source_collisions={};stage_source_timeouts={};
        }
    }
}

static float wrap_angle_difference(float angle) {
    constexpr float pi=3.14159265358979323846f;
    while(angle>pi)angle-=2.0f*pi;
    while(angle<-pi)angle+=2.0f*pi;
    return angle;
}

static void probe_initial_scan(const std::string& bank_path,
                               const std::string& warmstart,
                               const std::string& output_dir,
                               const std::string& arm) {
    require(arm=="iid"||arm=="yaw-ar1"||arm=="held-scan",
            "scan probe arm must be iid, yaw-ar1, or held-scan");
    Metal metal;
    metal.compile(base_source()+PPO_TRAINER_MSL+temporal_msl);
    const std::string world_hash=challenge_evaluation::sha256_file(
        std::string(SOURCE_DIR)+"/world.hpp");
    std::string bank_hash;
    const auto bank_levels=challenge_evaluation::load_split(
        bank_path,"train",world_hash,bank_hash);
    std::vector<challenge_evaluation::Level> levels;
    for(const auto& level:bank_levels)
        if(level.family==kFamilyCorner)levels.push_back(level);
    require(levels.size()==30,"scan probe must use the30 family14 TRAIN levels");

    SimConfig config;
    config.n=uint32_t(levels.size());config.family=0;config.mode=22;config.eval=1;
    config.seed=levels.front().seed;config.distance=8.0f;config.speed=kSpeedCapMps;
    config.max_steps=kMaxSteps;config.geometry_memory=1;config.risk_coef=kClearanceRisk;
    config.entropy_coef=kTemporalEntropy;config.learning_rate=kLearningRate;
    constexpr uint32_t probe_ticks=40;
    Sim sim(metal,config,probe_ticks);
    auto exploration_state=metal.buffer(levels.size()*sizeof(float));
    std::memset(exploration_state.contents,0,exploration_state.length);
    const auto actor=load_actor_weights(warmstart,sim);
    auto* worlds=static_cast<WWorld*>(sim.worlds.contents);
    auto* runs=static_cast<SimRun*>(sim.runs.contents);
    auto* states=static_cast<RLPhysicsState*>(sim.states.contents);
    for(uint32_t env=0;env<levels.size();env++) {
        const auto& level=levels[env];
        worlds[env]=level.world;
        runs[env].rng=level.base_seed+level.environment_index*challenge_evaluation::kEnvStride+
                      challenge_evaluation::kEnvOffset;
        runs[env].steps=0;
        runs[env].initial_distance=std::sqrt(level.world.goal[0]*level.world.goal[0]+
            level.world.goal[1]*level.world.goal[1]+
            (level.world.goal[2]-1.5f)*(level.world.goal[2]-1.5f));
        runs[env].reference_position[0]=0.0f;
        runs[env].reference_position[1]=0.0f;
        runs[env].reference_position[2]=1.5f;
        require(std::fabs(states[env].position[0])<1.0e-6f&&
                std::fabs(states[env].position[1])<1.0e-6f&&
                std::fabs(states[env].position[2]-1.5f)<1.0e-6f,
                "scan probe must retain the native source spawn");
    }
    std::filesystem::create_directories(output_dir);
    const std::string trace_path=output_dir+"/"+arm+"-first-2s.csv";
    std::ofstream trace(trace_path);
    require(bool(trace),"cannot write scan probe trace");
    trace<<"failure_id,t_s,x_m,y_m,z_m,heading_rad,heading_excursion_rad,cmd_vx_world_mps,cmd_vy_world_mps,cmd_vz_world_mps,cmd_yaw_rate_rps,clearance_m,raw_yaw_sample,actor_yaw_mean,standardized_yaw_noise,ar1_previous_noise,rho,conditional_log_probability,action_mask_yaw,macro_active\n";
    trace<<std::setprecision(9);
    auto previous_noise_rows=temporal_previous_noise_buffer(metal,sim);
    auto scan_state=held_scan_state_buffer(metal,sim);
    auto action_masks=held_scan_action_mask_buffer(metal,sim);
    if(arm=="yaw-ar1") {
        auto rho=temporal_rho_buffer(metal,kYawCorrelation);
        auto commands=[metal.queue commandBuffer];
        collect_temporal_rollout(sim,metal,commands,exploration_state,
                                 previous_noise_rows,rho);
        metal.finish(commands);
    } else if(arm=="held-scan") {
        auto commands=[metal.queue commandBuffer];
        collect_held_scan_rollout(sim,metal,commands,scan_state,action_masks);
        metal.finish(commands);
    } else {
        auto commands=[metal.queue commandBuffer];
        sim.collect(commands,probe_ticks);metal.finish(commands);
    }

    std::ofstream summary(output_dir+"/"+arm+"-scan-summary.csv");
    require(bool(summary),"cannot write scan probe summary");
    summary<<"failure_id,steps,collision,timeout,final_yaw_excursion_rad,max_yaw_excursion_rad,max_forward_x_m,minimum_clearance_m,scan_before_wall\n";
    summary<<std::setprecision(9);
    const auto* critic_rows=static_cast<const float*>(sim.co.contents);
    const auto* observations=static_cast<const float*>(sim.obs.contents);
    const auto* sampled_actions=static_cast<const float*>(sim.actions.contents);
    const auto* log_probabilities=static_cast<const float*>(sim.logp.contents);
    const auto* temporal_rows=static_cast<const float*>(previous_noise_rows.contents);
    fixed_ppo::ActorParams actor_parameters{};
    std::copy(actor.begin(),actor.end(),actor_parameters.values.begin());
    const float yaw_sigma=std::exp(actor_parameters.values[fixed_ppo::actor_log_std_offset+3]);
    const float nav_dt=static_cast<const RLPhysicsParams*>(sim.physics.contents)->dt*config.substeps;
    constexpr uint32_t context=160;
    uint32_t scan_count=0;
    for(uint32_t env=0;env<levels.size();env++) {
        float previous_yaw=0.0f,unwrapped_yaw=0.0f;
        float maximum_yaw=0.0f,maximum_forward=0.0f,minimum_clearance=12.0f;
        bool got_scan=false;
        const uint32_t valid_steps=std::min(runs[env].steps,probe_ticks);
        for(uint32_t tick=0;tick<valid_steps;tick++) {
            const size_t row=size_t(tick)*config.n+env;
            const float* state=critic_rows+row*32;
            const float* observation=observations+row*fixed_ppo::actor_obs_dim;
            const float yaw=std::atan2(2.0f*(state[9]*state[12]+state[10]*state[11]),
                1.0f-2.0f*(state[11]*state[11]+state[12]*state[12]));
            if(tick==0)previous_yaw=yaw;
            else {
                unwrapped_yaw+=wrap_angle_difference(yaw-previous_yaw);
                previous_yaw=yaw;
            }
            const float x=state[13]*10.0f,y=state[14]*10.0f,z=state[15]*10.0f;
            maximum_yaw=std::max(maximum_yaw,std::fabs(unwrapped_yaw));
            maximum_forward=std::max(maximum_forward,x);
            minimum_clearance=std::min(minimum_clearance,state[19]*5.0f);
            float applied[4];
            for(uint32_t axis=0;axis<4;axis++)
                applied[axis]=tick+1<valid_steps
                    ? observations[size_t(tick+1)*fixed_ppo::actor_obs_dim+context+13+axis]
                    : runs[env].previous_nav[axis];
            float hidden[fixed_ppo::hidden_dim],mean[fixed_ppo::action_dim];
            fixed_ppo::actor_forward(observation,actor_parameters,hidden,mean);
            const float latent_yaw=sampled_actions[row*4+3];
            const float residual=(latent_yaw-mean[3])/yaw_sigma;
            const float z_before=arm=="yaw-ar1"
                ? temporal_rows[row*kPreviousNoiseStride] : 0.0f;
            const float rho=arm=="yaw-ar1"
                ? temporal_rows[row*kPreviousNoiseStride+1] : 0.0f;
            const float yaw_action_mask=arm=="held-scan"
                ? static_cast<const float*>(action_masks.contents)[row*4+3] : 1.0f;
            const float macro_active=arm=="held-scan"&&levels[env].family==14&&tick<40?1.0f:0.0f;
            if(std::fabs(unwrapped_yaw)>=0.6f&&x<=1.2f)got_scan=true;
            trace<<levels[env].failure_id<<','<<tick*nav_dt<<','<<x<<','<<y<<','<<z<<','
                 <<yaw<<','<<unwrapped_yaw<<','<<applied[0]*config.speed<<','
                 <<applied[1]*config.speed<<','<<applied[2]*config.speed<<','
                 <<applied[3]*0.5f<<','<<state[19]*5.0f<<','<<latent_yaw<<','<<mean[3]
                 <<','<<residual<<','<<z_before<<','<<rho<<','<<log_probabilities[row]
                 <<','<<yaw_action_mask<<','<<macro_active<<'\n';
        }
        if(got_scan)scan_count++;
        summary<<levels[env].failure_id<<','<<valid_steps<<','<<runs[env].collisions<<','
               <<runs[env].timeouts<<','<<unwrapped_yaw<<','<<maximum_yaw<<','
               <<maximum_forward<<','<<minimum_clearance<<','<<(got_scan?1:0)<<'\n';
    }
    trace.flush();summary.flush();
    require(bool(trace)&&bool(summary),"scan probe output flush failed");
    std::cout<<"scan_probe arm="<<arm<<" scenes="<<levels.size()<<" horizon_s=2.0"
             <<" precontact_scan="<<scan_count<<"/30"<<" rho="
             <<(arm=="yaw-ar1"?kYawCorrelation:0.0f)
             <<" bank_sha256="<<bank_hash<<"\n";
}
}

#ifndef TEMPORAL_EXPLORATION_EMBEDDED
int main(int argc,char** argv) {
    @autoreleasepool {
        try {
            if(argc==3&&std::string(argv[1])=="--check-logprob") {
                temporal_exploration::verify_temporal_canaries(argv[2],
                    temporal_exploration::kYawCorrelation);
                return 0;
            }
            if(argc==6&&std::string(argv[1])=="--probe") {
                temporal_exploration::probe_initial_scan(argv[2],argv[3],argv[4],argv[5]);
                return 0;
            }
            if(argc==7&&std::string(argv[1])=="--train") {
                std::filesystem::create_directories(argv[4]);
                temporal_exploration::train_arm(argv[2],argv[3],argv[4],argv[5],
                    uint32_t(std::stoul(argv[6])));
                return 0;
            }
            require(argc==8&&std::string(argv[1])=="--resume",
                "navigation_exploration --check-logprob WARMSTART | --probe BANK WARMSTART OUTPUT_DIR iid|yaw-ar1|held-scan | --train BANK WARMSTART OUTPUT_DIR iid|held-scan ROLLOUTS | --resume BANK WARMSTART CHECKPOINT OUTPUT_DIR iid|held-scan ROLLOUTS");
            std::filesystem::create_directories(argv[5]);
            temporal_exploration::train_arm(argv[2],argv[3],argv[5],argv[6],
                uint32_t(std::stoul(argv[7])),argv[4]);
            return 0;
        } catch(const std::exception& error) {
            std::cerr<<error.what()<<'\n';
            return 1;
        }
    }
}
#endif
