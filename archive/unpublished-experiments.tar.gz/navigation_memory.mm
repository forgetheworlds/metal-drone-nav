// Sensor-only persistent geometry and frontier guidance experiment.
// The map uses only RangeFinder-equivalent depth and the pose saved with each
// sensor frame. World geometry is used only by sim_advance's independent score.
#define main embedded_navigation_main
#include "main.mm"
#undef main

#include <algorithm>
#include <array>
#include <cmath>
#include <queue>

namespace sensor_memory {

constexpr float kCell = 0.25f;
// Broad computational region centered around the source simulator's start.
// These bounds are deliberately larger than the task bank; they are not room
// walls. Leaving the represented region is treated as unknown and blocked.
constexpr float kMin[3] = {-8.0f, -16.0f, -4.0f};
constexpr int kSize[3] = {128, 128, 64};
constexpr int kCellCount = kSize[0] * kSize[1] * kSize[2];
constexpr float kSensorMaxRange = 12.0f;
// A measured surface may be replaced by free evidence only after it has gone
// unobserved for this long, i.e. only once re-measurement has stopped
// contradicting it. This is a re-confirmation window for ray disagreement, not a
// forgetting rule: blocking in body_clear never depends on it, so a wall the
// vehicle has stopped looking at keeps blocking.
constexpr float kHitReconfirmS = 1.0f;
// The physical collision contract is an 0.18 m sphere. This source run uses
// ground-truth pose and configures no depth noise, so no extra margin is
// invented: the exact body sphere is tested against the actual voxel boxes.
constexpr float kBodyRadius = 0.18f;

struct Point { float x, y, z; };
static float heading_error(float target,float current) {
    return std::atan2(std::sin(target-current),std::cos(target-current));
}
struct SearchNode { float cost; int cell; };
struct SearchLater { bool operator()(SearchNode a, SearchNode b) const { return a.cost > b.cost; } };

struct SensorMap {
    std::array<uint8_t,kCellCount> state{}; // 0 unknown, 1 observed free, 2 observed hit.
    std::array<float,kCellCount> seen_at{};
    std::array<int,kCellCount> parent{};
    std::array<float,kCellCount> cost{};
    std::array<uint8_t,kCellCount> closed{};
    size_t free_cells = 0;
    size_t unique_hit_cells = 0;
    size_t ray_updates = 0;
    size_t hit_updates = 0;

    int index(int x,int y,int z) const { return (z*kSize[1]+y)*kSize[0]+x; }
    bool inside(int x,int y,int z) const {
        return x>=0&&x<kSize[0]&&y>=0&&y<kSize[1]&&z>=0&&z<kSize[2];
    }
    int cell(Point p) const {
        const int x=int(std::floor((p.x-kMin[0])/kCell));
        const int y=int(std::floor((p.y-kMin[1])/kCell));
        const int z=int(std::floor((p.z-kMin[2])/kCell));
        return inside(x,y,z)?index(x,y,z):-1;
    }
    Point center(int cell_id) const {
        int x=cell_id%kSize[0],y=(cell_id/kSize[0])%kSize[1],z=cell_id/(kSize[0]*kSize[1]);
        return {kMin[0]+(x+.5f)*kCell,kMin[1]+(y+.5f)*kCell,kMin[2]+(z+.5f)*kCell};
    }
    // Evidence rule, no time-based forgetting of a belief:
    //   measured surface  -> blocks until a free ray is recorded after it *and*
    //                          the surface has gone unobserved for
    //                          kHitReconfirmS (ray disagreement protection)
    //   measured free     -> cleared only by a surface recorded after it
    // Within one capture a hit wins, so grazing rays that disagree about a
    // voxel the surface touches stay order-independent. A static wall is
    // remembered after it leaves the field of view, and a moved obstacle's
    // vacated voxels are cleared because rays then traverse them.
    void mark_free(int id,float now) {
        uint8_t& old=state[size_t(id)];
        if(old==2) {
            if(now-seen_at[size_t(id)]<=kHitReconfirmS)return;
            unique_hit_cells--;free_cells++;old=1;seen_at[size_t(id)]=now;return;
        }
        if(old!=1){free_cells++;old=1;}
        seen_at[size_t(id)]=now;
    }
    void mark_hit(int id,float now) {
        uint8_t& old=state[size_t(id)];
        if(old==1)free_cells--;
        if(old!=2)unique_hit_cells++;
        old=2;seen_at[size_t(id)]=now;hit_updates++;
    }
    // Proprioception: the vehicle is physically at this position and the
    // episode continues, so the voxels its body sphere currently overlaps are
    // known free. This is the only source of free evidence that is not a depth
    // ray, and it is what makes the strict body test usable at a frontier edge.
    void mark_body_footprint(Point position,float now) {
        const int radius=int(std::ceil((kBodyRadius+kCell)/kCell));
        const int cx=int(std::floor((position.x-kMin[0])/kCell));
        const int cy=int(std::floor((position.y-kMin[1])/kCell));
        const int cz=int(std::floor((position.z-kMin[2])/kCell));
        for(int dz=-radius;dz<=radius;dz++)for(int dy=-radius;dy<=radius;dy++)for(int dx=-radius;dx<=radius;dx++) {
            const int nx=cx+dx,ny=cy+dy,nz=cz+dz;
            if(!inside(nx,ny,nz))continue;
            const Point low{kMin[0]+nx*kCell,kMin[1]+ny*kCell,kMin[2]+nz*kCell};
            const Point high{low.x+kCell,low.y+kCell,low.z+kCell};
            if(sphere_box_distance(position,low,high)<=kBodyRadius)mark_free(index(nx,ny,nz),now);
        }
    }
    bool fresh_free(int id,[[maybe_unused]] float now) const {
        return id>=0&&state[size_t(id)]==1;
    }
    static float sphere_box_distance(Point center,Point low,Point high) {
        const float dx=std::max(std::max(low.x-center.x,center.x-high.x),0.0f);
        const float dy=std::max(std::max(low.y-center.y,center.y-high.y),0.0f);
        const float dz=std::max(std::max(low.z-center.z,center.z-high.z),0.0f);
        return std::sqrt(dx*dx+dy*dy+dz*dz);
    }
    // Body test: a traversable cell must be fresh known-free, and the 0.18 m
    // collision sphere at its centre must not overlap any fresh occupied voxel.
    // Unknown voxels are not counted as obstacles here; they are handled by the
    // frontier rule (a traversable cell adjacent to unknown is an exploration
    // target) and by segment_body_clear, which stops executed motion at the
    // observed boundary.
    bool body_clear(int x,int y,int z,float now) const {
        if(!inside(x,y,z))return false;
        const int id=index(x,y,z);
        if(!fresh_free(id,now))return false;
        const Point c=center(id);
        const int radius=int(std::ceil(kBodyRadius/kCell));
        for(int dz=-radius;dz<=radius;dz++)for(int dy=-radius;dy<=radius;dy++)for(int dx=-radius;dx<=radius;dx++) {
            const int nx=x+dx,ny=y+dy,nz=z+dz;
            if(!inside(nx,ny,nz))return false;
            const int near=index(nx,ny,nz);
            // A measured surface blocks while it is current evidence. Expiry
            // keeps quantisation false positives (a hit voxel whose surface is
            // closer to the body than the voxel face) from freezing motion;
            // mark_free clears a hit once a real free ray passes through.
            if(state[size_t(near)]!=2)continue;
            const Point low{kMin[0]+nx*kCell,kMin[1]+ny*kCell,kMin[2]+nz*kCell};
            const Point high{low.x+kCell,low.y+kCell,low.z+kCell};
            if(sphere_box_distance(c,low,high)<=kBodyRadius)return false;
        }
        return true;
    }
    bool blocked(int x,int y,int z,float now) const { return !body_clear(x,y,z,now); }
    // A traversable cell next to never-observed space is a frontier: reaching it
    // and looking out is what extends the known-free map.
    bool frontier_cell(int x,int y,int z,float now) const {
        if(!body_clear(x,y,z,now))return false;
        for(int dz=-1;dz<=1;dz++)for(int dy=-1;dy<=1;dy++)for(int dx=-1;dx<=1;dx++) {
            if(dx==0&&dy==0&&dz==0)continue;
            const int nx=x+dx,ny=y+dy,nz=z+dz;
            if(!inside(nx,ny,nz))continue;
            if(state[size_t(index(nx,ny,nz))]==0)return true;
        }
        return false;
    }
    struct WallProbe { float extent=0.0f; bool opening=false; };
    // Walk alongside a bearing, restricted to the side the goal lies on (that
    // is where the blocking obstacle is). extent is how far the obstacle runs
    // beside the walk before it stops; opening is true when observed free space
    // lies beyond that stop, i.e. the obstacle ends in a passage rather than
    // running into the room boundary. Both read the persistent belief, so a
    // side revealed a moment earlier is still readable from the other heading.
    WallProbe wall_probe(Point origin,float bearing,float goal_bearing,[[maybe_unused]] float now) const {
        WallProbe probe;
        const float cx=std::cos(bearing),sy=std::sin(bearing);
        const float sign=heading_error(goal_bearing,bearing)<0.0f?-1.0f:1.0f;
        bool broken=false;
        for(float r=0.25f;r<=8.0f&&!broken;r+=0.25f) {
            bool occupied=false,free_space=false;
            for(float u=0.25f;u<=3.0f;u+=0.25f) {
                const float lateral=u*sign;
                const Point p{origin.x+r*cx-lateral*sy,origin.y+r*sy+lateral*cx,origin.z};
                const int id=cell(p);if(id<0)continue;
                if(state[size_t(id)]==2)occupied=true;
                if(state[size_t(id)]==1)free_space=true;
            }
            if(occupied)probe.extent=r;
            else {broken=true;if(free_space)probe.opening=true;}
        }
        return probe;
    }
    int blocked_reason(int x,int y,int z,[[maybe_unused]] float now,int& cause_cell) const {
        cause_cell=-1;
        if(!inside(x,y,z))return 1; // outside the generic computational grid
        const int id=index(x,y,z);
        if(state[size_t(id)]==2){cause_cell=id;return 2;} // measured surface here
        if(state[size_t(id)]!=1)return 3;                // never observed
        // Matches body_clear exactly: the cell centre must be observed free and
        // only a *measured* surface inside the body sphere blocks. An unobserved
        // neighbour does not block, so overlap with unobserved space is a stated
        // residual risk, not a cleared guarantee.
        const Point c=center(id);
        const int radius=int(std::ceil(kBodyRadius/kCell));
        for(int dz=-radius;dz<=radius;dz++)for(int dy=-radius;dy<=radius;dy++)for(int dx=-radius;dx<=radius;dx++) {
            const int nx=x+dx,ny=y+dy,nz=z+dz;
            if(!inside(nx,ny,nz))return 6; // body sphere leaves the computational grid
            const int near=index(nx,ny,nz);
            if(state[size_t(near)]!=2)continue;
            const Point low{kMin[0]+nx*kCell,kMin[1]+ny*kCell,kMin[2]+nz*kCell};
            const Point high{low.x+kCell,low.y+kCell,low.z+kCell};
            if(sphere_box_distance(c,low,high)<=kBodyRadius){cause_cell=near;return 7;}
        }
        return 0;
    }
    // Physical clearance left between the body surface and the nearest voxel
    // that is not fresh known-free.
    float nearest_obstacle_clearance(Point position,float now) const {
        float best=INFINITY;
        const int radius=int(std::ceil((kBodyRadius+kCell)/kCell));
        const int cx=int(std::floor((position.x-kMin[0])/kCell));
        const int cy=int(std::floor((position.y-kMin[1])/kCell));
        const int cz=int(std::floor((position.z-kMin[2])/kCell));
        for(int dz=-radius;dz<=radius;dz++)for(int dy=-radius;dy<=radius;dy++)for(int dx=-radius;dx<=radius;dx++) {
            const int nx=cx+dx,ny=cy+dy,nz=cz+dz;
            if(!inside(nx,ny,nz))continue;
            const int id=index(nx,ny,nz);
            if(fresh_free(id,now))continue;
            const Point low{kMin[0]+nx*kCell,kMin[1]+ny*kCell,kMin[2]+nz*kCell};
            const Point high{low.x+kCell,low.y+kCell,low.z+kCell};
            best=std::min(best,sphere_box_distance(position,low,high)-kBodyRadius);
        }
        return std::isfinite(best)?best:3.0f;
    }
    // Swept body-centre test for a commanded straight segment: every sampled
    // point must sit in a known-free cell with full physical clearance from
    // known obstacles. The map is a conservative obstacle map, so unknown space
    // is not treated as an obstacle; the residual risk of an unobserved surface
    // inside the corridor is stated in the run report.
    bool segment_body_clear(Point from,Point to,float now) const {
        const float dx=to.x-from.x,dy=to.y-from.y,dz=to.z-from.z;
        const float length=std::sqrt(dx*dx+dy*dy+dz*dz);
        const int samples=std::max(1,int(std::ceil(length/(kCell*0.125f))));
        const int own=cell(from);
        for(int sample=0;sample<=samples;sample++) {
            const float fraction=float(sample)/samples;
            const Point point{from.x+fraction*dx,from.y+fraction*dy,from.z+fraction*dz};
            const int id=cell(point);
            if(id<0)return false;
            // Only the cell the body physically occupies right now is trusted.
            // A fixed distance window let the vehicle creep a third of a metre
            // into a cell the map already calls unsafe before the test fired.
            if(id==own)continue;
            if(!body_clear(id%kSize[0],(id/kSize[0])%kSize[1],id/(kSize[0]*kSize[1]),now))return false;
        }
        return true;
    }
    // Amanatides & Woo voxel traversal: mark every voxel the measured ray
    // crosses as free and the voxel holding the measured range as occupied.
    // Exact cell crossings replace fixed-step sampling, so no crossed voxel is
    // skipped, and the hit voxel is the true measured endpoint rather than a
    // half-cell-shortened estimate.
    void integrate_ray(Point origin,Point direction,float range,float now) {
        int coordinate[3],step[3];
        float t_max[3],t_delta[3];
        const float p[3]={origin.x,origin.y,origin.z};
        const float d[3]={direction.x,direction.y,direction.z};
        for(int axis=0;axis<3;axis++) {
            coordinate[axis]=int(std::floor((p[axis]-kMin[axis])/kCell));
            if(d[axis]>1e-8f){step[axis]=1;t_max[axis]=((coordinate[axis]+1)*kCell+kMin[axis]-p[axis])/d[axis];}
            else if(d[axis]<-1e-8f){step[axis]=-1;t_max[axis]=(coordinate[axis]*kCell+kMin[axis]-p[axis])/d[axis];}
            else {step[axis]=0;t_max[axis]=INFINITY;}
            t_delta[axis]=step[axis]==0?INFINITY:std::fabs(kCell/d[axis]);
        }
        for(int guard=0;guard<1024;guard++) {
            float next_t=t_max[0];
            for(int axis=1;axis<3;axis++)next_t=std::min(next_t,t_max[axis]);
            if(next_t>range) {
                if(inside(coordinate[0],coordinate[1],coordinate[2])) {
                    const int id=index(coordinate[0],coordinate[1],coordinate[2]);
                    if(range<kSensorMaxRange-0.1f)mark_hit(id,now);else mark_free(id,now);
                }
                return;
            }
            if(inside(coordinate[0],coordinate[1],coordinate[2]))
                mark_free(index(coordinate[0],coordinate[1],coordinate[2]),now);
            // Advance every axis whose crossing coincides, so voxels the ray
            // only touches along an edge or a corner are never certified free.
            const float epsilon=1e-4f*std::max(1.0f,next_t);
            for(int axis=0;axis<3;axis++)if(t_max[axis]<=next_t+epsilon) {
                coordinate[axis]+=step[axis];t_max[axis]+=t_delta[axis];
            }
        }
    }
    void integrate(const float* ranges,const float* pose,float now) {
        // Integrate every one of the 320 real measured rays through the shared
        // wcamera model, so mapping and information gain agree on the camera.
        const Point origin{pose[0],pose[1],pose[2]};
        for(int pixel=0;pixel<320;pixel++) {
            const WVec local=wcamera(uint(pixel));
            const Point direction{pose[3]*local.x+pose[4]*local.y+pose[5]*local.z,
                                  pose[6]*local.x+pose[7]*local.y+pose[8]*local.z,
                                  pose[9]*local.x+pose[10]*local.y+pose[11]*local.z};
            integrate_ray(origin,direction,std::clamp(ranges[pixel],0.0f,kSensorMaxRange),now);
            ray_updates++;
        }
    }

    bool plan(Point position,Point global_goal,float now,Point& local_goal,
              int preferred_frontier,int preferred_side,int& selected_frontier,int& selected_gain,float& selected_yaw,
              size_t& expanded,size_t& frontier_count,std::vector<Point>* route_out=nullptr) {
        if(route_out)route_out->clear();
        selected_frontier=-1;selected_gain=0;selected_yaw=0.0f;
        const int goal=cell(global_goal);
        int start=cell(position);
        if(start<0)return false;
        if(!fresh_free(start,now)||!body_clear(start%kSize[0],(start/kSize[0])%kSize[1],start/(kSize[0]*kSize[1]),now)) {
            // Proprioception: the body is physically at this position and the
            // episode has not recorded contact, so the true clearance already
            // exceeds the 0.18 m contract. A blocked verdict on our own cell can
            // only come from a voxel that contains a measured surface, i.e. a
            // quantisation over-approximation, never from a real obstacle.
            // Replanning from a retreating cell here is what sent the vehicle
            // backwards out of a physically passable lane. Only move the start
            // when our own cell has no fresh free evidence at all.
            const bool own_cell_observed=fresh_free(start,now);
            if(!own_cell_observed) {
                int replacement=-1;float best_distance=INFINITY;
                const int cx=start%kSize[0],cy=(start/kSize[0])%kSize[1],cz=start/(kSize[0]*kSize[1]);
                for(int dz=-3;dz<=3;dz++)for(int dy=-3;dy<=3;dy++)for(int dx=-3;dx<=3;dx++) {
                    const int nx=cx+dx,ny=cy+dy,nz=cz+dz;
                    if(!body_clear(nx,ny,nz,now))continue;
                    const float d=float(dx*dx+dy*dy+dz*dz);
                    if(d<best_distance){best_distance=d;replacement=index(nx,ny,nz);}
                }
                if(replacement<0)return false;
                start=replacement;
            }
        }
        std::fill(cost.begin(),cost.end(),INFINITY);
        std::fill(parent.begin(),parent.end(),-1);
        std::fill(closed.begin(),closed.end(),0);
        std::priority_queue<SearchNode,std::vector<SearchNode>,SearchLater> open;
        const auto heuristic=[&](int id) {
            const Point p=center(id);
            const float dx=p.x-global_goal.x,dy=p.y-global_goal.y,dz=p.z-global_goal.z;
            return std::sqrt(dx*dx+dy*dy+dz*dz);
        };
        cost[size_t(start)]=0;open.push({heuristic(start),start});expanded=0;frontier_count=0;
        int chosen=-1,deepest=start;float deepest_cost=0.0f;
        std::vector<int> frontier_candidates;
        constexpr float kMinFrontierTravelM=0.50f;
        while(!open.empty()) {
            const auto current=open.top();open.pop();const int id=current.cell;
            if(closed[size_t(id)])continue;
            closed[size_t(id)]=1;expanded++;
            if(cost[size_t(id)]>deepest_cost){deepest_cost=cost[size_t(id)];deepest=id;}
            if(id==goal&&fresh_free(goal,now)){chosen=goal;break;}
            const int x=id%kSize[0],y=(id/kSize[0])%kSize[1],z=id/(kSize[0]*kSize[1]);
            if(frontier_cell(x,y,z,now)) {
                frontier_count++;
                if(cost[size_t(id)]>=kMinFrontierTravelM)frontier_candidates.push_back(id);
            }
            for(int dz=-1;dz<=1;dz++)for(int dy=-1;dy<=1;dy++)for(int dx=-1;dx<=1;dx++) {
                if(dx==0&&dy==0&&dz==0)continue;
                const int nx=x+dx,ny=y+dy,nz=z+dz;
                if(!body_clear(nx,ny,nz,now))continue;
                bool corner=false;
                if(dx&&!body_clear(x+dx,y,z,now))corner=true;
                if(dy&&!body_clear(x,y+dy,z,now))corner=true;
                if(dz&&!body_clear(x,y,z+dz,now))corner=true;
                if(corner)continue;
                const int next=index(nx,ny,nz);if(closed[size_t(next)])continue;
                const float candidate=cost[size_t(id)]+kCell*std::sqrt(float(dx*dx+dy*dy+dz*dz));
                if(candidate<cost[size_t(next)]){cost[size_t(next)]=candidate;parent[size_t(next)]=id;open.push({candidate+heuristic(next),next});}
            }
        }
        // If the goal is not reachable, head for the reachable frontier closest
        // to the goal in a straight line, keeping the vehicle altitude and the
        // previous exploration bearing so the route cannot flip to the opposite
        // side of an obstacle every re-plan.
        if(chosen<0) {
            float best_score=INFINITY;
            const bool have_previous=preferred_frontier>=0;
            float previous_bearing=0.0f;
            if(have_previous) {
                const Point p=center(preferred_frontier);
                previous_bearing=std::atan2(p.y-position.y,p.x-position.x);
            }
            // First pass: only the side the look committed to. The side is a
            // hard constraint, not a weight: a weight let the depth term pick
            // a frontier eight metres away on the forbidden side.
            for(int pass=0;pass<2&&chosen<0;pass++) {
                for(int id:frontier_candidates) {
                    const Point p=center(id);
                    const float dx=p.x-global_goal.x,dy=p.y-global_goal.y,dz=p.z-global_goal.z;
                    const float bearing=std::atan2(p.y-position.y,p.x-position.x);
                    const float goal_bearing=std::atan2(global_goal.y-position.y,global_goal.x-position.x);
                    const float lateral=heading_error(bearing,goal_bearing);
                    if(preferred_side!=0&&(pass==0)?
                       ((preferred_side>0&&lateral<0.0f)||(preferred_side<0&&lateral>0.0f)):false)continue;
                    // No term penalises a change of altitude from the current
                    // pose: that keeps the vehicle at whatever height it
                    // already has instead of approaching the goal's height.
                    // h() already carries the goal-relative altitude error.
                    float score=std::sqrt(dx*dx+dy*dy+dz*dz)+0.35f*cost[size_t(id)];
                    if(preferred_side!=0) {
                        // While a side is committed the decision that is still
                        // live is "travel along the blocking obstacle", not
                        // "approach the goal" - the goal is behind the
                        // obstacle, so goal distance falls fastest by stopping
                        // against it. Reward progress in the committed
                        // direction instead of proximity, which is what turned
                        // a 3 m approach into repeated 0.3 m frontier hops.
                        const float side_bearing=goal_bearing+(preferred_side>0?1.5707963f:-1.5707963f);
                        const float projection=(p.x-position.x)*std::cos(side_bearing)
                                              +(p.y-position.y)*std::sin(side_bearing);
                        score-=projection;
                    }
                    if(have_previous)score+=0.5f*std::fabs(heading_error(bearing,previous_bearing));
                    if(score<best_score){best_score=score;chosen=id;}
                }
            }
        }
        if(chosen<0)chosen=deepest;
        if(chosen<0)return false;
        selected_frontier=chosen;
        std::vector<int> path;
        for(int id=chosen;id>=0;id=parent[size_t(id)]){path.push_back(id);if(id==start)break;}
        if(path.empty()||path.back()!=start)return false;
        std::reverse(path.begin(),path.end());
        if(route_out) {
            route_out->reserve(path.size());
            for(int id:path)route_out->push_back(center(id));
        }
        // Supply a short sensor-derived waypoint; the benchmark goal is kept
        // untouched in WWorld and remains the only success/scoring target.
        const float waypoint_distance=2.0f;
        int waypoint=path.back();
        for(int id:path) {
            const Point p=center(id);
            const float dx=p.x-position.x,dy=p.y-position.y,dz=p.z-position.z;
            if(std::sqrt(dx*dx+dy*dy+dz*dz)>=waypoint_distance){waypoint=id;break;}
        }
        local_goal=center(waypoint);
        return true;
    }
};

struct RouteTarget {
    Point point{};
    Point heading{};
    size_t path_index=0;
    float path_distance=0.0f;
    float map_clearance=0.0f;
    bool line_clear=false;
};

static RouteTarget choose_safe_route_target(const SensorMap& map,const std::vector<Point>& route,
                                            Point position,float now,float lookahead) {
    RouteTarget target;target.point=position;target.heading=position;
    if(route.empty())return target;
    size_t nearest=0;float nearest_distance=INFINITY;
    for(size_t i=0;i<route.size();i++) {
        const float dx=route[i].x-position.x,dy=route[i].y-position.y,dz=route[i].z-position.z;
        const float distance=dx*dx+dy*dy+dz*dz;
        if(distance<nearest_distance){nearest_distance=distance;nearest=i;}
    }
    // The A* route may plan through unknown space (optimistically). Translation
    // is allowed only while the straight commanded segment passes the swept
    // capsule test, so the follower never enters unobserved space.
    target.line_clear=map.segment_body_clear(position,route[nearest],now);
    size_t target_index=nearest;
    const float kLookaheadM=lookahead;
    float arc_distance=0.0f;
    for(size_t i=nearest+1;i<route.size();i++) {
        const float dx=route[i].x-route[i-1].x,dy=route[i].y-route[i-1].y,dz=route[i].z-route[i-1].z;
        const float segment=std::sqrt(dx*dx+dy*dy+dz*dz);
        if(arc_distance>0.0f&&arc_distance+segment>kLookaheadM)break;
        if(!map.segment_body_clear(position,route[i],now))break;
        arc_distance+=segment;target_index=i;
    }
    target.point=route[target_index];target.path_index=target_index;
    target.map_clearance=map.nearest_obstacle_clearance(route[target_index],now);
    // Heading always points a little further along the route than translation,
    // so the vehicle turns to observe the planned direction before it moves.
    const size_t heading_index=std::min(route.size()-1,target_index+3);
    target.heading=route[heading_index];
    const float dx=target.point.x-position.x,dy=target.point.y-position.y,dz=target.point.z-position.z;
    target.path_distance=std::sqrt(dx*dx+dy*dy+dz*dz);
    return target;
}

static const char* blocked_reason_name(int code) {
    switch(code) {
        case 0:return "free";case 1:return "outside_grid";case 2:return "fresh_hit";
        case 3:return "unknown";case 4:return "stale_free";case 5:return "stale_hit_unknown";
        case 6:return "inflated_grid_edge";case 7:return "inflated_fresh_hit";
        default:return "invalid";
    }
}

static void write_frontier_cause_receipt(std::ofstream& out,const SensorMap& map,
                                         const std::string& failure_id,const std::string& bank_path,
                                         const std::string& checkpoint_path,const float* ranges,
                                         const float* camera_pose,uint32_t frame,uint32_t steps,float now,
                                         Point position,float reference_yaw,float vehicle_yaw,
                                         size_t expanded,size_t frontiers,bool plan_found) {
    const int center_id=map.cell(position);
    require(center_id>=0,"frontier diagnostic pose is outside map grid");
    const int cx=center_id%kSize[0],cy=(center_id/kSize[0])%kSize[1],cz=center_id/(kSize[0]*kSize[1]);
    auto write_vec3=[&](Point p){out<<'['<<p.x<<','<<p.y<<','<<p.z<<']';};
    auto write_cell=[&](int x,int y,int z) {
        if(!map.inside(x,y,z)){out<<"{\"inside\":false}";return;}
        const int id=map.index(x,y,z);const uint8_t state=map.state[size_t(id)];
        const float age=now-map.seen_at[size_t(id)];
        int cause=-1;const int reason=map.blocked_reason(x,y,z,now,cause);
        out<<"{\"xyz\":["<<x<<','<<y<<','<<z<<"],\"state\":\""<<(state==0?"UNKNOWN":(state==1?"FREE":"HIT"))
           <<"\",\"age_s\":"<<age<<",\"blocked\":"<<(reason!=0)<<",\"blocked_api\":"<<map.blocked(x,y,z,now)
           <<",\"reason\":\""<<blocked_reason_name(reason)<<"\",\"cause_cell\":"<<cause
           <<",\"astar_closed\":"<<int(map.closed[size_t(id)])<<",\"astar_g_cost\":";
        if(std::isfinite(map.cost[size_t(id)]))out<<map.cost[size_t(id)];else out<<"null";
        out<<",\"astar_parent\":"<<map.parent[size_t(id)]<<'}';
    };
    out<<"{\n\"failure_id\":\""<<failure_id<<"\",\"bank_sha256\":\""<<challenge_evaluation::sha256_file(bank_path)
       <<"\",\"checkpoint_sha256\":\""<<challenge_evaluation::sha256_file(checkpoint_path)
       <<"\",\"world_source_sha256\":\""<<challenge_evaluation::sha256_file(std::string(SOURCE_DIR)+"/world.hpp")
       <<"\",\"map_source_sha256\":\""<<challenge_evaluation::sha256_file(__FILE__)
       <<"\",\"step\":"<<steps<<",\"time_s\":"<<now<<",\"sensor_frame\":"<<frame
       <<",\"astar_plan_found\":"<<plan_found<<",\"astar_expanded_cells\":"<<expanded<<",\"reachable_frontiers\":"<<frontiers
       <<",\"position_m\":";write_vec3(position);
    out<<",\"map_cell_xyz\":["<<cx<<','<<cy<<','<<cz<<"],\"cell_fraction_xyz\":["
       <<((position.x-kMin[0])/kCell-cx)<<','<<((position.y-kMin[1])/kCell-cy)<<','<<((position.z-kMin[2])/kCell-cz)
       <<"],\"reference_yaw_rad\":"<<reference_yaw<<",\"vehicle_yaw_rad\":"<<vehicle_yaw
       <<",\"camera_pose_xyz_rotation\":[";
    for(int i=0;i<12;i++){if(i)out<<',';out<<camera_pose[i];}
    out<<"],\"depth_ranges_m\":[";
    for(int i=0;i<320;i++){if(i)out<<',';out<<ranges[i];}
    out<<"],\"center_and_26_neighbors\":[";bool first=true;
    for(int dz=-1;dz<=1;dz++)for(int dy=-1;dy<=1;dy++)for(int dx=-1;dx<=1;dx++) {
        if(!first)out<<',';first=false;write_cell(cx+dx,cy+dy,cz+dz);
    }
    out<<"],\"astar_neighbor_tests\":[";first=true;
    for(int dz=-1;dz<=1;dz++)for(int dy=-1;dy<=1;dy++)for(int dx=-1;dx<=1;dx++) {
        if(dx==0&&dy==0&&dz==0)continue;
        const int nx=cx+dx,ny=cy+dy,nz=cz+dz;int edge_cause=-1;
        const int edge_reason=map.blocked_reason(nx,ny,nz,now,edge_cause);
        const int neighbor_id=map.inside(nx,ny,nz)?map.index(nx,ny,nz):-1;
        bool corner_reject=false;out<<(first?"":",");first=false;
        out<<"{\"offset\":["<<dx<<','<<dy<<','<<dz<<"],\"edge_reason\":\""<<blocked_reason_name(edge_reason)
           <<"\",\"edge_blocked_api\":"<<map.blocked(nx,ny,nz,now)<<",\"edge_cause_cell\":"<<edge_cause
           <<",\"astar_closed\":"<<(neighbor_id>=0?int(map.closed[size_t(neighbor_id)]):0)
           <<",\"astar_g_cost\":";
        if(neighbor_id>=0&&std::isfinite(map.cost[size_t(neighbor_id)]))out<<map.cost[size_t(neighbor_id)];else out<<"null";
        out<<",\"astar_parent\":"<<(neighbor_id>=0?map.parent[size_t(neighbor_id)]:-1)<<",\"axis_prerequisites\":[";
        bool axis_first=true;
        auto axis_check=[&](int ax,int ay,int az) {
            int cause=-1;const int reason=map.blocked_reason(cx+ax,cy+ay,cz+az,now,cause);
            if(!axis_first)out<<',';axis_first=false;
            const bool api_blocked=map.blocked(cx+ax,cy+ay,cz+az,now);
            out<<"{\"offset\":["<<ax<<','<<ay<<','<<az<<"],\"reason\":\""<<blocked_reason_name(reason)<<"\",\"blocked_api\":"<<api_blocked<<",\"cause_cell\":"<<cause<<'}';
            corner_reject|=api_blocked;
        };
        if(dx)axis_check(dx,0,0);if(dy)axis_check(0,dy,0);if(dz)axis_check(0,0,dz);
        out<<"],\"astar_rejects_edge\":"<<(edge_reason!=0)<<",\"astar_rejects_corner\":"<<(edge_reason==0&&corner_reject)<<'}';
    }
    out<<"]}\n";require(bool(out),"frontier diagnostic receipt write failed");
}

struct EpisodeResult {
    std::string id;uint32_t family=0,success=0,collision=0,timeout=0,steps=0;
    float elapsed=0,path=0,peak=0,min_clearance=12,goal_error=0;
    size_t observed_free=0,hit_voxel_updates=0,ray_updates=0,planner_expansions=0,frontiers=0;
    double map_plan_ms=0;bool active_scan_used=false;
    int preferred_side=0,look_ticks_used=0;
    float look_extent_left=0,look_extent_right=0;
    int look_open_left=0,look_open_right=0;
    int plan_count=0,plan_goal_count=0,look_first_step=-1,look_last_step=-1;
};

static void write_trace_header(std::ofstream& out) {
    out<<"failure_id,family,controller,step,time_s,x,y,z,camera_x,camera_y,camera_z,global_goal_x,global_goal_y,global_goal_z,global_goal_error_m,local_goal_x,local_goal_y,local_goal_z,path_target_x,path_target_y,path_target_z,waypoint_distance_m,waypoint_dir_x,waypoint_dir_y,waypoint_dir_z,route_path_index,map_los_clear,map_los_clearance_m,body_command_x,body_command_y,body_command_z,yaw_command_normalized,reference_yaw_before_rad,reference_yaw_after_rad,vehicle_yaw_rad,executed_vx_mps,executed_vy_mps,executed_vz_mps,frontier_commit,frontier_gain,scan_phase,active_scan,success,collision,timeout,expanded,frontiers,free_cells,hit_voxel_updates,scan_min_m,scan_max_m\n";
}

static EpisodeResult run_episode(Metal& metal,const challenge_evaluation::Level& level,
                                 const float* actor,std::ofstream& trace,bool waypoint_velocity_controller,
                                 std::ofstream* frontier_cause_receipt,const std::string& bank_path,
                                 const std::string& checkpoint_path) {
    SimConfig cfg;cfg.n=1;cfg.family=level.family;cfg.mode=17;cfg.eval=1;cfg.speed=1.5f;cfg.distance=level.distance;cfg.max_steps=400;cfg.geometry_memory=1;cfg.sensor_period=1;
    Sim sim(metal,cfg,1);*static_cast<WWorld*>(sim.worlds.contents)=level.world;
    auto& run=*static_cast<SimRun*>(sim.runs.contents);auto& state=*static_cast<RLPhysicsState*>(sim.states.contents);
    std::memcpy(sim.actor.contents,actor,fixed_ppo::actor_param_count*sizeof(float));
    run.initial_distance=std::sqrt(std::pow(level.world.goal[0]-state.position[0],2)+std::pow(level.world.goal[1]-state.position[1],2)+std::pow(level.world.goal[2]-state.position[2],2));
    auto map_storage=std::make_unique<SensorMap>();SensorMap& map=*map_storage;
    EpisodeResult result;result.id=level.failure_id;result.family=level.family;
    Point global_goal{level.world.goal[0],level.world.goal[1],level.world.goal[2]};
    Point local_goal=global_goal;size_t expanded=0,frontiers=0;uint32_t last_plan=UINT32_MAX;
    std::vector<Point> mapped_route;
    int committed_frontier=-1,frontier_gain=0,scan_phase=-1;
    float selected_view_yaw=0.0f;
    bool active_scan_used=false;
    Point progress_anchor{state.position[0],state.position[1],state.position[2]};
    uint32_t last_progress_step=0;
    bool plan_found=true;
    int plan_count=0,plan_goal_count=0;
    int preferred_side=0;
    // One deliberate in-place look: 0 idle, 1 turn to bearing+90, 2 hold,
    // 3 turn to bearing-90, 4 hold, 5 decided. Replanning is never gated on it.
    int look_state=0;
    bool looked=false;
    float look_target_yaw=0.0f;
    uint32_t look_settled=0,look_ticks=0;
    float look_extent_left=0.0f,look_extent_right=0.0f;
    bool look_open_left=false,look_open_right=false;
    int look_first_step=-1,look_last_step=-1;
    const size_t frame_offset=0;
    for(uint32_t step=0;step<400&&!run.episodes;step++) {
        const float actor_reference_yaw=run.yaw;
        cfg.tick=0;std::memcpy(sim.configs[0].contents,&cfg,sizeof(cfg));
        auto cb=[metal.queue commandBuffer];auto c=sim.configs[0];
        metal.dispatch(cb,sim.depth_p,320,{sim.states,sim.runs,sim.worlds,sim.sensors,sim.physics,c,sim.poses});
        metal.finish(cb);

        const float now=run.elapsed;const uint32_t frame=(run.steps/cfg.sensor_period)%8;
        const float* ranges=static_cast<const float*>(sim.sensors.contents)+(frame_offset+frame)*320;
        const float* pose=static_cast<const float*>(sim.poses.contents)+(frame_offset+frame)*12;
        const auto map_start=std::chrono::steady_clock::now();
        map.integrate(ranges,pose,now);
        Point position{state.position[0],state.position[1],state.position[2]};
        map.mark_body_footprint(position,now);
        const float goal_bearing=std::atan2(global_goal.y-position.y,global_goal.x-position.x);
        // Structural fix for the first-obstacle stall: when the straight route
        // to the goal is blocked, look once to each side of the goal bearing so
        // the map records how far the blocking wall extends on both sides, then
        // commit to the side where it ends sooner. This runs alongside normal
        // replanning and never gates it.
        if(!looked&&look_state==0) {
            const Point ahead{position.x+1.0f*std::cos(goal_bearing),position.y+1.0f*std::sin(goal_bearing),position.z};
            if(!map.segment_body_clear(position,ahead,now)){look_state=1;look_target_yaw=goal_bearing+0.6981317f;look_settled=0;look_ticks=0;}
        }
        if(look_state>0) {
            float vehicle_rotation[9];cpu_reference::rotation(state.orientation_wxyz,vehicle_rotation);
            const float vehicle_yaw=std::atan2(vehicle_rotation[3],vehicle_rotation[0]);
            look_ticks++;
            if(look_first_step<0)look_first_step=int(step);
            look_last_step=int(step);
            if(std::fabs(heading_error(look_target_yaw,vehicle_yaw))<0.15f)look_settled++;else look_settled=0;
            if((look_state==1||look_state==3)&&look_settled>=3){look_state=(look_state==1)?2:4;look_settled=0;}
            else if((look_state==2||look_state==4)&&look_settled>=3) {
                // Each side is probed at its own heading. Measured surfaces and
                // measured free space both persist, so the two sides stay
                // readable across the turn between them.
                const float bearing=goal_bearing+(look_state==2?1.5707963f:-1.5707963f);
                // The probe answers "what is this heading showing right now",
                // so it reads the last second of evidence - the turn and hold
                // into this heading. It is a view window for a measurement, not
                // the belief the planner traverses, which stays persistent.
                const SensorMap::WallProbe probe=map.wall_probe(position,bearing,goal_bearing,now-1.0f);
                if(look_state==2){
                    look_extent_left=probe.extent;look_open_left=probe.opening;
                    look_state=3;look_target_yaw=goal_bearing-0.6981317f;look_settled=0;
                }
                else {
                    look_extent_right=probe.extent;look_open_right=probe.opening;
                    // Commit only when exactly one side shows a passage. An
                    // ambiguous reading is not turned into a direction: the
                    // vehicle then explores on the ordinary goal-directed score
                    // with bearing continuity, which cannot lock a wrong side.
                    if(look_open_left!=look_open_right)preferred_side=look_open_left?1:-1;
                    else preferred_side=look_extent_left<=look_extent_right?1:-1;
                    look_state=0;looked=true;last_plan=UINT32_MAX;committed_frontier=-1;
                }
            }
            if(look_state>0&&look_ticks>130){look_state=0;looked=true;last_plan=UINT32_MAX;} // hard bound
        }
        // The side decision exists only to resolve the obstacle that caused the
        // look. Once a straight swept route to the goal exists again the
        // decision has no cause, so it is released rather than allowed to keep
        // excluding frontiers for the rest of the episode.
        if(looked&&preferred_side!=0&&look_state==0) {
            const Point ahead{position.x+1.0f*std::cos(goal_bearing),position.y+1.0f*std::sin(goal_bearing),position.z};
            if(map.segment_body_clear(position,ahead,now)){preferred_side=0;last_plan=UINT32_MAX;}
        }
        // Commit to a route until its local waypoint is reached, the route is
        // blocked, or the vehicle stalls. Re-planning every few ticks let two
        // near-equal frontiers alternate and wasted most of the budget near the
        // first obstacle.
        {
            const float anchor_x=position.x-progress_anchor.x,anchor_y=position.y-progress_anchor.y,anchor_z=position.z-progress_anchor.z;
            if(anchor_x*anchor_x+anchor_y*anchor_y+anchor_z*anchor_z>0.20f*0.20f){progress_anchor=position;last_progress_step=step;}
            const float goal_x=local_goal.x-position.x,goal_y=local_goal.y-position.y,goal_z=local_goal.z-position.z;
            const float local_goal_error=std::sqrt(goal_x*goal_x+goal_y*goal_y+goal_z*goal_z);
            if(last_plan==UINT32_MAX||!plan_found||local_goal_error<0.50f||step-last_progress_step>20) {
                plan_found=map.plan(position,global_goal,now,local_goal,committed_frontier,preferred_side,committed_frontier,frontier_gain,
                                    selected_view_yaw,expanded,frontiers,&mapped_route);
                plan_count++;
                if(plan_found&&committed_frontier==map.cell(global_goal))plan_goal_count++;
                if(plan_found)last_plan=step;
                else { mapped_route.clear();local_goal=position;committed_frontier=-1;frontier_gain=0; }
            }
        }
        if(frontier_cause_receipt) {
            float rotation[9];cpu_reference::rotation(state.orientation_wxyz,rotation);
            const float vehicle_yaw=std::atan2(rotation[3],rotation[0]);
            write_frontier_cause_receipt(*frontier_cause_receipt,map,level.failure_id,bank_path,checkpoint_path,
                ranges,pose,frame,run.steps,now,position,run.yaw,vehicle_yaw,expanded,frontiers,plan_found);
            break;
        }
        RouteTarget route_target;
        {
            // Validate the local goal every tick, not only when re-planning:
            // the learned actor flies a straight-ish line to a waypoint ahead,
            // and an unswept waypoint lets it cut a corner into a wall between
            // re-plans. The waypoint is only handed over while a swept
            // body-centre segment from the current pose proves it clear.
            const float lookahead=waypoint_velocity_controller?0.75f:2.5f;
            route_target=choose_safe_route_target(map,mapped_route,position,now,lookahead);
            if(!waypoint_velocity_controller) {
                if(route_target.line_clear)local_goal=route_target.point;
                else local_goal=position; // no clear straight segment: hold
            }
        }
        const double map_plan_ms=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-map_start).count();
        result.map_plan_ms+=map_plan_ms;result.planner_expansions+=expanded;result.frontiers=frontiers;
        // Use the production observation and actor path for the local waypoint.
        // Candidate clearances depend on the goal, so changing just four host
        // observation slots (and omitting actor forward) is not equivalent.
        auto& policy_world=*static_cast<WWorld*>(sim.worlds.contents);
        policy_world.goal[0]=local_goal.x;policy_world.goal[1]=local_goal.y;policy_world.goal[2]=local_goal.z;
        cfg.tick=0;std::memcpy(sim.configs[0].contents,&cfg,sizeof(cfg));
        cb=[metal.queue commandBuffer];c=sim.configs[0];
        metal.dispatch(cb,sim.memory_points_p,640,{sim.states,sim.runs,sim.sensors,sim.poses,sim.memory_points,sim.physics,c});
        metal.dispatch(cb,sim.memory_candidates_p,85,{sim.states,sim.worlds,sim.memory_points,sim.memory_clearances,c});
        metal.dispatch(cb,sim.observe_p,1,{sim.states,sim.runs,sim.worlds,sim.sensors,sim.obs,sim.co,sim.physics,c,sim.poses,sim.memory_clearances},64);
        metal.dispatch(cb,metal.pipeline("ppo_actor_forward"),1,
            {sim.obs,sim.actor,sim.actor_workspace,sim.actions,sim.env_count},64);
        metal.finish(cb);
        if(step<4&&!waypoint_velocity_controller) {
            float hidden[64],expected[4];
            fixed_ppo::actor_forward(static_cast<const float*>(sim.obs.contents),
                *reinterpret_cast<const fixed_ppo::ActorParams*>(actor),hidden,expected);
            const auto* actual=static_cast<const float*>(sim.actions.contents);
            float error=0;for(int axis=0;axis<4;axis++)error=std::max(error,std::fabs(expected[axis]-actual[axis]));
            require(error<2e-4f,"sensor waypoint actor CPU/Metal mean mismatch");
        }
        cb=[metal.queue commandBuffer];
        metal.dispatch(cb,sim.act_p,1,{sim.states,sim.runs,sim.worlds,sim.obs,sim.co,sim.actor,sim.critic,sim.actions,sim.logp,sim.values,sim.commands,sim.physics,c},64);
        // sim_act owns previous_nav and the yaw reference. Complete it before
        // applying the host active-sensing override, or the kernel will race
        // with and erase the yaw command.
        metal.finish(cb);
        // The independent scorer always uses the given final goal. A frontier
        // or local waypoint never becomes a benchmark success.
        policy_world.goal[0]=global_goal.x;policy_world.goal[1]=global_goal.y;policy_world.goal[2]=global_goal.z;
        if(waypoint_velocity_controller) {
            // Replace only the learned local controller. Follow a short segment
            // of the existing A* polyline, after sensor-map line-of-sight check.
            const Point control_target=route_target.point;
            const float dx=control_target.x-position.x,dy=control_target.y-position.y,dz=control_target.z-position.z;
            const float distance=std::sqrt(dx*dx+dy*dy+dz*dz);
            float speed=route_target.line_clear?std::min(cfg.speed,1.2f*distance):0.0f;
            if(route_target.path_index>0&&route_target.path_index+1<mapped_route.size()) {
                Point before=mapped_route[route_target.path_index],after=mapped_route[route_target.path_index+1],prior=mapped_route[route_target.path_index-1];
                const float ax=before.x-prior.x,ay=before.y-prior.y,az=before.z-prior.z;
                const float bx=after.x-before.x,by=after.y-before.y,bz=after.z-before.z;
                const float an=std::sqrt(ax*ax+ay*ay+az*az),bn=std::sqrt(bx*bx+by*by+bz*bz);
                if(an>1e-6f&&bn>1e-6f&&(ax*bx+ay*by+az*bz)/(an*bn)<0.7f)speed=std::min(speed,0.5f);
            }
            const float world_velocity[3]={route_target.line_clear&&distance>1e-6f?dx*speed/distance:0.0f,
                                           route_target.line_clear&&distance>1e-6f?dy*speed/distance:0.0f,
                                           route_target.line_clear&&distance>1e-6f?dz*speed/distance:0.0f};
            float rotation[9];cpu_reference::rotation(state.orientation_wxyz,rotation);
            for(int axis=0;axis<3;axis++) {
                const float body=rotation[axis]*world_velocity[0]+rotation[3+axis]*world_velocity[1]+rotation[6+axis]*world_velocity[2];
                run.previous_nav[axis]=body/cfg.speed;
                run.desired_velocity[axis]=world_velocity[axis];
            }
            const float hdx=route_target.heading.x-position.x,hdy=route_target.heading.y-position.y;
            float desired_yaw=actor_reference_yaw;
            if(hdx*hdx+hdy*hdy>.01f)desired_yaw=std::atan2(hdy,hdx);
            const float tracking_yaw=std::clamp(4.0f*heading_error(desired_yaw,actor_reference_yaw),-1.0f,1.0f);
            run.previous_nav[3]=tracking_yaw;
            run.yaw=actor_reference_yaw+tracking_yaw*.05f*.5f;
            float* command_history=static_cast<float*>(sim.commands.contents)+(run.steps%8)*4;
            for(int axis=0;axis<4;axis++)command_history[axis]=run.previous_nav[axis];
        }
        const float reference_yaw_before=run.yaw;
        bool active_scan=false;
        if(look_state>0) {
            // Physically executed look: zero translation and steer the
            // reference yaw at the same 0.025 rad/tick the deployed actor
            // command uses, i.e. a 0.5 rad/s cap at 20 Hz.
            active_scan=true;active_scan_used=true;
            const float look_error=heading_error(look_target_yaw,run.yaw);
            const float look_yaw=std::clamp(4.0f*look_error,-1.0f,1.0f);
            const float prior_yaw=run.previous_nav[3];
            run.previous_nav[3]=look_yaw;
            run.yaw+=(look_yaw-prior_yaw)*static_cast<RLPhysicsParams*>(sim.physics.contents)->dt*cfg.substeps*0.5f;
            float* command_history=static_cast<float*>(sim.commands.contents)+(run.steps%8)*4;
            for(int axis=0;axis<3;axis++){run.previous_nav[axis]=0.0f;run.desired_velocity[axis]=0.0f;command_history[axis]=0.0f;}
            command_history[3]=look_yaw;
            scan_phase=look_state;
        } else scan_phase=-1;
        const float reference_yaw_after=run.yaw;
        cb=[metal.queue commandBuffer];c=sim.configs[0];
        metal.dispatch(cb,sim.advance_p,1,{sim.states,sim.runs,sim.worlds,sim.sensors,sim.commands,sim.raptor,sim.critic,sim.rewards,sim.next_values,sim.terminated,sim.truncated,sim.physics,c,sim.bank_worlds,sim.bank_schedule,sim.bank_control,sim.bank_active_ids,sim.bank_transition_ids,sim.environment_physics,sim.runtime_control,sim.task_states,sim.task_control,sim.potential_fields,sim.potential_spec,sim.potential_control},64);
        metal.finish(cb);
        const size_t free_cells=map.free_cells;
        const auto limits=std::minmax_element(ranges,ranges+320);
        float vehicle_rotation[9];cpu_reference::rotation(state.orientation_wxyz,vehicle_rotation);
        const float vehicle_yaw=std::atan2(vehicle_rotation[3],vehicle_rotation[0]);
        const Point logged_target=waypoint_velocity_controller?route_target.point:local_goal;
        const float waypoint_dx=logged_target.x-position.x,waypoint_dy=logged_target.y-position.y,waypoint_dz=logged_target.z-position.z;
        const float waypoint_distance=std::sqrt(waypoint_dx*waypoint_dx+waypoint_dy*waypoint_dy+waypoint_dz*waypoint_dz);
        const float waypoint_dir_x=waypoint_distance>1e-6f?waypoint_dx/waypoint_distance:0.0f;
        const float waypoint_dir_y=waypoint_distance>1e-6f?waypoint_dy/waypoint_distance:0.0f;
        const float waypoint_dir_z=waypoint_distance>1e-6f?waypoint_dz/waypoint_distance:0.0f;
        const float global_goal_error=std::sqrt(std::pow(global_goal.x-state.position[0],2)+std::pow(global_goal.y-state.position[1],2)+std::pow(global_goal.z-state.position[2],2));
        trace<<level.failure_id<<','<<level.family<<','<<(waypoint_velocity_controller?"polyline":"actor")<<','<<run.steps<<','<<run.elapsed<<','<<state.position[0]<<','<<state.position[1]<<','<<state.position[2]<<','<<pose[0]<<','<<pose[1]<<','<<pose[2]<<','<<global_goal.x<<','<<global_goal.y<<','<<global_goal.z<<','<<global_goal_error<<','<<local_goal.x<<','<<local_goal.y<<','<<local_goal.z<<','<<logged_target.x<<','<<logged_target.y<<','<<logged_target.z<<','<<waypoint_distance<<','<<waypoint_dir_x<<','<<waypoint_dir_y<<','<<waypoint_dir_z<<','<<route_target.path_index<<','<<route_target.line_clear<<','<<route_target.map_clearance<<','<<run.previous_nav[0]<<','<<run.previous_nav[1]<<','<<run.previous_nav[2]<<','<<run.previous_nav[3]<<','<<reference_yaw_before<<','<<reference_yaw_after<<','<<vehicle_yaw<<','<<run.desired_velocity[0]<<','<<run.desired_velocity[1]<<','<<run.desired_velocity[2]<<','<<committed_frontier<<','<<frontier_gain<<','<<scan_phase<<','<<active_scan<<','<<run.successes<<','<<run.collisions<<','<<run.timeouts<<','<<expanded<<','<<frontiers<<','<<free_cells<<','<<map.unique_hit_cells<<','<<*limits.first<<','<<*limits.second<<'\n';
        result.observed_free=free_cells;result.hit_voxel_updates=map.hit_updates;
    }
    result.success=run.successes;result.collision=run.collisions;result.timeout=run.timeouts;result.steps=run.steps;result.elapsed=run.elapsed;result.path=run.path;result.peak=run.peak_speed;result.min_clearance=run.min_clearance;
    result.goal_error=std::sqrt(std::pow(global_goal.x-state.position[0],2)+std::pow(global_goal.y-state.position[1],2)+std::pow(global_goal.z-state.position[2],2));
    result.ray_updates=map.ray_updates;
    result.active_scan_used=active_scan_used;
    result.preferred_side=preferred_side;result.look_ticks_used=int(look_ticks);
    result.look_extent_left=look_extent_left;result.look_extent_right=look_extent_right;
    result.look_open_left=look_open_left?1:0;result.look_open_right=look_open_right?1:0;
    result.plan_count=plan_count;result.plan_goal_count=plan_goal_count;
    result.look_first_step=look_first_step;result.look_last_step=look_last_step;
    return result;
}

static std::vector<float> load_actor_weights(const std::string& checkpoint) {
    std::ifstream file(checkpoint,std::ios::binary);auto header=read_checkpoint_header(file);
    require(file&&header.actor_count==fixed_ppo::actor_param_count,"checkpoint actor dimensions");
    std::vector<float> actor(header.actor_count);file.read(reinterpret_cast<char*>(actor.data()),std::streamsize(actor.size()*sizeof(float)));
    require(bool(file),"checkpoint actor is incomplete");return actor;
}

static void run_bank(Metal& metal,const std::string& checkpoint,const std::string& bank_path,
                     const std::string& output_dir,const std::string& split,size_t max_levels,bool waypoint_velocity_controller,
                     bool write_frontier_cause) {
    std::filesystem::create_directories(output_dir);
    const auto actor=load_actor_weights(checkpoint);std::string bank_hash;
    auto levels=challenge_evaluation::load_split(bank_path,split,challenge_evaluation::sha256_file(std::string(SOURCE_DIR)+"/world.hpp"),bank_hash);
    if(max_levels&&levels.size()>max_levels)levels.resize(max_levels);
    std::ofstream scores(output_dir+"/episodes.csv");
    std::ofstream trace(output_dir+"/trajectories.csv");write_trace_header(trace);
    scores<<"failure_id,family,success,collision,timeout,steps,time_s,path_m,mean_speed_mps,peak_speed_mps,min_clearance_m,global_goal_error_m,observed_free_cells,hit_voxel_updates,ray_cell_updates,planner_expansions,frontiers,map_plan_ms,active_scan_used,preferred_side,look_ticks,look_extent_left,look_open_left,look_extent_right,look_open_right,look_first_step,look_last_step,plan_count,plan_goal_count\n";
    uint32_t counts[3]={},successes[3]={},collisions[3]={},timeouts[3]={};double total_map_ms=0;
    for(size_t i=0;i<levels.size();i++) {
        const auto& level=levels[i];std::ofstream cause_receipt;
        if(write_frontier_cause&&i==0)cause_receipt.open(output_dir+"/frontier-cause.json");
        auto r=run_episode(metal,level,actor.data(),trace,waypoint_velocity_controller,
            cause_receipt.is_open()?&cause_receipt:nullptr,bank_path,checkpoint);
        size_t family=level.family-14;counts[family]++;successes[family]+=r.success;collisions[family]+=r.collision;timeouts[family]+=r.timeout;total_map_ms+=r.map_plan_ms;
        scores<<r.id<<','<<r.family<<','<<r.success<<','<<r.collision<<','<<r.timeout<<','<<r.steps<<','<<r.elapsed<<','<<r.path<<','<<(r.elapsed?r.path/r.elapsed:0)<<','<<r.peak<<','<<r.min_clearance<<','<<r.goal_error<<','<<r.observed_free<<','<<r.hit_voxel_updates<<','<<r.ray_updates<<','<<r.planner_expansions<<','<<r.frontiers<<','<<r.map_plan_ms<<','<<r.active_scan_used<<','<<r.preferred_side<<','<<r.look_ticks_used<<','<<r.look_extent_left<<','<<r.look_open_left<<','<<r.look_extent_right<<','<<r.look_open_right<<','<<r.look_first_step<<','<<r.look_last_step<<','<<r.plan_count<<','<<r.plan_goal_count<<'\n';scores.flush();
        std::cout<<i+1<<'/'<<levels.size()<<" "<<r.id<<" f"<<r.family<<" success="<<r.success<<" collision="<<r.collision<<" timeout="<<r.timeout<<" time="<<r.elapsed<<"s path="<<r.path<<"m map_ms="<<r.map_plan_ms<<std::endl;
    }
    std::ofstream report(output_dir+"/report.md");
    report<<"# Sensor-only persistent geometry experiment\n\nController diagnostic: "<<(waypoint_velocity_controller?"bounded sensor-waypoint velocity":"frozen learned actor")<<".\n\n"
          <<"Split: `"<<split<<"`; bank SHA-256: `"<<bank_hash<<"`; checkpoint SHA-256: `"<<challenge_evaluation::sha256_file(checkpoint)<<"`. The actor sees a 2.0 m local waypoint selected from observed free voxels. `WWorld.goal` remains fixed and is the only success, collision, and score target. Physics runs the original 20 Hz navigation / 100 Hz RAPTOR motor path with 0.18 m contact radius and 400-step (20 s) cap.\n\n"
          <<"Belief: 0.25 m world-aligned voxels in a broad computational region; the grid limits do not encode bank room bounds or topology. All 320 measured rays are integrated with exact Amanatides-Woo voxel traversal through the shared `wcamera` model; the voxel holding the true measured endpoint becomes occupied. Evidence is persistent and contradiction-only: a measured surface is cleared only by a free ray recorded after it, and measured free is cleared only by a surface recorded after it, so a static wall is remembered after it leaves the field of view and a moved obstacle's vacated voxels are cleared because rays then traverse them. Within one capture a hit wins, so grazing rays stay order-independent. Exact traversal assumption: a cell is traversable only when its centre is measured free; the 0.18 m body sphere must not overlap a *measured* occupied voxel; overlap with unobserved voxels is NOT verified and is a stated residual risk, not a cleared guarantee. The vehicle's own cell is accepted proprioceptively under this simulator's 0.18 m physical body, which is not a hardware claim. There is no inflation constant. Exploration is a goal-directed A* frontier search; when the straight swept route to the given goal is blocked the vehicle performs one two-sided in-place look of plus/minus 40 degrees about the goal bearing at a 0.5 rad/s cap with zero translation, probes how far the blocking obstacle runs alongside each side and whether observed free space lies beyond it, and commits to the side where it ends in a passage. That side decision is released as soon as a straight swept route to the goal exists again. Re-planning happens on waypoint arrival, route invalidation or stall. The local waypoint handed to the actor is re-validated every tick with a swept body-centre segment test; otherwise the goal is held. The host overrides translation and yaw only during the look; `look_first_step`/`look_last_step`/`look_ticks` give the exact override window, and `plan_count`/`plan_goal_count` report how often the planner targeted the global goal itself.\n\n"
          <<"| Family | Success | Contact | Timeout |\n|---:|---:|---:|---:|\n";
    for(int i=0;i<3;i++)report<<'|'<<14+i<<'|'<<successes[i]<<'/'<<counts[i]<<'|'<<collisions[i]<<'|'<<timeouts[i]<<"|\n";
    report<<"\nMap/planner host time across the bank: "<<total_map_ms<<" ms. Full policy/physics loop time is in the console run log. Per-episode traces include pose, original global goal, local goal and map counts. Baseline control is the preserved frozen actor at 54/90 (0/30 corners, 25/30 rooms, 29/30 vertical) from the existing original-bank evaluation.\n\nThis is hybrid navigation logic around a frozen learned local controller. Development-split scores are feedback, not blind zero-shot proof.\n";
}
}

int main(int argc,char** argv) {@autoreleasepool {try {
    require(argc>=5,"sensor-memory CHECKPOINT BANK_JSONL OUTPUT_DIR train|dev [MAX_LEVELS=all] [actor|polyline] [cause-debug]");
    Metal metal;metal.compile(base_source());
    const bool waypoint_velocity_controller=argc>6&&(std::string(argv[6])=="waypoint"||std::string(argv[6])=="polyline");
    require(argc<=6||waypoint_velocity_controller||std::string(argv[6])=="actor","controller must be actor or polyline");
    const bool write_frontier_cause=argc>7&&std::string(argv[7])=="cause-debug";
    require(argc<=7||write_frontier_cause,"diagnostic option must be cause-debug");
    sensor_memory::run_bank(metal,argv[1],argv[2],argv[3],argv[4],argc>5?std::stoul(argv[5]):0,
                            waypoint_velocity_controller,write_frontier_cause);
    return 0;
} catch(const std::exception& error) { std::cerr<<"ERROR: "<<error.what()<<"\n";return 1; }}}
