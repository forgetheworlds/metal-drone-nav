// Narrow source-only experiment: train a small recurrent residual over the
// frozen selected raw-depth actor. Hidden state belongs to one episode and is
// reset at every reset; each call is one 20 Hz observation.
#define main embedded_navigation_main
#include "main.mm"
#undef main

#include <array>
#include <cmath>
#include <fstream>

namespace navigation_recurrent {
constexpr size_t kObs = fixed_ppo::actor_obs_dim;
constexpr size_t kHidden = 8;
constexpr size_t kInputs = kObs;
constexpr std::array<float,3> kSensingVelocityWorld{{0,.15f,0}};
static_assert(kObs == 824, "recurrent source experiment requires raw824 observations");
static_assert(fixed_ppo::has_geometry_prior, "guided actor action map required");

// The temporal encoder projects every raw824 observation value. No ray is
// selected away. The recurrent state gets both raw frames, actor context,
// ego/goal state, and the geometry prior. It adds no route or world state.
struct Memory {
    std::array<float,kHidden> h{};
};
struct Params {
    std::array<float,kHidden*kInputs> input{};
    std::array<float,kHidden*kHidden> recurrent{};
    std::array<float,kHidden> bias{};
    std::array<float,4*kHidden> output{};
    std::array<float,4> output_bias{};
};
struct SequenceRow {
    std::array<float,kObs> observation{};
    std::array<float,4> target{}; // normalized body velocity and yaw command
};
struct EpisodeRows { uint32_t family=0;std::string id;std::vector<SequenceRow> rows; };
struct BaseAction { std::array<float,4> mean{};float gate=0; };
struct RnnCheckpointHeader { char magic[8]={'R','N','N','R','E','S','1','\0'};uint32_t version=1,observation=kObs,hidden=kHidden;char actor_sha256[65]{}; };
using Input = std::array<float,kInputs>;
static Input observation_input(const float* obs) { Input x{};std::copy(obs,obs+kInputs,x.begin());return x; }
static std::array<float,4> forward(const float* obs,const Params& p,Memory& memory) {
    const Input x=observation_input(obs);
    std::array<float,kHidden> next{};
    for(size_t j=0;j<kHidden;j++) {
        float z=p.bias[j];
        for(size_t i=0;i<kInputs;i++) z+=p.input[j*kInputs+i]*x[i];
        for(size_t h=0;h<kHidden;h++) z+=p.recurrent[j*kHidden+h]*memory.h[h];
        next[j]=std::tanh(z);
    }
    memory.h=next;
    std::array<float,4> residual{};
    for(size_t a=0;a<4;a++) {
        residual[a]=p.output_bias[a];
        for(size_t h=0;h<kHidden;h++) residual[a]+=p.output[a*kHidden+h]*next[h];
    }
    return residual;
}

// This routine is the executable definition of the deployed command map.
// The frozen actor mean receives the residual, then the existing guidance
// gate, tanh, spherical 1.5 m/s cap, and normalized yaw map are applied.
static std::array<float,4> deployed(const float* obs,const fixed_ppo::ActorParams& actor,
                                    const Params& recurrent,Memory& memory) {
    float hidden[fixed_ppo::hidden_dim],mean[4];
    fixed_ppo::actor_forward(obs,actor,hidden,mean);
    const auto delta=forward(obs,recurrent,memory);
    float open=0;for(size_t i=0;i<20;i++)open+=obs[i]*12.0f>2.5f;
    const float gate=.25f+.75f*open/20.0f;
    std::array<float,4> command{};
    float norm=0;
    for(size_t a=0;a<3;a++) {
        const float prior=obs[kObs-3+a];
        command[a]=std::tanh(prior+gate*(mean[a]+delta[a]-prior));
        norm+=command[a]*command[a];
    }
    // Commands are normalized by the1.5m/s cap before conversion to RAPTOR.
    // Therefore the spherical cap is1 in command space; execution multiplies
    // bycfg.speed exactly once.
    const float scale=std::min(1.0f,1.0f/std::max(std::sqrt(norm),1e-8f));
    for(size_t a=0;a<3;a++)command[a]*=scale;
    command[3]=std::tanh(gate*(mean[3]+delta[3]));
    return command;
}
static void save_residual(const std::string& path,const std::string& actor_hash,const Params& params) {
    RnnCheckpointHeader header;require(actor_hash.size()==64,"actor hash must be SHA-256");
    std::memcpy(header.actor_sha256,actor_hash.c_str(),64);
    std::ofstream out(path,std::ios::binary);require(bool(out),"cannot write residual checkpoint");
    out.write(reinterpret_cast<const char*>(&header),sizeof(header));out.write(reinterpret_cast<const char*>(&params),sizeof(params));
    require(bool(out),"residual checkpoint write failed");
}
static Params load_residual(const std::string& path,const std::string& actor_hash) {
    std::ifstream in(path,std::ios::binary);require(bool(in),"cannot open recurrent residual checkpoint");
    RnnCheckpointHeader header;in.read(reinterpret_cast<char*>(&header),sizeof(header));
    require(bool(in)&&std::memcmp(header.magic,"RNNRES1",7)==0&&header.version==1&&header.observation==kObs&&header.hidden==kHidden,
            "recurrent checkpoint header mismatch");
    require(std::string(header.actor_sha256,64)==actor_hash,"recurrent checkpoint is bound to a different frozen actor");
    Params params;in.read(reinterpret_cast<char*>(&params),sizeof(params));require(bool(in),"recurrent checkpoint truncated");
    require(std::all_of(reinterpret_cast<const float*>(&params),reinterpret_cast<const float*>(&params)+sizeof(params)/sizeof(float),
                        [](float x){return std::isfinite(x);}),"recurrent checkpoint has non-finite parameters");
    return params;
}
static std::array<float,3> body_to_world(const std::array<float,3>& body,const float* qwxyz) {
    float rotation[9];cpu_reference::rotation(qwxyz,rotation);
    return {rotation[0]*body[0]+rotation[1]*body[1]+rotation[2]*body[2],
            rotation[3]*body[0]+rotation[4]*body[1]+rotation[5]*body[2],
            rotation[6]*body[0]+rotation[7]*body[1]+rotation[8]*body[2]};
}
static std::array<float,3> world_to_body(const std::array<float,3>& world,const float* qwxyz) {
    float rotation[9];cpu_reference::rotation(qwxyz,rotation);
    return {rotation[0]*world[0]+rotation[3]*world[1]+rotation[6]*world[2],
            rotation[1]*world[0]+rotation[4]*world[1]+rotation[7]*world[2],
            rotation[2]*world[0]+rotation[5]*world[1]+rotation[8]*world[2]};
}
static float point_distance(const std::array<float,3>& a,const std::array<float,3>& b) {
    const float x=a[0]-b[0],y=a[1]-b[1],z=a[2]-b[2];return std::sqrt(x*x+y*y+z*z);
}
static float teacher_yaw_command(const std::array<float,3>& world_velocity,float current_yaw) {
    if(std::hypot(world_velocity[0],world_velocity[1])<.05f)return 0;
    const float desired=std::atan2(world_velocity[1],world_velocity[0]);
    const float error=std::atan2(std::sin(desired-current_yaw),std::cos(desired-current_yaw));
    return std::clamp(2.0f*error,-1.0f,1.0f); // max reference rate is0.5 rad/s.
}
static std::array<float,3> interpolate(const std::array<float,3>& a,const std::array<float,3>& b,float u) {
    return {a[0]+u*(b[0]-a[0]),a[1]+u*(b[1]-a[1]),a[2]+u*(b[2]-a[2])};
}
static bool line_visible(const WWorld& world,const std::array<float,3>& from,const std::array<float,3>& to,float time) {
    const int count=std::max(1,int(std::ceil(point_distance(from,to)/.02f)));
    for(int i=0;i<=count;i++) {auto p=interpolate(from,to,float(i)/count);if(wclearance(world,wv(p[0],p[1],p[2]),time)<.04f)return false;}
    return true;
}
static std::array<float,3> teacher_target(const WWorld& world,const std::vector<std::array<float,3>>& route,
                                         const std::array<float,3>& position,float time,float max_ahead=1.5f) {
    size_t segment=0;float fraction=0,best=INFINITY;
    for(size_t i=0;i+1<route.size();i++) {
        std::array<float,3> d{},r{};for(size_t k=0;k<3;k++){d[k]=route[i+1][k]-route[i][k];r[k]=position[k]-route[i][k];}
        float square=0,dot=0;for(size_t k=0;k<3;k++){square+=d[k]*d[k];dot+=r[k]*d[k];}
        const float u=std::clamp(dot/std::max(square,1e-8f),0.0f,1.0f);const auto nearest=interpolate(route[i],route[i+1],u);
        const float error=point_distance(nearest,position);if(error<best){best=error;segment=i;fraction=u;}
    }
    auto selected=interpolate(route[segment],route[segment+1],fraction);
    for(size_t i=segment;i+1<route.size();i++) {
        const float begin=i==segment?fraction:0;
        const int count=std::max(1,int(std::ceil(point_distance(route[i],route[i+1])/.05f)));
        for(int j=0;j<=count;j++) {
            const auto candidate=interpolate(route[i],route[i+1],begin+(1-begin)*float(j)/count);
            if(point_distance(candidate,position)>max_ahead||!line_visible(world,position,candidate,time))return selected;
            selected=candidate;
        }
    }
    return selected;
}

// Tiny independent scalar reference checks recurrent backprop through time.
// The checked objective is 0.5 * final_hidden[0]^2 over a two-row sequence.
static float reference_loss(const Params& p,const std::array<Input,2>& x) {
    Memory m;
    for(const auto& row:x) {
        std::array<float,kHidden> next{};
        for(size_t j=0;j<kHidden;j++) {
            float z=p.bias[j];
            for(size_t i=0;i<kInputs;i++)z+=p.input[j*kInputs+i]*row[i];
            for(size_t h=0;h<kHidden;h++)z+=p.recurrent[j*kHidden+h]*m.h[h];
            next[j]=std::tanh(z);
        }
        m.h=next;
    }
    return .5f*m.h[0]*m.h[0];
}
static float recurrent_gradient(const Params& p,const std::array<Input,2>& x,size_t parameter) {
    Memory states[3];
    for(size_t t=0;t<2;t++) {
        const Input& row=x[t];
        for(size_t j=0;j<kHidden;j++) {
            float z=p.bias[j];for(size_t i=0;i<kInputs;i++)z+=p.input[j*kInputs+i]*row[i];
            for(size_t h=0;h<kHidden;h++)z+=p.recurrent[j*kHidden+h]*states[t].h[h];
            states[t+1].h[j]=std::tanh(z);
        }
    }
    std::array<float,kHidden> dh{};dh[0]=states[2].h[0];
    float answer=0;
    for(int t=1;t>=0;t--) {
        std::array<float,kHidden> dz{};
        for(size_t j=0;j<kHidden;j++)dz[j]=dh[j]*(1-states[t+1].h[j]*states[t+1].h[j]);
        const size_t recurrent_start=kHidden*kInputs;
        if(parameter<recurrent_start) {
            const size_t j=parameter/kInputs,i=parameter%kInputs;
            answer+=dz[j]*x[size_t(t)][i];
        } else if(parameter<recurrent_start+kHidden*kHidden) {
            const size_t q=parameter-recurrent_start;
            answer+=dz[q/kHidden]*states[t].h[q%kHidden];
        }
        std::array<float,kHidden> prior{};
        for(size_t old=0;old<kHidden;old++)for(size_t j=0;j<kHidden;j++)
            prior[old]+=dz[j]*p.recurrent[j*kHidden+old];
        dh=prior;
    }
    return answer;
}
static void check(const std::string& out) {
    Params p;
    for(size_t i=0;i<p.input.size();i++)p.input[i]=.0001f*std::sin(float(i+1));
    for(size_t i=0;i<p.recurrent.size();i++)p.recurrent[i]=.03f*std::cos(float(i+2));
    std::array<Input,2> x{};
    for(size_t t=0;t<2;t++)for(size_t i=0;i<kInputs;i++)x[t][i]=.2f*std::sin(float(i+3*t+1));
    float worst=0;const float eps=1e-3f;
    for(size_t i=kHidden*kInputs;i<kHidden*kInputs+kHidden*kHidden;i++) {
        float* v=&p.recurrent[i-kHidden*kInputs];const float saved=*v;
        *v=saved+eps;const float plus=reference_loss(p,x);
        *v=saved-eps;const float minus=reference_loss(p,x);*v=saved;
        worst=std::max(worst,std::fabs((plus-minus)/(2*eps)-recurrent_gradient(p,x,i)));
    }
    for(size_t j=0;j<kHidden;j++)for(size_t i:std::array<size_t,4>{{0,181,501,821}}) {
        const size_t parameter=j*kInputs+i;float* v=&p.input[parameter];const float saved=*v;
        *v=saved+eps;const float plus=reference_loss(p,x);
        *v=saved-eps;const float minus=reference_loss(p,x);*v=saved;
        worst=std::max(worst,std::fabs((plus-minus)/(2*eps)-recurrent_gradient(p,x,parameter)));
    }
    require(worst<1e-5f,"recurrent BPTT differs from CPU finite differences");
    std::array<float,kObs> obs{};obs[181]=.5f;obs[kObs-3]=.2f;obs[kObs-2]=-.1f;
    fixed_ppo::ActorParams frozen{};Params zero_params;Memory memory,m;
    const auto zero_residual_command=deployed(obs.data(),frozen,zero_params,memory);
    require(std::fabs(zero_residual_command[0]-std::tanh(obs[kObs-3]))<1e-7f,
            "zero residual must preserve the frozen guided tanh mapping");
    require(std::fabs(zero_residual_command[1]-std::tanh(obs[kObs-2]))<1e-7f,
            "zero residual must preserve lateral guidance mapping");
    float yaw_before=.3f;const float yaw_cmd=.9f,dt=.01f,substeps=5;
    float yaw_after=yaw_before+yaw_cmd*dt*substeps*.5f;
    require(std::fabs(yaw_after-(yaw_before+.0225f))<1e-7f,"normalized yaw command conversion changed");
    std::array<float,4> q{{.70710678f,0,0,.70710678f}};
    const auto world=body_to_world({{.4f,-.2f,.1f}},q.data());
    require(std::fabs(world[0]-.2f)<1e-6f&&std::fabs(world[1]-.4f)<1e-6f&&std::fabs(world[2]-.1f)<1e-6f,
            "body velocity to world velocity rotation changed");
    require(std::all_of(m.h.begin(),m.h.end(),[](float v){return v==0;}),"zero recurrent parameters must preserve zero residual");
    m.h.fill(1);m=Memory{};require(std::all_of(m.h.begin(),m.h.end(),[](float v){return v==0;}),"episode reset must clear recurrent memory");
    std::filesystem::create_directories(std::filesystem::path(out).parent_path());
    std::ofstream f(out);f<<"{\"passed\":true,\"recurrent_parameters_checked\":"<<kHidden*kHidden
        <<",\"input_projection_parameters_checked\":"<<kHidden*4
        <<",\"bptt_finite_difference_max_error\":"<<worst<<",\"hidden\":"<<kHidden
        <<",\"input_features\":"<<kInputs<<",\"episode_reset\":true,\"zero_residual\":true}\n";
    std::cout<<"recurrent_bptt_check PASS max_error="<<worst<<"\n";
}

static void observe(Metal& metal,Sim& sim) {
    const auto cfg=sim.configs[0];auto cb=[metal.queue commandBuffer];
    metal.dispatch(cb,sim.depth_p,320,{sim.states,sim.runs,sim.worlds,sim.sensors,sim.physics,cfg,sim.poses});
    metal.dispatch(cb,sim.memory_points_p,640,{sim.states,sim.runs,sim.sensors,sim.poses,sim.memory_points,sim.physics,cfg});
    metal.dispatch(cb,sim.memory_candidates_p,85,{sim.states,sim.worlds,sim.memory_points,sim.memory_clearances,cfg});
    metal.dispatch(cb,sim.observe_p,1,{sim.states,sim.runs,sim.worlds,sim.sensors,sim.obs,sim.co,sim.physics,cfg,sim.poses,sim.memory_clearances},64);
    metal.finish(cb);
}
static void advance_world_velocity(Sim& sim,const std::array<float,3>& world_velocity,float normalized_yaw) {
    auto& run=*static_cast<SimRun*>(sim.runs.contents);
    const auto& state=*static_cast<RLPhysicsState*>(sim.states.contents);
    float r[9];cpu_reference::rotation(state.orientation_wxyz,r);
    auto* commands=static_cast<float*>(sim.commands.contents);
    const float magnitude=std::sqrt(world_velocity[0]*world_velocity[0]+world_velocity[1]*world_velocity[1]+world_velocity[2]*world_velocity[2]);
    require(std::isfinite(magnitude)&&magnitude<=1.50001f,"executed world-velocity command exceeds1.5m/s cap");
    for(size_t axis=0;axis<3;axis++) {
        run.desired_velocity[axis]=world_velocity[axis];
        run.previous_nav[axis]=(r[axis]*run.desired_velocity[0]+r[3+axis]*run.desired_velocity[1]+r[6+axis]*run.desired_velocity[2])/sim.cfg.speed;
        commands[(run.steps%8)*4+axis]=run.previous_nav[axis];
    }
    require(std::isfinite(normalized_yaw)&&std::fabs(normalized_yaw)<=1.0f,"normalized yaw outside deployed range");
    run.previous_nav[3]=normalized_yaw;commands[(run.steps%8)*4+3]=normalized_yaw;
    const auto& physics=*static_cast<RLPhysicsParams*>(sim.physics.contents);
    run.yaw+=normalized_yaw*physics.dt*sim.cfg.substeps*.5f;
    auto& metal=sim.m;auto cb=[metal.queue commandBuffer];
    metal.dispatch(cb,sim.advance_p,1,{sim.states,sim.runs,sim.worlds,sim.sensors,sim.commands,sim.raptor,sim.critic,
        sim.rewards,sim.next_values,sim.terminated,sim.truncated,sim.physics,sim.configs[0],
        sim.bank_worlds,sim.bank_schedule,sim.bank_control,sim.bank_active_ids,sim.bank_transition_ids,
        sim.environment_physics,sim.runtime_control,sim.task_states,sim.task_control,
        sim.potential_fields,sim.potential_spec,sim.potential_control},64);
    metal.finish(cb);
}
static void protocol_eval(const std::string& bank,const std::string& checkpoint,const std::string& split,const std::string& output,
                          const std::string& residual_path="",uint prelude_ticks=40) {
    require(split=="train"||split=="dev","only TRAIN or DEV may use protocol evaluator");
    require(prelude_ticks==0||prelude_ticks==40,"protocol evaluator supports the original or2s common prelude");
    const std::string world_hash=challenge_evaluation::sha256_file(std::string(SOURCE_DIR)+"/world.hpp");
    std::string bank_hash;
    const auto levels=challenge_evaluation::load_split(bank,split,world_hash,bank_hash);
    std::ifstream in(checkpoint,std::ios::binary);require(bool(in),"cannot open frozen actor");
    const auto header=read_checkpoint_header(in);
    require(header.actor_count==fixed_ppo::actor_param_count&&header.config.velocity_contract==1,
            "protocol evaluation requires the compatible raw824 guided checkpoint");
    fixed_ppo::ActorParams actor;in.read(reinterpret_cast<char*>(actor.values.data()),sizeof(actor));
    require(bool(in),"frozen actor parameters truncated");
    std::filesystem::create_directories(std::filesystem::path(output).parent_path());
    std::ofstream csv(output);require(bool(csv),"cannot write protocol evaluation");
    csv<<"failure_id,family,split,protocol,success,collision,timeout,elapsed_s,path_m,min_clearance_m,prelude_ticks,post_prelude_ticks,bank_sha256,checkpoint_sha256\n";
    Metal metal;metal.compile(base_source()+PPO_TRAINER_MSL);
    Params residual;if(!residual_path.empty())residual=load_residual(residual_path,challenge_evaluation::sha256_file(checkpoint));
    uint successes=0,collisions=0,timeouts=0;
    for(size_t index=0;index<levels.size();index++) {
        const auto& level=levels[index];
        SimConfig cfg;cfg.n=1;cfg.family=level.family;cfg.mode=17;cfg.eval=1;cfg.seed=level.seed;
        cfg.speed=1.5f;cfg.distance=level.distance;cfg.max_steps=400;cfg.geometry_memory=1;cfg.sensor_period=1;
        Sim sim(metal,cfg,1);*static_cast<WWorld*>(sim.worlds.contents)=level.world;
        std::memcpy(sim.actor.contents,actor.values.data(),sizeof(actor));
        auto& run=*static_cast<SimRun*>(sim.runs.contents);auto& state=*static_cast<RLPhysicsState*>(sim.states.contents);
        run.initial_distance=std::sqrt(std::pow(level.world.goal[0]-state.position[0],2)+std::pow(level.world.goal[1]-state.position[1],2)+std::pow(level.world.goal[2]-state.position[2],2));
        Memory memory;uint prelude=0;
        while(run.steps<400&&!run.episodes) {
            observe(metal,sim);
            std::array<float,3> velocity{};float yaw=0;
            float* obs=static_cast<float*>(sim.obs.contents);
            if(run.steps<prelude_ticks) { // common physical sensing prelude, all splits and families.
                (void)forward(obs,residual,memory); // update memory while scripted behavior controls motion.
                velocity=kSensingVelocityWorld;yaw=.9f;prelude++;
            } else {
                const auto action=deployed(obs,actor,residual,memory);
                const std::array<float,3> body{{action[0]*cfg.speed,action[1]*cfg.speed,action[2]*cfg.speed}};
                velocity=body_to_world(body,state.orientation_wxyz);yaw=action[3];
            }
            advance_world_velocity(sim,velocity,yaw);
        }
        const bool success=run.successes>0&&!run.collisions;
        successes+=success;collisions+=run.collisions>0;timeouts+=run.timeouts>0;
        csv<<level.failure_id<<','<<level.family<<','<<split<<','<<(prelude_ticks?"common_parallax_2s":"original_no_prelude")<<','<<success<<','<<bool(run.collisions)<<','<<bool(run.timeouts)
           <<','<<run.elapsed<<','<<run.path<<','<<run.min_clearance<<','<<prelude<<','<<(run.steps-prelude)<<','<<bank_hash<<','
           <<challenge_evaluation::sha256_file(checkpoint)<<'\n';csv.flush();
        std::cout<<"protocol_eval "<<index+1<<'/'<<levels.size()<<" family="<<level.family<<" success="<<success
                 <<" collision="<<bool(run.collisions)<<" elapsed="<<run.elapsed<<std::endl;
    }
    std::cout<<"protocol_eval split="<<split<<" episodes="<<levels.size()<<" success="<<successes
             <<" collision="<<collisions<<" timeout="<<timeouts<<" prelude_s="<<prelude_ticks*.05f<<" budget_s=20 output="<<output<<'\n';
}
static std::vector<EpisodeRows> collect_source(const std::string& bank,const std::string& checkpoint,const std::string& output) {
    std::filesystem::create_directories(output);
    std::string bank_hash;const auto levels=challenge_evaluation::load_split(bank,"train",
        challenge_evaluation::sha256_file(std::string(SOURCE_DIR)+"/world.hpp"),bank_hash);
    std::ifstream in(checkpoint,std::ios::binary);require(bool(in),"cannot open selected raw824 actor");
    const auto header=read_checkpoint_header(in);require(header.actor_count==fixed_ppo::actor_param_count,"selected actor dimensions mismatch");
    fixed_ppo::ActorParams actor;in.read(reinterpret_cast<char*>(actor.values.data()),sizeof(actor));require(bool(in),"selected actor truncated");
    Metal metal;metal.compile(base_source()+PPO_TRAINER_MSL);
    std::ofstream flights(output+"/source-flights.csv");require(bool(flights),"cannot write source flights");
    flights<<"failure_id,family,success,collision,timeout,elapsed_s,path_m,min_clearance_m,rows,teacher_labels_off_camera,bank_sha256\n";
    std::vector<EpisodeRows> episodes;episodes.reserve(levels.size());
    for(size_t index=0;index<levels.size();index++) {
        const auto& level=levels[index];
        SimConfig cfg;cfg.n=1;cfg.family=level.family;cfg.mode=17;cfg.eval=1;cfg.seed=level.seed;
        cfg.speed=1.5f;cfg.distance=level.distance;cfg.max_steps=400;cfg.geometry_memory=1;cfg.sensor_period=1;
        Sim sim(metal,cfg,1);*static_cast<WWorld*>(sim.worlds.contents)=level.world;
        std::memcpy(sim.actor.contents,actor.values.data(),sizeof(actor));
        auto& run=*static_cast<SimRun*>(sim.runs.contents);auto& state=*static_cast<RLPhysicsState*>(sim.states.contents);
        run.initial_distance=point_distance({{level.world.goal[0],level.world.goal[1],level.world.goal[2]}},{{state.position[0],state.position[1],state.position[2]}});
        EpisodeRows episode;episode.family=level.family;episode.id=level.failure_id;Memory memory;Params zero_residual;uint off_camera=0;
        while(run.steps<400&&!run.episodes) {
            observe(metal,sim);float* obs=static_cast<float*>(sim.obs.contents);SequenceRow row;
            std::memcpy(row.observation.data(),obs,kObs*sizeof(float));std::array<float,3> velocity{};float yaw=0;
            if(run.steps<40) {
                (void)forward(obs,zero_residual,memory);velocity=kSensingVelocityWorld;yaw=.9f;
            } else {
                // Privileged expert flight: follow the validated witness route.
                // The student never sees the route; only the teacher command
                // becomes the supervised label. Speed and look-ahead shrink with
                // local clearance so the expert stays physically valid in
                // clutter instead of driving straight into an obstacle.
                const std::array<float,3> position{{state.position[0],state.position[1],state.position[2]}};
                const float speed_cap=level.family==16?.9f:(level.family==15?1.0f:1.49f);
                const float ahead=level.family==16?.7f:(level.family==15?.8f:1.5f);
                const auto target=teacher_target(level.world,level.witness_route,position,run.elapsed,ahead);
                for(size_t k=0;k<3;k++)velocity[k]=target[k]-position[k];
                const float magnitude=std::sqrt(velocity[0]*velocity[0]+velocity[1]*velocity[1]+velocity[2]*velocity[2]);
                const float scale=std::min(1.0f,speed_cap/std::max(magnitude,1e-8f));for(float& v:velocity)v*=scale;
                yaw=teacher_yaw_command(velocity,run.yaw);
                const float bearing=std::atan2(velocity[1],velocity[0]);
                const float off_axis=std::atan2(std::sin(bearing-run.yaw),std::cos(bearing-run.yaw));
                if(std::fabs(off_axis)>1.2f)off_camera++;
            }
            {
                const auto body=world_to_body(velocity,state.orientation_wxyz);
                for(size_t k=0;k<3;k++)row.target[k]=body[k]/cfg.speed;row.target[3]=yaw;
            }
            episode.rows.push_back(row);advance_world_velocity(sim,velocity,yaw);
        }
        flights<<level.failure_id<<','<<level.family<<','<<bool(run.successes&&!run.collisions)<<','<<bool(run.collisions)<<','<<bool(run.timeouts)
               <<','<<run.elapsed<<','<<run.path<<','<<run.min_clearance<<','<<episode.rows.size()<<','<<off_camera<<','<<bank_hash<<'\n';flights.flush();
        std::cout<<"source_flight "<<index+1<<'/'<<levels.size()<<" family="<<level.family<<" success="<<bool(run.successes&&!run.collisions)
                 <<" collision="<<bool(run.collisions)<<" rows="<<episode.rows.size()<<std::endl;
        episodes.push_back(std::move(episode));
    }
    std::ofstream data(output+"/sequences.bin",std::ios::binary);require(bool(data),"cannot write sequence data");
    const uint64_t count=episodes.size();data.write(reinterpret_cast<const char*>(&count),sizeof(count));
    for(const auto& episode:episodes) {
        const uint32_t family=episode.family;const uint32_t id_size=uint32_t(episode.id.size());const uint64_t rows=episode.rows.size();
        data.write(reinterpret_cast<const char*>(&family),sizeof(family));data.write(reinterpret_cast<const char*>(&id_size),sizeof(id_size));
        data.write(episode.id.data(),std::streamsize(id_size));data.write(reinterpret_cast<const char*>(&rows),sizeof(rows));
        data.write(reinterpret_cast<const char*>(episode.rows.data()),std::streamsize(rows*sizeof(SequenceRow)));
    }
    require(bool(data),"sequence write failed");return episodes;
}
struct PrefixSnapshot { std::array<float,kObs> observation{};float clearance=12;bool collision=false;uint steps=0; };
static PrefixSnapshot sense_prefix(Metal& metal,WWorld world,uint32_t seed) {
    SimConfig cfg;cfg.n=1;cfg.family=14;cfg.mode=17;cfg.eval=1;cfg.seed=seed;cfg.speed=1.5f;cfg.max_steps=400;cfg.geometry_memory=1;
    Sim sim(metal,cfg,1);*static_cast<WWorld*>(sim.worlds.contents)=world;
    auto& run=*static_cast<SimRun*>(sim.runs.contents);
    for(uint tick=0;tick<40&&!run.episodes;tick++) {
        observe(metal,sim);const auto velocity=kSensingVelocityWorld;
        advance_world_velocity(sim,velocity,.9f);
    }
    PrefixSnapshot result;result.steps=run.steps;result.collision=run.collisions>0;result.clearance=run.min_clearance;
    if(run.steps==40) {
        observe(metal,sim); // capture the decision observation after all40 actions (t=2.00s).
        std::memcpy(result.observation.data(),sim.obs.contents,sizeof(result.observation));
    }
    return result;
}
static void cue_audit(const std::string& bank,const std::string& output) {
    std::string bank_hash;const auto levels=challenge_evaluation::load_split(bank,"train",
        challenge_evaluation::sha256_file(std::string(SOURCE_DIR)+"/world.hpp"),bank_hash);
    Metal metal;metal.compile(base_source()+PPO_TRAINER_MSL);
    std::filesystem::create_directories(std::filesystem::path(output).parent_path());std::ofstream out(output);
    require(bool(out),"cannot write controlled mirror cue audit");
    out<<"failure_id,raw_max_delta,raw_changed_over_0_01,pooled_current_max_delta,full824_max_delta,left_prefix_ticks,right_prefix_ticks,left_collision,right_collision,left_clearance_m,right_clearance_m,bank_sha256\n";
    uint pairs=0,raw_separated=0,pooled_separated=0,unsafe=0;
    for(const auto& level:levels) {
        if(level.family!=14||level.failure_id.find("-mirror-y")!=std::string::npos)continue;
        WWorld left=level.world,right=level.world;left.goal[1]=right.goal[1]=0;
        for(uint i=0;i<left.count;i++){right.obstacles[i].center[1]=-left.obstacles[i].center[1];right.obstacles[i].velocity[1]=-left.obstacles[i].velocity[1];}
        const auto a=sense_prefix(metal,left,level.seed),b=sense_prefix(metal,right,level.seed);
        float raw_max=0,pooled_max=0,full_max=0;uint changed=0;
        for(size_t i=0;i<320;i++){const float d=std::fabs(a.observation[181+i]-b.observation[181+i]);raw_max=std::max(raw_max,d);changed+=d>.01f;}
        for(size_t i=0;i<80;i++)pooled_max=std::max(pooled_max,std::fabs(a.observation[i]-b.observation[i]));
        for(size_t i=0;i<kObs;i++)full_max=std::max(full_max,std::fabs(a.observation[i]-b.observation[i]));
        raw_separated+=raw_max>.01f;pooled_separated+=pooled_max>.01f;unsafe+=a.steps<40||b.steps<40;
        out<<level.failure_id<<','<<raw_max<<','<<changed<<','<<pooled_max<<','<<full_max<<','<<a.steps<<','<<b.steps<<','
           <<a.collision<<','<<b.collision<<','<<a.clearance<<','<<b.clearance<<','<<bank_hash<<'\n';out.flush();pairs++;
    }
    std::ofstream summary(std::filesystem::path(output).replace_extension(".json"));
    summary<<"{\"pairs\":"<<pairs<<",\"raw_separated_over_0_01\":"<<raw_separated
           <<",\"pooled_current_separated_over_0_01\":"<<pooled_separated<<",\"unsafe_prefixes\":"<<unsafe
           <<",\"protocol\":\"body_vy_0.15mps_yaw_0.9_40ticks\",\"goal_y_both\":0,\"bank_sha256\":\""<<bank_hash<<"\"}\n";
    std::cout<<"controlled_mirror_prefix pairs="<<pairs<<" raw_separated="<<raw_separated<<" pooled_current_separated="<<pooled_separated
             <<" unsafe="<<unsafe<<" output="<<output<<std::endl;
}
static void command_map_check(const std::string& bank,const std::string& checkpoint,const std::string& output) {
    std::string hash;const auto levels=challenge_evaluation::load_split(bank,"train",
        challenge_evaluation::sha256_file(std::string(SOURCE_DIR)+"/world.hpp"),hash);
    const auto selected=std::find_if(levels.begin(),levels.end(),[](const auto& l){return l.family==16;});
    require(selected!=levels.end(),"no TRAIN vertical case for active-cap command check");
    std::ifstream in(checkpoint,std::ios::binary);const auto header=read_checkpoint_header(in);
    require(header.actor_count==fixed_ppo::actor_param_count,"command-map actor dimensions");
    fixed_ppo::ActorParams actor;in.read(reinterpret_cast<char*>(actor.values.data()),sizeof(actor));require(bool(in),"command-map actor truncated");
    Metal metal;metal.compile(base_source()+PPO_TRAINER_MSL);
    SimConfig cfg;cfg.n=1;cfg.family=16;cfg.mode=17;cfg.eval=1;cfg.seed=selected->seed;cfg.speed=1.5f;cfg.max_steps=400;cfg.geometry_memory=1;
    Sim sim(metal,cfg,1);*static_cast<WWorld*>(sim.worlds.contents)=selected->world;std::memcpy(sim.actor.contents,actor.values.data(),sizeof(actor));
    auto& run=*static_cast<SimRun*>(sim.runs.contents);auto& state=*static_cast<RLPhysicsState*>(sim.states.contents);
    for(uint tick=0;tick<40;tick++){observe(metal,sim);advance_world_velocity(sim,kSensingVelocityWorld,.9f);}
    std::filesystem::create_directories(std::filesystem::path(output).parent_path());std::ofstream csv(output);
    require(bool(csv),"cannot write active-cap command check");csv<<"step,cpu_gpu_body_error,cpu_gpu_yaw_error,executed_speed_mps,raw_body_command_norm,cap_active\n";
    Params residual;Memory memory;float max_body_error=0,max_yaw_error=0,max_speed=0;uint checked=0,cap_active=0;
    while(checked<32&&!run.episodes) {
        observe(metal,sim);
        auto cb=[metal.queue commandBuffer];
        encode(metal,cb,sim.simd_actor?"ppo_actor_forward_simd_fused":"ppo_actor_forward",
               sim.simd_actor?256:1,{{sim.obs,0},{sim.actor,0},{sim.actor_workspace,0},{sim.actions,0},{sim.env_count,0}},sim.simd_actor?256:64);
        metal.dispatch(cb,sim.act_p,1,{sim.states,sim.runs,sim.worlds,sim.obs,sim.co,sim.actor,sim.critic,sim.actions,sim.logp,sim.values,sim.commands,sim.physics,sim.configs[0]},64);
        metal.finish(cb);
        float* obs=static_cast<float*>(sim.obs.contents);const auto cpu=deployed(obs,actor,residual,memory);
        const auto gpu_body=world_to_body({{run.desired_velocity[0],run.desired_velocity[1],run.desired_velocity[2]}},state.orientation_wxyz);
        float error2=0,raw_norm2=0;
        for(size_t axis=0;axis<3;axis++){const float normalized=gpu_body[axis]/cfg.speed;error2+=(normalized-cpu[axis])*(normalized-cpu[axis]);raw_norm2+=run.previous_nav[axis]*run.previous_nav[axis];}
        const float body_error=std::sqrt(error2),yaw_error=std::fabs(run.previous_nav[3]-cpu[3]);
        const float speed=std::sqrt(run.desired_velocity[0]*run.desired_velocity[0]+run.desired_velocity[1]*run.desired_velocity[1]+run.desired_velocity[2]*run.desired_velocity[2]);
        require(speed<=1.50001f,"Metal mode17 executed command exceeds1.5m/s cap");
        max_body_error=std::max(max_body_error,body_error);max_yaw_error=std::max(max_yaw_error,yaw_error);max_speed=std::max(max_speed,speed);
        cap_active+=raw_norm2>1.0001f;csv<<checked<<','<<body_error<<','<<yaw_error<<','<<speed<<','<<std::sqrt(raw_norm2)<<','<<(raw_norm2>1.0001f)<<'\n';
        auto advance=[metal.queue commandBuffer];
        metal.dispatch(advance,sim.advance_p,1,{sim.states,sim.runs,sim.worlds,sim.sensors,sim.commands,sim.raptor,sim.critic,
            sim.rewards,sim.next_values,sim.terminated,sim.truncated,sim.physics,sim.configs[0],
            sim.bank_worlds,sim.bank_schedule,sim.bank_control,sim.bank_active_ids,sim.bank_transition_ids,
            sim.environment_physics,sim.runtime_control,sim.task_states,sim.task_control,
            sim.potential_fields,sim.potential_spec,sim.potential_control},64);
        metal.finish(advance);checked++;
    }
    require(checked>=16,"actor terminated before enough actual-observation checks");
    require(max_body_error<3e-5f&&max_yaw_error<3e-5f,"CPU zero-residual action differs from native mode17 on captured observations");
    require(cap_active>0,"captured observations did not exercise the spherical cap");
    std::cout<<"command_map_check PASS observations="<<checked<<" active_cap="<<cap_active
             <<" max_body_error="<<max_body_error<<" max_yaw_error="<<max_yaw_error<<" max_speed="<<max_speed<<std::endl;
}
struct DecisionSample {
    std::array<float,3> policy_world{},base_world{},teacher_world{};
    std::array<float,kHidden> hidden{};std::array<float,4> residual_mean{};
    std::array<float,320> raw_current{};uint ticks=0;bool collision=false;
};
static DecisionSample decision_after_prefix(Metal& metal,const challenge_evaluation::Level& level,WWorld world,
        std::vector<std::array<float,3>> route,const fixed_ppo::ActorParams& actor,const Params& residual) {
    SimConfig cfg;cfg.n=1;cfg.family=14;cfg.mode=17;cfg.eval=1;cfg.seed=level.seed;cfg.speed=1.5f;cfg.max_steps=400;cfg.geometry_memory=1;
    Sim sim(metal,cfg,1);*static_cast<WWorld*>(sim.worlds.contents)=world;std::memcpy(sim.actor.contents,actor.values.data(),sizeof(actor));
    auto& run=*static_cast<SimRun*>(sim.runs.contents);auto& state=*static_cast<RLPhysicsState*>(sim.states.contents);Memory memory;
    for(uint t=0;t<40&&!run.episodes;t++) {
        observe(metal,sim);float* obs=static_cast<float*>(sim.obs.contents);(void)forward(obs,residual,memory);
        advance_world_velocity(sim,kSensingVelocityWorld,.9f);
    }
    DecisionSample result;result.ticks=run.steps;result.collision=run.collisions>0;
    if(run.steps!=40||run.episodes)return result;
    observe(metal,sim);float* obs=static_cast<float*>(sim.obs.contents);
    for(size_t i=0;i<320;i++)result.raw_current[i]=obs[181+i];
    Memory candidate_memory=memory;result.residual_mean=forward(obs,residual,candidate_memory);result.hidden=candidate_memory.h;
    Memory base_memory;Params zero;const auto base_action=deployed(obs,actor,zero,base_memory);
    result.base_world=body_to_world({{base_action[0]*cfg.speed,base_action[1]*cfg.speed,base_action[2]*cfg.speed}},state.orientation_wxyz);
    const auto action=deployed(obs,actor,residual,memory);
    result.policy_world=body_to_world({{action[0]*cfg.speed,action[1]*cfg.speed,action[2]*cfg.speed}},state.orientation_wxyz);
    const std::array<float,3> position{{state.position[0],state.position[1],state.position[2]}};
    const auto target=teacher_target(world,route,position,run.elapsed);
    for(size_t k=0;k<3;k++)result.teacher_world[k]=target[k]-position[k];
    const float magnitude=std::sqrt(result.teacher_world[0]*result.teacher_world[0]+result.teacher_world[1]*result.teacher_world[1]+result.teacher_world[2]*result.teacher_world[2]);
    if(magnitude>1.49f)for(float& v:result.teacher_world)v*=1.49f/magnitude;
    return result;
}
static void pair_action_audit(const std::string& bank,const std::string& actor_path,const std::string& residual_path,const std::string& output) {
    std::string hash;const auto levels=challenge_evaluation::load_split(bank,"train",
        challenge_evaluation::sha256_file(std::string(SOURCE_DIR)+"/world.hpp"),hash);
    std::ifstream in(actor_path,std::ios::binary);const auto header=read_checkpoint_header(in);require(header.actor_count==fixed_ppo::actor_param_count,"pair audit actor dimensions");
    fixed_ppo::ActorParams actor;in.read(reinterpret_cast<char*>(actor.values.data()),sizeof(actor));require(bool(in),"pair audit actor truncated");
    const Params residual=load_residual(residual_path,challenge_evaluation::sha256_file(actor_path));
    Metal metal;metal.compile(base_source()+PPO_TRAINER_MSL);
    std::filesystem::create_directories(std::filesystem::path(output).parent_path());std::ofstream out(output);require(bool(out),"cannot write pair action audit");
    out<<"failure_id,base_left_world_y,policy_left_world_y,residual_left_y,teacher_left_world_y,base_right_world_y,policy_right_world_y,residual_right_y,teacher_right_world_y,raw_current_max_delta,hidden_max_delta,left_prefix_ticks,right_prefix_ticks,left_collision,right_collision,pair_opposite_policy,pair_correct_teacher_signs,bank_sha256\n";
    uint pairs=0,opposite=0,correct=0,unsafe=0;float max_hidden_delta=0,min_raw_delta=INFINITY;
    for(const auto& level:levels) {
        if(level.family!=14||level.failure_id.find("-mirror-y")!=std::string::npos)continue;
        WWorld left=level.world,right=level.world;left.goal[1]=right.goal[1]=0;
        auto left_route=level.witness_route;auto right_route=level.witness_route;
        for(uint i=0;i<left.count;i++){right.obstacles[i].center[1]=-left.obstacles[i].center[1];right.obstacles[i].velocity[1]=-left.obstacles[i].velocity[1];}
        for(auto& p:right_route)p[1]=-p[1];
        if(!left_route.empty())left_route.back()[1]=0;if(!right_route.empty())right_route.back()[1]=0;
        const auto a=decision_after_prefix(metal,level,left,left_route,actor,residual);
        const auto b=decision_after_prefix(metal,level,right,right_route,actor,residual);
        float raw_delta=0,hidden_delta=0;for(size_t i=0;i<320;i++)raw_delta=std::max(raw_delta,std::fabs(a.raw_current[i]-b.raw_current[i]));
        for(size_t i=0;i<kHidden;i++)hidden_delta=std::max(hidden_delta,std::fabs(a.hidden[i]-b.hidden[i]));
        max_hidden_delta=std::max(max_hidden_delta,hidden_delta);min_raw_delta=std::min(min_raw_delta,raw_delta);
        const bool pair_flip=a.policy_world[1]*b.policy_world[1]<0;
        const bool label_match=(a.policy_world[1]*a.teacher_world[1]>0)&&(b.policy_world[1]*b.teacher_world[1]>0);
        opposite+=pair_flip;correct+=label_match;unsafe+=a.ticks<40||b.ticks<40||a.collision||b.collision;
        out<<level.failure_id<<','<<a.base_world[1]<<','<<a.policy_world[1]<<','<<a.residual_mean[1]<<','<<a.teacher_world[1]
           <<','<<b.base_world[1]<<','<<b.policy_world[1]<<','<<b.residual_mean[1]<<','<<b.teacher_world[1]<<','<<raw_delta<<','<<hidden_delta
           <<','<<a.ticks<<','<<b.ticks<<','<<a.collision<<','<<b.collision<<','<<pair_flip<<','<<label_match<<','<<hash<<'\n';out.flush();pairs++;
    }
    std::cout<<"pair_action_audit pairs="<<pairs<<" opposite_policy="<<opposite<<" correct_teacher_signs="<<correct
             <<" min_raw_max_delta="<<min_raw_delta<<" max_hidden_delta="<<max_hidden_delta
             <<" unsafe="<<unsafe<<" output="<<output<<std::endl;
}
static constexpr size_t kParameterCount=kHidden*kInputs+kHidden*kHidden+kHidden+kHidden*4+4;
static_assert(sizeof(Params)==kParameterCount*sizeof(float),"residual parameters must be a packed float vector");
struct Adam { std::array<float,kParameterCount> first{},second{}; };
struct StepCache { std::array<float,kHidden> previous{},hidden{};std::array<float,4> residual{}; };
// The teacher label is a bounded normalized body velocity and yaw command.
// The deployed map is q=tanh(prior+gate*(mean+delta-prior)) followed by a unit
// spherical cap, and yaw=tanh(gate*(mean+delta)). Real teacher flights scale to
// at most1.49m/s, so the cap stays inactive and the label is reachable: inverting
// the map gives the residual that reproduces it exactly,
//   delta[a]=(atanh(label[a])-prior[a])/gate+prior[a]-mean[a]
//   delta[3]=atanh(label[3])/gate-mean[3]
// Regressing the residual head onto that latent target trains cancellation
// directly instead of through the saturating tanh Jacobian, which is near zero
// whenever the frozen actor strongly prefers forward motion. Labels are clipped
// just inside the open interval and the target residual is bounded, so
// saturated teacher labels are handled explicitly, not by a false exact inverse.
static constexpr float kLabelClamp=.995f;
static constexpr float kLatentBound=8.0f;
static std::array<float,4> residual_target(const SequenceRow& row,const BaseAction& base,bool& clipped) {
    std::array<float,4> target{};
    clipped=false;
    for(size_t a=0;a<3;a++) {
        const float latent=std::atanh(std::clamp(row.target[a],-kLabelClamp,kLabelClamp));
        const float prior=row.observation[kObs-3+a];
        float residual=(latent-prior)/base.gate+prior-base.mean[a];
        if(std::fabs(residual)>kLatentBound){residual=std::clamp(residual,-kLatentBound,kLatentBound);clipped=true;}
        target[a]=residual;
    }
    const float latent=std::atanh(std::clamp(row.target[3],-kLabelClamp,kLabelClamp));
    float residual=latent/base.gate-base.mean[3];
    if(std::fabs(residual)>kLatentBound){residual=std::clamp(residual,-kLatentBound,kLatentBound);clipped=true;}
    target[3]=residual;
    return target;
}
static float residual_loss_gradient(const std::array<float,4>& residual,const std::array<float,4>& target,
                                    std::array<float,4>& gradient) {
    float loss=0;
    for(size_t a=0;a<4;a++){const float error=residual[a]-target[a];loss+=.5f*error*error;gradient[a]=error;}
    return loss;
}
static std::array<float,4> residual_from_hidden(const Params& p,const std::array<float,kHidden>& h) {
    std::array<float,4> out{};
    for(size_t a=0;a<4;a++){out[a]=p.output_bias[a];for(size_t j=0;j<kHidden;j++)out[a]+=p.output[a*kHidden+j]*h[j];}
    return out;
}
static void recurrent_step(const SequenceRow& row,const Params& p,Memory& memory,StepCache* cache=nullptr) {
    if(cache)cache->previous=memory.h;
    std::array<float,kHidden> next{};
    for(size_t j=0;j<kHidden;j++) {
        float z=p.bias[j];const float* obs=row.observation.data();
        for(size_t i=0;i<kInputs;i++)z+=p.input[j*kInputs+i]*obs[i];
        for(size_t h=0;h<kHidden;h++)z+=p.recurrent[j*kHidden+h]*memory.h[h];
        next[j]=std::tanh(z);
    }
    memory.h=next;if(cache)cache->hidden=next;
}
static std::vector<std::vector<BaseAction>> cache_base_actions(const std::vector<EpisodeRows>& episodes,const std::string& checkpoint) {
    std::ifstream in(checkpoint,std::ios::binary);const auto header=read_checkpoint_header(in);
    require(header.actor_count==fixed_ppo::actor_param_count,"base actor dimensions changed");
    fixed_ppo::ActorParams actor;in.read(reinterpret_cast<char*>(actor.values.data()),sizeof(actor));require(bool(in),"base actor parameters truncated");
    std::vector<std::vector<BaseAction>> result(episodes.size());
    for(size_t e=0;e<episodes.size();e++) {
        result[e].resize(episodes[e].rows.size());
        for(size_t t=0;t<episodes[e].rows.size();t++) {
            const auto& row=episodes[e].rows[t];float hidden[fixed_ppo::hidden_dim],mean[4];
            fixed_ppo::actor_forward(row.observation.data(),actor,hidden,mean);
            BaseAction& base=result[e][t];std::copy(mean,mean+4,base.mean.begin());float open=0;
            for(size_t i=0;i<20;i++)open+=row.observation[i]*12.0f>2.5f;
            base.gate=.25f+.75f*open/20.0f;
        }
    }
    return result;
}
struct SourceScore { std::array<uint,3> success{};std::array<uint,3> episodes{}; };
static SourceScore read_source_score(const std::string& csv_path) {
    std::ifstream in(csv_path);require(bool(in),"cannot read source score");std::string line;std::getline(in,line);SourceScore score;
    while(std::getline(in,line)) {
        std::stringstream row(line);std::string field;std::vector<std::string> columns;
        while(std::getline(row,field,','))columns.push_back(field);
        require(columns.size()>5,"malformed source evaluation row");const int family=std::stoi(columns[1]);
        const size_t index=size_t(family-14);score.episodes.at(index)++;score.success.at(index)+=std::stoi(columns[4]);
    }
    return score;
}
static SourceScore evaluate_arm(const std::string& bank,const std::string& actor,const std::string& out,
                                uint update,const std::string& residual_path,uint prelude_ticks,const std::string& split) {
    const auto csv=out+"/"+split+"-"+std::to_string(update)+".csv";
    protocol_eval(bank,actor,split,csv,residual_path,prelude_ticks);const auto score=read_source_score(csv);
    std::cout<<"eval update="<<update<<" split="<<split<<" protocol="<<(prelude_ticks?"common_prelude":"original")
             <<" corners="<<score.success[0]<<'/'<<score.episodes[0]<<" rooms="<<score.success[1]<<'/'<<score.episodes[1]
             <<" vertical="<<score.success[2]<<'/'<<score.episodes[2]<<std::endl;
    return score;
}
static void train(const std::string& bank,const std::string& actor_path,const std::string& out,uint updates,
                  const std::string& runner_hash) {
    require(updates>0&&updates<=2000,"recurrent learner budget must be1..2000 updates");
    std::filesystem::create_directories(out);const std::string actor_hash=challenge_evaluation::sha256_file(actor_path);
    std::ofstream manifest(out+"/manifest.json");require(bool(manifest),"cannot write recurrent run manifest");
    manifest<<"{\"protocol\":\"common_world_y_yaw_prelude_2s_v2\",\"prelude_ticks\":40,\"flight_cap_ticks\":400,"
            <<"\"actor_sha256\":\""<<actor_hash<<"\",\"bank_sha256\":\""<<challenge_evaluation::sha256_file(bank)
            <<"\",\"world_source_sha256\":\""<<challenge_evaluation::sha256_file(std::string(SOURCE_DIR)+"/world.hpp")
            <<"\",\"runner_sha256\":\""<<runner_hash<<"\",\"observation_count\":"<<kObs
            <<",\"hidden_count\":"<<kHidden<<",\"optimizer\":\"Adam\",\"learning_rate\":0.0003,"
            <<"\"sampled_episodes_per_update\":4,\"supervision\":\"full_post_prefix_trajectory\","
            <<"\"objective\":\"inverse_map_latent_residual_mse\",\"latent_bound\":"<<kLatentBound
            <<",\"prefix_bptt_steps\":40,\"scripted_prefix_loss_masked\":true,"
            <<"\"teacher\":\"privileged_witness_route_all_families\",\"updates_requested\":"<<updates
            <<",\"families\":[14,15,16],\"failed_episodes_retained\":true,\"final_split_read\":false}\n";
    manifest.close();
    const auto episodes=collect_source(bank,actor_path,out+"/source-data");
    const auto base=cache_base_actions(episodes,actor_path);
    std::array<std::vector<size_t>,3> families;
    for(size_t e=0;e<episodes.size();e++)families.at(size_t(episodes[e].family-14)).push_back(e);
    for(const auto& indices:families)require(!indices.empty(),"source dataset is missing a family");
    Params params;std::mt19937 rng(41);std::normal_distribution<float> normal(0,1);
    for(float& w:params.input)w=normal(rng)*.0035f;
    for(size_t j=0;j<kHidden;j++)params.recurrent[j*kHidden+j]=.98f;
    Adam adam;std::ofstream history(out+"/progress.csv");require(bool(history),"cannot write recurrent progress");
    history<<"update,latent_residual_mse,clipped_rows,supervised_rows,corner_success,corner_episodes,room_success,room_episodes,vertical_success,vertical_episodes,elapsed_s\n";
    constexpr uint episodes_per_update=4,prefix_ticks=40;const double start_time=seconds();
    for(uint update=1;update<=updates;update++) {
        Params gradient;double loss_total=0;uint32_t row_count=0,clipped_count=0;
        // Two corner episodes plus one room and one vertical episode per update.
        const uint selected_family[episodes_per_update]={14,14,15,16};
        for(uint sample=0;sample<episodes_per_update;sample++) {
            const auto& pool=families[size_t(selected_family[sample]-14)];
            const size_t episode_index=pool[size_t(rng())%pool.size()];const auto& episode=episodes[episode_index];
            const auto& base_actions=base[episode_index];
            if(episode.rows.size()<=prefix_ticks)continue;
            const size_t length=episode.rows.size();
            // Burn in the whole sensing prefix from zero memory under the
            // current weights. Hidden state produced by older parameters is
            // never reused.
            Memory memory{};std::vector<StepCache> sequence;sequence.reserve(length);
            for(size_t t=0;t<length;t++) {
                StepCache cache;recurrent_step(episode.rows[t],params,memory,&cache);
                cache.residual=residual_from_hidden(params,cache.hidden);
                sequence.push_back(cache);
            }
            // Supervise every post-prefix step and backpropagate through the
            // full episode, so the scripted prefix still shapes first-turn
            // credit while the rest of the route is supervised directly.
            std::array<float,kHidden> dh{};
            for(size_t reverse=length;reverse>0;reverse--) {
                const size_t t=reverse-1;const auto& cache=sequence[t];
                std::array<float,4> direct_gradient{};
                if(t>=prefix_ticks) {
                    bool clipped=false;
                    const auto target=residual_target(episode.rows[t],base_actions[t],clipped);
                    loss_total+=residual_loss_gradient(cache.residual,target,direct_gradient);
                    row_count++;clipped_count+=clipped;
                }
                for(size_t a=0;a<4;a++) {
                    gradient.output_bias[a]+=direct_gradient[a];
                    for(size_t j=0;j<kHidden;j++) {
                        gradient.output[a*kHidden+j]+=direct_gradient[a]*cache.hidden[j];
                        dh[j]+=params.output[a*kHidden+j]*direct_gradient[a];
                    }
                }
                std::array<float,kHidden> dz{},previous{};
                for(size_t j=0;j<kHidden;j++)dz[j]=dh[j]*(1-cache.hidden[j]*cache.hidden[j]);
                for(size_t j=0;j<kHidden;j++) {
                    gradient.bias[j]+=dz[j];const float* obs=episode.rows[t].observation.data();
                    for(size_t i=0;i<kInputs;i++)gradient.input[j*kInputs+i]+=dz[j]*obs[i];
                    for(size_t h=0;h<kHidden;h++) {
                        gradient.recurrent[j*kHidden+h]+=dz[j]*cache.previous[h];
                        previous[h]+=params.recurrent[j*kHidden+h]*dz[j];
                    }
                }
                dh=previous;
            }
        }
        require(row_count>0,"recurrent batch has no source transitions");
        float* grad=reinterpret_cast<float*>(&gradient);const float inv_count=1.0f/row_count;double norm2=0;
        for(size_t i=0;i<kParameterCount;i++){grad[i]*=inv_count;norm2+=double(grad[i])*grad[i];}
        const float scale=std::min(1.0f,.5f/std::max(float(std::sqrt(norm2)),1e-8f));
        float* weight=reinterpret_cast<float*>(&params);constexpr float learning_rate=.0003f,beta1=.9f,beta2=.999f,epsilon=1e-8f;
        const float correction1=1-std::pow(beta1,float(update)),correction2=1-std::pow(beta2,float(update));
        for(size_t i=0;i<kParameterCount;i++) {
            const float g=grad[i]*scale;adam.first[i]=beta1*adam.first[i]+(1-beta1)*g;
            adam.second[i]=beta2*adam.second[i]+(1-beta2)*g*g;
            weight[i]-=learning_rate*(adam.first[i]/correction1)/(std::sqrt(adam.second[i]/correction2)+epsilon);
        }
        if(update%20==0||update==updates)
            std::cout<<"loss_curve update="<<update<<" mse="<<loss_total/std::max(1u,row_count)
                     <<" clipped="<<clipped_count<<'/'<<row_count<<std::endl;
        if(update%200==0||update==updates) {
            const std::string model=out+"/candidate-"+std::to_string(update)+".rnn";
            save_residual(model,actor_hash,params);
            const auto score=evaluate_arm(bank,actor_path,out,update,model,40,"train");
            history<<update<<','<<loss_total/std::max(1u,row_count)<<','<<clipped_count<<','<<row_count<<','
                   <<score.success[0]<<','<<score.episodes[0]<<','<<score.success[1]<<','<<score.episodes[1]<<','
                   <<score.success[2]<<','<<score.episodes[2]<<','<<seconds()-start_time<<'\n';history.flush();
            if(score.success[0]>0)evaluate_arm(bank,actor_path,out,update,model,40,"dev");
            std::cout<<"recurrent_update="<<update<<" latent_mse="<<loss_total/std::max(1u,row_count)
                     <<" clipped="<<clipped_count<<'/'<<row_count
                     <<" wall_s="<<seconds()-start_time<<" checkpoint="<<model<<std::endl;
        }
    }
}
} // namespace navigation_recurrent

#ifndef NAVIGATION_RECURRENT_EMBEDDED
int main(int argc,char** argv) {
    @autoreleasepool { try {
        if(argc==3&&std::string(argv[1])=="--check") {navigation_recurrent::check(argv[2]);return 0;}
        if((argc==6||argc==7||argc==8)&&std::string(argv[1])=="--protocol-eval") {
            navigation_recurrent::protocol_eval(argv[2],argv[3],argv[4],argv[5],
                argc>=7?argv[6]:"",argc>=8?uint(std::stoul(argv[7])):40u);return 0;
        }
        if(argc==5&&std::string(argv[1])=="--collect") {
            std::filesystem::create_directories(argv[4]);
            navigation_recurrent::collect_source(argv[2],argv[3],argv[4]);return 0;
        }
        if(argc==4&&std::string(argv[1])=="--cue-audit") {
            navigation_recurrent::cue_audit(argv[2],argv[3]);return 0;
        }
        if(argc==5&&std::string(argv[1])=="--map-check") {
            navigation_recurrent::command_map_check(argv[2],argv[3],argv[4]);return 0;
        }
        if(argc==6&&std::string(argv[1])=="--pair-action-audit") {
            navigation_recurrent::pair_action_audit(argv[2],argv[3],argv[4],argv[5]);return 0;
        }
        if(argc==6&&std::string(argv[1])=="--train") {
            navigation_recurrent::train(argv[2],argv[3],argv[4],std::stoul(argv[5]),challenge_evaluation::sha256_file(argv[0]));return 0;
        }
        require(false,"navigation_recurrent --check OUTPUT_JSON | --protocol-eval BANK CHECKPOINT train|dev OUTPUT_CSV [RESIDUAL] [PRELUDE_TICKS] | --collect BANK CHECKPOINT OUTPUT_DIR | --cue-audit BANK OUTPUT_CSV | --map-check BANK CHECKPOINT OUTPUT_CSV | --pair-action-audit BANK CHECKPOINT RESIDUAL OUTPUT_CSV | --train BANK CHECKPOINT OUTPUT_DIR UPDATES");
        return 2;
    } catch(const std::exception& e) { std::cerr<<e.what()<<'\n';return 1; } }
}
#endif
