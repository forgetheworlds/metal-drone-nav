#!/usr/bin/env python3
"""Speed x difficulty frontier experiments for mimo-next.

Owns: this file and results/mimo-speed-next/** only.
Every Metal subprocess runs under an exclusive flock on
results/metal-training.lock for its entire duration.

Subcommands:
  gate       determinism gate: rooms@1.5 bank-eval vs baseline-verify-dev.csv
  sweep      bank cap sweep (families 14/15/16, dev) + dynamic cap sweep (family 3)
  aggregate  frontier CSVs from raw outputs
  plot       labeled matplotlib figures
  budget     episode accounting vs EPISODE_BUDGET
"""

import argparse
import csv
import fcntl
import hashlib
import json
import math
import re
import statistics
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "results" / "mimo-speed-next"
RAW = OUT / "raw"
LOGS = OUT / "logs"
PLOTS = OUT / "plots"
LOCK = ROOT / "results" / "metal-training.lock"
BINARY = ROOT / "build" / "metal_nav_guided"
BANK = ROOT / "results" / "challenge-bank-mirrored-v1.jsonl"
BASELINE = ROOT / "results" / "mimo-room-learning" / "baseline-verify-dev.csv"

CHECKPOINTS = {
    "rooms": ROOT / "results" / "rooms-focused.bin.best",
    "arrival": ROOT / "results" / "arrival-open-domain.bin.best",
}

BANK_CAPS = [0.75, 1.0, 1.25, 1.5, 1.75, 2.0, 2.5, 3.0]
DYN_CAPS = [0.75, 1.0, 1.5, 2.0, 3.0]
BANK_MODE = 17
BANK_MAX_STEPS = 400
BANK_SPLIT = "dev"
DYN_FAMILY = 3
DYN_SEED = 800001
DYN_DISTANCE = 4.0
DYN_MAX_STEPS = 200
EPISODE_BUDGET = 12000
RUN_TIMEOUT_S = 900

EVAL_LINE_RE = re.compile(r"^eval family=")


def sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def cap_tag(cap):
    return f"cap{cap:.2f}"


def bank_cell_name(ckpt_name, cap):
    return f"bank-{ckpt_name}-{cap_tag(cap)}"


def dyn_cell_name(ckpt_name, cap):
    return f"dyn-{ckpt_name}-{cap_tag(cap)}"


def now_utc():
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def load_command_log():
    path = OUT / "commands.jsonl"
    if not path.exists():
        return []
    return [json.loads(line) for line in path.read_text().splitlines() if line.strip()]


def append_command_log(entry):
    with open(OUT / "commands.jsonl", "a") as f:
        f.write(json.dumps(entry) + "\n")


def run_locked(cmd, log_path):
    log_path.parent.mkdir(parents=True, exist_ok=True)
    started = now_utc()
    t0 = time.time()
    with open(LOCK, "a") as lock_file:
        fcntl.flock(lock_file, fcntl.LOCK_EX)
        try:
            proc = subprocess.run(
                [str(c) for c in cmd],
                capture_output=True,
                text=True,
                timeout=RUN_TIMEOUT_S,
            )
            wall = time.time() - t0
        finally:
            fcntl.flock(lock_file, fcntl.LOCK_UN)
    log_path.write_text(
        "$ " + " ".join(str(c) for c in cmd) + f"\n# started={started} wall_s={wall:.3f}"
        f" exit={proc.returncode}\n\n=== stdout ===\n{proc.stdout}\n=== stderr ===\n{proc.stderr}"
    )
    append_command_log({
        "ts": started,
        "argv": [str(c) for c in cmd],
        "wall_s": round(wall, 3),
        "exit": proc.returncode,
        "log": str(log_path.relative_to(ROOT)),
    })
    return proc, wall


def count_episodes():
    bank_rows = 0
    for path in sorted(RAW.glob("bank-*.csv")):
        with open(path) as f:
            bank_rows += sum(1 for _ in csv.DictReader(f))
    dyn_episodes = 0
    for path in sorted(RAW.glob("dyn-*.json")):
        dyn_episodes += json.loads(path.read_text())["episodes"]
    return bank_rows + dyn_episodes


def budget_guard(additional):
    used = count_episodes()
    after = used + additional
    if after > EPISODE_BUDGET:
        raise SystemExit(
            f"episode budget exceeded: {used} used + {additional} = {after} > {EPISODE_BUDGET}"
        )
    print(f"budget: {used} used, +{additional} this run -> {after}/{EPISODE_BUDGET}")
    return after


def update_budget_json():
    payload = {
        "updated_utc": now_utc(),
        "episodes_used": count_episodes(),
        "episodes_budget": EPISODE_BUDGET,
    }
    (OUT / "budget.json").write_text(json.dumps(payload, indent=2) + "\n")


def bank_cmd(ckpt_name, cap):
    return [
        BINARY, "bank-eval", CHECKPOINTS[ckpt_name], BANK, BANK_SPLIT,
        RAW / f"{bank_cell_name(ckpt_name, cap)}.csv",
        BANK_MODE, f"{cap}", BANK_MAX_STEPS,
    ]


def dyn_cmd(ckpt_name, cap):
    return [
        BINARY, "eval", CHECKPOINTS[ckpt_name], BANK_MODE, DYN_FAMILY, DYN_SEED,
        f"{cap}", DYN_DISTANCE, 0, 0, 0, 0, 0, DYN_MAX_STEPS,
    ]


def parse_eval_line(text):
    for line in text.splitlines():
        if EVAL_LINE_RE.match(line.strip()):
            fields = {}
            for token in line.split():
                if "=" in token:
                    k, v = token.split("=", 1)
                    fields[k] = v
            return fields, line.strip()
    return None, None


def cell_bank_done(ckpt_name, cap):
    path = RAW / f"{bank_cell_name(ckpt_name, cap)}.csv"
    if not path.exists():
        return False
    with open(path) as f:
        return sum(1 for _ in csv.DictReader(f)) == 90


def cell_dyn_done(ckpt_name, cap):
    return (RAW / f"{dyn_cell_name(ckpt_name, cap)}.json").exists()


def cmd_sweep(args):
    OUT.mkdir(parents=True, exist_ok=True)
    RAW.mkdir(exist_ok=True)
    ckpts = args.ckpts.split(",")
    arms = args.arm.split(",")
    manifest = {
        "updated_utc": now_utc(),
        "binary": str(BINARY.relative_to(ROOT)),
        "binary_sha256": sha256(BINARY),
        "bank": str(BANK.relative_to(ROOT)),
        "bank_sha256": sha256(BANK),
        "world_source_sha256": sha256(ROOT / "world.hpp"),
        "checkpoints": {n: {"path": str(p.relative_to(ROOT)), "sha256": sha256(p)}
                        for n, p in CHECKPOINTS.items()},
        "bank_caps": BANK_CAPS,
        "bank_mode": BANK_MODE,
        "bank_max_steps": BANK_MAX_STEPS,
        "bank_split": BANK_SPLIT,
        "dynamic": {"family": DYN_FAMILY, "seed": DYN_SEED, "distance_m": DYN_DISTANCE,
                    "max_steps": DYN_MAX_STEPS, "caps": DYN_CAPS},
        "episode_budget": EPISODE_BUDGET,
    }

    planned = 0
    cells = []
    if "bank" in arms:
        for ckpt in ckpts:
            for cap in args.caps or BANK_CAPS:
                if not cell_bank_done(ckpt, cap):
                    cells.append(("bank", ckpt, cap))
                    planned += 90
    if "dynamic" in arms:
        for ckpt in ckpts:
            for cap in (args.caps or DYN_CAPS):
                if not cell_dyn_done(ckpt, cap):
                    cells.append(("dynamic", ckpt, cap))
                    planned += 128

    if not cells:
        print("nothing to run: all requested cells already present")
    else:
        budget_guard(planned)

    for arm, ckpt, cap in cells:
        if arm == "bank":
            out_csv = RAW / f"{bank_cell_name(ckpt, cap)}.csv"
            tmp = Path(str(out_csv) + ".tmp")
            if tmp.exists():
                tmp.unlink()
            proc, wall = run_locked(bank_cmd(ckpt, cap), LOGS / f"{bank_cell_name(ckpt, cap)}.log")
            if proc.returncode != 0 or not out_csv.exists():
                raise SystemExit(f"bank-eval failed for {ckpt}@{cap}: exit={proc.returncode}")
            with open(out_csv) as f:
                rows = list(csv.DictReader(f))
            if len(rows) != 90:
                raise SystemExit(f"expected 90 rows for {ckpt}@{cap}, got {len(rows)}")
            successes = sum(int(r["success"]) for r in rows)
            print(f"bank {ckpt} cap={cap}: success={successes}/90 wall_s={wall:.1f}")
            if args.gate and ckpt == "rooms" and cap == 1.5:
                gate(rows)
        else:
            proc, wall = run_locked(dyn_cmd(ckpt, cap), LOGS / f"{dyn_cell_name(ckpt, cap)}.log")
            if proc.returncode != 0:
                raise SystemExit(f"eval failed for {ckpt}@{cap}: exit={proc.returncode}")
            fields, raw_line = parse_eval_line(proc.stdout)
            if fields is None:
                raise SystemExit(f"no eval aggregate line for {ckpt}@{cap}")
            payload = {
                "checkpoint": ckpt,
                "checkpoint_sha256": sha256(CHECKPOINTS[ckpt]),
                "cap": cap,
                "family": DYN_FAMILY,
                "seed": DYN_SEED,
                "distance_m": DYN_DISTANCE,
                "max_steps": DYN_MAX_STEPS,
                "budget_s": DYN_MAX_STEPS * 0.05,
                "episodes": int(fields["episodes"]),
                "success": float(fields["success"]),
                "collision": float(fields["collision"]),
                "timeout": float(fields["timeout"]),
                "progress": float(fields["progress"]),
                "mean_goal_time_s": float(fields["mean_goal_time"]),
                "mean_speed_mps": float(fields["mean_speed"]),
                "peak_speed_mps": float(fields["peak_speed"]),
                "min_clearance_m": float(fields["min_clearance"]),
                "wall_s": round(wall, 3),
                "raw_line": raw_line,
            }
            (RAW / f"{dyn_cell_name(ckpt, cap)}.json").write_text(json.dumps(payload, indent=2) + "\n")
            print(f"dyn {ckpt} cap={cap}: success={payload['success']:.4f} wall_s={wall:.1f}")

    manifest["completed_utc"] = now_utc()
    (OUT / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
    update_budget_json()
    print("sweep done")


def gate(rows):
    with open(BASELINE) as f:
        baseline = {r["failure_id"]: r for r in csv.DictReader(f)}
    mismatches = []
    numeric = ["progress", "path_m", "elapsed_s", "goal_time_s", "mean_speed_mps",
               "peak_speed_mps", "min_clearance_m"]
    for row in rows:
        base = baseline.get(row["failure_id"])
        if base is None:
            mismatches.append(f"{row['failure_id']}: missing in baseline")
            continue
        for col in ("success", "collision", "timeout"):
            if row[col] != base[col]:
                mismatches.append(f"{row['failure_id']} {col}: {row[col]} != {base[col]}")
        for col in numeric:
            a, b = row[col], base[col]
            if a == "" and b == "":
                continue
            if a == "" or b == "" or not math.isclose(float(a), float(b), rel_tol=1e-4, abs_tol=1e-4):
                mismatches.append(f"{row['failure_id']} {col}: {a} != {b}")
    if mismatches:
        print("GATE FAILED:")
        for m in mismatches[:20]:
            print("  " + m)
        raise SystemExit(f"determinism gate failed with {len(mismatches)} mismatches")
    print("GATE PASSED: rooms@1.5 exactly reproduces baseline-verify-dev.csv")


def wilson(successes, n, z=1.96):
    if n == 0:
        return (0.0, 0.0)
    p = successes / n
    denom = 1 + z * z / n
    center = p + z * z / (2 * n)
    half = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n))
    return ((center - half) / denom, (center + half) / denom)


def pct(values, q):
    if not values:
        return float("nan")
    ordered = sorted(values)
    idx = min(len(ordered) - 1, max(0, int(round(q * (len(ordered) - 1)))))
    return ordered[idx]


def polyline_len(points):
    total = 0.0
    for a, b in zip(points, points[1:]):
        total += math.dist(a, b)
    return total


def bank_cell_rows(ckpt_name, cap):
    with open(RAW / f"{bank_cell_name(ckpt_name, cap)}.csv") as f:
        return list(csv.DictReader(f))


def summarize_bank(rows, narrowness):
    n = len(rows)
    successes = [r for r in rows if int(r["success"])]
    succ = len(successes)
    collision = sum(int(r["collision"]) for r in rows)
    timeout = sum(int(r["timeout"]) for r in rows)
    goal_times = [float(r["goal_time_s"]) for r in successes if r["goal_time_s"]]
    speeds_success = [float(r["mean_speed_mps"]) for r in successes]
    speeds_all = [float(r["mean_speed_mps"]) for r in rows if r["mean_speed_mps"]]
    clearances = [float(r["min_clearance_m"]) for r in successes if r["min_clearance_m"] != ""]
    clearances_all = [float(r["min_clearance_m"]) for r in rows if r["min_clearance_m"] != ""]
    elapsed_total = sum(float(r["elapsed_s"]) for r in rows if r["elapsed_s"])
    eff_witness, eff_straight = [], []
    for r in successes:
        route = json.loads(r["witness_route_json"])
        path_m = float(r["path_m"])
        straight = math.dist(route[0], route[-1])
        if path_m > 0:
            eff_witness.append(polyline_len(route) / path_m)
            eff_straight.append(straight / path_m)
    lo, hi = wilson(succ, n)
    return {
        "episodes": n,
        "success": succ,
        "collision": collision,
        "timeout": timeout,
        "success_rate": succ / n,
        "success_rate_wilson_lo": lo,
        "success_rate_wilson_hi": hi,
        "mean_goal_time_s": statistics.fmean(goal_times) if goal_times else float("nan"),
        "median_goal_time_s": statistics.median(goal_times) if goal_times else float("nan"),
        "total_time_per_success_s": elapsed_total / succ if succ else float("nan"),
        "mean_speed_success_mps": statistics.fmean(speeds_success) if speeds_success else float("nan"),
        "mean_speed_all_mps": statistics.fmean(speeds_all) if speeds_all else float("nan"),
        "peak_speed_max_mps": max((float(r["peak_speed_mps"]) for r in rows if r["peak_speed_mps"]),
                                  default=float("nan")),
        "clearance_p10_success_m": pct(clearances, 0.10),
        "clearance_min_success_m": min(clearances) if clearances else float("nan"),
        "clearance_p10_all_m": pct(clearances_all, 0.10),
        "path_efficiency_witness_success": statistics.fmean(eff_witness) if eff_witness else float("nan"),
        "path_efficiency_straight_success": statistics.fmean(eff_straight) if eff_straight else float("nan"),
        "mean_difficulty": statistics.fmean(float(r["difficulty"]) for r in rows),
        "narrowness_values": narrowness,
    }


def cmd_aggregate(args):
    RAW.mkdir(parents=True, exist_ok=True)
    bank_params = {}
    with open(BANK) as f:
        for line in f:
            level = json.loads(line)
            if level.get("split") == BANK_SPLIT:
                bank_params[level["failure_id"]] = level["parameters"]

    per_level_path = OUT / "per-level-cap.csv"
    per_level_fields = [
        "checkpoint", "checkpoint_sha256", "cap", "failure_id", "family", "family_name",
        "difficulty", "difficulty_band", "success", "collision", "timeout", "progress",
        "path_m", "elapsed_s", "goal_time_s", "mean_speed_mps", "peak_speed_mps",
        "min_clearance_m", "lane_width_m", "door_clear_width_m",
    ]
    frontier_rows = []
    family_rows = []
    with open(per_level_path, "w", newline="") as pf:
        writer = csv.DictWriter(pf, fieldnames=per_level_fields)
        writer.writeheader()
        for ckpt_name in CHECKPOINTS:
            ckpt_sha = sha256(CHECKPOINTS[ckpt_name])
            for cap in BANK_CAPS:
                csv_path = RAW / f"{bank_cell_name(ckpt_name, cap)}.csv"
                if not csv_path.exists():
                    continue
                rows = bank_cell_rows(ckpt_name, cap)
                params = {r["failure_id"]: bank_params.get(r["failure_id"], {}) for r in rows}
                summary = summarize_bank(rows, {})
                summary.update({
                    "checkpoint": ckpt_name,
                    "checkpoint_sha256": ckpt_sha,
                    "cap": cap,
                    "bank_sha256": sha256(BANK),
                    "bank_split": BANK_SPLIT,
                    "mode": BANK_MODE,
                    "max_steps": BANK_MAX_STEPS,
                })
                summary.pop("narrowness_values")
                frontier_rows.append(summary)
                for r in rows:
                    p = params[r["failure_id"]]
                    writer.writerow({
                        "checkpoint": ckpt_name,
                        "checkpoint_sha256": ckpt_sha,
                        "cap": cap,
                        "failure_id": r["failure_id"],
                        "family": r["family"],
                        "family_name": r["family_name"],
                        "difficulty": r["difficulty"],
                        "difficulty_band": r["difficulty_band"],
                        "success": r["success"],
                        "collision": r["collision"],
                        "timeout": r["timeout"],
                        "progress": r["progress"],
                        "path_m": r["path_m"],
                        "elapsed_s": r["elapsed_s"],
                        "goal_time_s": r["goal_time_s"],
                        "mean_speed_mps": r["mean_speed_mps"],
                        "peak_speed_mps": r["peak_speed_mps"],
                        "min_clearance_m": r["min_clearance_m"],
                        "lane_width_m": p.get("lane_width_m", ""),
                        "door_clear_width_m": p.get("door_clear_width_m", ""),
                    })
                for family in (14, 15, 16):
                    fam_rows = [r for r in rows if int(r["family"]) == family]
                    fam_summary = summarize_bank(fam_rows, {})
                    fam_summary.update({
                        "checkpoint": ckpt_name,
                        "checkpoint_sha256": ckpt_sha,
                        "cap": cap,
                        "family": family,
                        "bank_sha256": sha256(BANK),
                        "bank_split": BANK_SPLIT,
                        "mode": BANK_MODE,
                        "max_steps": BANK_MAX_STEPS,
                    })
                    fam_summary.pop("narrowness_values")
                    family_rows.append(fam_summary)
                band_stats = {}
                for r in rows:
                    band = r["difficulty_band"]
                    band_stats.setdefault(band, []).append(r)
                for band, band_rows in sorted(band_stats.items()):
                    band_summary = summarize_bank(band_rows, {})
                    band_summary.update({
                        "checkpoint": ckpt_name,
                        "checkpoint_sha256": ckpt_sha,
                        "cap": cap,
                        "band": band,
                        "bank_sha256": sha256(BANK),
                        "bank_split": BANK_SPLIT,
                        "mode": BANK_MODE,
                        "max_steps": BANK_MAX_STEPS,
                    })
                    band_summary.pop("narrowness_values")
                    family_rows.append(band_summary)

    write_frontier_csv(OUT / "frontier-bank.csv", frontier_rows)
    write_frontier_csv(OUT / "frontier-bank-family.csv", family_rows)

    dyn_rows = []
    for path in sorted(RAW.glob("dyn-*.json")):
        dyn_rows.append(json.loads(path.read_text()))
    dyn_rows.sort(key=lambda r: (r["checkpoint"], r["cap"]))
    write_frontier_csv(OUT / "frontier-dynamic.csv", dyn_rows)
    print(f"aggregate: {len(frontier_rows)} overall rows, {len(family_rows)} family/band rows, "
          f"{len(dyn_rows)} dynamic rows")
    update_budget_json()


def write_frontier_csv(path, rows):
    if not rows:
        path.write_text("")
        return
    fields = []
    for row in rows:
        for key in row:
            if key not in fields:
                fields.append(key)
    with open(path, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def read_frontier(path):
    if not path.exists():
        return []
    with open(path) as f:
        return list(csv.DictReader(f))


def cmd_plot(args):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    PLOTS.mkdir(parents=True, exist_ok=True)
    manifest = json.loads((OUT / "manifest.json").read_text()) if (OUT / "manifest.json").exists() else {}
    bank_sha = manifest.get("bank_sha256", sha256(BANK))[:8]
    budget = f"bank: mode17 dev n=90/cap {BANK_MAX_STEPS} steps=20s | dynamic: family3 seed={DYN_SEED} n=128/cap {DYN_MAX_STEPS} steps=10s"
    ckpt_shas = {n: sha256(p)[:8] for n, p in CHECKPOINTS.items()}

    overall = read_frontier(OUT / "frontier-bank.csv")
    family = read_frontier(OUT / "frontier-bank-family.csv")
    dynamic = read_frontier(OUT / "frontier-dynamic.csv")
    if not overall:
        raise SystemExit("no frontier-bank.csv; run aggregate first")

    colors = {"rooms": "#1f77b4", "arrival": "#d62728"}

    def num(row, key):
        try:
            return float(row[key])
        except (KeyError, ValueError):
            return float("nan")

    families = ["ALL", 14, 15, 16]
    fig, axes = plt.subplots(2, 2, figsize=(13, 10))
    for ax, family_id in zip(axes.flat, families):
        rows = overall if family_id == "ALL" else [r for r in family if r.get("family") == str(family_id)]
        plotted = False
        for ckpt in CHECKPOINTS:
            series = sorted([r for r in rows if r["checkpoint"] == ckpt], key=lambda r: float(r["cap"]))
            if not series:
                continue
            xs = [num(r, "mean_goal_time_s") for r in series]
            ys = [num(r, "success_rate") for r in series]
            if all(math.isnan(x) for x in xs):
                total_succ = sum(int(r["success"]) for r in series)
                total_ep = sum(int(r["episodes"]) for r in series)
                ax.text(0.5, 0.5, f"{ckpt}: {total_succ}/{total_ep} successes\nat all caps (no data points)",
                        ha="center", va="center", transform=ax.transAxes, fontsize=10,
                        color=colors[ckpt])
                continue
            plotted = True
            ax.plot(xs, ys, "o-", color=colors[ckpt], label=ckpt)
            for r, x, y in zip(series, xs, ys):
                ax.annotate(cap_tag(float(r["cap"])), (x, y), fontsize=8,
                            xytext=(4, 4), textcoords="offset points")
        ax.set_xlabel("success-conditioned mean goal time [s]")
        ax.set_ylabel("success rate")
        ax.set_ylim(-0.02, 1.02)
        ax.grid(True, alpha=0.3)
        ax.set_title(f"family {family_id} frontier (bank sha {bank_sha})")
        if plotted:
            ax.legend()
    fig.suptitle(f"speed-success frontier | caps labeled | {budget}")
    fig.tight_layout()
    fig.savefig(PLOTS / "frontier_time_vs_success.png", dpi=140)
    plt.close(fig)

    fig, axes = plt.subplots(1, 3, figsize=(16, 5))
    for ckpt in CHECKPOINTS:
        series = sorted([r for r in overall if r["checkpoint"] == ckpt], key=lambda r: float(r["cap"]))
        if not series:
            continue
        caps = [num(r, "cap") for r in series]
        succ = [num(r, "success_rate") for r in series]
        lo = [num(r, "success_rate_wilson_lo") for r in series]
        hi = [num(r, "success_rate_wilson_hi") for r in series]
        coll = [num(r, "collision") / num(r, "episodes") for r in series]
        tout = [num(r, "timeout") / num(r, "episodes") for r in series]
        axes[0].plot(caps, succ, "o-", color=colors[ckpt], label=ckpt)
        axes[0].fill_between(caps, lo, hi, color=colors[ckpt], alpha=0.15)
        axes[1].plot(caps, coll, "o-", color=colors[ckpt], label=f"{ckpt} collision")
        axes[1].plot(caps, tout, "s--", color=colors[ckpt], label=f"{ckpt} timeout", alpha=0.7)
        axes[2].plot(caps, [num(r, "mean_goal_time_s") for r in series], "o-",
                     color=colors[ckpt], label=f"{ckpt} success-time")
        axes[2].plot(caps, [num(r, "total_time_per_success_s") for r in series], "s--",
                     color=colors[ckpt], alpha=0.6, label=f"{ckpt} cost/success (all episodes)")
    axes[0].set_ylabel("success rate (Wilson 95% band)")
    axes[1].set_ylabel("episode fraction")
    axes[2].set_ylabel("seconds (log)")
    axes[2].set_yscale("log")
    for ax in axes:
        ax.set_xlabel("commanded speed cap [m/s]")
        ax.grid(True, alpha=0.3)
        ax.legend(fontsize=8)
    axes[0].set_ylim(-0.02, 1.02)
    axes[1].set_ylim(-0.02, 1.02)
    fig.suptitle(f"outcome vs commanded cap | bank sha {bank_sha} | dev n=90/cap mode17 {BANK_MAX_STEPS} steps")
    fig.tight_layout()
    fig.savefig(PLOTS / "rates_vs_cap.png", dpi=140)
    plt.close(fig)

    fig, axes = plt.subplots(1, 3, figsize=(16, 5))
    for ckpt in CHECKPOINTS:
        series = sorted([r for r in overall if r["checkpoint"] == ckpt], key=lambda r: float(r["cap"]))
        if not series:
            continue
        caps = [num(r, "cap") for r in series]
        axes[0].plot(caps, [num(r, "mean_speed_success_mps") for r in series], "o-",
                     color=colors[ckpt], label=f"{ckpt} measured (successes)")
        axes[0].plot(caps, [num(r, "peak_speed_max_mps") for r in series], "^:",
                     color=colors[ckpt], alpha=0.6, label=f"{ckpt} peak max")
        axes[1].plot(caps, [num(r, "path_efficiency_witness_success") for r in series], "o-",
                     color=colors[ckpt], label=f"{ckpt} vs witness route")
        axes[1].plot(caps, [num(r, "path_efficiency_straight_success") for r in series], "s--",
                     color=colors[ckpt], alpha=0.6, label=f"{ckpt} vs straight")
        axes[2].plot(caps, [num(r, "clearance_p10_success_m") for r in series], "o-",
                     color=colors[ckpt], label=f"{ckpt} successes p10")
        axes[2].plot(caps, [num(r, "clearance_p10_all_m") for r in series], "s--",
                     color=colors[ckpt], alpha=0.6, label=f"{ckpt} all p10")
    axes[0].plot(BANK_CAPS, BANK_CAPS, "k-", alpha=0.4, label="commanded cap")
    axes[0].set_ylabel("m/s")
    axes[1].set_ylabel("path efficiency (route/path, 1.0 = direct)")
    axes[2].set_ylabel("min clearance p10 [m] (<=0 => penetration)")
    for ax in axes:
        ax.set_xlabel("commanded speed cap [m/s]")
        ax.grid(True, alpha=0.3)
        ax.legend(fontsize=8)
    fig.suptitle(f"speed binding, path efficiency, clearance | bank sha {bank_sha} | ckpts "
                 + ", ".join(f"{k}={v}" for k, v in ckpt_shas.items()))
    fig.tight_layout()
    fig.savefig(PLOTS / "speed_efficiency_clearance.png", dpi=140)
    plt.close(fig)

    if dynamic:
        fig, axes = plt.subplots(1, 2, figsize=(13, 5))
        for ckpt in CHECKPOINTS:
            series = sorted([r for r in dynamic if r["checkpoint"] == ckpt], key=lambda r: float(r["cap"]))
            if not series:
                continue
            caps = [float(r["cap"]) for r in series]
            axes[0].plot(caps, [float(r["success"]) for r in series], "o-", color=colors[ckpt], label=ckpt)
            axes[0].plot(caps, [float(r["collision"]) for r in series], "s--", color=colors[ckpt],
                         alpha=0.6, label=f"{ckpt} collision")
            axes[1].plot(caps, [float(r["mean_goal_time_s"]) for r in series], "o-",
                         color=colors[ckpt], label=f"{ckpt} goal time")
            axes[1].plot(caps, [float(r["mean_speed_mps"]) for r in series], "^:",
                         color=colors[ckpt], alpha=0.7, label=f"{ckpt} measured speed")
        axes[0].set_ylabel("episode fraction")
        axes[0].set_ylim(-0.02, 1.02)
        axes[1].set_ylabel("seconds / m/s")
        for ax in axes:
            ax.set_xlabel("commanded speed cap [m/s]")
            ax.grid(True, alpha=0.3)
            ax.legend(fontsize=8)
        fig.suptitle(f"dynamic moving-obstacle arm: family {DYN_FAMILY} seed {DYN_SEED} n=128/cap "
                     f"{DYN_MAX_STEPS} steps=10s | bank sha {bank_sha} | not in static-speed.csv")
        fig.tight_layout()
        fig.savefig(PLOTS / "dynamic_family3.png", dpi=140)
        plt.close(fig)

    per_level = read_frontier(per_level_path := OUT / "per-level-cap.csv")
    if per_level:
        interesting_caps = [1.5, 2.0, 3.0]
        fig, axes = plt.subplots(1, 2, figsize=(13, 5))
        f15 = [r for r in per_level if r["checkpoint"] == "rooms" and r["family"] == "15"
               and float(r["cap"]) in interesting_caps]
        f14 = [r for r in per_level if r["checkpoint"] == "rooms" and r["family"] == "14"
               and float(r["cap"]) in interesting_caps]
        markers = {1.5: "o", 2.0: "s", 3.0: "^"}
        for cap in interesting_caps:
            xs = [float(r["door_clear_width_m"]) for r in f15 if float(r["cap"]) == cap and r["door_clear_width_m"]]
            ys = [float(r["success"]) for r in f15 if float(r["cap"]) == cap and r["door_clear_width_m"]]
            axes[0].scatter(xs, ys, marker=markers[cap], alpha=0.6, label=f"cap={cap}")
            xs = [float(r["lane_width_m"]) for r in f14 if float(r["cap"]) == cap and r["lane_width_m"]]
            ys = [float(r["success"]) for r in f14 if float(r["cap"]) == cap and r["lane_width_m"]]
            axes[1].scatter(xs, ys, marker=markers[cap], alpha=0.6, label=f"cap={cap}")
        axes[0].set_xlabel("f15 door clear width [m]")
        axes[1].set_xlabel("f14 lane width [m]")
        for ax in axes:
            ax.set_ylabel("success (0/1)")
            ax.set_ylim(-0.1, 1.1)
            ax.grid(True, alpha=0.3)
            ax.legend(fontsize=8)
        fig.suptitle(f"narrowness vs outcome at selected caps (rooms ckpt {ckpt_shas['rooms']}) | "
                     f"bank sha {bank_sha} | dev n=90/cap")
        fig.tight_layout()
        fig.savefig(PLOTS / "narrowness_vs_outcome.png", dpi=140)
        plt.close(fig)

    print(f"wrote plots to {PLOTS}")


def cmd_budget(args):
    update_budget_json()
    print((OUT / "budget.json").read_text())


def cmd_gate(args):
    csv_path = RAW / f"{bank_cell_name('rooms', 1.5)}.csv"
    if not csv_path.exists() or args.force:
        budget_guard(90)
        proc, _ = run_locked(bank_cmd("rooms", 1.5), LOGS / f"{bank_cell_name('rooms', 1.5)}.log")
        if proc.returncode != 0:
            raise SystemExit(f"bank-eval failed: exit={proc.returncode}")
    with open(csv_path) as f:
        rows = list(csv.DictReader(f))
    if len(rows) != 90:
        raise SystemExit(f"expected 90 rows, got {len(rows)}")
    gate(rows)


def main():
    parser = argparse.ArgumentParser(description=__doc__,
                                     formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = parser.add_subparsers(dest="command", required=True)

    p_gate = sub.add_parser("gate", help="determinism gate against baseline-verify-dev.csv")
    p_gate.add_argument("--force", action="store_true", help="rerun rooms@1.5 even if present")
    p_gate.set_defaults(func=cmd_gate)

    p_sweep = sub.add_parser("sweep", help="bank + dynamic speed sweeps under flock")
    p_sweep.add_argument("--ckpts", default="rooms,arrival")
    p_sweep.add_argument("--arm", default="bank,dynamic", help="bank, dynamic, or bank,dynamic")
    p_sweep.add_argument("--caps", type=float, nargs="*", default=None,
                         help="override caps for the selected arm(s)")
    p_sweep.add_argument("--gate", action="store_true",
                         help="verify rooms@1.5 cell against baseline when it runs")
    p_sweep.set_defaults(func=cmd_sweep)

    p_agg = sub.add_parser("aggregate", help="build frontier CSVs")
    p_agg.set_defaults(func=cmd_aggregate)

    p_plot = sub.add_parser("plot", help="generate labeled plots")
    p_plot.set_defaults(func=cmd_plot)

    p_budget = sub.add_parser("budget", help="episode accounting")
    p_budget.set_defaults(func=cmd_budget)

    args = parser.parse_args()
    args.func(args)


if __name__ == "__main__":
    main()
