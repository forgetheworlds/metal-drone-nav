#!/usr/bin/env python3
"""Render an honest Blender reconstruction from Webots scene metadata and pose samples."""

import argparse
import csv
import json
import math
import sys
import subprocess
from pathlib import Path

import bpy
from mathutils import Quaternion, Vector


def read_scene(path: Path) -> dict:
    data = json.loads(path.read_text())
    if data.get("schema") == "webots-metal-scene-v1":
        return {
            "scene_name": data["scene_name"],
            "family": str(data["family_name"]),
            "start": data["start_xyz_m"],
            "goal": data["goal_xyz_m"],
            "room_bounds": data["room_bounds_m"],
            "body_radius": float(data["body_collision_radius_m"]),
            "obstacles": [
                {"kind": int(o["kind"]), "center": o["center"], "half": o["half_extent"]}
                for o in data["obstacles"]
            ],
        }
    if data.get("schema") == "webots-challenge-v1":
        obstacles = []
        for obstacle in data["obstacles"]:
            kind = obstacle["kind"]
            if kind == "box":
                half = [float(v) * 0.5 for v in obstacle["size"]]
                shape_kind = 0
            elif kind == "cylinder":
                half = [float(obstacle["radius"]), float(obstacle["radius"]), float(obstacle["height"]) * 0.5]
                shape_kind = 2
            elif kind == "sphere":
                half = [float(obstacle["radius"])] * 3
                shape_kind = 1
            else:
                raise ValueError(f"unsupported scene obstacle kind: {kind}")
            obstacles.append({"kind": shape_kind, "center": obstacle["center"], "half": half})
        return {
            "scene_name": f"challenge_{data['family']}_{data['seed']}",
            "family": str(data["family"]),
            "start": data["start_xyz_m"],
            "goal": data["goal_xyz_m"],
            "room_bounds": data.get("room_bounds_m") if data.get("bounded_room") else None,
            "body_radius": float(data["body_collision_radius_m"]),
            "obstacles": obstacles,
        }
    raise ValueError("scene metadata must use webots-metal-scene-v1 or webots-challenge-v1")


def read_trace(path: Path, episode_path: Path, stride: int) -> tuple[list[dict], dict]:
    episode = json.loads(episode_path.read_text())
    if not episode.get("success") or episode.get("collision") or episode.get("timeout"):
        raise ValueError("render_recorded_flight only renders a confirmed successful, collision-free episode")
    with path.open(newline="") as source:
        rows = list(csv.DictReader(source))
    if len(rows) < 2:
        raise ValueError("trajectory trace must contain at least two samples")
    required = ("time_s", "x", "y", "z", "q_w", "q_x", "q_y", "q_z")
    for name in required:
        if name not in rows[0]:
            raise ValueError(f"trajectory trace is missing {name}")
    for row in rows:
        values = [float(row[key]) for key in required]
        if not all(math.isfinite(value) for value in values):
            raise ValueError("trajectory contains a non-finite pose")
        norm = math.sqrt(sum(float(row[key]) ** 2 for key in ("q_w", "q_x", "q_y", "q_z")))
        if norm < 0.99 or norm > 1.01:
            raise ValueError("trajectory quaternion is not normalized")
    times = [float(row["time_s"]) for row in rows]
    if any(b <= a for a, b in zip(times, times[1:])):
        raise ValueError("trajectory timestamps must increase")
    samples = rows[::stride]
    if samples[-1] is not rows[-1]:
        samples.append(rows[-1])
    return samples, episode


def material(name: str, color: tuple[float, float, float, float], *, emission: float = 0.0,
             transparent: bool = False):
    mat = bpy.data.materials.new(name)
    mat.diffuse_color = color
    mat.use_nodes = True
    bsdf = mat.node_tree.nodes.get("Principled BSDF")
    if bsdf:
        bsdf.inputs["Base Color"].default_value = color
        bsdf.inputs["Roughness"].default_value = 0.78
        bsdf.inputs["Alpha"].default_value = color[3]
        if "Emission Color" in bsdf.inputs:
            bsdf.inputs["Emission Color"].default_value = color
            bsdf.inputs["Emission Strength"].default_value = emission
    if transparent:
        try:
            mat.surface_render_method = "BLENDED"
        except Exception:
            try:
                mat.surface_render_method = "DITHERED"
            except Exception:
                pass
    return mat


def assign(obj, mat):
    obj.data.materials.append(mat)
    return obj


def box_object(name, center, size, mat):
    bpy.ops.mesh.primitive_cube_add(size=1.0, location=center)
    obj = bpy.context.object
    obj.name = name
    obj.dimensions = size
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    return assign(obj, mat)


def cylinder_object(name, center, radius, depth, mat, vertices=24):
    bpy.ops.mesh.primitive_cylinder_add(vertices=vertices, radius=radius, depth=depth, location=center)
    obj = bpy.context.object
    obj.name = name
    return assign(obj, mat)


def wire_sphere(name, center, radius, mat, thickness=0.002):
    bpy.ops.mesh.primitive_uv_sphere_add(segments=16, ring_count=8, radius=radius, location=center)
    obj = bpy.context.object
    obj.name = name
    modifier = obj.modifiers.new("Wire envelope", "WIREFRAME")
    modifier.thickness = thickness
    modifier.use_replace = True
    obj.data.materials.append(mat)
    return obj


def curve_line(name, points, mat, thickness):
    curve = bpy.data.curves.new(name, "CURVE")
    curve.dimensions = "3D"
    curve.resolution_u = 1
    curve.bevel_depth = thickness
    curve.bevel_resolution = 1
    poly = curve.splines.new("POLY")
    poly.points.add(len(points) - 1)
    for point, xyz in zip(poly.points, points):
        point.co = (xyz[0], xyz[1], xyz[2], 1.0)
    obj = bpy.data.objects.new(name, curve)
    bpy.context.collection.objects.link(obj)
    obj.data.materials.append(mat)
    return obj


def clear_scene():
    bpy.ops.object.select_all(action="SELECT")
    bpy.ops.object.delete(use_global=False)
    for datablocks in (bpy.data.meshes, bpy.data.curves, bpy.data.materials, bpy.data.cameras, bpy.data.lights):
        for block in list(datablocks):
            if block.users == 0:
                datablocks.remove(block)


def create_room(scene_data, world_path: Path | None, mats):
    bounds = scene_data["room_bounds"]
    if bounds:
        x0, x1 = map(float, bounds["x"])
        y0, y1 = map(float, bounds["y"])
        z0, z1 = map(float, bounds["z"])
        floor_size = (x1 - x0, y1 - y0)
        floor_center = ((x0 + x1) * 0.5, (y0 + y1) * 0.5, z0 - 0.035)
        wall_t = 0.1
        box_object("Room floor", floor_center, (floor_size[0], floor_size[1], 0.07), mats["floor"])
        # Cutaway walls show the bounded-room geometry without hiding flight.
        box_object("Cutaway west boundary", (x0 - wall_t * .5, (y0+y1)*.5, (z0+z1)*.5), (wall_t, floor_size[1], z1-z0), mats["wall"])
        box_object("Cutaway east boundary", (x1 + wall_t * .5, (y0+y1)*.5, (z0+z1)*.5), (wall_t, floor_size[1], z1-z0), mats["wall"])
        box_object("Cutaway south boundary", ((x0+x1)*.5, y0-wall_t*.5, (z0+z1)*.5), (floor_size[0], wall_t, z1-z0), mats["wall"])
        box_object("Cutaway north boundary", ((x0+x1)*.5, y1+wall_t*.5, (z0+z1)*.5), (floor_size[0], wall_t, z1-z0), mats["wall"])
        box_object("Cutaway ceiling", ((x0+x1)*.5, (y0+y1)*.5, z1+wall_t*.5), (floor_size[0], floor_size[1], wall_t), mats["wall"])
        return {"x": [x0, x1], "y": [y0, y1], "z": [z0, z1], "bounds_are_walls": True}

    # The legacy doorway scenes have a finite floor but no side walls. Read its
    # actual first floor Solid from route.wbt and label its edge as a view frame.
    if world_path is None:
        raise ValueError("unbounded scene metadata requires the exact route.wbt to recover its floor extent")
    source = world_path.read_text()
    match = __import__("re").search(
        r"Solid\s*\{\s*translation\s+([-+\deE.]+)\s+([-+\deE.]+)\s+([-+\deE.]+).*?geometry Box\s*\{\s*size\s+([-+\deE.]+)\s+([-+\deE.]+)\s+([-+\deE.]+)",
        source, flags=__import__("re").S)
    if not match:
        raise ValueError("cannot read the finite floor Solid from route.wbt")
    cx, cy, cz, sx, sy, sz = map(float, match.groups())
    z0 = cz + sz * .5
    bounds = {"x": [cx - sx*.5, cx + sx*.5], "y": [cy - sy*.5, cy + sy*.5], "z": [z0, z0+5]}
    box_object("Webots floor", (cx, cy, cz), (sx, sy, sz), mats["floor"])
    return {**bounds, "bounds_are_walls": False}


def add_obstacles(obstacles, mats):
    for i, obstacle in enumerate(obstacles):
        kind, center, half = obstacle["kind"], list(map(float, obstacle["center"])), list(map(float, obstacle["half"]))
        if kind == 0:
            box_object(f"Bank obstacle {i:02d} AABB", center, [2*v for v in half], mats["obstacle"])
        elif kind == 1:
            bpy.ops.mesh.primitive_uv_sphere_add(segments=20, ring_count=12, radius=half[0], location=center)
            assign(bpy.context.object, mats["obstacle"])
            bpy.context.object.name = f"Bank obstacle {i:02d} sphere"
        elif kind == 2:
            cylinder_object(f"Bank obstacle {i:02d} vertical cylinder", center, half[0], 2*half[2], mats["obstacle"])
        else:
            raise ValueError(f"unsupported obstacle kind: {kind}")


def build_drone(scene_data, samples, episode, mats):
    bpy.ops.object.empty_add(type="PLAIN_AXES", location=(0, 0, 0))
    rig = bpy.context.object
    rig.name = "Recorded Webots quadrotor pose"
    body = box_object("CF-scaled chassis 60mm", (0,0,0), (.060,.060,.014), mats["drone_body"])
    body.parent=rig;body.location=(0,0,0)
    arm_x = box_object("CF-scaled x arm 84mm", (0,0,0), (.084,.008,.008), mats["drone_arm"])
    arm_x.parent=rig;arm_x.location=(0,0,0)
    arm_y = box_object("CF-scaled y arm 84mm", (0,0,0), (.008,.084,.008), mats["drone_arm"])
    arm_y.parent=rig;arm_y.location=(0,0,0)
    for i,(x,y) in enumerate(((.028,-.028),(-.028,-.028),(-.028,.028),(.028,.028))):
        hub=cylinder_object(f"Motor hub {i}",(0,0,0),.006,.012,mats["drone_hub"])
        hub.parent=rig;hub.location=(x,y,0)
        prop=cylinder_object(f"45-50mm swept prop visual {i}",(0,0,0),.025,.001,mats["prop"])
        prop.parent=rig;prop.location=(x,y,0)
    envelope=wire_sphere("Historical 0.18m safety envelope",(0,0,0),float(scene_data["body_radius"]),mats["safety"],.002)
    envelope.parent=rig;envelope.location=(0,0,0)
    for frame, row in enumerate(samples,1):
        rig.location=(float(row["x"]),float(row["y"]),float(row["z"]))
        rig.rotation_mode="QUATERNION"
        rig.rotation_quaternion=Quaternion((float(row["q_w"]),float(row["q_x"]),float(row["q_y"]),float(row["q_z"])))
        rig.keyframe_insert(data_path="location",frame=frame,group="Recorded Webots samples")
        rig.keyframe_insert(data_path="rotation_quaternion",frame=frame,group="Recorded Webots samples")
    return rig


def main():
    argv=sys.argv[sys.argv.index("--")+1:] if "--" in sys.argv else []
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--metadata",type=Path,required=True)
    parser.add_argument("--trace",type=Path,required=True)
    parser.add_argument("--episode",type=Path,required=True)
    parser.add_argument("--world",type=Path)
    parser.add_argument("--output",type=Path,required=True)
    parser.add_argument("--preview",type=Path,required=True)
    parser.add_argument("--stride",type=int,default=5,help="use every fifth 100Hz Webots pose for 20fps; no pose interpolation")
    parser.add_argument("--width",type=int,default=1280)
    parser.add_argument("--height",type=int,default=720)
    parser.add_argument("--fps",type=int,default=20)
    parser.add_argument("--preview-only",action="store_true",help="render one representative PNG without encoding the MP4")
    args=parser.parse_args(argv)
    if args.stride<1 or args.fps<1: raise ValueError("stride and fps must be positive")
    scene_data=read_scene(args.metadata)
    episode=json.loads(args.episode.read_text())
    if not episode.get("success") or episode.get("collision") or episode.get("timeout"):
        raise ValueError("only successful, collision-free Webots runs can be rendered as success videos")
    with args.trace.open(newline="") as source:
        all_rows=list(csv.DictReader(source))
    if len(all_rows)<2: raise ValueError("trajectory trace has fewer than two samples")
    columns=set(all_rows[0])
    required={"time_s","x","y","z","q_w","q_x","q_y","q_z"}
    if not required.issubset(columns): raise ValueError(f"trace misses pose columns: {sorted(required-columns)}")
    samples=all_rows[::args.stride]
    if samples[-1] is not all_rows[-1]: samples.append(all_rows[-1])
    for sample in samples:
        values=[float(sample[k]) for k in required]
        if not all(math.isfinite(v) for v in values): raise ValueError("trace contains a non-finite pose")
    if len(samples)<2: raise ValueError("downsampled flight trace is too short")
    sampled_times=[float(row["time_s"]) for row in samples]
    if any(b<=a for a,b in zip(sampled_times,sampled_times[1:])): raise ValueError("trace times must increase")

    clear_scene()
    scene=bpy.context.scene
    scene.render.engine="BLENDER_EEVEE"
    scene.render.resolution_x=args.width;scene.render.resolution_y=args.height;scene.render.resolution_percentage=100
    scene.render.fps=args.fps;scene.render.fps_base=1.0
    scene.frame_start=1;scene.frame_end=len(samples)
    scene.render.image_settings.color_mode="RGBA"
    scene.world.color=(.025,.035,.055)
    scene.render.film_transparent=False
    scene.view_settings.view_transform="AgX"

    mats={
        "floor":material("Warm concrete floor",(.14,.19,.24,1)),
        "wall":material("Cutaway room boundary",(.16,.32,.44,.16),transparent=True),
        "obstacle":material("Exact Webots obstacle, cutaway",(.78,.31,.12,.32),transparent=True),
        "drone_body":material("Quadrotor chassis",(.06,.75,.72,1),emission=.3),
        "drone_arm":material("Quadrotor arms",(.03,.20,.24,1)),
        "drone_hub":material("Motor hubs",(.92,.74,.22,1),emission=.3),
        "prop":material("Swept propeller visuals",(.90,.91,.91,.50),transparent=True),
        "safety":material("0.18m safety envelope",(1,.57,.05,.85),emission=.6),
        "goal":material("Goal region",(.20,1,.35,.8),emission=.6),
        "path":material("Recorded path",(.08,.90,1,1),emission=.8),
        "text":material("Overlay text",(1,1,1,1),emission=1.0),
    }
    bounds=create_room(scene_data,args.world,mats)
    add_obstacles(scene_data["obstacles"],mats)
    goal=Vector(scene_data["goal"])
    wire_sphere("0.35m Webots goal-entry region",goal,.35,mats["goal"],.005)
    bpy.ops.mesh.primitive_uv_sphere_add(segments=16,ring_count=8,radius=.045,location=goal)
    assign(bpy.context.object,mats["goal"]);bpy.context.object.name="Goal center marker"
    path_points=[(float(r["x"]),float(r["y"]),float(r["z"])) for r in all_rows]
    curve_line("Recorded Webots position trace",path_points,mats["path"],.008)
    rig=build_drone(scene_data,samples,episode,mats)

    # Scene lighting is soft and readable on the transparent cutaway obstacles.
    bpy.ops.object.light_add(type="AREA",location=(3,-5,10))
    key=bpy.context.object;key.data.energy=1800;key.data.shape="DISK";key.data.size=8
    key.rotation_euler=(math.radians(22),0,math.radians(24))
    bpy.ops.object.light_add(type="AREA",location=(8,4,7))
    fill=bpy.context.object;fill.data.energy=950;fill.data.size=7
    fill.rotation_euler=(math.radians(12),0,math.radians(-145))

    # A fixed three-quarter overview keeps the door frame/table and the whole
    # recorded route in view. The camera does not invent or smooth flight data.
    frame_points=[Vector(scene_data["start"]),Vector(scene_data["goal"])]
    frame_points.extend(Vector((float(r["x"]),float(r["y"]),float(r["z"]))) for r in all_rows)
    for obstacle in scene_data["obstacles"]:
        center=Vector(obstacle["center"]);half=obstacle["half"]
        if obstacle["kind"]==0:
            frame_points.extend(center+Vector((sx*half[0],sy*half[1],sz*half[2]))
                                for sx in (-1,1) for sy in (-1,1) for sz in (-1,1))
        else:
            extent=Vector((half[0],half[0],half[2] if obstacle["kind"]==2 else half[0]))
            frame_points.extend((center-extent,center+extent))
    if bounds["bounds_are_walls"]:
        frame_points.extend(Vector((x,y,z)) for x in bounds["x"] for y in bounds["y"] for z in bounds["z"])
    low=Vector(tuple(min(p[i] for p in frame_points) for i in range(3)))
    high=Vector(tuple(max(p[i] for p in frame_points) for i in range(3)))
    target=(low+high)*.5
    span=max(high.x-low.x,high.y-low.y,high.z-low.z,3.0)
    direction=Vector((-0.72,-1.0,0.68)).normalized()
    bpy.ops.object.camera_add(location=target+direction*span*2.0)
    camera=bpy.context.object;camera.name="Static three-quarter scene overview";camera.data.type="ORTHO";camera.data.clip_end=250
    camera.rotation_euler=(target-camera.location).to_track_quat("-Z","Y").to_euler()
    scene.camera=camera
    # Fit the recorded route and geometry to the camera's actual projected box.
    bpy.context.view_layer.update();inverse=camera.matrix_world.inverted()
    projected=[inverse@point for point in frame_points]
    width=max(p.x for p in projected)-min(p.x for p in projected)
    height=max(p.y for p in projected)-min(p.y for p in projected)
    camera.data.ortho_scale=max(width,height*(args.width/args.height))*1.12

    # Parent the title/captions to the camera so the provenance stays visible.
    def overlay(name,text,local_location,size):
        bpy.ops.object.text_add(location=(0,0,0))
        obj=bpy.context.object;obj.name=name;obj.data.body=text;obj.data.size=size;obj.data.extrude=0
        obj.data.materials.append(mats["text"]);obj.parent=camera;obj.location=local_location
        obj.rotation_euler=(0,0,0)
        return obj
    view_width=camera.data.ortho_scale
    view_height=view_width*args.height/args.width
    left=-view_width*.47;top=view_height*.44;bottom=-view_height*.44
    overlay("Title overlay",f"WEBOTS FLIGHT RECONSTRUCTION  |  {scene_data['family']}",(left,top,-10.0),view_width*.012)
    overlay("Success overlay",f"Recorded result: SUCCESS  |  {float(episode['time_s']):.2f}s  |  {float(episode['path_m']):.1f}m path",(left,top-view_width*.027,-10.0),view_width*.009)
    overlay("Truth note overlay","Rendered from recorded Webots physics; not camera footage.",(left,bottom,-10.0),view_width*.008)
    overlay("Model note overlay","Orange wire: 0.18m collision envelope  |  solids are translucent cutaways of exact Webots geometry",(left,bottom-view_width*.020,-10.0),view_width*.006)
    if not bounds["bounds_are_walls"]:
        overlay("Open floor bounds overlay","Outer line is the floor extent; this scene has no perimeter walls.",(left,bottom-view_width*.034,-10.0),view_width*.005)

    scene.render.image_settings.file_format="PNG"
    args.preview.parent.mkdir(parents=True,exist_ok=True)
    preview_frame=max(1,min(len(samples),int(len(samples)*.45)))
    scene.frame_set(preview_frame);scene.render.filepath=str(args.preview)
    bpy.ops.render.render(write_still=True)
    if args.preview_only:
        print(f"PREVIEW scene={scene_data['scene_name']} success={episode['success']} frame={preview_frame} output={args.preview}")
        return
    args.output.parent.mkdir(parents=True,exist_ok=True)
    frames_dir=args.output.parent/(args.output.stem+"-frames")
    frames_dir.mkdir(parents=True,exist_ok=True)
    scene.render.image_settings.file_format="PNG"
    scene.render.filepath=str(frames_dir/"frame_")
    bpy.ops.render.render(animation=True)
    subprocess.run(["/opt/homebrew/bin/ffmpeg","-y","-v","error","-framerate",str(args.fps),
        "-start_number","1","-i",str(frames_dir/"frame_%04d.png"),"-c:v","libx264",
        "-crf","20","-pix_fmt","yuv420p","-movflags","+faststart",str(args.output)],check=True)
    if not args.output.is_file() or args.output.stat().st_size<100_000:
        raise RuntimeError("Blender did not produce a usable MP4")
    print(f"RENDERED scene={scene_data['scene_name']} success={episode['success']} samples={len(samples)} fps={args.fps} output={args.output} preview={args.preview}")


if __name__ == "__main__":
    main()
