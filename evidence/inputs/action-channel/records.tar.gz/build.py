from pathlib import Path
import hashlib,json,subprocess
ROOT=Path('/Users/muadhsambul/RL')
WORK=Path('/Users/muadhsambul/.codex/worktrees/navigation-actor-capacity/RL')
OUT=ROOT/'results/root-action-channel'
source=(WORK/'navigation_critic_training.mm').read_text()
source=source.replace('namespace waypoint {','''namespace waypoint {
// Root-only frozen output-channel intervention. Production source is unchanged.
static id<MTLBuffer> channel_reference=nil, channel_means=nil, channel_mode=nil;
static id<MTLComputePipelineState> channel_select=nil;
''',1)
needle='''                         sim.env_count,sim.cfg.n);
    if(run.action_transform)'''
insert='''                         sim.env_count,sim.cfg.n);
    if(channel_reference) {
        encode_actor_forward(sim.m,cb,sim.wide_actor,sim.simd_actor,sim.obs,row_offset*fixed_ppo::actor_obs_dim*4,
                             channel_reference,sim.actor_workspace,channel_means,0,sim.env_count,sim.cfg.n);
        sim.m.dispatch(cb,channel_select,sim.cfg.n,{sim.actions,channel_means,c,channel_mode},64);
    }
    if(run.action_transform)'''
assert source.count(needle)==1
source=source.replace(needle,insert)
(OUT/'trainer_channel.mm').write_text(source)
s=(WORK/'navigation_stress_eval.mm').read_text()
s=s.replace('#include "navigation_critic_training.mm"','#include "trainer_channel.mm"')
s=s.replace('return base_source() + PPO_TRAINER_MSL + waypoint::kWaypointKernels;', '''return base_source() + PPO_TRAINER_MSL + waypoint::kWaypointKernels + R"MSL(
kernel void root_select_channel(device float* actions [[buffer(0)]],
                                device const float* reference [[buffer(1)]],
                                constant SimConfig& cfg [[buffer(2)]],
                                constant uint& component [[buffer(3)]],
                                uint n [[thread_position_in_grid]]) {
    if(n>=cfg.n)return;
    const uint row=(cfg.tick*cfg.n+n)*4;
    for(uint axis=0;axis<4;axis++) {
        if((component==1 && axis==3) || (component==2 && axis<3))actions[row+axis]=reference[n*4+axis];
    }
}
)MSL";''')
s=s.replace('require(argc==5||argc==6,"stress_eval CHECKPOINT BANK OUT_CSV PROFILE [TRACE_CSV]");','require(argc==7,"channel_eval EARLY FULL BANK OUT_CSV COMPONENT PROFILE");')
s=s.replace('checkpoint=argv[1],bank_path=argv[2],output=argv[3],profile=argv[4]', 'checkpoint=argv[2],bank_path=argv[3],output=argv[4],profile=argv[6]')
s=s.replace('    navigation_training::load_actor(sim,checkpoint,false);','''    navigation_training::load_actor(sim,checkpoint,false);
    const std::string component=argv[5];
    require(component=="full"||component=="early-yaw"||component=="early-xyz","unknown component");
    if(component!="full") {
        std::ifstream file(argv[1],std::ios::binary);const auto header=read_checkpoint_header(file);
        require(header.actor_count==fixed_ppo::actor_param_count,"reference actor width mismatch");
        std::vector<float> actor(header.actor_count);file.read((char*)actor.data(),actor.size()*4);
        require(bool(file),"truncated reference actor");
        waypoint::channel_reference=metal.buffer(actor.size()*4,actor.data());
        waypoint::channel_means=metal.buffer(cfg.n*4*4);
        uint32_t component_id=component=="early-yaw"?1:2;
        waypoint::channel_mode=metal.buffer(sizeof(component_id),&component_id);
        waypoint::channel_select=metal.pipeline("root_select_channel");
    }''')
(OUT/'channel_eval.mm').write_text(s)
command=['/usr/bin/c++','-O3','-DNDEBUG','-std=gnu++17','-arch','arm64','-fobjc-arc','-Wno-unused-function',f'-DSOURCE_DIR="{WORK}"','-DFIXED_PPO_ACTOR_OBS_DIM=184','-DFIXED_PPO_CRITIC_OBS_DIM=64','-DFIXED_PPO_ACTOR_HIDDEN_DIM=2560','-DFIXED_PPO_CRITIC_HIDDEN_DIM=64','-DNAV_SENSOR_PROFILE=1','-DNAV_CRITIC_CONTROL_STATE=1','-DNAV_DELAY_REHEARSAL=1',f'-I{OUT}',f'-I{WORK}',str(OUT/'channel_eval.mm'),'-o',str(OUT/'channel_eval'),'-framework','Foundation','-framework','Metal','-framework','Accelerate']
r=subprocess.run(command,capture_output=True,text=True)
assert r.returncode==0,r.stderr
hashes={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in [WORK/'navigation_critic_training.mm',WORK/'navigation_stress_eval.mm',OUT/'trainer_channel.mm',OUT/'channel_eval.mm',OUT/'channel_eval',OUT/'decision.md']}
(OUT/'freeze.json').write_text(json.dumps({'argv':command,'hashes':hashes},indent=2)+'\n')
print('CHANNEL_EVAL_BUILT')
