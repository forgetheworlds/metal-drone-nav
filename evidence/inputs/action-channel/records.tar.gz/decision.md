# Output-channel intervention — frozen development diagnosis

The original goal remains incomplete. No new learner, reward or curriculum is
introduced. The completed update audit does not justify repeating advantage
winsorization: an earlier test of radius 3 already harmed learning. Gradient
norm clipping before Adam also does not set a fixed parameter-step size, and
near-orthogonal updates do not prove noise. Root found the probe's policy-active
threshold compares log ratios against +/-0.2 rather than probability ratios
against 0.8/1.2; the learner itself uses the correct thresholds.

A more direct intervention follows the measured same-state change: yaw means
change by about 0.55 latent units from useful early actors to full actors, larger
than each translation channel. Test whether restoring the early actor's yaw
OUTPUT at the current observations recovers course navigation. Compare with
restoring its XYZ outputs. Both frozen actors see the exact same deployable
observation on every tick; no ground-truth route, witness or outcome enters.
The geometry gate, tanh, reference adapter, RAPTOR and motors stay unchanged.
Two-network composition is a causal diagnostic, not the delivery architecture.

Initial cases: two training seeds, existing nominal composite DEV, early-yaw and
early-XYZ interventions. Reuse preserved early/full actor grades after proving
reference and identical-actor byte parity on the same scored flights. No task
filtering. Keep successes, contacts, timeouts, shared arrival time, rescued and
newly lost tasks. Require at least half of the full actor's early-solved losses
recovered in BOTH seeds with no greater than three new losses per seed before
calling one channel a strong candidate. A failure rejects that attribution.
Broader static/open/long and delay probes follow only a positive channel result.

No promotion. Even a successful intervention must become one learned policy and
retain speed, broad capability and independent transfer. Preserve all source,
commands, hashes and receipts. All runs use the absolute root GPU lock.
