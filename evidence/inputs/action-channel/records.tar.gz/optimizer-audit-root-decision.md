# Root review of the bounded optimizer audit

The mission is terminal, exit 0. Four cloned saved learners completed sixteen
actual updates each. Default instrument-off resume checks match the original
checkpoints. The core learner and original actors remain unchanged.

Do not launch the proposed advantage cap. The earlier RESEARCH_TRAINING report
records radius 3 harming its tested setting. Current gradient concentration is
a measurement, not proof it causes erosion. Reward-carrying failure rows should
often have large gradients; removing them can weaken avoidance.

Root found an instrument-only policy-active error: it compares log ratio to
+/-0.2 instead of comparing ratio to 0.8/1.2. Saved-row replay changes 188-359
labels per 16,384-row dump. Actual ppo_sample_loss_grad uses correct thresholds.
The cap comparison's checkpoints_identical field also merely compares minibatch
offsets; checkpoint byte hashes need an independent check.

Global gradient clipping occurs before Adam. It bounds gradient norm, not a
fixed parameter or functional step. Near-orthogonal updates do not establish
noise; extrapolating sixteen update norms to all 2,304 updates is not measured
path length. Gradients projected onto an Adam update are not an additive causal
share of that update. Advantage clipping affects log-std policy derivatives,
so its exploration effects are not established neutral.

Root now tests output-channel interventions directly in results/root-action-channel.
The large same-state yaw change alone does not make yaw the cause. Both actors
read the same observations; restore early yaw or early XYZ outputs separately,
keeping guidance, delays, physics, RAPTOR and scoring fixed. No new learning yet.
