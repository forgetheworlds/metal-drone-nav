from pathlib import Path
import hashlib,json,shutil,struct,tarfile
ROOT=Path('/Users/muadhsambul/RL');OUT=ROOT/'results/root-action-channel';A=ROOT/'results/omp-actor-step';DEST=ROOT/'evidence/inputs/action-channel';STAGE=OUT/'public-records'
STAGE.mkdir(exist_ok=True);(STAGE/'models').mkdir(exist_ok=True)
for p in OUT.iterdir():
 if p.is_file() and p.suffix in ['.csv','.json','.mm','.py','.md','.log']:
  shutil.copyfile(p,STAGE/p.name)
for seed in [1,2]:
 for stage,name in [('early',f'w2560-as04-s{seed}.bin.at-256.model.bin'),('full',f'w2560-as04-s{seed}.bin')]:
  source=A/'runs'/name;data=source.read_bytes();actor,critic=struct.unpack_from('<2I',data,12)
  (STAGE/'models'/f'{stage}-s{seed}.bin').write_bytes(data[:136+4*(actor+critic)])
  for prefix in ['pilot' if stage=='early' else 'full']:
   for panel,profile in [('composite','nominal'),('open','nominal'),('long-open','nominal'),('dev-b','nominal'),('fresh-course-reflected','both-delay'),('fresh-course-reflected','combined')]:
    p=A/f'{prefix}-evals/w2560-as04-s{seed}-{panel}-{profile}.csv'
    shutil.copyfile(p,STAGE/f'{stage}-s{seed}-{panel}-{profile}.csv')
 shutil.copyfile(OUT/f'composed-s{seed}.bin',STAGE/'models'/f'composed-s{seed}.bin')
shutil.copyfile(ROOT/'navigation_compose_checkpoint.py',STAGE/'navigation_compose_checkpoint.py')
shutil.copyfile(ROOT/'results/root-update-mechanism-review/decision.md',STAGE/'optimizer-audit-root-decision.md')
shutil.copyfile(ROOT/'results/root-update-mechanism-review/policy-active-correction.json',STAGE/'policy-active-correction.json')
manifest={str(p.relative_to(STAGE)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(STAGE.rglob('*')) if p.is_file() and p.name!='SHA256.json'}
(STAGE/'SHA256.json').write_text(json.dumps(manifest,indent=2)+'\n')
DEST.mkdir(parents=True,exist_ok=True)
with tarfile.open(DEST/'records.tar.gz','w:gz') as archive:
 for p in sorted(STAGE.rglob('*')):
  if p.is_file():archive.add(p,arcname=str(p.relative_to(STAGE)),recursive=False)
print('ACTION_CHANNEL_BUNDLE',len(manifest),'records', (DEST/'records.tar.gz').stat().st_size,'bytes')
