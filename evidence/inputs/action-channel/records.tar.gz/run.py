"""Run one bounded frozen action-channel intervention, retaining all flights."""
from pathlib import Path
import csv,hashlib,json,subprocess,time
ROOT=Path('/Users/muadhsambul/RL');OUT=ROOT/'results/root-action-channel';ACTOR=ROOT/'results/omp-actor-step'
BANK=ROOT/'results/root-motion-fidelity/dev/challenges.bin';BIN=OUT/'channel_eval'
receipts=[]
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def execute(seed,component,identity=False):
 early=ACTOR/'runs'/f'w2560-as04-s{seed}.bin.at-256.model.bin';full=ACTOR/'runs'/f'w2560-as04-s{seed}.bin'
 if identity:early=full
 tag=f's{seed}-{component}'+('-identity' if identity else '')
 output=OUT/(tag+'.csv');log=OUT/(tag+'.log')
 assert not output.exists(),f'Existing run {output}; never overwrite'
 argv=['python3',str(ROOT/'run_locked.py'),'--',str(BIN),str(early),str(full),str(BANK),str(output),component,'nominal']
 r={'tag':tag,'seed':seed,'component':component,'identity':identity,'argv':argv,'model_hashes':{'early':sha(early),'full':sha(full)},'bank_sha256':sha(BANK),'binary_sha256':sha(BIN)}
 start=time.monotonic()
 with log.open('w') as file:
  process=subprocess.Popen(argv,stdout=file,stderr=subprocess.STDOUT);r['pid']=process.pid
  receipts.append(r);(OUT/'receipts.json').write_text(json.dumps(receipts,indent=2)+'\n')
  r['exit']=process.wait()
 r['wall_s']=time.monotonic()-start
 assert r['exit']==0,log.read_text()
 r['csv_sha256']=sha(output);r['csv']=str(output);(OUT/'receipts.json').write_text(json.dumps(receipts,indent=2)+'\n')
 print(tag,'exit',r['exit'],'wall',round(r['wall_s'],3),flush=True)
 return output
# Current binary reference and identical-actor teacher dispatch must preserve ALL
# scored flight fields and exact plant bytes against the existing completed grade.
reference=execute(1,'full')
identity=execute(1,'early-yaw',True)
retained=ACTOR/'full-evals/w2560-as04-s1-composite-nominal.csv'
assert reference.read_bytes()==retained.read_bytes(),'Reference CSV diverges from preserved endpoint'
assert identity.read_bytes()==reference.read_bytes(),'Same-actor channel dispatch changes scored flights'
assert sha(str(identity)+'.physics.bin')==sha(str(reference)+'.physics.bin')
(OUT/'parity.json').write_text(json.dumps({'reference_vs_preserved_csv_exact':True,'identity_vs_reference_csv_exact':True,'identity_plant_exact':True,'cached_csv_sha256':sha(retained)},indent=2)+'\n')
for seed in [1,2]:
 for component in ['early-yaw','early-xyz']:execute(seed,component)
print('CHANNEL_INTERVENTION_COMPLETE',len(receipts),'actual panels',flush=True)
