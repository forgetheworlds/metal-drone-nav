"""Verify the single MLP against every scored dual-channel diagnostic flight."""
from pathlib import Path
import json,subprocess,time,hashlib,csv
ROOT=Path('/Users/muadhsambul/RL');OUT=ROOT/'results/root-action-channel'
base=json.loads((OUT/'receipts.json').read_text());broad=json.loads((OUT/'retention-receipts.json').read_text())
cases=[r for r in base if r['component']=='early-xyz']+broad
receipts=[]
for r in cases:
 seed=r['seed'] if 'seed' in r else int(r['tag'][1]);old=r['argv'];bank=old[-4];profile=old[-1];model=OUT/f'composed-s{seed}.bin'
 path=OUT/(r['tag']+'-single.csv');assert not path.exists()
 argv=['python3',str(ROOT/'run_locked.py'),'--',str(OUT/'channel_eval_w5120'),str(model),str(model),bank,str(path),'full',profile]
 start=time.monotonic();log=path.with_suffix('.log')
 entry={'tag':r['tag'],'argv':argv,'binary_sha256':hashlib.sha256((OUT/'channel_eval_w5120').read_bytes()).hexdigest(),'model_sha256':hashlib.sha256(model.read_bytes()).hexdigest()}
 with log.open('w') as f:
  p=subprocess.Popen(argv,stdout=f,stderr=subprocess.STDOUT);entry['pid']=p.pid;receipts.append(entry);(OUT/'composed-receipts.json').write_text(json.dumps(receipts,indent=2)+'\n');entry['exit']=p.wait()
 entry['wall_s']=time.monotonic()-start;assert entry['exit']==0,log.read_text()
 reference=Path(r.get('csv',str(OUT/(r['tag']+'.csv'))))
 a=list(csv.DictReader(reference.open()));b=list(csv.DictReader(path.open()));assert len(a)==len(b)==128
 keys=['success','collision','timeout'];entry['outcomes_identical']=all(x[k]==y[k] for x,y in zip(a,b) for k in keys)
 numeric=['time_s','path_m','peak_speed_mps','min_clearance_m','final_x','final_y','final_z','final_distance_m','final_speed_mps','stable_hold_s']
 entry['max_numeric_delta']=max(abs(float(x[k])-float(y[k])) for x,y in zip(a,b) for k in numeric)
 entry['entire_csv_identical']=path.read_bytes()==reference.read_bytes();entry['csv_sha256']=hashlib.sha256(path.read_bytes()).hexdigest()
 (OUT/'composed-receipts.json').write_text(json.dumps(receipts,indent=2)+'\n')
 print(r['tag'],'outcomes',entry['outcomes_identical'],'csv_exact',entry['entire_csv_identical'],'max_delta',entry['max_numeric_delta'],flush=True)
 assert entry['outcomes_identical'],'Composed policy changes scored outcomes'
print('SINGLE_COMPOSED_ACTOR_COMPLETE',len(receipts),'panels',flush=True)
