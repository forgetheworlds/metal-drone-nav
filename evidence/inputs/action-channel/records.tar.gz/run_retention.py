"""Check the positive XYZ intervention on preserved broader development panels."""
from pathlib import Path
import csv,json,subprocess,time,hashlib
ROOT=Path('/Users/muadhsambul/RL');OUT=ROOT/'results/root-action-channel';A=ROOT/'results/omp-actor-step'
full=json.loads((A/'full-eval-receipts.json').read_text());pilot=json.loads((A/'pilot-eval-receipts.json').read_text())
requested=[('open','nominal'),('long-open','nominal'),('dev-b','nominal'),('fresh-course-reflected','both-delay'),('fresh-course-reflected','combined')]
receipts=[];review={}
def rows(p):return {int(r['env']):r for r in csv.DictReader(Path(p).open())}
def outcome(x):return {k:sum(int(r[k]) for r in x.values()) for k in ['success','collision','timeout']}
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
for seed in [1,2]:
 for panel,profile in requested:
  cached=next(r for r in full if r['seed']==seed and r['group']=='treatment' and r['panel']==panel and r['profile']==profile)
  earlygrade=next(r for r in pilot if r['seed']==seed and r['group']=='treatment' and r['panel']==panel and r['profile']==profile)
  bank=Path(cached['argv'][-3]);assert bank.suffix=='.bin'
  early=A/f'runs/w2560-as04-s{seed}.bin.at-256.model.bin';model=A/f'runs/w2560-as04-s{seed}.bin'
  tag=f's{seed}-early-xyz-{panel}-{profile}';path=OUT/(tag+'.csv');log=OUT/(tag+'.log');assert not path.exists()
  argv=['python3',str(ROOT/'run_locked.py'),'--',str(OUT/'channel_eval'),str(early),str(model),str(bank),str(path),'early-xyz',profile]
  receipt={'tag':tag,'argv':argv,'bank_sha256':sha(bank),'early_sha256':sha(early),'full_sha256':sha(model)};start=time.monotonic()
  with log.open('w') as f:
   p=subprocess.Popen(argv,stdout=f,stderr=subprocess.STDOUT);receipt['pid']=p.pid;receipts.append(receipt)
   (OUT/'retention-receipts.json').write_text(json.dumps(receipts,indent=2)+'\n');receipt['exit']=p.wait()
  receipt['wall_s']=time.monotonic()-start;assert receipt['exit']==0,log.read_text();receipt['csv_sha256']=sha(path)
  e,b,n=rows(earlygrade['csv']),rows(cached['csv']),rows(path);assert e.keys()==b.keys()==n.keys()
  es,bs,ns=outcome(e),outcome(b),outcome(n)
  # These gates diagnose whether recovery merely trades away another skill.
  review[tag]={'early':es,'full':bs,'early_xyz':ns,'retention_floor':min(es['success'],bs['success'])-3,'retention_gate':ns['success']>=min(es['success'],bs['success'])-3,'rescued_full_failures':sum(int(b[k]['success'])==0 and int(n[k]['success'])==1 for k in n),'new_full_losses':sum(int(b[k]['success'])==1 and int(n[k]['success'])==0 for k in n)}
  (OUT/'retention-receipts.json').write_text(json.dumps(receipts,indent=2)+'\n');(OUT/'retention-review.json').write_text(json.dumps(review,indent=2)+'\n');print(tag,review[tag],flush=True)
print('CHANNEL_RETENTION_COMPLETE',len(receipts),'panels',flush=True)
