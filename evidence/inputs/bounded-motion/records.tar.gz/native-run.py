from pathlib import Path
import sys,json
root=Path('/Users/muadhsambul/RL');sys.path.insert(0,str(root/'webots'))
import local_waypoint_transfer as t
import bounded_motion_scene as scene
r=root/'results/root-motion-fidelity';project=r/'native-project';slug='bounded-motion-smoke-v2'
world=scene.export(r/'dev/challenges.bin',3,r/'anchor-s2.nav',project,slug)
t.WEBOTS_DIR=project;t.OUT_DIR=r/'native-smoke-v2';t.FLIGHT_DIR=t.OUT_DIR/'flights'
out=t.run_flight(world,t.FLIGHT_DIR/slug,False)
(r/'native-smoke-v2-result.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2),flush=True)
