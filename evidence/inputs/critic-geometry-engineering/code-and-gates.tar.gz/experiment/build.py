"""Build a matched zero-extra/full-geometry critic pair from frozen sources."""
from pathlib import Path
import hashlib,json,subprocess
ROOT=Path('/Users/muadhsambul/RL')
OUT=ROOT/'results/root-critic-geometry'
FROZEN=ROOT/'results/omp-functional-retention'
WORK=Path('/Users/muadhsambul/.codex/worktrees/navigation-actor-capacity/RL')

def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def replace_once(text,old,new):
    if text.count(old)!=1:raise ValueError(f'Expected one source seam: {old[:80]}')
    return text.replace(old,new)

sim=(WORK/'sim.metal').read_text()
sim=replace_once(sim,'static_assert(FIXED_PPO_CRITIC_OBS_DIM==64,"control-state critic requires64 inputs");',
    'static_assert(FIXED_PPO_CRITIC_OBS_DIM==226,"geometry experiment requires226 inputs");')
needle='''#endif
}
kernel void sim_observe'''
sim=replace_once(sim,needle,'''#endif
#if NAV_CRITIC_GEOMETRY
    critic_geometry_features(w,s.position,run.elapsed,obs+64);
#endif
}
kernel void sim_observe''')
(OUT/'sim.metal').write_text(sim)
main=(FROZEN/'main.mm').read_text()
main=replace_once(main,'read_text(root+"/sim.metal")',
    'read_text(CRITIC_GEOMETRY_HEADER_PATH)+read_text(CRITIC_GEOMETRY_SHADER_PATH)')
main=replace_once(main,'return "#include <metal_stdlib>\\nusing namespace metal;\\n"+sensor_profile_define',
    'return "#include <metal_stdlib>\\nusing namespace metal;\\n#define NAV_CRITIC_GEOMETRY "+std::to_string(NAV_CRITIC_GEOMETRY)+"\\n"+sensor_profile_define')
(OUT/'main.mm').write_text(main)
(OUT/'trainer_for_retention.mm').write_bytes((FROZEN/'trainer_for_retention.mm').read_bytes())
(OUT/'retention.mm').write_bytes((FROZEN/'retention.mm').read_bytes())
training=(WORK/'navigation_training.hpp').read_text()
needle='''        } else if(fixed_ppo::critic_obs_dim==64 && header.critic_count==2177) {'''
added='''        } else if(fixed_ppo::critic_obs_dim==226 && fixed_ppo::critic_hidden_dim==64 && header.critic_count==4225) {
            // Parameter-only warmstart migration, never optimizer-state resume.
            // Preserve every existing bias/head and only zero appended W1 columns.
            std::vector<float> old(header.critic_count);
            file.read((char*)old.data(),old.size()*sizeof(float));
            float* target=(float*)sim.critic.contents;
            std::fill(target,target+fixed_ppo::critic_param_count,0.0f);
            for(size_t h=0;h<64;h++) {
                std::copy_n(old.data()+h*64,64,target+h*226);
                target[fixed_ppo::critic_b1_offset+h]=old[4096+h];
                target[fixed_ppo::critic_w2_offset+h]=old[4160+h];
            }
            target[fixed_ppo::critic_b2_offset]=old[4224];
'''+needle
training=replace_once(training,needle,added)
(OUT/'navigation_training.hpp').write_text(training)
inputs=[OUT/'main.mm',OUT/'sim.metal',OUT/'trainer_for_retention.mm',OUT/'navigation_training.hpp',OUT/'critic_geometry_features.hpp']
inputs += sorted(FROZEN.glob('retention*.hpp'))+[FROZEN/'retention.mm']
inputs += sorted(WORK.glob('*.hpp'))+sorted(WORK.glob('*.metal'))
inputs += [WORK/'assets/raptor.bin',WORK/'assets/physics.bin']
hashes={str(p):sha(p) for p in inputs}
implementation=hashlib.sha256(json.dumps(hashes,sort_keys=True).encode()).hexdigest()
base=['/usr/bin/c++','-O3','-DNDEBUG','-std=gnu++17','-arch','arm64','-fobjc-arc',
      '-Wno-unused-function','-Wno-unused-variable',f'-DSOURCE_DIR="{WORK}"',
      '-DFIXED_PPO_ACTOR_OBS_DIM=184','-DFIXED_PPO_ACTOR_HIDDEN_DIM=5120',
      '-DFIXED_PPO_CRITIC_OBS_DIM=226','-DFIXED_PPO_CRITIC_HIDDEN_DIM=64',
      '-DNAV_CRITIC_CONTROL_STATE=1','-DNAV_SENSOR_PROFILE=1','-DNAV_DELAY_REHEARSAL=1',
      f'-DCRITIC_GEOMETRY_HEADER_PATH="{OUT}/critic_geometry_features.hpp"',
      f'-DCRITIC_GEOMETRY_SHADER_PATH="{OUT}/sim.metal"',
      f'-DRETENTION_IMPLEMENTATION_SHA256="{implementation}"',
      f'-I{OUT}',f'-I{FROZEN}',f'-I{WORK}']
receipts=[]
for arm,flag in [('control',0),('geometry',1)]:
    binary=OUT/f'nav_{arm}'
    argv=base+[f'-DNAV_CRITIC_GEOMETRY={flag}',str(OUT/'retention.mm'),'-o',str(binary),
               '-framework','Foundation','-framework','Metal','-framework','Accelerate']
    r=subprocess.run(argv,capture_output=True,text=True)
    receipt={'arm':arm,'argv':argv,'exit':r.returncode,'stderr':r.stderr}
    if not r.returncode:receipt['binary_sha256']=sha(binary)
    receipts.append(receipt)
    (OUT/'build.json').write_text(json.dumps({'inputs':hashes,'implementation':implementation,'receipts':receipts},indent=2)+'\n')
    if r.returncode:print(r.stderr[-4000:]);raise SystemExit(r.returncode)
    print('built',arm,receipt['binary_sha256'][:12],flush=True)
