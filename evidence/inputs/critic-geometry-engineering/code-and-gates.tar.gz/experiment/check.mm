#define WAYPOINT_EMBEDDED 1
#include "trainer_for_retention.mm"
#undef WAYPOINT_EMBEDDED
#include "critic_geometry_features.hpp"

int main(int argc,char** argv) {@autoreleasepool {try {
    require(argc==4,"check BANK WARMSTART OUTPUT_JSON");
    waypoint::BankControl control{};std::string hash;
    auto bank=waypoint::read_bank(argv[1],control,hash);
    SimConfig cfg;cfg.n=control.count/control.period;cfg.mode=22;cfg.seed=20261210;
    cfg.speed=2;cfg.max_steps=400;cfg.geometry_memory=1;cfg.sensor_delay=2;cfg.command_delay=2;
    Metal metal;metal.compile(base_source()+PPO_TRAINER_MSL+waypoint::kWaypointKernels);
    Sim sim(metal,cfg,32);
    auto run=waypoint::make_local_run(sim,bank,control,metal.pipeline("waypoint_task_apply"),1,50,10);
    navigation_training::load_actor(sim,argv[2],true);
    auto cb=[metal.queue commandBuffer];waypoint::local_probe(run,cb);metal.finish(cb);
    const auto* states=(const RLPhysicsState*)sim.states.contents;
    const auto* runs=(const SimRun*)sim.runs.contents;
    const auto* worlds=(const WWorld*)sim.worlds.contents;
    const auto* inputs=(const float*)sim.co.contents;
    const auto* weights=(const float*)sim.critic.contents;
    std::ifstream warm(argv[2],std::ios::binary);auto header=read_checkpoint_header(warm);
    require(header.critic_count==4225,"expected original64 critic");
    warm.seekg(sizeof(header)+sim.actor.length);
    std::vector<float> old(4225);warm.read((char*)old.data(),old.size()*4);require(bool(warm),"old critic read");
    double features_error=0, warm_error=0, extra_weights=0, extra_gradient=0;
    for(uint h=0;h<64;h++)for(uint j=64;j<226;j++)extra_weights+=fabs(weights[h*226+j]);
    require(extra_weights==0,"appended warmstart columns not zero");
    fixed_ppo::CriticParams critic;std::memcpy(critic.values.data(),weights,sim.critic.length);
    std::vector<float> grad(fixed_ppo::critic_param_count),sum(fixed_ppo::critic_param_count,0);
    std::vector<float> hidden(64);
    for(uint n=0;n<cfg.n;n++) {
        float features[162]={};
#if NAV_CRITIC_GEOMETRY
        critic_geometry_features(worlds[n],states[n].position,runs[n].elapsed,features);
#endif
        for(uint j=0;j<162;j++)features_error=std::max(features_error,double(fabs(features[j]-inputs[n*226+64+j])));
        float expected=old[4224];
        for(uint h=0;h<64;h++) {
            float z=old[4096+h];for(uint j=0;j<64;j++)z+=old[h*64+j]*inputs[n*226+j];
            expected+=old[4160+h]*std::tanh(z);
        }
        const float current=fixed_ppo::critic_forward(inputs+n*226,critic,hidden.data());
        warm_error=std::max(warm_error,double(fabs(current-expected)));
        if(n<32) {
            fixed_ppo::critic_backward_sample(inputs+n*226,hidden.data(),1.0f/32.0f,critic,grad.data());
            for(size_t j=0;j<grad.size();j++)sum[j]+=grad[j];
        }
    }
    for(uint h=0;h<64;h++)for(uint j=64;j<226;j++)extra_gradient+=double(sum[h*226+j])*sum[h*226+j];
    std::cout<<"feature_error="<<features_error<<" warm_error="<<warm_error<<" extra_grad2="<<extra_gradient<<"\n";
    require(features_error<1e-6 && warm_error==0,"initial feature/value parity failed");
    require(NAV_CRITIC_GEOMETRY?extra_gradient>1e-10:extra_gradient==0,"extra input derivative failure");
    // Compare actual Metal gradients with the CPU sum on these same inputs.
    const uint batch=32;std::vector<float> dv(batch,1.0f/float(batch));
    auto batch_b=metal.buffer(4,&batch),dv_b=metal.buffer(batch*4,dv.data());
    auto hidden_b=metal.buffer(batch*64*4),values_b=metal.buffer(batch*4);
    auto delta_b=metal.buffer(batch*64*4),gradient_b=metal.buffer(sim.critic.length);
    cb=[metal.queue commandBuffer];
    metal.dispatch(cb,metal.pipeline("ppo_critic_forward"),batch,{sim.co,sim.critic,hidden_b,values_b,batch_b});
    metal.dispatch(cb,metal.pipeline("ppo_critic_hidden_delta"),batch*64,{sim.critic,dv_b,hidden_b,delta_b,batch_b});
    metal.dispatch(cb,metal.pipeline("ppo_critic_grad_direct"),fixed_ppo::critic_param_count,{sim.co,hidden_b,dv_b,delta_b,gradient_b,batch_b});
    metal.finish(cb);
    double gradient_error=0;
    const auto* gpu_gradient=(const float*)gradient_b.contents;
    for(size_t j=0;j<sum.size();j++)gradient_error=std::max(gradient_error,double(fabs(sum[j]-gpu_gradient[j])));
    require(gradient_error<1e-4,"new-input critic gradient CPU/Metal mismatch");
    const std::string actor_obs_hash=ppo_safeguard_sha256(sim.obs.contents,size_t(cfg.n)*184*4);
    std::vector<float> basic_inputs(size_t(cfg.n)*64);
    for(uint n=0;n<cfg.n;n++)std::copy_n(inputs+n*226,64,basic_inputs.data()+n*64);
    const std::string basic_hash=ppo_safeguard_sha256(basic_inputs.data(),basic_inputs.size()*4);
    // Both paths call sim_critic_obs. Give the new input columns nonzero weights
    // so a missing bootstrap feature path cannot pass solely due zero warmstart.
    for(uint h=0;h<64;h++)for(uint j=64;j<226;j++)((float*)sim.critic.contents)[h*226+j]=.0001f*sin(float(h*226+j));
    cb=[metal.queue commandBuffer];waypoint::local_collect(run,cb,1);metal.finish(cb);
    std::vector<float> next(cfg.n);std::memcpy(next.data(),sim.next_values.contents,next.size()*4);
    std::memcpy(critic.values.data(),sim.critic.contents,sim.critic.length);
    // Observe the post-transition state without applying/resetting its bank entry.
    cb=[metal.queue commandBuffer];
    metal.dispatch(cb,sim.observe_p,cfg.n,{sim.states,sim.runs,sim.worlds,sim.sensors,sim.obs,sim.co,sim.physics,sim.configs[0],sim.poses,sim.memory_clearances},64);
    metal.finish(cb);
    double bootstrap_error=0;uint bootstrap_rows=0;
    inputs=(const float*)sim.co.contents;runs=(const SimRun*)sim.runs.contents;
    for(uint n=0;n<cfg.n;n++)if(!runs[n].episodes) {
        const float value=fixed_ppo::critic_forward(inputs+n*226,critic,hidden.data());
        bootstrap_error=std::max(bootstrap_error,double(fabs(value-next[n])));bootstrap_rows++;
    }
    require(bootstrap_rows>0 && bootstrap_error<1e-4,"next-value feature mismatch");
    std::ofstream out(argv[3]);require(bool(out),"gate receipt write");
    out<<std::setprecision(10)<<"{\"geometry\":"<<NAV_CRITIC_GEOMETRY<<",\"environments\":"<<cfg.n
       <<",\"critic_inputs\":226,\"critic_parameters\":"<<fixed_ppo::critic_param_count
       <<",\"feature_max_error\":"<<features_error<<",\"initial_value_max_error\":"<<warm_error
       <<",\"appended_weight_l1\":"<<extra_weights<<",\"appended_gradient_l2\":"<<sqrt(extra_gradient)
       <<",\"gradient_max_error\":"<<gradient_error<<",\"actor_observation_sha256\":\""<<actor_obs_hash<<"\",\"basic_input_sha256\":\""<<basic_hash<<"\",\"bootstrap_rows\":"<<bootstrap_rows<<",\"bootstrap_max_error\":"<<bootstrap_error<<",\"actual_transitions\":"<<cfg.n<<"}\n";
    std::cout<<"critic geometry gates PASS mode="<<NAV_CRITIC_GEOMETRY<<" bootstrap_error="<<bootstrap_error<<"\n";
    return 0;
} catch(const std::exception& e){std::cerr<<e.what()<<'\n';return 1;}}}
