# Critic geometry pilot — frozen decision

The audit found that the critic sees only three obstacle centers and no shapes
or motion parameters. This is a structural information gap. Its causal effect
on learning is unproven. This experiment tests one addition; it does not assume
the critic is the sole failure cause or that this supplies complete state.

Both arms: critic226/64/1 (14,593 parameters), actor184/5120/4, composed parents,
fresh Adam, same frozen2048-payload source and halfclean/half100ms delay lanes,
reward1/50/10, actor step.4, teacher coefficient4.134632354, anchor.01, speed1.5,
512 environments, horizon32, epochs2, minibatch256. Four256-rollout arms total
16,777,216 transitions. Reuse exactly23 development/stress panels per model;
final checkpoint only. No FINAL or target training. All datasets are exposed DEV.

Control pads the old64 inputs with162zeros. Treatment appends count, actual
elapsed time and all sixteen obstacles' kind, base-relative center, sizes and
peak/linear velocity. Kind3 phase is normalized as radians. This supplies the
parameters of bounded motion, not a falsely labelled instantaneous velocity.
Both V(s) and V(s_next) call the same builder. Original weights/bias/head are
preserved and appended W1 columns start zero. Control extra weights remain
inactive; equal nominal parameter count does not isolate information from every
possible function-class effect. Hidden width is fixed. Actor receives no truth.

Engineering gates PASS before pilot: CPU/Metal feature and derivative agreement;
identical actor/basic64 observations; initial value preservation; nonzero new
feature gradients; bootstrap consistency with nonzero appended weights; both
seeds C/T6 versus3+3 FULL resume exact; wrong feature/width refusal without writes;
first complete rollout actor byte equality. The initial exact CPU value fixture
failed by7.87e-6 under compiler FMA contraction. Disabling contraction in the
REFERENCE TEST ONLY restores zero error; trainer flags stay unchanged. Preserve
that failure and distinguish CPU reference precision from Metal tolerance.
The feature fixture uses speed2; the training/evaluation recipe is explicitly1.5.

Capability gates: pooled static-C success>=control+4 and contacts<=control-3;
no static-C success loss in either seed; old/fresh open>=253/256; long and fresh
long open>=253; course>=241 and>=control-3. Across ALL23 panels, success loss
no worse than3 and contacts/timeouts no worse than control+3. Reflected combined
stress>=178 and>=control-3. Mean arrival on common successes within.5s of control
on nominal long and course, and within.2s on nominal short open. Report training
and evaluation wall separately. Also retain comparison with the composed parent
and prior unmasked model. Target EV is diagnostic, never promotion criterion.

No extension, coefficient or feature sweep before root reads all outcomes.
A failure rejects this recipe, not every critic-information hypothesis. Default
assets stay unchanged and independent robust transfer remains unproven.
