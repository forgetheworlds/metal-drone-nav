"""Freeze the pilot recipe and exact development panels after real gates."""
from pathlib import Path
import hashlib,json
ROOT=Path('/Users/muadhsambul/RL');OUT=ROOT/'results/root-critic-geometry'
old=json.loads((ROOT/'results/omp-functional-retention/pilot-request.json').read_text())
bases={a['seed']:a for a in old['arms'] if a['group']=='treatment'}
gates=json.loads((OUT/'validation-complete.json').read_text());assert gates['status']=='PASS'
for p,h in gates['source_inputs'].items():assert hashlib.sha256(Path(p).read_bytes()).hexdigest()==h,p
arms=[]
for seed in [1,2]:
 for group in ['control','geometry']:
  src=bases[seed];cp=OUT/'runs'/f'{group}-s{seed}'/f'{group}-s{seed}.bin';args=src['argv'][:];args[3]=str(OUT/('nav_'+group));args[6]=str(cp);args+=['--speed','1.5'];arms.append({'seed':seed,'group':group,'checkpoint':str(cp),'argv':args,'warmstart':src['warmstart'],'warmstart_sha256':src['warmstart_sha256'],'total_rollouts':256,'transitions':4194304})
evaluator=ROOT/'results/omp-functional-retention/nav_stress_eval_w5120'
cases=[]
for arm in arms:
 for oldcase in old['evaluation']['jobs']:
  if oldcase['label']=='treatment' and oldcase['seed']==arm['seed']:
   case=oldcase.copy();case['label']=arm['group'];case['checkpoint']=arm['checkpoint'];csv=OUT/'eval'/f"{arm['group']}-s{arm['seed']}"/f"{case['panel']}-{case['profile']}.csv";case['csv']=str(csv);case['argv']=['python3',str(ROOT/'run_locked.py'),'--',str(evaluator),arm['checkpoint'],case['bank'],str(csv),case['profile']];cases.append(case)
assert len(cases)==92,len(cases)
request={'schema':'critic-geometry-v1','arms':arms,'evaluation':cases,'evaluator_sha256':hashlib.sha256(evaluator.read_bytes()).hexdigest(),'critic':{'inputs':226,'hidden':64,'parameters':14593,'control':'original64 plus162zeros','treatment':'original64 plus count, elapsed, sixteen shape/position/motion records'},'actor':'184/5120/4 unchanged; no privileged inputs at inference','budget':16777216,'selection':'final256 only; no outcome-selected checkpoint','speed_cap_mps':1.5,'feature_scope':'Training-only world geometry, not sensor/queue completeness. Extra control weights are inactive; nominal parameter count is matched, not an independent capacity-versus-information proof.'}
(OUT/'pilot-request.json').write_text(json.dumps(request,indent=2)+'\n')
print('prepared',len(arms),'arms and',len(cases),'evaluations')
