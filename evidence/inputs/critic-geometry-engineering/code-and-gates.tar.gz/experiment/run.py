"""Root persistent owner of all four frozen producers and their actual grading."""
from pathlib import Path
import hashlib,json,struct,subprocess,time
ROOT=Path('/Users/muadhsambul/RL');OUT=ROOT/'results/root-critic-geometry'
request=json.loads((OUT/'pilot-request.json').read_text());validation=json.loads((OUT/'validation-complete.json').read_text());preflight=json.loads((OUT/'eval-preflight.json').read_text())
assert validation['status']=='PASS' and preflight['actual_csv_byte_identical']
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
freeze=validation['source_inputs'].copy()
for name in ['run.py','pilot-request.json','decision.md','prepare.py','build.py','validation-complete.json','eval-preflight.json']:
 p=OUT/name;freeze[str(p)]=sha(p)
for arm in request['arms']:
 freeze[arm['argv'][3]]=validation['binary_hashes'][arm['group']]
 freeze[arm['warmstart']]=arm['warmstart_sha256']
for case in request['evaluation']:
 freeze[case['bank']]=case['bank_sha256'];freeze[case['argv'][3]]=request['evaluator_sha256']
(OUT/'freeze.json').write_text(json.dumps(freeze,indent=2)+'\n')
def verify():
 for p,h in freeze.items():assert sha(p)==h,p
jobs=[];grades=[]
for arm in request['arms']:
 verify();cp=Path(arm['checkpoint']);cp.parent.mkdir(parents=True,exist_ok=True);assert not cp.exists(),'Never overwrite or guess a resume'
 log=cp.with_suffix('.log');record={**arm,'log':str(log)};jobs.append(record)
 with log.open('w') as output:
  start=time.time();p=subprocess.Popen(arm['argv'],stdout=output,stderr=subprocess.STDOUT);record['pid']=p.pid;(OUT/'jobs.json').write_text(json.dumps(jobs,indent=2)+'\n');record['exit']=p.wait();record['wall_s']=time.time()-start
 if record['exit']:raise RuntimeError(log.read_text()[-1800:])
 header=cp.read_bytes()[:136]
 assert struct.unpack_from('<I',header,36)[0]==256 and struct.unpack_from('<Q',header,40)[0]==32768
 assert struct.unpack_from('<I',header,16)[0]==14593
 counts=Path(str(cp)+'.entry-transitions.bin').read_bytes();assert sum(struct.unpack('<'+str(len(counts)//8)+'Q',counts))==4194304
 record['checkpoint_sha256']=sha(cp);(OUT/'jobs.json').write_text(json.dumps(jobs,indent=2)+'\n');print('GEOMETRY_ARM_COMPLETE',arm['group'],arm['seed'],flush=True)
for case in request['evaluation']:
 verify();csv=Path(case['csv']);csv.parent.mkdir(parents=True,exist_ok=True);assert not csv.exists()
 log=csv.with_suffix('.log');record={**case,'log':str(log)};grades.append(record)
 with log.open('w') as output:
  start=time.time();p=subprocess.Popen(case['argv'],stdout=output,stderr=subprocess.STDOUT);record['pid']=p.pid;(OUT/'eval-jobs.json').write_text(json.dumps(grades,indent=2)+'\n');record['exit']=p.wait();record['wall_s']=time.time()-start
 if record['exit']:raise RuntimeError(log.read_text()[-1800:])
 record['csv_sha256']=sha(csv);(OUT/'eval-jobs.json').write_text(json.dumps(grades,indent=2)+'\n')
print('GEOMETRY_PILOT_COMPLETE',len(jobs),'producers',len(grades),'actual evaluations',flush=True)
(OUT/'complete.json').write_text(json.dumps({'producers':len(jobs),'actual_evaluations':len(grades),'status':'complete; capability verdict pending independent root grading'},indent=2)+'\n')
