"""Root-owned bounded resume and contract gates; never launch a full pilot."""
from pathlib import Path
import hashlib,json,shutil,struct,subprocess,time
ROOT=Path('/Users/muadhsambul/RL');OUT=ROOT/'results/root-critic-geometry'
request=json.loads((ROOT/'results/omp-functional-retention/pilot-request.json').read_text())
bases={a['seed']:a['argv'] for a in request['arms'] if a['group']=='treatment'}
build=json.loads((OUT/'build.json').read_text());jobs=[];verdicts=[]
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def invoke(arm,seed,tag,count,checkpoint=None,expected_exit=0):
 folder=OUT/'gates'/tag;folder.mkdir(parents=True,exist_ok=True)
 cp=Path(checkpoint) if checkpoint else folder/(tag+'.bin')
 args=bases[seed][:];args[3]=str(OUT/('nav_'+arm));args[5]=str(count);args[6]=str(cp)
 log=folder/('run-'+str(len(jobs))+'.log');record={'arm':arm,'seed':seed,'tag':tag,'argv':args,'log':str(log)};jobs.append(record)
 with log.open('w') as handle:
  start=time.time();p=subprocess.Popen(args,stdout=handle,stderr=subprocess.STDOUT);record['pid']=p.pid;(OUT/'gate-jobs.json').write_text(json.dumps(jobs,indent=2)+'\n');record['exit']=p.wait();record['wall_s']=time.time()-start
 (OUT/'gate-jobs.json').write_text(json.dumps(jobs,indent=2)+'\n')
 if expected_exit==0:
  if record['exit']!=0:raise RuntimeError(log.read_text()[-2300:])
 else:
  if not record['exit']:raise RuntimeError('Expected contract refusal')
 print(tag,'exit',record['exit'],flush=True)
 return cp
for p,h in build['inputs'].items():assert sha(p)==h,p
for seed in [1,2]:
 for arm in ['control','geometry']:
  full=invoke(arm,seed,f'{arm}-s{seed}-full6',6)
  split=invoke(arm,seed,f'{arm}-s{seed}-split3',3)
  split=invoke(arm,seed,f'{arm}-s{seed}-resume3',3,split)
  if full.read_bytes()!=split.read_bytes():raise RuntimeError(f'Full resume parity failed {arm} seed{seed}')
  verdicts.append({'arm':arm,'seed':seed,'full6_vs_3plus3_byte_identical':True,'full_sha256':sha(full)})
# Same dimensions but different shader semantics must refuse before writing.
saved=OUT/'gates/geometry-s1-full6/geometry-s1-full6.bin';before=sha(saved)
invoke('control',1,'wrong-feature-refusal',1,saved,expected_exit=1)
assert sha(saved)==before,'Refused run overwrote checkpoint'
# The original64-input instrument must refuse a226-input full resume.
args=bases[1][:];args[5]='1';args[6]=str(saved)
r=subprocess.run(args,capture_output=True,text=True);(OUT/'wrong-width-refusal.log').write_text(r.stdout+r.stderr)
assert r.returncode!=0 and sha(saved)==before,'Old critic accepted incompatible full state'
# Compare the actor at the first complete rollout under matched initial values.
ones={arm:invoke(arm,1,f'{arm}-s1-first1',1) for arm in ['control','geometry']}
a,b=[ones[arm].read_bytes() for arm in ['control','geometry']]
actor_count=struct.unpack_from('<I',a,12)[0];assert a[136:136+actor_count*4]==b[136:136+actor_count*4]
result={'status':'PASS','resume':verdicts,'wrong_feature_refused_without_write':True,'wrong_width_refused_without_write':True,'first_rollout_actor_byte_identical':True,'binary_hashes':{r['arm']:r['binary_sha256'] for r in build['receipts']},'source_inputs':build['inputs']}
(OUT/'validation-complete.json').write_text(json.dumps(result,indent=2)+'\n');print('GEOMETRY_CRITIC_VALIDATION_COMPLETE',flush=True)
