// Functional-retention instrument entry point.
//
// The frozen trainer is copied byte-identically (trainer_for_retention.mm) and
// included with WAYPOINT_EMBEDDED, so the source's own embedding switch owns the
// entry point. The copy of main.mm beside it carries exactly three retention
// hooks; no frozen file is modified and both hashes are recorded by
// build_retention.py.
//
//   retention-train     ROLLOUTS CHECKPOINT WARMSTART [options]
//   retention-gradcheck ROLLOUTS CHECKPOINT WARMSTART [options] --out FILE
//   retention-calibrate ROLLOUTS CHECKPOINT WARMSTART [options] --out FILE
#define WAYPOINT_EMBEDDED 1
#include "trainer_for_retention.mm"
#undef WAYPOINT_EMBEDDED

#include "retention_train.hpp"
