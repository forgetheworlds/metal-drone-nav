// Functional-retention commands: training with the retention loss, the
// derivative/parity gates, and the single coefficient calibration.
#pragma once

#include "retention_session.hpp"

namespace retention_run {

using namespace retention;

static double vector_norm(const std::vector<float>& values) {
    double acc = 0;
    for (float value : values) acc += double(value) * double(value);
    return std::sqrt(acc);
}

static std::vector<float> read_actor_gradient(PPOTrainer& trainer, Sim& sim, uint32_t batch, uint32_t begin) {
    // Runs the frozen actor backward kernels on the current d_mean/d_log_std and
    // returns the full actor gradient.
    const size_t obs_offset = size_t(begin) * fixed_ppo::actor_obs_dim * 4;
    const size_t tiles = ((fixed_ppo::actor_hidden_dim + 7) / 8) * ((fixed_ppo::actor_obs_dim + 7) / 8);
    auto cb = [sim.m.queue commandBuffer];
    trainer.dispatch(cb, trainer.actor_hidden_delta_p, size_t(batch) * fixed_ppo::actor_hidden_dim,
                     {{sim.actor, 0}, {trainer.d_means, 0}, {trainer.actor_hidden, 0},
                      {trainer.actor_hidden_delta, 0}, {trainer.batch_size_buffers[batch], 0}}, 128);
    trainer.dispatch(cb, trainer.actor_grad_tiled_p, ((tiles + 3) / 4) * 128,
                     {{sim.obs, obs_offset}, {trainer.actor_hidden_delta, 0}, {trainer.actor_grad, 0},
                      {trainer.batch_size_buffers[batch], 0}}, 128);
    trainer.dispatch(cb, trainer.actor_grad_head_p, fixed_ppo::actor_param_count - fixed_ppo::actor_b1_offset,
                     {{trainer.actor_hidden, 0}, {trainer.actor_hidden_delta, 0}, {trainer.d_means, 0},
                      {trainer.d_log_stds, 0}, {trainer.actor_grad, 0},
                      {trainer.batch_size_buffers[batch], 0}}, 128);
    sim.m.finish(cb);
    const float* grad = static_cast<const float*>(trainer.actor_grad.contents);
    return std::vector<float>(grad, grad + fixed_ppo::actor_param_count);
}

static void forward_minibatch(Session& session, uint32_t batch, uint32_t begin) {
    Sim& sim = *session.sim;
    PPOTrainer& trainer = *session.trainer;
    const size_t obs_offset = size_t(begin) * fixed_ppo::actor_obs_dim * 4;
    const size_t co_offset = size_t(begin) * fixed_ppo::critic_obs_dim * 4;
    const size_t action_offset = size_t(begin) * fixed_ppo::action_dim * 4;
    const size_t row_offset = size_t(begin) * 4;
    auto cb = [sim.m.queue commandBuffer];
    encode_actor_forward(sim.m, cb, sim.wide_actor, sim.simd_actor, sim.obs, obs_offset, sim.actor,
                         trainer.actor_hidden, trainer.actor_means, 0, trainer.batch_size_buffers[batch], batch);
    trainer.dispatch(cb, trainer.critic_forward_p, batch,
                     {{sim.co, co_offset}, {sim.critic, 0}, {trainer.critic_hidden, 0},
                      {trainer.predicted_values, 0}, {trainer.batch_size_buffers[batch], 0}}, 64);
    trainer.dispatch(cb, trainer.loss_grad_p, batch,
                     {{sim.actions, action_offset}, {trainer.actor_means, 0},
                      {sim.actor, fixed_ppo::actor_log_std_offset * 4}, {sim.logp, row_offset},
                      {trainer.predicted_values, 0}, {sim.values, row_offset}, {sim.advantages, row_offset},
                      {sim.returns, row_offset}, {trainer.d_means, 0}, {trainer.d_log_stds, 0},
                      {trainer.d_values, 0}, {trainer.losses, 0}, {trainer.batch_size_buffers[batch], 0},
                      {trainer.clip_b, 0}, {trainer.value_coef_b, 0}, {trainer.entropy_coef_b, 0}}, 64);
    sim.m.finish(cb);
}

// --------------------------------------------------------------- gradcheck
static int command_gradcheck(int argc, char** argv) {
    require(argc >= 5, "retention-gradcheck ROLLOUTS CHECKPOINT WARMSTART [options] --out FILE");
    Session session = setup_session(argc, argv, 1);
    const std::string output = session.options.out_path.empty()
        ? std::string(argv[3]) + ".gradcheck.json" : session.options.out_path;
    require(session.options.retention_coefficient > 0.0f, "gradcheck needs a positive coefficient");
    load_teacher(session);
    Sim& sim = *session.sim;
    PPOTrainer& trainer = *session.trainer;
    const uint32_t rows = sim.cfg.n * sim.horizon;
    const uint32_t batch = 256;
    trainer.enable_physical_retention(rows, sim.cfg.speed);
    trainer.set_retention_coefficient(session.options.retention_coefficient);

    auto collect = [&] {
        std::memset(session.run->sample_counts.contents, 0, session.run->sample_counts.length);
        auto cb = [session.metal->queue commandBuffer];
        waypoint::local_collect(*session.run, cb, sim.horizon);
        session.metal->finish(cb);
    };
    // A genuine ordinary PPO update makes the student differ from its teacher.
    // Retention remains zero for that update; this probe is not a new learning arm.
    trainer.set_retention_coefficient(0.0f);
    collect();
    cache_teacher_means(session);
    auto ordinary = [sim.m.queue commandBuffer];
    trainer.rollout_update(ordinary, trainer.completed_rollouts);
    sim.m.finish(ordinary);
    ++trainer.completed_rollouts;
    trainer.set_retention_coefficient(session.options.retention_coefficient);
    collect();
    cache_teacher_means(session);
    auto gae = [&] {
        auto cb = [sim.m.queue commandBuffer];
        trainer.dispatch(cb, trainer.gae_p, sim.cfg.n,
                         {{sim.rewards, 0}, {sim.values, 0}, {sim.next_values, 0}, {sim.terminated, 0},
                          {sim.truncated, 0}, {sim.advantages, 0}, {sim.returns, 0},
                          {trainer.horizon_b, 0}, {trainer.envs_b, 0}, {trainer.gamma_b, 0},
                          {trainer.lambda_b, 0}}, 64);
        trainer.dispatch(cb, trainer.normalize_p, 1,
                         {{sim.advantages, 0}, {trainer.rows_b, 0}, {trainer.gae_epsilon_b, 0},
                          {trainer.adv_clip_b, 0}}, 1);
        sim.m.finish(cb);
    };
    gae();
    // the real first minibatch of epoch 0
    std::vector<uint32_t> starts(rows / batch);
    for (uint32_t b = 0; b < starts.size(); ++b) starts[b] = b * batch;
    std::mt19937 rng(0x9e3779b9u + trainer.completed_rollouts * 0x85ebca6bu);
    std::shuffle(starts.begin(), starts.end(), rng);
    const uint32_t begin = starts[0];
    forward_minibatch(session, batch, begin);

    const float* obs = static_cast<const float*>(sim.obs.contents);
    const float* means = static_cast<const float*>(trainer.actor_means.contents);
    const float* teacher_means = static_cast<const float*>(trainer.retention_teacher_means.contents);
    const float speed = sim.cfg.speed;
    std::ostringstream json;
    json << std::setprecision(17) << "{\n \"minibatch_begin\": " << begin << ",\n"
         << " \"batch\": " << batch << ",\n \"speed_mps\": " << speed << ",\n"
         << " \"coefficient\": " << session.options.retention_coefficient << ",\n";

    // 1. float64 finite differences on real rows and synthetic edge cases
    double worst_fd = 0, worst_fd_rel = 0;
    std::vector<std::array<double, 184>> cases;
    for (uint32_t i = 0; i < 32; ++i) {
        std::array<double, 184> row{};
        for (uint32_t k = 0; k < 184; ++k) row[k] = obs[size_t(begin + i) * 184 + k];
        cases.push_back(row);
    }
    std::vector<std::array<double, 4>> synthetic_mean;
    auto synthetic = [&](double prior, double mean_value, double depth) {
        std::array<double, 184> row{};
        for (uint32_t k = 0; k < 20; ++k) row[k] = depth;
        for (uint32_t k = 0; k < 3; ++k) row[181 + k] = prior;
        synthetic_mean.push_back({mean_value, -mean_value, 0.5 * mean_value, mean_value});
        return row;
    };
    cases.push_back(synthetic(1.0, 0.0, 0.05));    // prior saturated, gate low
    cases.push_back(synthetic(-1.0, 0.0, 0.05));
    cases.push_back(synthetic(0.0, 3.0, 3.0));     // saturated mean, gate high
    cases.push_back(synthetic(0.0, -3.0, 3.0));
    cases.push_back(synthetic(0.5, 0.5, 0.0));     // zero-velocity intent
    cases.push_back(synthetic(0.0, 0.0, 3.0));     // high speed -> projection active
    double worst_projection = 0;
    for (size_t index = 0; index < cases.size(); ++index) {
        const auto& row = cases[index];
        double student[4], teacher[4];
        for (uint32_t axis = 0; axis < 4; ++axis) {
            student[axis] = (index < 32)
                ? double(means[size_t(index) * 4 + axis])
                : synthetic_mean[index - 32][axis];
            teacher[axis] = (index < 32)
                ? double(teacher_means[size_t(begin + index) * 4 + axis])
                : double(row[181 + (axis < 3 ? axis : 0)]) - 0.2 * (axis + 1);
        }
        double grad[4];
        const double loss = Map::loss_grad(student, teacher, row.data(), speed, grad);
        require(std::isfinite(loss) && loss >= 0.0, "retention loss must be finite and non-negative");
        require(grad[3] == 0.0, "retention gradient must not touch the yaw mean");
        for (uint32_t axis = 0; axis < 3; ++axis) {
            const double step = 1e-6;
            double plus[4], minus[4];
            for (uint32_t k = 0; k < 4; ++k) { plus[k] = student[k]; minus[k] = student[k]; }
            plus[axis] += step;
            minus[axis] -= step;
            double dummy[4];
            const double loss_plus = Map::loss_grad(plus, teacher, row.data(), speed, dummy);
            const double loss_minus = Map::loss_grad(minus, teacher, row.data(), speed, dummy);
            const double numeric = (loss_plus - loss_minus) / (2.0 * step);
            const double error = std::fabs(numeric - grad[axis]);
            worst_fd = std::max(worst_fd, error);
            worst_fd_rel = std::max(worst_fd_rel, error / std::max(1e-9, std::fabs(numeric)));
        }
        double velocity[3];
        Map::velocity(student, row.data(), speed, velocity);
        const double magnitude = std::sqrt(velocity[0] * velocity[0] + velocity[1] * velocity[1] +
                                           velocity[2] * velocity[2]);
        worst_projection = std::max(worst_projection, magnitude - speed);
    }
    require(worst_fd_rel < 1e-6, "finite-difference check failed: " + std::to_string(worst_fd_rel));
    require(worst_projection < 1e-9, "spherical projection exceeded the speed cap");
    json << " \"finite_difference_cases\": " << cases.size() << ",\n"
         << " \"finite_difference_max_abs\": " << worst_fd << ",\n"
         << " \"finite_difference_max_rel\": " << worst_fd_rel << ",\n"
         << " \"speed_cap_max_excess\": " << worst_projection << ",\n";

    // 2. Metal versus float64 CPU on the same real rows
    // Isolate the auxiliary derivative. Subtracting it from a much larger PPO
    // derivative loses float precision and makes near-zero relative tests vacuous.
    std::vector<float> before(size_t(batch)*4,0.0f);
    std::fill_n(static_cast<float*>(trainer.d_means.contents),size_t(batch)*4,0.0f);
    const void* teacher_before = nullptr;
    std::vector<float> teacher_snapshot(session.teacher_host);
    std::vector<float> critic_snapshot(static_cast<const float*>(sim.critic.contents),
                                       static_cast<const float*>(sim.critic.contents) +
                                           fixed_ppo::critic_param_count);
    (void)teacher_before;
    auto retention_cb = [&](float coefficient, uint32_t batch_size, id<MTLBuffer> batch_buffer) {
        std::memcpy(trainer.retention_coefficient_b.contents, &coefficient, sizeof(coefficient));
        auto cb = [sim.m.queue commandBuffer];
        trainer.dispatch(cb, trainer.retention_grad_p, batch_size,
                         {{sim.obs, size_t(begin) * fixed_ppo::actor_obs_dim * 4}, {trainer.actor_means, 0},
                          {trainer.retention_teacher_means, size_t(begin) * fixed_ppo::action_dim * 4},
                          {trainer.d_means, 0}, {trainer.retention_row_loss, size_t(begin) * 4},
                          {batch_buffer, 0}, {trainer.retention_coefficient_b, 0},
                          {trainer.retention_speed_b, 0}}, 64);
        sim.m.finish(cb);
    };
    retention_cb(1.0f, batch, trainer.batch_size_buffers[batch]);
    const float* d_means_after = static_cast<const float*>(trainer.d_means.contents);
    const std::vector<float> derivative256(d_means_after,d_means_after+size_t(batch)*4);
    double worst_metal = 0, worst_metal_rel = 0, yaw_delta = 0, metal_error2=0, metal_reference2=0;
    for (uint32_t i = 0; i < batch; ++i)
        for (uint32_t axis = 0; axis < 4; ++axis)
            if (axis == 3)
                yaw_delta = std::max(yaw_delta, std::fabs(double(derivative256[i * 4 + axis]) -
                                                          double(before[i * 4 + axis])));
    std::vector<double> obs_row(184);
    for (uint32_t i = 0; i < batch; ++i) {
        for (uint32_t k = 0; k < 184; ++k) obs_row[k] = obs[size_t(begin + i) * 184 + k];
        double student[4] = {double(means[i * 4]), double(means[i * 4 + 1]), double(means[i * 4 + 2]),
                             double(means[i * 4 + 3])};
        double teacher[4] = {double(teacher_means[size_t(begin + i) * 4]),
                             double(teacher_means[size_t(begin + i) * 4 + 1]),
                             double(teacher_means[size_t(begin + i) * 4 + 2]),
                             double(teacher_means[size_t(begin + i) * 4 + 3])};
        double grad[4];
        Map::loss_grad(student, teacher, obs_row.data(), speed, grad);
        for (uint32_t axis = 0; axis < 3; ++axis) {
            const double added = double(derivative256[i * 4 + axis]) - double(before[i * 4 + axis]);
            const double expected = grad[axis] / double(batch);
            const double error = std::fabs(added - expected);
            worst_metal = std::max(worst_metal, error);
            metal_error2+=error*error;metal_reference2+=expected*expected;
            worst_metal_rel = std::max(worst_metal_rel, error / std::max(1e-12, std::fabs(expected)));
        }
    }
    const double metal_relative_l2=std::sqrt(metal_error2/std::max(1e-30,metal_reference2));
    std::cout << "retention_derivative_replay max_abs=" << worst_metal
              << " max_rel_near_zero=" << worst_metal_rel << " relative_l2=" << metal_relative_l2 << '\n';
    require(worst_metal < 1e-7 && metal_relative_l2 < 2e-5,
            "Metal retention derivative replay failed");
    require(yaw_delta == 0.0, "retention kernel wrote to the yaw mean");
    json << " \"metal_vs_float64_max_abs\": " << worst_metal << ",\n"
         << " \"metal_vs_float64_relative_l2\": " << metal_relative_l2 << ",\n"
         << " \"metal_vs_float64_max_rel\": " << worst_metal_rel << ",\n"
         << " \"yaw_mean_delta\": " << yaw_delta << ",\n";

    // 3. immutability of the teacher and the critic during the derivative probe
    require(std::memcmp(session.teacher_weights.contents, session.teacher_host.data(),
                        session.teacher_host.size() * 4) == 0, "retention modified the teacher weights");
    require(std::memcmp(sim.critic.contents, critic_snapshot.data(),
                        critic_snapshot.size() * 4) == 0, "retention modified the critic");
    json << " \"teacher_unchanged\": true,\n \"critic_unchanged\": true,\n";

    // 4. descent: moving the student mean against the gradient must lower the loss
    double worst_descent = -std::numeric_limits<double>::infinity();
    uint32_t descent_rows=0;
    for (uint32_t i = 0; i < 32; ++i) {
        for (uint32_t k = 0; k < 184; ++k) obs_row[k] = obs[size_t(begin + i) * 184 + k];
        double student[4] = {double(means[i * 4]), double(means[i * 4 + 1]), double(means[i * 4 + 2]),
                             double(means[i * 4 + 3])};
        double teacher[4] = {double(teacher_means[size_t(begin + i) * 4]),
                             double(teacher_means[size_t(begin + i) * 4 + 1]),
                             double(teacher_means[size_t(begin + i) * 4 + 2]),
                             double(teacher_means[size_t(begin + i) * 4 + 3])};
        double grad[4];
        const double loss = Map::loss_grad(student, teacher, obs_row.data(), speed, grad);
        double moved[4];
        const double step = 1e-3;
        for (uint32_t axis = 0; axis < 4; ++axis) moved[axis] = student[axis] - step * grad[axis];
        double dummy[4];
        const double after = Map::loss_grad(moved, teacher, obs_row.data(), speed, dummy);
        worst_descent = std::max(worst_descent, after - loss);
        descent_rows += after < loss - 1e-12;
    }
    require(worst_descent <= 1e-12 && descent_rows>0,
            "gradient step increased the loss or never reduced it");
    json << " \"descent_worst_increase\": " << worst_descent << ",\n";

    // 5. batch normalisation: the per-row contribution scales exactly as 1/batch
    std::vector<float> scaled(before);
    std::memcpy(trainer.d_means.contents, scaled.data(), scaled.size() * 4);
    retention_cb(1.0f, 64, trainer.batch_size_buffers[64]);
    const float* d64 = static_cast<const float*>(trainer.d_means.contents);
    double worst_batch = 0;
    for (uint32_t i = 0; i < 64; ++i)
        for (uint32_t axis = 0; axis < 3; ++axis) {
            const double added64 = double(d64[i * 4 + axis]) - double(before[i * 4 + axis]);
            const double added256 = double(derivative256[i * 4 + axis]) - double(before[i * 4 + axis]);
            worst_batch = std::max(worst_batch, std::fabs(added64 - 4.0 * added256));
        }
    require(worst_batch < 1e-7, "batch normalisation is not exactly 1/batch");
    json << " \"batch_normalisation_max_abs\": " << worst_batch << ",\n";

    // 6. gradient support: XYZ parameters only, and nonzero on the new rows
    std::memcpy(trainer.d_means.contents, before.data(), before.size() * 4);
    std::fill(static_cast<float*>(trainer.d_log_stds.contents),
              static_cast<float*>(trainer.d_log_stds.contents) + size_t(batch) * 4, 0.0f);
    retention_cb(1.0f, batch, trainer.batch_size_buffers[batch]);
    const std::vector<float> grad = read_actor_gradient(trainer, sim, batch, begin);
    const size_t w1_half = size_t(2560) * fixed_ppo::actor_obs_dim;
    // After PPO, both hidden halves can affect XYZ. Only the yaw output head
    // and log-standard-deviation leaves have exactly zero auxiliary derivative.
    double xyz = 0, yaw = 0, w2_xyz_second_half = 0, w1_second_half = 0;
    for (size_t i = 0; i < fixed_ppo::actor_w2_offset; ++i) {
        xyz += double(grad[i]) * grad[i];
        if(i>=w1_half && i<fixed_ppo::actor_b1_offset)
            w1_second_half += double(grad[i]) * grad[i];
    }
    const size_t w2 = fixed_ppo::actor_w2_offset;
    for (uint32_t a = 0; a < 4; ++a)
        for (uint32_t h = 0; h < 5120; ++h) {
            const double value = double(grad[w2 + size_t(a) * 5120 + h]);
            if (a < 3) {
                xyz += value * value;
                if (h >= 2560) w2_xyz_second_half += value * value;
            } else {
                yaw += value * value;
            }
        }
    for (uint32_t a = 0; a < 4; ++a) {
        const double value = double(grad[fixed_ppo::actor_b2_offset + a]);
        if (a < 3) xyz += value * value; else yaw += value * value;
    }
    for (size_t i = fixed_ppo::actor_log_std_offset; i < fixed_ppo::actor_param_count; ++i)
        yaw += double(grad[i]) * grad[i];
    require(std::sqrt(xyz) > 0.0, "retention gradient is zero on the XYZ parameters");
    require(w1_second_half > 0.0, "updated second hidden half has no retention derivative");
    require(std::sqrt(yaw) == 0.0,
            "retention gradient reached the yaw output head or log_std");
    json << " \"gradient_norm_xyz_parameters\": " << std::sqrt(xyz) << ",\n"
         << " \"gradient_norm_w1_second_half\": " << std::sqrt(w1_second_half) << ",\n"
         << " \"gradient_norm_yaw_parameters\": " << std::sqrt(yaw) << ",\n"
         << " \"gradient_norm_w2_xyz_second_half\": " << std::sqrt(w2_xyz_second_half) << ",\n"
         << " \"w2_xyz_second_half_note\": \"nonzero: an update can make the XYZ rows depend on the "
            "second hidden half, so the halves stop being separable\",\n";

    // 7. non-finite row: the kernel must report and contribute nothing
    {
        std::vector<float> poisoned(before);
        std::memcpy(trainer.d_means.contents, poisoned.data(), poisoned.size() * 4);
        std::vector<float> means_copy(static_cast<const float*>(trainer.actor_means.contents),
                                      static_cast<const float*>(trainer.actor_means.contents) + size_t(batch) * 4);
        const float nan = std::numeric_limits<float>::quiet_NaN();
        std::memcpy(trainer.actor_means.contents, &nan, sizeof(nan));
        retention_cb(1.0f, batch, trainer.batch_size_buffers[batch]);
        std::memcpy(trainer.actor_means.contents, means_copy.data(), means_copy.size() * 4);
        const float* after_poison = static_cast<const float*>(trainer.d_means.contents);
        double poison_delta = 0;
        for (uint32_t axis = 0; axis < 4; ++axis)
            poison_delta = std::max(poison_delta,
                                    std::fabs(double(after_poison[axis]) - double(before[axis])));
        const float row0 = static_cast<const float*>(trainer.retention_row_loss.contents)[0];
        require(std::isnan(row0), "non-finite row was not reported");
        require(poison_delta == 0.0, "non-finite row contributed a gradient");
        json << " \"nonfinite_row_reported\": true,\n \"nonfinite_row_gradient\": " << poison_delta << ",\n";
    }
    std::memcpy(trainer.d_means.contents, before.data(), before.size() * 4);

    json << " \"teacher_sha256\": \"" << session.teacher_sha256 << "\",\n"
         << " \"warmstart_parameter_file\": \"" << argv[4] << "\",\n"
         << " \"source_parameter_sha256\": \"" << challenge_evaluation::sha256_file(argv[4]) << "\",\n"
         << " \"observations_sha256\": \"" << ppo_safeguard_sha256(
                static_cast<const char*>(sim.obs.contents),
                size_t(rows) * fixed_ppo::actor_obs_dim * sizeof(float)) << "\"\n}\n";
    std::ofstream out(output);
    require(bool(out), "cannot write gradcheck output " + output);
    out << json.str();
    out.close();
    std::cout << "retention_gradcheck minibatch=" << begin << " fd_rel=" << worst_fd_rel
              << " metal_rel=" << worst_metal_rel << " output=" << output << '\n';
    return 0;
}

// --------------------------------------------------------------- calibrate
static int command_calibrate(int argc, char** argv) {
    require(argc >= 5, "retention-calibrate ROLLOUTS CHECKPOINT WARMSTART [options] --out FILE");
    Session session = setup_session(argc, argv, 1);
    const std::string output = session.options.out_path.empty()
        ? std::string(argv[3]) + ".calibration.json" : session.options.out_path;
    load_teacher(session);
    Sim& sim = *session.sim;
    PPOTrainer& trainer = *session.trainer;
    const uint32_t rows = sim.cfg.n * sim.horizon;
    const uint32_t batch = 256;
    trainer.enable_physical_retention(rows, sim.cfg.speed);
    trainer.set_retention_coefficient(0.0f);
    std::memset(session.run->sample_counts.contents, 0, session.run->sample_counts.length);
    auto collect = [&] {
        auto cb = [session.metal->queue commandBuffer];
        waypoint::local_collect(*session.run, cb, sim.horizon);
        session.metal->finish(cb);
    };
    auto normalise = [&] {
        auto cb = [sim.m.queue commandBuffer];
        trainer.dispatch(cb, trainer.gae_p, sim.cfg.n,
                         {{sim.rewards, 0}, {sim.values, 0}, {sim.next_values, 0}, {sim.terminated, 0},
                          {sim.truncated, 0}, {sim.advantages, 0}, {sim.returns, 0},
                          {trainer.horizon_b, 0}, {trainer.envs_b, 0}, {trainer.gamma_b, 0},
                          {trainer.lambda_b, 0}}, 64);
        trainer.dispatch(cb, trainer.normalize_p, 1,
                         {{sim.advantages, 0}, {trainer.rows_b, 0}, {trainer.gae_epsilon_b, 0},
                          {trainer.adv_clip_b, 0}}, 1);
        sim.m.finish(cb);
    };
    // One ordinary source rollout with the retention term at exactly zero, so the
    // student is a genuinely updated policy before the calibration batch.
    collect();
    cache_teacher_means(session);
    normalise();
    {
        auto cb = [session.metal->queue commandBuffer];
        trainer.rollout_update(cb, trainer.completed_rollouts);
        session.metal->finish(cb);
        trainer.completed_rollouts += 1;
    }
    // The first nonzero functional difference: the next rollout's first minibatch.
    collect();
    cache_teacher_means(session);
    normalise();
    const uint32_t rollout_index = trainer.completed_rollouts;
    std::vector<uint32_t> starts(rows / batch);
    for (uint32_t b = 0; b < starts.size(); ++b) starts[b] = b * batch;
    std::mt19937 rng(0x9e3779b9u + rollout_index * 0x85ebca6bu);
    std::shuffle(starts.begin(), starts.end(), rng);
    const uint32_t begin = starts[0];
    forward_minibatch(session, batch, begin);
    const std::vector<float> grad_ppo = read_actor_gradient(trainer, sim, batch, begin);
    const double norm_ppo = vector_norm(grad_ppo);
    // retention-only gradient at unit coefficient
    std::fill(static_cast<float*>(trainer.d_means.contents),
              static_cast<float*>(trainer.d_means.contents) + size_t(batch) * 4, 0.0f);
    std::fill(static_cast<float*>(trainer.d_log_stds.contents),
              static_cast<float*>(trainer.d_log_stds.contents) + size_t(batch) * 4, 0.0f);
    float unit = 1.0f;
    std::memcpy(trainer.retention_coefficient_b.contents, &unit, sizeof(unit));
    auto rc = [sim.m.queue commandBuffer];
    trainer.dispatch(rc, trainer.retention_grad_p, batch,
                     {{sim.obs, size_t(begin) * fixed_ppo::actor_obs_dim * 4}, {trainer.actor_means, 0},
                      {trainer.retention_teacher_means, size_t(begin) * fixed_ppo::action_dim * 4},
                      {trainer.d_means, 0}, {trainer.retention_row_loss, size_t(begin) * 4},
                      {trainer.batch_size_buffers[batch], 0}, {trainer.retention_coefficient_b, 0},
                      {trainer.retention_speed_b, 0}}, 64);
    sim.m.finish(rc);
    const std::vector<float> grad_retention = read_actor_gradient(trainer, sim, batch, begin);
    const double norm_retention = vector_norm(grad_retention);
    require(norm_retention > 0.0 && std::isfinite(norm_retention), "retention gradient is degenerate");
    const double coefficient = 0.25 * norm_ppo / norm_retention;
    // linearity of the coefficient, and the retention loss on this batch
    std::fill(static_cast<float*>(trainer.d_means.contents),
              static_cast<float*>(trainer.d_means.contents) + size_t(batch) * 4, 0.0f);
    float probe = float(coefficient);
    std::memcpy(trainer.retention_coefficient_b.contents, &probe, sizeof(probe));
    auto rc2 = [sim.m.queue commandBuffer];
    trainer.dispatch(rc2, trainer.retention_grad_p, batch,
                     {{sim.obs, size_t(begin) * fixed_ppo::actor_obs_dim * 4}, {trainer.actor_means, 0},
                      {trainer.retention_teacher_means, size_t(begin) * fixed_ppo::action_dim * 4},
                      {trainer.d_means, 0}, {trainer.retention_row_loss, size_t(begin) * 4},
                      {trainer.batch_size_buffers[batch], 0}, {trainer.retention_coefficient_b, 0},
                      {trainer.retention_speed_b, 0}}, 64);
    sim.m.finish(rc2);
    const std::vector<float> grad_scaled = read_actor_gradient(trainer, sim, batch, begin);
    const double norm_scaled = vector_norm(grad_scaled);
    const double linearity = std::fabs(norm_scaled / std::max(1e-30, norm_retention) - coefficient);
    const float* row_loss = static_cast<const float*>(trainer.retention_row_loss.contents);
    double loss_mean = 0;
    for (uint32_t i = 0; i < batch; ++i) loss_mean += row_loss[begin + i];
    loss_mean /= double(batch);
    require(std::isfinite(loss_mean), "retention loss is not finite on the calibration batch");
    std::ostringstream json;
    json << std::setprecision(17) << "{\n"
         << " \"purpose\": \"single TRAIN-only coefficient calibration; no DEV or outcome selection\",\n"
         << " \"seed\": " << sim.cfg.seed << ",\n"
         << " \"rollout_index\": " << rollout_index << ",\n"
         << " \"calibration_after_ordinary_rollout\": true,\n"
         << " \"minibatch_begin\": " << begin << ",\n"
         << " \"batch\": " << batch << ",\n"
         << " \"speed_mps\": " << sim.cfg.speed << ",\n"
         << " \"warmstart_parameter_file\": \"" << argv[4] << "\",\n"
         << " \"source_parameter_sha256\": \"" << challenge_evaluation::sha256_file(argv[4]) << "\",\n"
         << " \"warmstart\": \"" << argv[4] << "\",\n"
         << " \"warmstart_sha256\": \"" << challenge_evaluation::sha256_file(argv[4]) << "\",\n"
         << " \"teacher\": \"" << session.options.teacher_path << "\",\n"
         << " \"teacher_sha256\": \"" << session.teacher_sha256 << "\",\n"
         << " \"observations_sha256\": \"" << ppo_safeguard_sha256(
                static_cast<const char*>(sim.obs.contents),
                size_t(rows) * fixed_ppo::actor_obs_dim * sizeof(float)) << "\",\n"
         << " \"advantage_sha256\": \"" << ppo_safeguard_sha256(
                static_cast<const char*>(sim.advantages.contents), size_t(rows) * sizeof(float)) << "\",\n"
         << " \"teacher_means_sha256\": \"" << ppo_safeguard_sha256(
                static_cast<const char*>(trainer.retention_teacher_means.contents),
                size_t(rows) * fixed_ppo::action_dim * sizeof(float)) << "\",\n"
         << " \"student_means_sha256\": \"" << ppo_safeguard_sha256(
                static_cast<const char*>(trainer.actor_means.contents),
                size_t(batch) * fixed_ppo::action_dim * sizeof(float)) << "\",\n"
         << " \"ppo_actor_gradient_norm\": " << norm_ppo << ",\n"
         << " \"retention_actor_gradient_norm_unit_coefficient\": " << norm_retention << ",\n"
         << " \"ratio_target\": 0.25,\n"
         << " \"coefficient\": " << coefficient << ",\n"
         << " \"coefficient_linearity_max_abs\": " << linearity << ",\n"
         << " \"retention_loss_mean_batch\": " << loss_mean << ",\n"
         << " \"note\": \"norm is the pre-clip actor-parameter gradient of the additive loss on one "
            "globally normalised source minibatch; later ratios are not guaranteed\"\n}\n";
    std::ofstream out(output);
    require(bool(out), "cannot write calibration output " + output);
    out << json.str();
    out.close();
    std::cout << "retention_calibrate norm_ppo=" << norm_ppo << " norm_retention=" << norm_retention
              << " coefficient=" << coefficient << " linearity=" << linearity << '\n';
    return 0;
}

}  // namespace retention_run
