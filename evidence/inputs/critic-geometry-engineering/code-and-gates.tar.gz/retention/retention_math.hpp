// Physical-mean retention: the deployed mode-22 translation map, its loss, and
// its exact derivative. One definition of the math, used by three consumers:
//
//   * the Metal kernel below (training path),
//   * the float64 CPU reference (finite-difference and parity checks),
//   * the report's description of the map.
//
// The map is the one sim_act actually executes in mode 22, applied to the
// actor's Gaussian MEAN instead of a sample:
//
//   prior_j    = obs[181+j]                         (deployed geometry prior)
//   gate       = 0.25 + 0.75 * #{k<20 : obs[k]*12 > 2.5} / 20
//   executed_j = prior_j + gate * (mean_j - prior_j)   j in 0..2
//   q_j        = tanh(executed_j)
//   q_s        = min(1, 1/||q||)
//   v_j        = speed * q_s * q_j                  (desired BODY velocity, m/s)
//
// speed is the run's cfg.speed (1.5 here) and the projection is the same
// spherical cap sim_act applies under velocity_contract 1. The loss is the mean
// squared error over the three translation axes between the student and the
// frozen teacher; yaw (axis 3) and log_std never enter it.
#pragma once

#include <cmath>
#include <cstdint>

namespace retention {

static constexpr uint32_t kAxes = 3;

// ---------------------------------------------------------------- MSL kernel
static const char* kRetentionMSL = R"MSL(
// Training-only physical-mean retention. Adds the loss gradient for the three
// translation axes to d_mean before the actor backward pass. Yaw, log_std and
// the critic objective are untouched. row_loss holds the per-row squared error
// in (m/s)^2 for reporting only.
kernel void ppo_physical_retention_grad(device const float* observations [[buffer(0)]],
                                        device const float* means [[buffer(1)]],
                                        device const float* teacher_means [[buffer(2)]],
                                        device float* d_means [[buffer(3)]],
                                        device float* row_loss [[buffer(4)]],
                                        constant uint& batch_size [[buffer(5)]],
                                        constant float& coefficient [[buffer(6)]],
                                        constant float& speed [[buffer(7)]],
                                        uint n [[thread_position_in_grid]]) {
    if(n>=batch_size)return;
    const uint obs_base=n*PPO_ACTOR_OBS;
    const uint a_base=n*PPO_ACTIONS;
    float overhead=0.0f;
    for(uint k=0;k<20;k++)overhead+=observations[obs_base+k]*12.0f>2.5f;
    const float gate=0.25f+0.75f*(overhead/20.0f);
    float q[3],t[3];
    for(uint axis=0;axis<3;axis++) {
        const float prior=observations[obs_base+PPO_ACTOR_OBS-3+axis];
        q[axis]=tanh(prior+gate*(means[a_base+axis]-prior));
        t[axis]=tanh(prior+gate*(teacher_means[a_base+axis]-prior));
    }
    const float q_n=sqrt(q[0]*q[0]+q[1]*q[1]+q[2]*q[2]);
    const float t_n=sqrt(t[0]*t[0]+t[1]*t[1]+t[2]*t[2]);
    if(!isfinite(q_n) || !isfinite(t_n)) {
        // A non-finite row must never contribute a gradient; the host checks
        // the reported loss and refuses the rollout.
        row_loss[n]=NAN;
        return;
    }
    const float q_s=q_n>1.0f?1.0f/q_n:1.0f;
    const float t_s=t_n>1.0f?1.0f/t_n:1.0f;
    float total=0.0f;
    for(uint axis=0;axis<3;axis++) {
        const float d=speed*(q_s*q[axis]-t_s*t[axis]);
        total+=d*d;
    }
    row_loss[n]=total/3.0f;
    const float scale=coefficient/float(max(batch_size,1u));
    for(uint axis=0;axis<3;axis++) {
        float acc=0.0f;
        for(uint j=0;j<3;j++) {
            const float dv=speed*(q_s*q[j]-t_s*t[j]);
            const float dq=(q_n>1.0f)
                ? ((axis==j?1.0f/q_n:0.0f)-q[j]*q[axis]/(q_n*q_n*q_n))
                : (axis==j?1.0f:0.0f);
            acc+=dv*dq;
        }
        d_means[a_base+axis]+=scale*(2.0f/3.0f)*speed*(1.0f-q[axis]*q[axis])*gate*acc;
    }
}
)MSL";

// ------------------------------------------------------- float64 reference
// Mirrors the kernel above exactly, in double precision.
struct Map {
    double speed = 1.5;

    static double gate_of(const double* obs) {
        double overhead = 0.0;
        for (uint32_t k = 0; k < 20; ++k) overhead += (obs[k] * 12.0 > 2.5) ? 1.0 : 0.0;
        return 0.25 + 0.75 * (overhead / 20.0);
    }
    static double prior_of(const double* obs, uint32_t axis) {
        return obs[184 - 3 + axis];
    }
    // q_j = tanh(prior + gate*(mean - prior)) for the three translation axes
    static void latents(const double* mean, const double* obs, double q[3]) {
        const double gate = gate_of(obs);
        for (uint32_t axis = 0; axis < 3; ++axis) {
            const double prior = prior_of(obs, axis);
            q[axis] = std::tanh(prior + gate * (mean[axis] - prior));
        }
    }
    // Desired body velocity in m/s for the three translation axes.
    static void velocity(const double* mean, const double* obs, double speed, double v[3]) {
        double q[3];
        latents(mean, obs, q);
        const double n = std::sqrt(q[0] * q[0] + q[1] * q[1] + q[2] * q[2]);
        const double s = n > 1.0 ? 1.0 / n : 1.0;
        for (uint32_t axis = 0; axis < 3; ++axis) v[axis] = speed * s * q[axis];
    }
    // Loss and its exact derivative with respect to the student's four means.
    // grad[3] is always exactly zero: yaw is not supervised.
    static double loss_grad(const double* student, const double* teacher, const double* obs,
                            double speed, double grad[4]) {
        double q[3], t[3];
        latents(student, obs, q);
        latents(teacher, obs, t);
        const double q_n = std::sqrt(q[0] * q[0] + q[1] * q[1] + q[2] * q[2]);
        const double t_n = std::sqrt(t[0] * t[0] + t[1] * t[1] + t[2] * t[2]);
        const double q_s = q_n > 1.0 ? 1.0 / q_n : 1.0;
        const double t_s = t_n > 1.0 ? 1.0 / t_n : 1.0;
        double total = 0.0;
        for (uint32_t axis = 0; axis < 3; ++axis) {
            const double d = speed * (q_s * q[axis] - t_s * t[axis]);
            total += d * d;
        }
        const double loss = total / 3.0;
        const double gate = gate_of(obs);
        for (uint32_t axis = 0; axis < 4; ++axis) grad[axis] = 0.0;
        for (uint32_t axis = 0; axis < 3; ++axis) {
            double acc = 0.0;
            for (uint32_t j = 0; j < 3; ++j) {
                const double dv = speed * (q_s * q[j] - t_s * t[j]);
                const double dq = (q_n > 1.0)
                    ? ((axis == j ? 1.0 / q_n : 0.0) - q[j] * q[axis] / (q_n * q_n * q_n))
                    : (axis == j ? 1.0 : 0.0);
                acc += dv * dq;
            }
            grad[axis] = (2.0 / 3.0) * speed * (1.0 - q[axis] * q[axis]) * gate * acc;
        }
        return loss;
    }
};

}  // namespace retention
