// Functional-retention session: setup shared by the training, derivative and
// calibration commands. Included after the frozen trainer copy.
#pragma once

#include "retention_math.hpp"

#ifndef RETENTION_IMPLEMENTATION_SHA256
#error "Build must pin the physical-retention implementation"
#endif
namespace retention_run {

using waypoint::BankControl;
using waypoint::BankEntry;
using waypoint::LocalRun;
using waypoint::TrainingOptions;

// ---------------------------------------------------------------- sidecar
struct RetentionSidecar {
    bool enabled = false;
    float coefficient = 0.0f;
    float speed = 0.0f;
    std::string teacher_sha256;
    uint32_t teacher_parameters = 0, teacher_width = 0;
    uint32_t student_width = 0, actor_obs_dim = 0, action_dim = 0;
    std::string anchor_reference_sha256;
};

static void write_retention_sidecar(const std::string& path, const RetentionSidecar& sidecar,
                                    const std::string& teacher_path) {
    std::ofstream out(path);
    require(bool(out), "cannot write retention sidecar " + path);
    out << std::setprecision(9) << "{\n"
        << "  \"schema\": \"physical-mean-retention-v2\",\n"
        << "  \"implementation_sha256\": \"" << RETENTION_IMPLEMENTATION_SHA256 << "\",\n"
        << "  \"enabled\": " << (sidecar.enabled ? 1 : 0) << ",\n"
        << "  \"coefficient\": " << sidecar.coefficient << ",\n"
        << "  \"speed_mps\": " << sidecar.speed << ",\n"
        << "  \"axes\": [0, 1, 2],\n"
        << "  \"yaw_supervised\": 0,\n"
        << "  \"log_std_supervised\": 0,\n"
        << "  \"map\": \"mode22_prior_gate_tanh_spherical_speed\",\n"
        << "  \"gate\": \"0.25+0.75*count(obs[k]*12>2.5,k<20)/20\",\n"
        << "  \"prior_offset\": 181,\n"
        << "  \"teacher_path\": \"" << teacher_path << "\",\n"
        << "  \"teacher_sha256\": \"" << sidecar.teacher_sha256 << "\",\n"
        << "  \"teacher_actor_parameters\": " << sidecar.teacher_parameters << ",\n"
        << "  \"teacher_width\": " << sidecar.teacher_width << ",\n"
        << "  \"student_width\": " << sidecar.student_width << ",\n"
        << "  \"actor_obs_dim\": " << sidecar.actor_obs_dim << ",\n"
        << "  \"action_dim\": " << sidecar.action_dim << ",\n"
        << "  \"anchor_reference_sha256\": \"" << sidecar.anchor_reference_sha256 << "\",\n"
        << "  \"teacher_policy\": \"frozen; loaded once, never recaptured from the student\"\n"
        << "}\n";
    require(bool(out), "retention sidecar write failed");
}

static std::string retention_token(const std::string& text, const std::string& key) {
    const std::string needle = "\"" + key + "\"";
    const size_t position = text.find(needle);
    require(position != std::string::npos, "retention sidecar is missing required key \"" + key + "\"");
    const size_t colon = text.find(':', position + needle.size());
    require(colon != std::string::npos, "retention sidecar key \"" + key + "\" has no value");
    size_t begin = colon + 1;
    while (begin < text.size() && (text[begin] == ' ' || text[begin] == '\t')) ++begin;
    if (begin < text.size() && text[begin] == '"') {
        const size_t end = text.find('"', begin + 1);
        require(end != std::string::npos, "retention sidecar string is unterminated");
        return text.substr(begin + 1, end - begin - 1);
    }
    size_t end = begin;
    while (end < text.size() && text[end] != ',' && text[end] != '\n' && text[end] != '}') ++end;
    return text.substr(begin, end - begin);
}

// Loads and validates the retention sidecar. Every mismatch is refused before
// any learner state is touched.
static RetentionSidecar load_retention_sidecar(const std::string& path, const RetentionSidecar& expected,
                                               const std::string& teacher_path) {
    require(std::filesystem::exists(path),
            "retention is enabled but " + path + " is missing; refusing to resume");
    const std::string text = [&] {
        std::ifstream file(path);
        require(bool(file), "cannot read retention sidecar " + path);
        return std::string(std::istreambuf_iterator<char>(file), std::istreambuf_iterator<char>());
    }();
    require(retention_token(text, "schema") == "physical-mean-retention-v2",
            "retention sidecar schema mismatch");
    require(retention_token(text,"implementation_sha256")==RETENTION_IMPLEMENTATION_SHA256,
            "retention implementation differs from the saved run");
    require(std::stoi(retention_token(text, "enabled")) == 1,
            "retention sidecar was written disabled but this run enables retention");
    require(std::stoi(retention_token(text, "yaw_supervised")) == 0 &&
            std::stoi(retention_token(text, "log_std_supervised")) == 0,
            "retention sidecar supervises a channel this implementation does not");
    require(retention_token(text, "map") == "mode22_prior_gate_tanh_spherical_speed",
            "retention sidecar physical map mismatch");
    require(retention_token(text, "teacher_sha256") == expected.teacher_sha256,
            "retention teacher differs from the saved run");
    require(retention_token(text, "teacher_path") == teacher_path,
            "retention teacher path differs from the saved run");
    require(std::stoul(retention_token(text, "teacher_actor_parameters")) == expected.teacher_parameters &&
            std::stoul(retention_token(text, "teacher_width")) == expected.teacher_width &&
            std::stoul(retention_token(text, "student_width")) == expected.student_width &&
            std::stoul(retention_token(text, "actor_obs_dim")) == expected.actor_obs_dim &&
            std::stoul(retention_token(text, "action_dim")) == expected.action_dim,
            "retention sidecar architecture mismatch");
    require(std::stof(retention_token(text, "speed_mps")) == expected.speed,
            "retention sidecar speed differs from the run's speed cap");
    require(std::stof(retention_token(text, "coefficient")) == expected.coefficient,
            "retention coefficient differs from the saved run");
    require(retention_token(text, "anchor_reference_sha256") == expected.anchor_reference_sha256,
            "retention anchor reference differs from the saved run");
    RetentionSidecar loaded;
    loaded.enabled = true;
    loaded.coefficient = std::stof(retention_token(text, "coefficient"));
    loaded.speed = std::stof(retention_token(text, "speed_mps"));
    loaded.teacher_sha256 = retention_token(text, "teacher_sha256");
    loaded.teacher_parameters = uint32_t(std::stoul(retention_token(text, "teacher_actor_parameters")));
    loaded.teacher_width = uint32_t(std::stoul(retention_token(text, "teacher_width")));
    loaded.student_width = uint32_t(std::stoul(retention_token(text, "student_width")));
    loaded.actor_obs_dim = uint32_t(std::stoul(retention_token(text, "actor_obs_dim")));
    loaded.action_dim = uint32_t(std::stoul(retention_token(text, "action_dim")));
    loaded.anchor_reference_sha256 = retention_token(text, "anchor_reference_sha256");
    return loaded;
}

// ------------------------------------------------------------------ options
struct Options : TrainingOptions {
    std::string teacher_path, out_path;
    float retention_coefficient = 0.0f;
    bool inherit_log_std = false;
    bool save_snapshots = false;
    uint32_t eval_every_override = 0;
};

static void parse_options(int argc, char** argv, int start, Options& options) {
    for (int index = start; index < argc; index++) {
        const std::string option = argv[index];
        if (option == "--spec") options.spec = waypoint::spec_by_name(waypoint::option_value(argc, argv, index, option));
        else if (option == "--bank") options.bank_path = waypoint::option_value(argc, argv, index, option);
        else if (option == "--seed") options.seed = waypoint::option_uint(argc, argv, index, option);
        else if (option == "--model-snapshots") options.model_snapshots = waypoint::option_uint(argc, argv, index, option);
        else if (option == "--sensor-delay") options.sensor_delay = waypoint::option_uint(argc, argv, index, option);
        else if (option == "--command-delay") options.command_delay = waypoint::option_uint(argc, argv, index, option);
        else if (option == "--epochs") options.epochs = waypoint::option_uint(argc, argv, index, option);
        else if (option == "--envs") options.environments = waypoint::option_uint(argc, argv, index, option);
        else if (option == "--horizon") options.horizon = waypoint::option_uint(argc, argv, index, option);
        else if (option == "--logstd") options.log_std = waypoint::option_float(argc, argv, index, option);
        else if (option == "--learning-rate") options.learning_rate = waypoint::option_float(argc, argv, index, option);
        else if (option == "--entropy") options.entropy = waypoint::option_float(argc, argv, index, option);
        else if (option == "--speed") options.speed = waypoint::option_float(argc, argv, index, option);
        else if (option == "--time-cost") options.time_cost = waypoint::option_float(argc, argv, index, option);
        else if (option == "--contact-penalty") options.contact_penalty = waypoint::option_float(argc, argv, index, option);
        else if (option == "--arrival-bonus") options.arrival_bonus = waypoint::option_float(argc, argv, index, option);
        else if (option == "--anchor") options.anchor_lambda = waypoint::option_float(argc, argv, index, option);
        else if (option == "--anchor-radius") options.anchor_radius = waypoint::option_float(argc, argv, index, option);
        else if (option == "--actor-step-factor") options.actor_step_factor = waypoint::option_float(argc, argv, index, option);
        else if (option == "--eval-spec") options.eval_spec = waypoint::option_value(argc, argv, index, option);
        else if (option == "--eval-every") options.eval_every = waypoint::option_uint(argc, argv, index, option);
        else if (option == "--retention-teacher") options.teacher_path = waypoint::option_value(argc, argv, index, option);
        else if (option == "--retention-coefficient") options.retention_coefficient = waypoint::option_float(argc, argv, index, option);
        else if (option == "--inherit-logstd") options.inherit_log_std = waypoint::option_uint(argc, argv, index, option) != 0;
        else if (option == "--save-snapshots") options.save_snapshots = waypoint::option_uint(argc, argv, index, option) != 0;
        else if (option == "--out") options.out_path = waypoint::option_value(argc, argv, index, option);
        else throw std::runtime_error("unknown retention option " + option);
    }
}

// ------------------------------------------------------------------ session
struct Session {
    std::unique_ptr<Metal> metal;
    std::unique_ptr<Sim> sim;
    std::unique_ptr<PPOTrainer> trainer;
    std::unique_ptr<LocalRun> run;
    BankControl control{};
    std::vector<BankEntry> bank;
    std::string bank_sha;
    std::vector<BankEntry> eval_bank;
    BankControl eval_control{};
    std::string eval_bank_sha = "none";
    waypoint::BankSpec eval_spec{};
    Options options;
    bool resume = false;
    // teacher
    id<MTLBuffer> teacher_weights = nil, teacher_hidden = nil, teacher_chunk_means = nil;
    std::string teacher_sha256;
    uint32_t teacher_parameters = 0, teacher_width = 0;
    std::vector<float> teacher_host;
    // retention reporting
    std::vector<float> row_loss_host;
};

static Session setup_session(int argc, char** argv, uint32_t rollouts) {
    require(argc >= 5, "expected ROLLOUTS CHECKPOINT WARMSTART");
    Session session;
    Options& options = session.options;
    const std::string checkpoint = argv[3], warmstart = argv[4];
    options.spec = waypoint::spec_by_name("source");
    options.eval_bank_spec = waypoint::spec_by_name("dev-a");
    parse_options(argc, argv, 5, options);
    require(rollouts > 0 && fixed_ppo::actor_obs_dim == 184, "retention runs need the 184D actor");
    require(options.actor_step_factor > 0.0f && options.actor_step_factor <= 1.0f, "actor step factor");
    if (!options.bank_path.empty()) options.spec.environments = options.environments;

    BankControl control{options.spec.period, uint32_t(options.spec.environments * options.spec.period)};
    std::vector<BankEntry> bank;
    std::string bank_sha;
    std::ostringstream bank_csv;
    if (options.bank_path.empty()) {
        bank_csv << std::setprecision(9);
        bank = waypoint::build_bank(options.spec, &bank_csv);
        bank_sha = ppo_safeguard_sha256(bank.data(), bank.size() * sizeof(BankEntry));
    } else {
        bank = waypoint::read_bank(options.bank_path, control, bank_sha);
        require(size_t(control.count) == size_t(options.environments) * control.period, "bank size mismatch");
    }
    session.control = control;
    session.bank = bank;
    session.bank_sha = bank_sha;

    if (options.eval_spec != "none") {
        options.eval_bank_spec = waypoint::spec_by_name(options.eval_spec);
        session.eval_spec = options.eval_bank_spec;
        std::ostringstream csv;
        session.eval_bank = waypoint::build_bank(session.eval_spec, &csv);
        session.eval_control.period = session.eval_spec.period;
        session.eval_control.count = uint32_t(session.eval_bank.size());
        session.eval_bank_sha = ppo_safeguard_sha256(session.eval_bank.data(),
                                                    session.eval_bank.size() * sizeof(BankEntry));
    }

    waypoint::TrainContract contract;
    contract.sensor_profile = NAV_SENSOR_ACTIVE_NAME;
    contract.actor_obs_dim = uint32_t(fixed_ppo::actor_obs_dim);
    contract.actor_hidden_dim = uint32_t(fixed_ppo::actor_hidden_dim);
    contract.actor_step_factor = options.actor_step_factor;
    contract.runner_sha256 = waypoint::contract_runner_sha256();
    contract.core_sha256 = waypoint::contract_core_sha256();
    contract.warmstart_sha256 = challenge_evaluation::sha256_file(warmstart);
    contract.bank_spec = options.spec.name;
    contract.bank_seed = options.spec.seed;
    contract.bank_entry_sha256 = bank_sha;
    contract.bank_entries = uint32_t(bank.size());
    contract.bank_period = control.period;
    contract.eval_spec = options.eval_spec;
    contract.eval_entry_sha256 = session.eval_bank_sha;
    contract.eval_entries = uint32_t(session.eval_bank.size());
    contract.eval_period = session.eval_control.period;
    contract.environments = options.environments;
    contract.horizon = options.horizon;
    contract.epochs = options.epochs;
    contract.eval_every = options.eval_every;
    contract.sensor_delay = options.sensor_delay;
    contract.command_delay = options.command_delay;
    contract.delay_rehearsal = NAV_DELAY_REHEARSAL;
    contract.model_snapshots = options.model_snapshots;
    contract.max_steps = 400;
    contract.learning_rate = options.learning_rate;
    contract.entropy_coef = options.entropy;
    contract.risk_coef = 0.0f;
    contract.value_coef = 0.5f;
    contract.speed = options.speed;
    contract.time_cost = options.time_cost;
    contract.contact_penalty = options.contact_penalty;
    contract.arrival_bonus = options.arrival_bonus;
    contract.warmstart_log_std = options.log_std;
    session.resume = std::filesystem::exists(checkpoint);
    if (session.resume) {
        waypoint::require_contract_matches(checkpoint + ".train.json", contract);
    } else {
        std::ofstream csv(checkpoint + ".bank.csv");
        waypoint::write_contract(checkpoint + ".train.json", contract);
    }

    session.metal = std::make_unique<Metal>();
    session.metal->compile(base_source() + PPO_TRAINER_MSL + waypoint::kWaypointKernels +
                           retention::kRetentionMSL);
    auto apply_pipeline = session.metal->pipeline("waypoint_task_apply");
    SimConfig config;
    config.n = options.environments; config.mode = 22; config.family = 0; config.seed = options.seed;
    config.sensor_delay = options.sensor_delay; config.command_delay = options.command_delay;
    config.speed = options.speed; config.distance = 4; config.max_steps = 400; config.geometry_memory = 1;
    config.entropy_coef = options.entropy; config.learning_rate = options.learning_rate;
    session.sim = std::make_unique<Sim>(*session.metal, config, options.horizon);
    Sim& sim = *session.sim;
    session.run = std::make_unique<LocalRun>(waypoint::make_local_run(
        sim, bank, control, apply_pipeline, options.time_cost, options.contact_penalty, options.arrival_bonus));
    session.run->sample_counts = session.metal->buffer(size_t(control.count) * sizeof(uint32_t));
    session.run->sample_count_pipeline = session.metal->pipeline("waypoint_count_sample");
    session.trainer = std::make_unique<PPOTrainer>(sim, options.epochs);
    session.trainer->set_actor_step_factor(options.actor_step_factor);
    const PpoSafeguardConfig safeguards{options.epochs, 0.0f, 0.5f, options.anchor_lambda,
                                        options.anchor_radius, 0.0f, std::string(64, '0')};
    if (session.resume) {
        std::ifstream saved(checkpoint, std::ios::binary);
        const auto existing_header = read_checkpoint_header(saved);
        load_ppo_safeguard_state(checkpoint, safeguards, existing_header.completed_rollouts,
                                 options.anchor_lambda > 0 ? session.trainer->anchor_ref_b.contents : nullptr);
        session.trainer->load_checkpoint(checkpoint, config.family, options.horizon, options.environments, options.seed);
    } else {
        navigation_training::load_actor(sim, warmstart, true);
        if (!options.inherit_log_std) {
            for (uint32_t axis = 0; axis < 4; axis++)
                ((float*)sim.actor.contents)[fixed_ppo::actor_log_std_offset + axis] = options.log_std;
        }
        session.trainer->recapture_anchor_reference();
    }
    session.trainer->set_anchor(options.anchor_lambda, options.anchor_radius);
    return session;
}

// Teacher weights are a frozen copy of the composed actor's parameters.
static void load_teacher(Session& session) {
    require(!session.options.teacher_path.empty(), "retention requires --retention-teacher");
    const std::string& path = session.options.teacher_path;
    session.teacher_sha256 = challenge_evaluation::sha256_file(path);
    std::ifstream file(path, std::ios::binary);
    const PpoCheckpointHeader header = read_checkpoint_header(file);
    require(header.actor_count == fixed_ppo::actor_param_count,
            "retention teacher actor dimensions do not match the student");
    session.teacher_parameters = header.actor_count;
    session.teacher_width = uint32_t(fixed_ppo::actor_hidden_dim);
    session.teacher_host.resize(header.actor_count);
    file.read(reinterpret_cast<char*>(session.teacher_host.data()),
              std::streamsize(session.teacher_host.size() * sizeof(float)));
    require(bool(file), "retention teacher read failed");
    session.teacher_weights = session.metal->buffer(session.teacher_host.size() * 4,
                                                   session.teacher_host.data());
    session.teacher_hidden = session.metal->buffer(size_t(256) * fixed_ppo::actor_hidden_dim * 4);
    session.teacher_chunk_means = session.metal->buffer(size_t(256) * fixed_ppo::action_dim * 4);
}

// One teacher forward for the whole rollout, cached for the update. Uses the
// same observation buffer as the student; no oracle labels, no teacher at
// inference.
static void cache_teacher_means(Session& session) {
    Sim& sim = *session.sim;
    PPOTrainer& trainer = *session.trainer;
    const uint32_t rows = sim.cfg.n * sim.horizon;
    for (uint32_t begin = 0; begin < rows; begin += 256) {
        auto cb = [session.metal->queue commandBuffer];
        encode_actor_forward(*session.metal, cb, sim.wide_actor, sim.simd_actor, sim.obs,
                             size_t(begin) * fixed_ppo::actor_obs_dim * 4, session.teacher_weights,
                             session.teacher_hidden, session.teacher_chunk_means, 0,
                             trainer.batch_size_buffers[256], 256);
        session.metal->finish(cb);
        std::memcpy(static_cast<char*>(trainer.retention_teacher_means.contents) +
                        size_t(begin) * fixed_ppo::action_dim * 4,
                    session.teacher_chunk_means.contents, size_t(256) * fixed_ppo::action_dim * 4);
    }
}

}  // namespace retention_run
