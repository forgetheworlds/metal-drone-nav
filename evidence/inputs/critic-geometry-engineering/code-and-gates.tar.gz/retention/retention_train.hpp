// Retention training loop: the ordinary source trainer with the physical-mean
// retention loss enabled. With coefficient 0 and no teacher the code path is the
// ordinary one, which the byte-parity gate verifies.
#pragma once

#include "retention_commands.hpp"

namespace retention_run {

static int command_train(int argc, char** argv) {
    require(argc >= 5, "retention-train ROLLOUTS CHECKPOINT WARMSTART [options]");
    const uint32_t rollouts = uint32_t(std::stoul(argv[2]));
    const std::string checkpoint = argv[3];
    Session session = setup_session(argc, argv, rollouts);
    Options& options = session.options;
    Sim& sim = *session.sim;
    PPOTrainer& trainer = *session.trainer;
    LocalRun& run = *session.run;
    const uint32_t rows = sim.cfg.n * sim.horizon;
    const bool retention_enabled = options.retention_coefficient > 0.0f;
    require(retention_enabled == !options.teacher_path.empty(),
            "a retention teacher is required exactly when the coefficient is positive");

    if (retention_enabled) {
        load_teacher(session);
        const std::string anchor_hash = ppo_safeguard_sha256(trainer.anchor_ref_b.contents,
                                                             trainer.anchor_ref_b.length);
        RetentionSidecar expected;
        expected.enabled = true;
        expected.coefficient = options.retention_coefficient;
        expected.speed = sim.cfg.speed;
        expected.teacher_sha256 = session.teacher_sha256;
        expected.teacher_parameters = session.teacher_parameters;
        expected.teacher_width = session.teacher_width;
        expected.student_width = uint32_t(fixed_ppo::actor_hidden_dim);
        expected.actor_obs_dim = uint32_t(fixed_ppo::actor_obs_dim);
        expected.action_dim = uint32_t(fixed_ppo::action_dim);
        expected.anchor_reference_sha256 = anchor_hash;
        const std::string sidecar_path = checkpoint + ".retention.json";
        if (session.resume) {
            load_retention_sidecar(sidecar_path, expected, options.teacher_path);
        } else {
            write_retention_sidecar(sidecar_path, expected, options.teacher_path);
        }
        trainer.enable_physical_retention(rows, sim.cfg.speed);
        trainer.set_retention_coefficient(options.retention_coefficient);
        std::cout << "retention_enabled coefficient=" << options.retention_coefficient
                  << " speed=" << sim.cfg.speed << " teacher=" << options.teacher_path
                  << " teacher_sha256=" << session.teacher_sha256.substr(0, 16)
                  << " anchor_reference_sha256=" << anchor_hash.substr(0, 16) << "\n";
    } else if (std::filesystem::exists(checkpoint + ".retention.json")) {
        // Coefficient 0 stays backward compatible: an absent sidecar is fine, a
        // sidecar recorded as enabled is a mismatch and must be refused.
        std::ifstream sidecar(checkpoint + ".retention.json");
        const std::string text{std::istreambuf_iterator<char>(sidecar), std::istreambuf_iterator<char>()};
        require(retention_token(text, "enabled") == "0",
                "this run disables retention but the checkpoint was trained with it enabled");
    }

    if (!session.resume) {
        auto probe = [session.metal->queue commandBuffer];
        waypoint::local_probe(run, probe);
        session.metal->finish(probe);
        waypoint::verify_reset(run, session.bank, session.control, options.sensor_delay == 0);
    }

    const std::filesystem::path checkpoint_path(checkpoint);
    if (checkpoint_path.has_parent_path()) std::filesystem::create_directories(checkpoint_path.parent_path());
    std::ofstream history(checkpoint + ".retention-history.csv", session.resume ? std::ios::app : std::ios::trunc);
    require(bool(history), "cannot write retention history");
    if (!session.resume)
        history << std::setprecision(9)
                << "rollout,transitions,wall_s,collect_gpu_s,update_gpu_s,policy_loss,value_loss,entropy,ratio,"
                   "episodes,ep_success,ep_contact,ep_timeout,clearance_min,logstd0,logstd1,logstd2,logstd3,"
                   "actor_drift_l2,actor_grad_norm_mean,actor_clip_frac,critic_grad_norm_mean,critic_clip_frac,"
                   "ppo_plus_retention_grad_norm_mean,anchor_grad_norm_mean,weight_update_l2,"
                   "retention_loss_mean_m2s2,retention_coefficient\n";
    std::ofstream slot_samples(checkpoint + ".slot-samples.csv", session.resume ? std::ios::app : std::ios::trunc);
    std::ofstream delay_samples(checkpoint + ".delay-exposure.csv", session.resume ? std::ios::app : std::ios::trunc);
    std::vector<SimRun> previous_runs(options.environments);
    std::vector<uint64_t> entry_totals(session.control.count, 0);
    const double started = seconds();
    double total_collect_gpu = 0, total_update_gpu = 0;
    size_t peak_gpu_allocated = session.metal->device.currentAllocatedSize;
    const uint32_t finish = trainer.completed_rollouts + rollouts;
    std::vector<float> actor_before(size_t(fixed_ppo::actor_param_count), 0.0f);
    std::cout << "retention_train environments=" << options.environments << " horizon=" << options.horizon
              << " epochs=" << options.epochs << " lr=" << options.learning_rate
              << " actor_step_factor=" << options.actor_step_factor << " anchor=" << options.anchor_lambda
              << " start=" << trainer.completed_rollouts << " finish=" << finish
              << " inherit_logstd=" << int(options.inherit_log_std) << "\n";
    for (uint32_t rollout = trainer.completed_rollouts; rollout < finish; rollout++) { @autoreleasepool {
        std::memcpy(previous_runs.data(), sim.runs.contents, options.environments * sizeof(SimRun));
        std::memset(run.sample_counts.contents, 0, run.sample_counts.length);
        auto commands = [session.metal->queue commandBuffer];
        waypoint::local_collect(run, commands, options.horizon);
        const double collect_gpu = session.metal->finish(commands);
        std::memcpy(actor_before.data(), sim.actor.contents, size_t(fixed_ppo::actor_param_count) * 4);
        if (retention_enabled) cache_teacher_means(session);
        auto update = [session.metal->queue commandBuffer];
        trainer.rollout_update(update, rollout);
        const double update_gpu = session.metal->finish(update);
        total_collect_gpu += collect_gpu;
        total_update_gpu += update_gpu;
        peak_gpu_allocated = std::max(peak_gpu_allocated, size_t(session.metal->device.currentAllocatedSize));
        trainer.completed_rollouts = rollout + 1;

        double retention_loss = 0;
        if (retention_enabled) {
            const float* row_loss = static_cast<const float*>(trainer.retention_row_loss.contents);
            for (uint32_t row = 0; row < rows; ++row) {
                require(std::isfinite(row_loss[row]),
                        "retention loss is not finite at rollout " + std::to_string(rollout + 1));
                retention_loss += row_loss[row];
            }
            retention_loss /= double(rows);
        }
        const auto* actor_obs = static_cast<const float*>(sim.obs.contents);
        uint64_t clean_rows = 0, delayed_rows = 0, positive_age = 0;
        float max_age = 0;
        for (size_t row = 0; row < rows; row++) {
            const uint32_t env = uint32_t(row % options.environments);
            const bool clean = NAV_DELAY_REHEARSAL && (env / 4) % 2 == 0;
            if (clean) clean_rows++; else delayed_rows++;
            const float age = actor_obs[row * fixed_ppo::actor_obs_dim + fixed_ppo::context_offset + 17];
            require(std::isfinite(age) && age >= 0, "invalid delay-training capture age");
            if (clean || options.sensor_delay == 0) require(age == 0, "nominal training lane has stale depth");
            positive_age += age > 0;
            max_age = std::max(max_age, age);
        }
        delay_samples << (rollout + 1) << ',' << clean_rows << ',' << delayed_rows << ',' << positive_age
                      << ',' << max_age << '\n';
        delay_samples.flush();
        const auto* counts = static_cast<const uint32_t*>(run.sample_counts.contents);
        uint64_t count_sum = 0;
        for (uint32_t slot = 0; slot < session.control.period; slot++) {
            uint64_t slot_total = 0;
            for (uint32_t env = 0; env < options.environments; env++) {
                const size_t index = size_t(env) * session.control.period + slot;
                entry_totals[index] += counts[index];
                slot_total += counts[index];
            }
            count_sum += slot_total;
            slot_samples << (rollout + 1) << ',' << slot << ',' << slot_total << '\n';
        }
        require(count_sum == rows, "per-slot exposure count does not cover the rollout");
        slot_samples.flush();

        const auto* runs_now = static_cast<const SimRun*>(sim.runs.contents);
        uint64_t episodes = 0, success = 0, contact = 0, timeout = 0;
        float clearance_min = 12.0f;
        for (uint32_t env = 0; env < options.environments; env++) {
            episodes += runs_now[env].episodes - previous_runs[env].episodes;
            success += runs_now[env].successes - previous_runs[env].successes;
            contact += runs_now[env].collisions - previous_runs[env].collisions;
            timeout += runs_now[env].timeouts - previous_runs[env].timeouts;
            clearance_min = std::min(clearance_min, runs_now[env].min_clearance);
        }
        const float* metric = static_cast<const float*>(trainer.metric_mean.contents);
        const float* actor = static_cast<const float*>(sim.actor.contents);
        const auto grad = trainer.grad_norm_summary();
        const auto anchor = trainer.anchor_norm_means();
        double update_l2 = 0;
        for (size_t i = 0; i < size_t(fixed_ppo::actor_param_count); ++i) {
            const double d = double(actor[i]) - double(actor_before[i]);
            update_l2 += d * d;
        }
        history << (rollout + 1) << ',' << uint64_t(rollout + 1) * rows << ',' << seconds() - started << ','
                << collect_gpu << ',' << update_gpu << ',' << metric[0] << ',' << metric[1] << ',' << metric[2]
                << ',' << metric[3] << ',' << episodes << ','
                << (episodes ? double(success) / episodes : 0.0) << ','
                << (episodes ? double(contact) / episodes : 0.0) << ','
                << (episodes ? double(timeout) / episodes : 0.0) << ',' << clearance_min << ',';
        for (uint32_t d = 0; d < 4; ++d) history << actor[fixed_ppo::actor_log_std_offset + d] << ',';
        history << trainer.actor_drift_l2() << ',' << grad.actor_mean << ',' << grad.actor_clip_frac << ','
                << grad.critic_mean << ',' << grad.critic_clip_frac << ',' << anchor[0] << ',' << anchor[1]
                << ',' << std::sqrt(update_l2) << ',' << retention_loss << ','
                << options.retention_coefficient << '\n';
        history.flush();
        if ((rollout + 1) % options.eval_every == 0 || rollout + 1 == finish) {
            trainer.save_checkpoint(checkpoint, sim.cfg.family, options.seed, rollout + 1);
            save_ppo_safeguard_state(trainer, checkpoint,
                                     PpoSafeguardConfig{options.epochs, 0.0f, 0.5f, options.anchor_lambda,
                                                        options.anchor_radius, 0.0f, std::string(64, '0')},
                                     rollout + 1);
            if (options.model_snapshots) {
                std::ifstream source(checkpoint, std::ios::binary);
                const PpoCheckpointHeader header = read_checkpoint_header(source);
                const size_t model_bytes = sizeof(header) +
                    size_t(header.actor_count + header.critic_count) * sizeof(float);
                source.seekg(0);
                std::vector<char> model(model_bytes);
                source.read(model.data(), model.size());
                require(bool(source), "model snapshot prefix read failed");
                std::ofstream snapshot(checkpoint + ".at-" + std::to_string(rollout + 1) + ".model.bin",
                                       std::ios::binary);
                snapshot.write(model.data(), model.size());
                require(bool(snapshot), "model snapshot write failed");
            }
            std::cout << "retention_train rollout=" << (rollout + 1) << " wall_s=" << seconds() - started
                      << " policy_loss=" << metric[0] << " value_loss=" << metric[1]
                      << " ep_success=" << (episodes ? double(success) / episodes : 0.0)
                      << " retention_loss=" << retention_loss
                      << " actor_drift=" << trainer.actor_drift_l2() << '\n';
        }
    }}
    std::ofstream exposure(checkpoint + ".entry-transitions.bin", std::ios::binary);
    exposure.write(reinterpret_cast<const char*>(entry_totals.data()), entry_totals.size() * sizeof(uint64_t));
    require(bool(exposure), "entry exposure write failed");
    struct rusage usage{};
    getrusage(RUSAGE_SELF, &usage);
    std::cout << "retention_train_done rollouts=" << finish << " wall_s=" << seconds() - started
              << " segment_transitions=" << uint64_t(rollouts) * options.environments * options.horizon
              << " collect_gpu_total_s=" << total_collect_gpu
              << " update_gpu_total_s=" << total_update_gpu
              << " peak_gpu_allocated_bytes=" << peak_gpu_allocated
              << " peak_process_rss_bytes=" << usage.ru_maxrss << '\n';
    return 0;
}

}  // namespace retention_run

int main(int argc, char** argv) {
    try {
        require(argc >= 2, "retention-train|retention-gradcheck|retention-calibrate");
        const std::string command = argv[1];
        if (command == "retention-train") return retention_run::command_train(argc, argv);
        if (command == "retention-gradcheck") return retention_run::command_gradcheck(argc, argv);
        if (command == "retention-calibrate") return retention_run::command_calibrate(argc, argv);
        throw std::runtime_error("unknown retention command " + command);
    } catch (const std::exception& error) {
        std::cerr << "ERROR: " << error.what() << '\n';
        return 1;
    }
}
