from pathlib import Path
import json,subprocess,struct,time
r=Path("/Users/muadhsambul/RL");o=r/"results/root-critic-state";(o/"evals").mkdir(exist_ok=True);receipts=[x for x in json.loads((o/"provenance/eval-receipts.json").read_text()) if x["exit"]==0]
done={(x["arm"],x["split"]) for x in receipts}
checkpoints=[o/"runs"/f"critic-{a}-s{i}.bin" for i in [1,2] for a in ["C","T"]]
while True:
 if all(p.exists() for p in checkpoints) and all(struct.unpack_from("<I",p.read_bytes(),36)[0]==5000 for p in checkpoints):break
 if subprocess.run(["ps","-p","90577","-o","pid="],stdout=subprocess.DEVNULL).returncode!=0:raise RuntimeError("critic producer stopped incomplete; inspect actual logs before resuming")
 time.sleep(10)
for i in [1,2]:
 for arm,binary in [("C","metal_nav_critic_control"),("T","metal_nav_critic_rich")]:
  for best in [False,True]:
   label=f"critic-{arm}-s{i}"+("-best" if best else "");ck=o/"runs"/(f"critic-{arm}-s{i}.bin"+(".best" if best else ""))
   for split in ["dev-r2","dev-a","dev-b","dev-c","open","clutter"]:
    if (label,split) in done:continue
    args=["python3",str(r/"run_locked.py"),"--",str(r/"build"/binary),"local-eval",str(ck),str(o/"evals"/(label+"-"+split+".csv")),"--spec",split,"--mode","17","--seed","700001"]
    if split=="dev-c":args.extend(["--bank",str(r/"results/omp-local-capability/banks/dev-c.bin")])
    item={"arm":label,"split":split,"argv":args};receipts.append(item)
    with (o/"logs"/(label+"-"+split+"-eval.log")).open("w") as log:item["exit"]=subprocess.run(args,stdout=log,stderr=subprocess.STDOUT).returncode
    (o/"provenance/eval-receipts.json").write_text(json.dumps(receipts,indent=2)+"\n");assert item["exit"]==0,item;print(label,split,"COMPLETE",flush=True)
print("CRITIC48EVAL_COMPLETE",flush=True)
