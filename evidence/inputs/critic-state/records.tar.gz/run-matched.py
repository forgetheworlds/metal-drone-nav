from pathlib import Path
import subprocess,json,hashlib,struct
from datetime import datetime,timezone
r=Path("/Users/muadhsambul/RL");o=r/"results/root-critic-state";(o/"runs").mkdir(exist_ok=True);(o/"provenance").mkdir(exist_ok=True)
files=["main.mm","sim.metal","navigation_training.hpp","navigation_critic_training.mm","ppo.hpp","ppo.metal","navigation_tasks.hpp"]
freeze={name:hashlib.sha256((r/name).read_bytes()).hexdigest() for name in files};freeze.update({name:hashlib.sha256((r/"build"/name).read_bytes()).hexdigest() for name in ["metal_nav_critic_control","metal_nav_critic_rich"]});(o/"provenance/freeze.json").write_text(json.dumps(freeze,indent=2)+"\n")
receipts=[]
for index,seed in [(1,20261014),(2,20261015)]:
 for arm,bname in [("C","metal_nav_critic_control"),("T","metal_nav_critic_rich")]:
  label=f"critic-{arm}-s{index}";ck=o/"runs"/(label+".bin");assert not ck.exists()
  for name,h in freeze.items():
   p=r/"build"/name if name.startswith("metal_nav_") else r/name
   assert hashlib.sha256(p.read_bytes()).hexdigest()==h,name
  args=["python3",str(r/"run_locked.py"),"--",str(r/"build"/bname),"local-train","5000",str(ck),str(r/"results/omp-local-capability/runs/bc.bin"),"--spec","source","--seed",str(seed),"--time-cost","1","--contact-penalty","50","--arrival-bonus","10","--eval-spec","dev-a","--eval-every","50"]
  item={"arm":label,"argv":args,"started_utc":datetime.now(timezone.utc).isoformat()};receipts.append(item)
  with (o/"logs"/(label+".log")).open("w") as log:
   proc=subprocess.Popen(args,stdout=log,stderr=subprocess.STDOUT);item["pid"]=proc.pid;(o/"provenance/jobs.json").write_text(json.dumps(receipts,indent=2)+"\n");item["exit"]=proc.wait()
  assert item["exit"]==0,item
  data=ck.read_bytes();item["rollouts"]=struct.unpack_from("<I",data,36)[0];item["optimizer_step"]=struct.unpack_from("<Q",data,40)[0]
  assert item["rollouts"]==5000 and item["optimizer_step"]==160000
  (o/"provenance/jobs.json").write_text(json.dumps(receipts,indent=2)+"\n");print(label,"COMPLETE",flush=True)
print("CRITIC_STATE_FOUR_TRAIN_COMPLETE",flush=True)
