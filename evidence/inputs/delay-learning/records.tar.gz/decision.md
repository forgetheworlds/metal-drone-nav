# Delay exposure comparison — frozen before full runs

Diagnosis: prior joint source runs configured sensor_delay=0 and command_delay=0.
The frozen stress matrix and scored-parity traces expose actual delayed contacts.
Capture-age uncertainty alone has mixed effects and remains disabled.

Test the missing learning exposure directly. Both arms keep the exact balanced
combined TRAIN bank (6144 records, period48), actor184/64/4, richcritic64,
RAPTOR/physics, timecost1/contact50/arrival10, anchor.01/radius0, freshoptimizer
and logstd-1. Warmstart both arms from matching consolidated-PPO final T seed.
New training seeds20261180/81; four10000rollout/320000optimizer runs.
Control sensor/command delay0/0. Treatment2/2 navigation steps (100ms each),
with alternate four-environment blocks clean. Both use the same opt-in build.
Every clean/delayed stratum has32static/16long/16bounded environments; no actor
family IDs or privileged task geometry. Actual exposure is logged per rollout.
No capture-age profile, density/FOV, frequency, reward or network change.

Final10000 checkpoints primary. Same dev-a selector is secondary, not new proof.
Evaluate four actors on all8nominal panels and composite sensor100,command100,
both100,combined(noise/dropout/dynamics/delays) =48panels/6144flights. This is
exposed development; no final or target-side training.

Mechanism gate: both-delay composite pooled256 success >=control+10,
contacts <=control-10, both seeds improve success. Nominal source success per
panel >=control-3; contacts/timeouts each <=control+3. Common-success arrival
<=control+.5s. Combined stress success >=control, contacts/timeouts <=control+3.
Absolute combined-goal floors short/longopen>=253/256,hall>=253,staticB>=223,
clutter>=219 remain independent adoption requirements. Retain all failures.
Passing a delay mechanism gate does not promote a policy that misses full
capability/retention/speed floors. No coefficient sweep if failed.

Preflight executed:100fullcheckpoint byte parity against preserved motiontrainer;
delay8 uninterrupted vs4+4 FULLcheckpoint parity; wrongdelay rejected before
mutation; actualclean/delayed exposure and per-capability allocation proved.
Sidecarv3 pins delay settings/rehearsal topology/source, ABI/network unchanged.
Full GPU jobs use absolute root Metal lock and persistent parent execution.
