from pathlib import Path
import json,time,subprocess,struct,hashlib
ROOT=Path('/Users/muadhsambul/RL');OUT=ROOT/'results/root-delay-learning';deadline=time.monotonic()+7200
while True:
 jobs=json.loads((OUT/'provenance/jobs.json').read_text())
 if any(x.get('exit',0)!=0 for x in jobs):raise RuntimeError('Training failed; inspect actual child, no auto restart')
 if len(jobs)==4 and all(x.get('exit')==0 and x.get('rollouts')==10000 and x.get('optimizer_step')==320000 for x in jobs):break
 if time.monotonic()>deadline:raise RuntimeError('Observation deadline; inspect current state before restarting')
 time.sleep(5)
for name,digest in json.loads((OUT/'provenance/freeze.json').read_text()).items():assert hashlib.sha256(Path(name).read_bytes()).hexdigest()==digest,name
(OUT/'evals').mkdir(exist_ok=True);receipts=[]
for seed in [1,2]:
 for arm in ['C','T']:
  actor=f'delay-{arm}-s{seed}';checkpoint=OUT/'runs'/(actor+'.bin');digest=hashlib.sha256(checkpoint.read_bytes()).hexdigest()
  for panel in ['long-open','long-hallway','dev-a','dev-b','dev-c','open','clutter','composite']:
   bank=(ROOT/'results/root-distance-learning/dev'/(panel.removeprefix('long-')+'.bin')) if panel.startswith('long-') else (ROOT/'results/root-motion-fidelity/dev/challenges.bin' if panel=='composite' else ROOT/'results/omp-local-dynamics/banks'/(panel+'-static.bin'))
   for profile in (['nominal','sensor-delay','command-delay','both-delay','combined'] if panel=='composite' else ['nominal']):
    label=f'{actor}-{panel}-{profile}';flight=OUT/'evals'/(label+'.csv');argv=['python3',str(ROOT/'run_locked.py'),'--',str(ROOT/'build/navigation_stress_eval'),str(checkpoint),str(bank),str(flight),profile]
    item={'actor':actor,'panel':panel,'profile':profile,'checkpoint_sha256':digest,'argv':argv};receipts.append(item)
    with (OUT/'logs'/(label+'-eval.log')).open('w') as log:item['exit']=subprocess.run(argv,stdout=log,stderr=subprocess.STDOUT).returncode
    (OUT/'provenance/eval-receipts.json').write_text(json.dumps(receipts,indent=2)+'\n');assert item['exit']==0,item
    print(label,'COMPLETE',flush=True)
print('DELAY48EVAL_COMPLETE',flush=True)
