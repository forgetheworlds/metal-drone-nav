"""Resume an execution-lost batch from verified headers; never replace completed arms."""
from pathlib import Path
from datetime import datetime,timezone
import os,errno,json,struct,hashlib,subprocess
ROOT=Path('/Users/muadhsambul/RL');OUT=ROOT/'results/root-delay-learning';provenance=OUT/'provenance'
for path,digest in json.loads((provenance/'freeze.json').read_text()).items():
 assert hashlib.sha256(Path(path).read_bytes()).hexdigest()==digest,path
jobs=json.loads((provenance/'jobs.json').read_text());resumes=[]
# Check both actual command and prior parent, not only a state label.
for pid in [27724,27729,27830,40382]:
 try:os.kill(pid,0)
 except ProcessLookupError:pass
 else:raise RuntimeError(f'Prior execution PID still exists: {pid}; inspect before resuming')
(provenance/'jobs-before-resume.json').write_text(json.dumps(jobs,indent=2)+'\n')
for seed,training_seed in [(1,20261180),(2,20261181)]:
 for arm in ['C','T']:
  label=f'delay-{arm}-s{seed}';checkpoint=OUT/'runs'/(label+'.bin')
  existing=next((x for x in jobs if x['arm']==label),None)
  completed=0
  if checkpoint.exists():
   data=checkpoint.read_bytes();completed=struct.unpack_from('<I',data,36)[0];steps=struct.unpack_from('<Q',data,40)[0]
   assert completed<=10000 and steps==completed*32,(label,completed,steps)
  if completed==10000:
   assert existing and existing['exit']==0;print(label,'ALREADY_COMPLETE',flush=True);continue
  if existing:
   existing['interrupted_segment']={'pid':existing['pid'],'saved_rollouts':completed,'saved_optimizer_step':completed*32,'state':'process_missing_after_interruption'}
  item=existing or {'arm':label};remaining=10000-completed
  argv=['python3',str(ROOT/'run_locked.py'),'--',str(ROOT/'build/navigation_delay_training'),'local-train',str(remaining),str(checkpoint),str(ROOT/'results/root-consolidated-ppo/runs'/f'consolidated-T-s{seed}.bin'),'--spec','source','--bank',str(ROOT/'results/root-balanced-valid-motion/banks/combined.bin'),'--seed',str(training_seed),'--time-cost','1','--contact-penalty','50','--arrival-bonus','10','--eval-spec','dev-a','--eval-every','50','--anchor','.01','--anchor-radius','0','--sensor-delay','2' if arm=='T' else '0','--command-delay','2' if arm=='T' else '0']
  segment={'arm':label,'start_rollouts':completed,'incremental_rollouts':remaining,'argv':argv,'started':datetime.now(timezone.utc).isoformat()};resumes.append(segment)
  if not existing:jobs.append(item)
  item['argv']=argv;item['resume_start_rollouts']=completed;item.pop('exit',None)
  with (OUT/'logs'/(label+'-resumed.log')).open('w') as log:
   process=subprocess.Popen(argv,stdout=log,stderr=subprocess.STDOUT);item['pid']=segment['pid']=process.pid
   (provenance/'jobs.json').write_text(json.dumps(jobs,indent=2)+'\n');(provenance/'resume-jobs.json').write_text(json.dumps(resumes,indent=2)+'\n')
   item['exit']=segment['exit']=process.wait()
  (provenance/'resume-jobs.json').write_text(json.dumps(resumes,indent=2)+'\n')
  assert item['exit']==0,item
  data=checkpoint.read_bytes();item['rollouts']=struct.unpack_from('<I',data,36)[0];item['optimizer_step']=struct.unpack_from('<Q',data,40)[0]
  assert item['rollouts']==10000 and item['optimizer_step']==320000,item
  (provenance/'jobs.json').write_text(json.dumps(jobs,indent=2)+'\n');print(label,'COMPLETE',flush=True)
print('DELAY_FOUR_TRAINING_COMPLETE',flush=True)
