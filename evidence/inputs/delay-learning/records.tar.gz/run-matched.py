from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess,struct
ROOT=Path('/Users/muadhsambul/RL');OUT=ROOT/'results/root-delay-learning'
for name in ['runs','logs','provenance']: (OUT/name).mkdir(exist_ok=True)
assert json.loads((OUT/'preflight.json').read_text())['default100_full_checkpoint_byte_parity']
files=[ROOT/p for p in ['main.mm','sim.metal','cpu_reference.hpp','guidance.hpp','memory.metal','navigation_critic_training.mm','navigation_training.hpp','ppo.hpp','ppo.metal','navigation_tasks.hpp','world.hpp','sensor_profile.hpp','build/navigation_delay_training','build/navigation_stress_eval','results/root-balanced-valid-motion/banks/combined.bin']]
files += [OUT/'decision.md',OUT/'run-matched.py',OUT/'eval-matched.py']
files += [ROOT/'results/root-consolidated-ppo/runs'/f'consolidated-T-s{seed}.bin' for seed in [1,2]]
freeze={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
(OUT/'provenance/freeze.json').write_text(json.dumps(freeze,indent=2)+'\n')
jobs=[]
for seed,training_seed in [(1,20261180),(2,20261181)]:
 for arm in ['C','T']:
  for path,digest in freeze.items():assert hashlib.sha256(Path(path).read_bytes()).hexdigest()==digest,path
  label=f'delay-{arm}-s{seed}';checkpoint=OUT/'runs'/(label+'.bin');assert not checkpoint.exists()
  argv=['python3',str(ROOT/'run_locked.py'),'--',str(ROOT/'build/navigation_delay_training'),'local-train','10000',str(checkpoint),str(ROOT/'results/root-consolidated-ppo/runs'/f'consolidated-T-s{seed}.bin'),'--spec','source','--bank',str(ROOT/'results/root-balanced-valid-motion/banks/combined.bin'),'--seed',str(training_seed),'--time-cost','1','--contact-penalty','50','--arrival-bonus','10','--eval-spec','dev-a','--eval-every','50','--anchor','.01','--anchor-radius','0','--sensor-delay','2' if arm=='T' else '0','--command-delay','2' if arm=='T' else '0']
  item={'arm':label,'argv':argv,'started':datetime.now(timezone.utc).isoformat()};jobs.append(item)
  with (OUT/'logs'/(label+'.log')).open('w') as log:
   process=subprocess.Popen(argv,stdout=log,stderr=subprocess.STDOUT);item['pid']=process.pid;(OUT/'provenance/jobs.json').write_text(json.dumps(jobs,indent=2)+'\n');item['exit']=process.wait()
  assert item['exit']==0,item
  data=checkpoint.read_bytes();item['rollouts']=struct.unpack_from('<I',data,36)[0];item['optimizer_step']=struct.unpack_from('<Q',data,40)[0]
  assert item['rollouts']==10000 and item['optimizer_step']==320000,item
  (OUT/'provenance/jobs.json').write_text(json.dumps(jobs,indent=2)+'\n');print(label,'COMPLETE',flush=True)
print('DELAY_FOUR_TRAINING_COMPLETE',flush=True)
