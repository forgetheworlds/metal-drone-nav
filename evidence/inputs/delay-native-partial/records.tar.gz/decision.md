# Fresh frozen native transfer — before any policy flight

Test final nominal-trained C and mixed-delay-trained T from the completed
matched source study, BOTH seeds. No default promotion: source static/short
retention gates failed. Native results test transfer of the candidate, not
completion of the whole navigation goal.

Freeze four final10000/320000 checkpoints and NAV files. No target-side training,
parameter changes or checkpoint selection. Generate two independent128-record
banks from seeds20261210 and20261211 AFTER weight freeze. Routes6–12.5m;
second bank reflects horizontal travel and floor/ceiling layouts. Keep exact
bounded movers and their full-path checks. Geometry witnesses do not establish
RAPTOR feasibility. Select earliest TWO records per six kinds x two difficulties
from each bank BEFORE any source or native policy evaluation:24perbank,48total.
Both seeds x C/T run all48:192 actual native flights. Never outcome-filter cases.

Nominal native sensing/dynamics/control timing; actual RangeFinder/ODE/motors/
RAPTOR. These flights do not directly verify the source100ms delay robustness.
Unknown geometry and independent implementation are the focus. All load,
world/NAV/hash, stablearrival, moverpose and reset evidence retained.
Invalid execution stops the batch; preserve/fix harness, don't call it a crash.
Task failure and valid collisions/timeouts remain counted. Same policy/frame/
command mapping/reference adapter, no teacher IDs or route witnesses.

Report perkind, difficulty, reflection, seed; paired wins/losses and common
successful arrival time. Transfer mechanism gate: pooled Tsuccess >=C+4/96,
contacts/timeouts each <=C+2, common-success time <=C+.5s, eachseed no success
regression. Passing native gate does NOT override failed source floors or prove
broad robustness/physicalflight/sealedFINAL. Before changing training, inspect
new failure causes and second-order effects.

Dedicated isolated RLproject,port23456,--minimize --batch. SharedWebotsother
project files/settings/processes read-only. Persistent parent holds absolute
Metal lock. Actor/source freeze checked each flight; no otherworldtouches.
