"""Frozen source actors in fresh isolated Webots courses; no target training."""
from pathlib import Path
import sys,json,hashlib,subprocess,struct,signal,os
ROOT=Path('/Users/muadhsambul/RL');OUT=ROOT/'results/root-delay-native'
sys.path.insert(0,str(ROOT/'webots'))
import local_waypoint_transfer as transfer
import bounded_motion_scene as scenes

def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def cancel(signum,frame):raise SystemExit(128+signum)
signal.signal(signal.SIGTERM,cancel);signal.signal(signal.SIGINT,cancel)
project=OUT/'project';(OUT/'nav').mkdir(exist_ok=True);(OUT/'flights').mkdir(exist_ok=True)
actors={}
for seed in [1,2]:
 for arm in ['C','T']:
  label=f'{arm}-s{seed}';checkpoint=ROOT/'results/root-delay-learning/runs'/f'delay-{arm}-s{seed}.bin'
  data=checkpoint.read_bytes();assert struct.unpack_from('<I',data,36)[0]==10000 and struct.unpack_from('<Q',data,40)[0]==320000
  nav=OUT/'nav'/(label+'.nav');assert not nav.exists(),'Do not duplicate an existing native batch'
  with (OUT/'nav'/(label+'.log')).open('w') as log:code=subprocess.run([str(ROOT/'build/metal_nav_guided'),'export',str(checkpoint),str(nav)],stdout=log,stderr=subprocess.STDOUT).returncode
  assert code==0,label;actors[label]={'checkpoint':str(checkpoint),'checkpoint_sha256':digest(checkpoint),'nav':str(nav),'nav_sha256':digest(nav)}
(OUT/'actors.json').write_text(json.dumps(actors,indent=2)+'\n')
selection=[]
for reflection in ['normal','reflected']:
 bank=OUT/'banks'/reflection/'challenges.bin';manifest=json.loads(bank.with_name('manifest.json').read_text());chosen=[]
 for kind in scenes.transfer.KINDS if hasattr(scenes.transfer,'KINDS') else ['staggered_gaps','vertical_weave','poles_overhang','gap_crossing','vertical_approach','combined']:
  for difficulty in [0,1]:
   matches=[x for x in manifest['records'] if x['kind']==kind and x['difficulty']==difficulty][:2];assert len(matches)==2
   for record in matches:chosen.append({'reflection':reflection,'bank':str(bank),'index':record['env'],'kind':kind,'difficulty':difficulty})
 assert len(chosen)==24;selection.extend(chosen)
(OUT/'selection.json').write_text(json.dumps(selection,indent=2)+'\n')
files=[OUT/'decision.md',OUT/'run.py',ROOT/'webots/local_waypoint_transfer.py',ROOT/'webots/bounded_motion_scene.py',ROOT/'webots/controllers/local_waypoint_transfer/local_waypoint_transfer',ROOT/'webots/controllers/local_waypoint_transfer/local_waypoint_transfer.cpp',ROOT/'webots/controllers/local_waypoint_transfer/physics_comparison.hpp',ROOT/'guidance.hpp',ROOT/'deployment.hpp',ROOT/'sensor_profile.hpp']
files += [OUT/'banks'/name/'challenges.bin' for name in ['normal','reflected']]
files += [Path(x['nav']) for x in actors.values()]+[Path(x['checkpoint']) for x in actors.values()]
freeze={str(p):digest(p) for p in files};(OUT/'freeze.json').write_text(json.dumps(freeze,indent=2)+'\n')
transfer.WEBOTS_DIR=project;transfer.WORLD_DIR=project/'worlds';transfer.OUT_DIR=OUT;transfer.FLIGHT_DIR=OUT/'flights'
receipts=[];print('NATIVE_PARENT_PID',os.getpid(),flush=True)
for case in selection:
 for label,actor in actors.items():
  for name,sha in freeze.items():assert digest(Path(name))==sha,name
  slug=f"delay-fresh-{case['reflection']}-{case['index']}-{label}"
  world=scenes.export(Path(case['bank']),case['index'],Path(actor['nav']),project,slug)
  result=transfer.run_flight(world,OUT/'flights'/slug,False)
  row={**case,'actor':label,'slug':slug,'nav_sha256':actor['nav_sha256'],'world_sha256':digest(world),'run':result};receipts.append(row)
  (OUT/'receipts.json').write_text(json.dumps(receipts,indent=2)+'\n')
  print(slug,'valid',result['valid'],flush=True)
  if not result['valid']:raise RuntimeError('Invalid native execution; preserve/fix before resuming: '+str(result))
print('FRESH_NATIVE192_COMPLETE',flush=True)
