from pathlib import Path
import json, subprocess
root=Path('/Users/muadhsambul/RL')
out=root/'results/root-distance-probe'
original=json.loads((out/'receipts.json').read_text())
receipts=[]
for item in original:
 kind,actor=item['kind'],item['actor']
 checkpoint=item['argv'][5]
 command=['python3',str(root/'run_locked.py'),'--',str(root/'build/navigation_distance_probe'),checkpoint,str(out/(kind+'.bin')),str(out/(kind+'-'+actor+'-cap1.csv')),'1']
 receipt={'kind':kind,'actor':actor,'argv':command}
 with (out/(kind+'-'+actor+'-cap1.log')).open('w') as log:
  receipt['exit']=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT).returncode
 receipts.append(receipt)
 (out/'cap-receipts.json').write_text(json.dumps(receipts,indent=2)+'\n')
 assert receipt['exit']==0,receipt
 print(kind,actor,'COMPLETE',flush=True)
