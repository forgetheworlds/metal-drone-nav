from pathlib import Path
import subprocess,json,struct,time
R=Path('/Users/muadhsambul/RL');O=R/'results/training-scale/long';out=O/'evals';out.mkdir(exist_ok=True);receipts=[];deadline=time.monotonic()+14400
for seed in [1,2]:
 for n in [512,8192]:
  arm=f'n{n}-s{seed}'
  while True:
   jobs=json.loads((O/'jobs.json').read_text());job=next((x for x in jobs if x['arm']==arm),None)
   if job and job.get('exit') is not None:
    if job['exit']!=0:raise RuntimeError('Producer failed, inspect actual process before repair')
    if job['optimizer_step']==327680:break
   if time.monotonic()>deadline:raise RuntimeError('Observation timeout only; inspect live producer, no autorestart')
   time.sleep(5)
  ck=O/(arm+'.bin');models=sorted(O.glob(arm+'.bin.at-*.model.bin'),key=lambda x:int(x.name.split('.at-')[1].split('.')[0]));assert len(models)==10
  for model in models:
   data=model.read_bytes();rollouts=struct.unpack_from('<I',data,36)[0];samples=rollouts*n*32;assert struct.unpack_from('<Q',data,40)[0]==samples//256*2
   for panel in ['long-open','long-hallway','dev-a','dev-b','dev-c','open','clutter','composite']:
    bank=(R/'results/root-distance-learning/dev'/(panel.removeprefix('long-')+'.bin')) if panel.startswith('long-') else (R/'results/root-motion-fidelity/dev/challenges.bin' if panel=='composite' else R/'results/omp-local-dynamics/banks'/(panel+'-static.bin'))
    for profile in ['nominal','sensor-delay','command-delay','both-delay','combined'] if panel=='composite' else ['nominal']:
     label=f'{arm}-samples{samples}-{panel}-{profile}';output=out/(label+'.csv');assert not output.exists()
     argv=['python3',str(R/'run_locked.py'),'--',str(R/'build/navigation_stress_eval'),str(model),str(bank),str(output),profile];start=time.monotonic()
     with (out/(label+'.log')).open('w') as log:code=subprocess.run(argv,stdout=log,stderr=subprocess.STDOUT).returncode
     item={'arm':arm,'samples':samples,'panel':panel,'profile':profile,'exit':code,'evaluation_wall_s':time.monotonic()-start,'argv':argv};receipts.append(item);(O/'eval-receipts.json').write_text(json.dumps(receipts,indent=2)+'\n');assert code==0,label
   print(arm,'samples',samples,'FULL_PORTFOLIO_COMPLETE',flush=True)
print('LONG480EVALS_COMPLETE',flush=True)
