# Longer matched PPO batch-regime comparison

Follow pilot with Ns512 and8192, each on TWO corresponding sourceT parents.
Eacharm41,943,040 transitions,327,680 Adamsteps: N5122560rollouts,N8192160.
Same actor184/64/4, richcritic64, horizon32,epochs2,minibatch256,reward1/50/10,
anchor.01radius0,freshoptimizer/std-1, sensor2command2 halfclean four-envblocks,
same2048unique corpus, phasebalancedbank. New trainingseeds20261210/11,matching
parentT-s1/s2 bothcounts. No curriculum, diversity, capacity or PPOsetting change.
This is PRACTICALPPO collection/batch regime, notpurehardware scaling.

Every4,194,304 samples save inference-only prefix plus fullresume checkpoint.
Prefix is NOTresumable/budgetproof; realheaders and processreceipts prove budget.
Final checkpoints primary, olddev-a bestsecondary. Evaluate all8 nominal/4stress
panels at everyprefix afterarm completes. Plot skills/retention vs samples and
trainingwall; report offlinegrading cost separately. No warmstart cherry-picking.

Instrumentation corrected to count actual (env,rotatedbankentry), notambiguous
slots. Final uint64 counts file maps to payload hashes for actualsource-record
coverage and clean/delayedcapability masses. Counters do not enteractor/critic.
Defaultmodel FULLcheckpoint parity and inferenceprefix smoke required prelaunch.

Compare broadPareto capability/time, absoluteexistingopen/long/staticfloors and
perseed outcomes, notreward/FPS. Ifthroughputwinner loses more than3oldskills,
don'tadopt it forfullgoal. Pilot single-seed is notscalinglaw. The point is enough
experience and repeatedbankcycles before fundamentalarchitecture conclusions.
GUIWebots anddeletedVM deferred. Largerteachers laterrequire safe width kernels,
separatecriticwidth, function-preservingwarmstart and provencompactdistillation.
