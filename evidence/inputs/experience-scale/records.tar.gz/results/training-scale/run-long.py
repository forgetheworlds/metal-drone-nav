from pathlib import Path
from datetime import datetime,timezone
import json,hashlib,subprocess,struct,time
R=Path('/Users/muadhsambul/RL');O=R/'results/training-scale';out=O/'long';out.mkdir(exist_ok=True);jobs=[]
assert json.loads((O/'entry-preflight/proof.json').read_text())['default_and_snapshot_full_checkpoint_byte_parity']
files=[R/p for p in ['main.mm','sim.metal','navigation_critic_training.mm','navigation_training.hpp','ppo.hpp','ppo.metal','guidance.hpp','memory.metal','world.hpp','sensor_profile.hpp','cpu_reference.hpp','build/navigation_scale_complete','build/navigation_stress_eval','navigation_scale_banks.py']]
files += [O/'long-decision.md',O/'run-long.py']+[O/'pilot-banks'/f'n{n}.bin' for n in [512,8192]]
files += [R/'results/root-delay-learning/runs'/f'delay-T-s{i}.bin' for i in [1,2]]
freeze={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in files};(out/'freeze.json').write_text(json.dumps(freeze,indent=2)+'\n')
for seed,training_seed in [(1,20261210),(2,20261211)]:
 for n in [512,8192]:
  for path,h in freeze.items():assert hashlib.sha256(Path(path).read_bytes()).hexdigest()==h,path
  label=f'n{n}-s{seed}';ck=out/(label+'.bin');assert not ck.exists();rollouts=41943040//(n*32);interval=4194304//(n*32)
  argv=['python3',str(R/'run_locked.py'),'--',str(R/'build/navigation_scale_complete'),'local-train',str(rollouts),str(ck),str(R/'results/root-delay-learning/runs'/f'delay-T-s{seed}.bin'),'--spec','source','--envs',str(n),'--bank',str(O/'pilot-banks'/f'n{n}.bin'),'--seed',str(training_seed),'--time-cost','1','--contact-penalty','50','--arrival-bonus','10','--anchor','.01','--anchor-radius','0','--eval-every',str(interval),'--sensor-delay','2','--command-delay','2','--model-snapshots','1']
  item={'arm':label,'n':n,'seed':seed,'argv':argv,'started':datetime.now(timezone.utc).isoformat()};jobs.append(item);start=time.monotonic()
  with (out/(label+'.log')).open('w') as log:
   process=subprocess.Popen(argv,stdout=log,stderr=subprocess.STDOUT);item['pid']=process.pid;(out/'jobs.json').write_text(json.dumps(jobs,indent=2)+'\n');item['exit']=process.wait()
  item['job_wall_s']=time.monotonic()-start;assert item['exit']==0,item
  data=ck.read_bytes();item['saved_rollouts']=struct.unpack_from('<I',data,36)[0];item['optimizer_step']=struct.unpack_from('<Q',data,40)[0];assert item['saved_rollouts']==rollouts and item['optimizer_step']==327680
  counts=struct.unpack('<'+str(n*48)+'Q',Path(str(ck)+'.entry-transitions.bin').read_bytes());assert sum(counts)==41943040
  (out/'jobs.json').write_text(json.dumps(jobs,indent=2)+'\n');print(label,'COMPLETE',flush=True)
print('FOUR_LONG_SCALE_ARMS_COMPLETE',flush=True)
