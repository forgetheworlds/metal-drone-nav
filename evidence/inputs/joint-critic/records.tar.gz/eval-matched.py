from pathlib import Path
import json,subprocess,struct,time
r=Path("/Users/muadhsambul/RL");o=r/"results/root-joint-critic";d=r/"results/omp-local-dynamics/banks";(o/"evals").mkdir(exist_ok=True);receipts=[]
ckpts=[o/"runs"/f"joint-{a}-s{i}.bin" for i in [1,2] for a in ["C","T"]]
while True:
 if all(p.exists() for p in ckpts) and all(struct.unpack_from("<I",p.read_bytes(),36)[0]==5000 for p in ckpts):break
 if subprocess.run(["ps","-p","70682","-o","pid="],stdout=subprocess.DEVNULL).returncode!=0:raise RuntimeError("joint producer ended incomplete; inspectactual receipts before resume")
 time.sleep(10)
for i in [1,2]:
 for arm,binary in [("C","metal_nav_joint_control"),("T","metal_nav_joint_rich")]:
  for best in [False,True]:
   label=f"joint-{arm}-s{i}"+("-best" if best else "");ck=o/"runs"/(f"joint-{arm}-s{i}.bin"+(".best" if best else ""))
   for split in ["dev-dyn","dev-dyn2","dev-a","dev-b","dev-c","open","clutter"]:
    dynamic=split.startswith("dev-dyn");bank=d/(split+".bin" if dynamic else split+"-static.bin")
    args=["python3",str(r/"run_locked.py"),"--",str(r/"build"/binary),"dynamic-eval",str(ck),str(o/"evals"/(label+"-"+split+".csv")),"--dyn-bank" if dynamic else "--static-bank",str(bank),"--split",split,"--mode","17","--seed","700001","--ablate","0"]
    item={"arm":label,"split":split,"argv":args};receipts.append(item)
    with (o/"logs"/(label+"-"+split+"-eval.log")).open("w") as log:item["exit"]=subprocess.run(args,stdout=log,stderr=subprocess.STDOUT).returncode
    (o/"provenance/eval-receipts.json").write_text(json.dumps(receipts,indent=2)+"\n");assert item["exit"]==0,item;print(label,split,"COMPLETE",flush=True)
print("JOINT56EVAL_COMPLETE",flush=True)
