from pathlib import Path
import subprocess,json,hashlib,struct
from datetime import datetime,timezone
r=Path("/Users/muadhsambul/RL");o=r/"results/root-joint-critic";d=r/"results/omp-local-dynamics/banks";(o/"runs").mkdir(exist_ok=True);(o/"provenance").mkdir(exist_ok=True)
files=["main.mm","sim.metal","navigation_training.hpp","navigation_joint_critic.mm","ppo.hpp","ppo.metal","navigation_tasks.hpp"]
freeze={str(r/n):hashlib.sha256((r/n).read_bytes()).hexdigest() for n in files}
for p in [r/"build/metal_nav_joint_control",r/"build/metal_nav_joint_rich",d/"dyn-train.bin",d/"static-source-1024.bin",d/"dev-dyn.bin",d/"dev-a-static.bin",r/"assets/checkpoints/local-waypoint-fast-experimental.bin.best"]:freeze[str(p)]=hashlib.sha256(p.read_bytes()).hexdigest()
(o/"provenance/freeze.json").write_text(json.dumps(freeze,indent=2)+"\n");jobs=[]
for num,seed in [(1,20261012),(2,20261013)]:
 for arm,binary in [("C","metal_nav_joint_control"),("T","metal_nav_joint_rich")]:
  for name,h in freeze.items():assert hashlib.sha256(Path(name).read_bytes()).hexdigest()==h,name
  label=f"joint-{arm}-s{num}";ck=o/"runs"/(label+".bin");assert not ck.exists()
  args=["python3",str(r/"run_locked.py"),"--",str(r/"build"/binary),"dynamic-train","5000",str(ck),str(r/"assets/checkpoints/local-waypoint-fast-experimental.bin.best"),"--dyn-bank",str(d/"dyn-train.bin"),"--static-bank",str(d/"static-source-1024.bin"),"--eval-dyn",str(d/"dev-dyn.bin"),"--eval-static",str(d/"dev-a-static.bin"),"--seed",str(seed),"--ablate","0"]
  item={"arm":label,"argv":args,"started":datetime.now(timezone.utc).isoformat()};jobs.append(item)
  with (o/"logs"/(label+".log")).open("w") as log:
   p=subprocess.Popen(args,stdout=log,stderr=subprocess.STDOUT);item["pid"]=p.pid;(o/"provenance/jobs.json").write_text(json.dumps(jobs,indent=2)+"\n");item["exit"]=p.wait()
  assert item["exit"]==0,item;b=ck.read_bytes();item["rollouts"]=struct.unpack_from("<I",b,36)[0];item["optimizer_step"]=struct.unpack_from("<Q",b,40)[0];assert item["rollouts"]==5000 and item["optimizer_step"]==160000
  (o/"provenance/jobs.json").write_text(json.dumps(jobs,indent=2)+"\n");print(label,"COMPLETE",flush=True)
print("JOINT4TRAIN_COMPLETE",flush=True)
