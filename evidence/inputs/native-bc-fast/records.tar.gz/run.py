import importlib.util,json,time
from pathlib import Path
root=Path('/Users/muadhsambul/RL')
work=Path('/Users/muadhsambul/.codex/worktrees/calibrated-navigation-sensors/RL')
out=root/'results/root-native-bc-fast-v1'
spec=importlib.util.spec_from_file_location('paired',work/'webots/devb_paired_transfer.py')
paired=importlib.util.module_from_spec(spec);spec.loader.exec_module(paired)
paired.OUT_DIR=out
paired.lwt.FLIGHT_DIR=out/'flights'
paired.lwt.flight_slug=lambda record,actor:'root'+paired.dbf_slug(record,actor)
original=paired.lwt.run_flight
def run_and_save(world,flight_dir,record_movie):
    result=original(world,flight_dir,record_movie)
    (flight_dir/'run.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
    return result
paired.lwt.run_flight=run_and_save
paired.command_flight()
paired.command_report()
print('PARENT_NATIVE_BATCH_COMPLETE',flush=True)
