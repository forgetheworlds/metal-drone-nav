#!/usr/bin/env python3
"""Paired development transfer: frozen BC vs frozen fast on immutable DEV-b.

Root froze the BC candidate (checkpoint `b8565035…`, NAV export
`results/posttraining-delay/navigation-bc-frozen.bin` `9b4a1164…`,
max_actor_error 0) and directed an independent native benchmark against the
preserved fast actor (NAV `assets/navigation-local-waypoint-experimental.bin`
`5b636f09…`) — without waiting for the grounded experiment.

Discipline (all enforced in code, in this order):

1. `select` writes `selection-manifest.json` BEFORE any Webots process
   starts: immutable DEV-b bank bytes, the balanced primary subset rule, the
   full128 flight plan for both actors, NAV/checkpoint/source-comparator
   hashes, task contract, grading and the primary endpoint. Native outcomes
   do not exist at write time.
2. `source` freezes the Metal comparator (already run once; reruns are
   byte-compared, not tuned): dev-b local-eval CSVs for both actors.
3. `flight` runs every planned flight (no outcome filtering; exclusions are
   fixed by `validate_task` in `select` and apply to BOTH actors).
4. `report` writes full denominators: paired balanced-86 primary, full-128
   secondary, per-class strata, and native-vs-source discrepancy causes
   (tracking, reference seeding, reset velocity, path ratio).

Reuse: the proven `local_waypoint_transfer.py` machinery (same shared
Webots read-only install, RL port 23456, `--batch --minimize --mode=fast
--no-rendering`, own receipts). Slugs are namespaced `dbf-` so no prior
evidence path can be overwritten. No target training, no tuning, no old
matrix rerun.

Usage:
    python3 webots/devb_paired_transfer.py select
    python3 webots/devb_paired_transfer.py flight
    python3 webots/devb_paired_transfer.py report
"""

import csv
import importlib.util
import json
import math
import os
import pathlib
import sys
import time

HERE = pathlib.Path(__file__).resolve().parent
WORKTREE = HERE.parent
ROOT = pathlib.Path("/Users/muadhsambul/RL")
OUT_DIR = ROOT / "results/omp-grounded-contract/native-bc-fast"
BANK = WORKTREE / "results/omp-local-waypoints/banks/dev-b.bin"
BANK_MANIFEST = WORKTREE / "results/omp-local-waypoints/banks/dev-b.json"
# Byte-identical worktree copies: the world files store worktree-relative
# policy paths (write_world contract). Hashes must equal the frozen originals
# (bc 9b4a1164… from root's export, fast 5b636f09…); verified in select.
BC_NAV = WORKTREE / "results/omp-grounded-contract/native-bc-fast/nav/navigation-bc-frozen.bin"
FAST_NAV = WORKTREE / "results/omp-local-waypoints/export/navigation-local-waypoint-fast.bin"
BC_FROZEN_ORIGINAL = ROOT / "results/posttraining-delay/navigation-bc-frozen.bin"
FAST_FROZEN_ORIGINAL = ROOT / "assets/navigation-local-waypoint-experimental.bin"
BC_CKPT = ROOT / "results/omp-local-capability/runs/bc.bin"
FAST_CKPT = ROOT / "assets/checkpoints/local-waypoint-fast-experimental.bin.best"
SOURCE_DIR = OUT_DIR / "source"
SELECTION_RULE = (
    "dev-b bank bytes (immutable, sha bound at select); every record flies for "
    "both actors; PRIMARY subset = per-family stratified balance: all blocked "
    "tasks plus, per family, the same number of direct tasks in bank order "
    "(43 blocked + 43 direct = 86); SECONDARY = the full 128-record bank with "
    "both route classes reported separately; exclusions only by validate_task "
    "before flights, applied to both actors; slugs namespaced dbf-"
)
PRIMARY_ENDPOINT = (
    "paired success difference (bc - fast) over the predeclared balanced 86 "
    "tasks; secondary full-bank128 and per-class counts reported with their "
    "own denominators; a native count is never filtered after outcomes"
)

# Reuse the proven transfer machinery (module main() is import-guarded).
_spec = importlib.util.spec_from_file_location(
    "lwt", HERE / "local_waypoint_transfer.py")
lwt = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(lwt)

ACTORS = [
    ("bc", BC_NAV, BC_CKPT),
    ("fast", FAST_NAV, FAST_CKPT),
]


def dbf_slug(record, actor):
    return f"dbf-env{record['index']:03d}-{record['family_name']}-{actor}"


# Everything in lwt that derives paths from flight_slug now resolves to this
# mission's namespace and output directory; prior evidence paths are never
# touched (separate process, separate slugs, separate OUT_DIR).
lwt.OUT_DIR = OUT_DIR
lwt.FLIGHT_DIR = OUT_DIR / "flights"
lwt.flight_slug = dbf_slug


def read_records():
    if not BANK.is_file():
        raise SystemExit(f"missing immutable dev-b bank {BANK}")
    bank_sha = lwt.sha256_file(BANK)
    manifest = json.loads(BANK_MANIFEST.read_text())
    if manifest.get("bank_sha256") != bank_sha:
        raise SystemExit(f"dev-b bank does not hash to its manifest: {bank_sha}")
    records = lwt.read_bank(BANK)
    kept, exclusions = [], []
    for record in records:
        try:
            lwt.validate_task(record)
            obstacles = lwt.usable_obstacles(record)
        except ValueError as error:
            exclusions.append({"index": record["index"],
                               "family_name": lwt.family_name(record["family"]),
                               "route_class": record["route_class"],
                               "reason": str(error)})
            continue
        record["obstacles_used"] = obstacles
        record["family_name"] = lwt.family_name(record["family"])
        kept.append(record)
    return kept, exclusions, bank_sha


def balanced_split(records):
    """Primary: all blocked + per-family same-count directs in bank order."""
    by_family = {}
    for record in records:
        by_family.setdefault(record["family_name"], []).append(record)
    primary, appendix = [], []
    for family in sorted(by_family):
        rows = by_family[family]
        blocked = [r for r in rows if r["route_class"] == 1]
        direct = [r for r in rows if r["route_class"] == 0]
        if len(direct) < len(blocked):
            raise SystemExit(f"{family}: {len(direct)} directs < {len(blocked)} blocked; "
                             "stratified balance impossible")
        primary += blocked + direct[:len(blocked)]
        appendix += direct[len(blocked):]
    primary.sort(key=lambda r: r["index"])
    appendix.sort(key=lambda r: r["index"])
    return primary, appendix


def comparator_payload():
    """Freeze the Metal source comparator rows for both actors."""
    payload = {}
    for actor, _, _ in ACTORS:
        path = SOURCE_DIR / f"{actor}-dev-b-mode17.csv"
        if not path.is_file():
            raise SystemExit(f"missing source comparator {path} (run the locked local-eval)")
        rows = []
        by_env = {}
        for row in csv.DictReader(path.open()):
            by_env[int(row["env"])] = row
        records, _, _ = read_records()
        for record in records:
            row = by_env.get(record["index"])
            if row is None:
                raise SystemExit(f"{path}: missing bank index {record['index']}")
            rows.append({"index": record["index"],
                         "success": int(row["success"]),
                         "collision": int(row["collision"]),
                         "timeout": int(row["timeout"]),
                         "time_s": float(row["time_s"])})
        payload[actor] = {
            "file": str(path),
            "sha256": lwt.sha256_file(path),
            "rows": rows,
            "full_split": {
                "tasks": len(rows),
                "success": sum(r["success"] for r in rows),
                "collision": sum(r["collision"] for r in rows),
                "timeout": sum(r["timeout"] for r in rows),
            },
        }
    return payload


def command_select():
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    records, exclusions, bank_sha = read_records()
    primary, appendix = balanced_split(records)
    assets = {}
    for actor, nav, ckpt in ACTORS:
        header = lwt.read_navpol1(nav)
        assets[actor] = {
            "nav": str(nav), "nav_sha256": lwt.sha256_file(nav),
            "nav_header": header,
            "checkpoint": str(ckpt), "checkpoint_sha256": lwt.sha256_file(ckpt),
        }
    manifest = {
        "schema": "devb-paired-transfer-selection-v1",
        "written_before_any_flight": True,
        "written_at": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
        "purpose": "independent development transfer (not sealed final, not blind)",
        "selection_rule": SELECTION_RULE,
        "primary_endpoint": PRIMARY_ENDPOINT,
        "bank": {"file": str(BANK), "bank_sha256": bank_sha,
                 "manifest_sha256": lwt.sha256_file(BANK_MANIFEST),
                 "records": len(records), "kept_tasks": len(records),
                 "exclusions_before_flights": exclusions,
                 "route_class_counts": {
                     "direct": sum(1 for r in records if r["route_class"] == 0),
                     "blocked": sum(1 for r in records if r["route_class"] == 1)}},
        "primary_indices": [r["index"] for r in primary],
        "primary_counts": {"total": len(primary),
                           "blocked": sum(1 for r in primary if r["route_class"] == 1),
                           "direct": sum(1 for r in primary if r["route_class"] == 0)},
        "appendix_indices": [r["index"] for r in appendix],
        "assets": assets,
        "task_contract": {
            "goal_radius_m": lwt.GOAL_RADIUS_M,
            "stable_speed_mps": getattr(lwt, "STABLE_SPEED_MPS", 0.5),
            "stable_hold_s": getattr(lwt, "STABLE_HOLD_S", 0.2),
            "contact_radius_m": getattr(lwt, "CONTACT_RADIUS_M", 0.18),
            "budget_steps": getattr(lwt, "MAX_STEPS", 400),
        },
        "adaptation_statement": ("documented coordinate/device adapter only "
                                 "(same local_waypoint_transfer controller contract as "
                                 "the published 32-flight matrix); no target training, "
                                 "no tuning, no threshold changes after native results"),
        "source_comparator": comparator_payload(),
        "planned_flights": [
            {"slug": dbf_slug(r, actor), "index": r["index"],
             "family": r["family"], "family_name": r["family_name"],
             "route_class": r["route_class"], "scene_seed": r["scene_seed"],
             "actor": actor}
            for r in records for actor, _, _ in ACTORS
        ],
    }
    lwt.write_json(OUT_DIR / "selection-manifest.json", manifest)
    print(f"select manifest={OUT_DIR/'selection-manifest.json'} "
          f"records={len(records)} primary={len(primary)} "
          f"flights={len(manifest['planned_flights'])} "
          f"exclusions={len(exclusions)} bank={bank_sha[:16]}")


def command_flight():
    manifest_path = OUT_DIR / "selection-manifest.json"
    if not manifest_path.is_file():
        raise SystemExit("run `select` first: manifest must exist before any flight")
    manifest = json.loads(manifest_path.read_text())
    records, _, _ = read_records()
    record_by_index = {r["index"]: r for r in records}
    nav_by_actor = {a: pathlib.Path(v["nav"]) for a, v in manifest["assets"].items()}
    if not lwt.WEBOTS.is_file():
        raise SystemExit(f"Webots executable missing: {lwt.WEBOTS}")
    lwt.FLIGHT_DIR.mkdir(parents=True, exist_ok=True)
    rows = []
    lock_fd = os.open(lwt.GPU_LOCK, os.O_RDWR | os.O_CREAT, 0o644)
    os.set_inheritable(lock_fd, False)
    if not lwt.acquire_lock(lock_fd, time.monotonic() + getattr(lwt, "LOCK_WAIT_S", 900)):
        os.close(lock_fd)
        raise SystemExit("timed out waiting for the shared GPU lock")
    started_all = time.monotonic()
    try:
        for planned in manifest["planned_flights"]:
            record = record_by_index[planned["index"]]
            actor = planned["actor"]
            world = lwt.write_world(record, actor, nav_by_actor[actor],
                                    movie=None, slug=planned["slug"])
            started = time.monotonic()
            run = lwt.run_flight(world, lwt.FLIGHT_DIR / planned["slug"],
                                 record_movie=False)
            row = lwt.flight_record(record, actor, run)
            row["slug"] = planned["slug"]
            row["wall_s"] = round(time.monotonic() - started, 3)
            row["world_sha256"] = lwt.sha256_file(world)
            rows.append(row)
            print(f"flight {planned['slug']} valid={row['valid']} "
                  f"s={row.get('success')} c={row.get('collision')} "
                  f"t={row.get('timeout')} wall={row['wall_s']}", flush=True)
    finally:
        os.close(lock_fd)
    lwt.write_json(OUT_DIR / "flights.json", rows)
    valid = [r for r in rows if r["valid"]]
    print(f"flights rows={len(rows)} valid={len(valid)} "
          f"wall_total={round(time.monotonic()-started_all,1)}s "
          f"output={OUT_DIR/'flights.json'}")


def paired_block(rows_by_key, indices):
    wins = losses = ties = 0
    detail = []
    for index in indices:
        bc = rows_by_key.get((index, "bc"))
        fast = rows_by_key.get((index, "fast"))
        if bc is None or fast is None:
            detail.append({"index": index, "status": "missing_valid_flight"})
            continue
        bs, fs = int(bc["success"]), int(fast["success"])
        if bs > fs:
            wins += 1
        elif fs > bs:
            losses += 1
        else:
            ties += 1
        detail.append({"index": index,
                       "bc": {"s": bs, "c": int(bc["collision"]), "t": int(bc["timeout"]),
                              "arrival_s": bc["arrival_s"], "path_m": bc["path_m"]},
                       "fast": {"s": fs, "c": int(fast["collision"]), "t": int(fast["timeout"]),
                                "arrival_s": fast["arrival_s"], "path_m": fast["path_m"]}})
    return {"n": len(indices), "bc_only_wins": wins, "fast_only_wins": losses,
            "ties": ties, "net_bc_minus_fast": wins - losses, "detail": detail}


def command_report():
    manifest = json.loads((OUT_DIR / "selection-manifest.json").read_text())
    rows = json.loads((OUT_DIR / "flights.json").read_text())
    records, _, _ = read_records()
    record_by_index = {r["index"]: r for r in records}
    valid = [r for r in rows if r["valid"]]
    invalid = [r for r in rows if not r["valid"]]
    if len(valid) + len(invalid) != len(manifest["planned_flights"]):
        raise SystemExit("flight row count drifted from the manifest plan")
    rows_by_key = {(r["index"], r["actor"]): r for r in valid}

    summaries = {actor: lwt.actor_summary(rows, actor) for actor, _, _ in ACTORS}
    primary = paired_block(rows_by_key, manifest["primary_indices"])
    full = paired_block(rows_by_key, [r["index"] for r in records])

    def class_block(route_class):
        indices = [r["index"] for r in records if r["route_class"] == route_class]
        return paired_block(rows_by_key, indices)

    # source-vs-native discrepancy causes: reuse the receipt-level diagnostics
    diagnosis = {"per_flight": [], "aggregate": {}}
    for row in valid:
        flight_dir = pathlib.Path(row["flight_dir"])
        receipt_path = flight_dir / "episode.json"
        if not receipt_path.is_file():
            continue
        receipt = json.loads(receipt_path.read_text())
        record = record_by_index[row["index"]]
        source_by_index = {r["index"]: r for r in
                           manifest["source_comparator"][row["actor"]]["rows"]}
        source = source_by_index.get(record["index"], {})
        diagnosis["per_flight"].append({
            "slug": row["slug"], "actor": row["actor"], "index": row["index"],
            "native": {"s": int(row["success"]), "c": int(row["collision"]),
                       "t": int(row["timeout"]), "arrival_s": row["arrival_s"]},
            "source": {"s": source.get("success"), "c": source.get("collision"),
                       "t": source.get("timeout")},
            "disagree": (int(row["success"]) != source.get("success")
                         or int(row["collision"]) != source.get("collision")),
            "tracking_rms_mps": receipt.get("tracking_rms_mps"),
            "reference_error_m": lwt.reference_error_m(flight_dir, record),
            "reset_velocity_error_mps": _reset_velocity_error(flight_dir, record),
            "path_ratio": (row["path_m"] / max(row["goal_distance_m"], 1e-6)
                           if row["path_m"] != "" else None),
        })
    for actor, _, _ in ACTORS:
        entries = [e for e in diagnosis["per_flight"] if e["actor"] == actor]
        disagree = [e for e in entries if e["disagree"]]
        diagnosis["aggregate"][actor] = {
            "flights": len(entries),
            "source_native_disagreements": len(disagree),
            "mean_tracking_rms_mps": (sum(e["tracking_rms_mps"] for e in entries
                                          if e["tracking_rms_mps"] is not None) /
                                      max(1, len(entries))),
            "max_reference_error_m": max((e["reference_error_m"] for e in entries
                                          if e["reference_error_m"] is not None),
                                         default=None),
            "max_reset_velocity_error_mps": max(
                (abs(e["reset_velocity_error_mps"]) for e in entries
                 if e["reset_velocity_error_mps"] is not None), default=None),
            "disagreeing_indices": [e["index"] for e in disagree],
        }

    payload = {
        "schema": "devb-paired-transfer-results-v1",
        "generated_at": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
        "development_transfer_not_sealed_final": True,
        "planned_flights": len(manifest["planned_flights"]),
        "valid_flights": len(valid),
        "invalid_flights": [{"slug": r["slug"], "reason": r.get("invalid_reason", "")}
                            for r in invalid],
        "primary_balanced": primary,
        "full_bank": full,
        "by_route_class": {"blocked": class_block(1), "direct": class_block(0)},
        "actors": summaries,
        "source_comparator": {a: v["full_split"] for a, v in
                              manifest["source_comparator"].items()},
        "source_files": {a: {"file": v["file"], "sha256": v["sha256"]}
                         for a, v in manifest["source_comparator"].items()},
        "assets": manifest["assets"],
        "diagnosis": diagnosis,
    }
    lwt.write_json(OUT_DIR / "paired-results.json", payload)
    with (OUT_DIR / "flights.csv").open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=sorted({k for r in rows for k in r}))
        writer.writeheader()
        writer.writerows(rows)
    print(f"report primary bc-fast net={primary['net_bc_minus_fast']} "
          f"(n={primary['n']}) full net={full['net_bc_minus_fast']} (n={full['n']}) "
          f"valid={valid.__len__()}/{len(rows)} -> {OUT_DIR/'paired-results.json'}")


def _reset_velocity_error(flight_dir, record):
    try:
        applied = lwt.applied_reset_velocity(flight_dir / "webots.log", record)
    except (SystemExit, ValueError, OSError):
        return None
    if applied is None:
        return None
    expected = record["start_velocity"]
    return math.sqrt(sum((applied[i] - expected[i]) ** 2 for i in range(3)))


def main():
    if len(sys.argv) != 2 or sys.argv[1] not in ("select", "flight", "report"):
        print(__doc__)
        return 2
    {"select": command_select, "flight": command_flight,
     "report": command_report}[sys.argv[1]]()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
