from pathlib import Path
import sys,json,time,struct,subprocess,hashlib,fcntl
r=Path('/Users/muadhsambul/RL');o=r/'results/root-valid-motion-native';parent=r/'results/root-balanced-valid-motion';cross=r/'results/root-cross-factor';deadline=time.monotonic()+7200
while True:
 primary=parent/'provenance/eval-receipts.json';secondary=cross/'eval-receipts.json'
 if primary.exists() and secondary.exists():
  a=json.loads(primary.read_text());b=json.loads(secondary.read_text())
  if len(a)==64 and len(b)==28 and all(x['exit']==0 for x in a+b):break
 if time.monotonic()>deadline:raise RuntimeError('Observationdeadline; inspect actual jobs, no restart')
 time.sleep(5)
sys.path.insert(0,str(r/'webots'))
import local_waypoint_transfer as transfer
import bounded_motion_scene as scene
project=o/'project';(o/'nav').mkdir(exist_ok=True);(o/'flights').mkdir(exist_ok=True)
records=[];actors={}
for seed in [1,2]:
 for role in ['parent','combined']:
  checkpoint=(r/'results/root-anchor-retention/runs'/f'anchor-T-s{seed}.bin' if role=='parent' else parent/'runs'/f'validmotion-T-s{seed}.bin')
  assert struct.unpack_from('<I',checkpoint.read_bytes(),36)[0]==10000
  label=f'{role}-s{seed}';nav=o/'nav'/(label+'.nav')
  with (o/'nav'/(label+'.log')).open('w') as log:code=subprocess.run([str(r/'build/metal_nav_guided'),'export',str(checkpoint),str(nav)],stdout=log,stderr=subprocess.STDOUT).returncode
  assert code==0;actors[label]={'checkpoint':str(checkpoint),'checkpoint_sha256':hashlib.sha256(checkpoint.read_bytes()).hexdigest(),'nav':str(nav),'nav_sha256':hashlib.sha256(nav.read_bytes()).hexdigest()}
(o/'actors.json').write_text(json.dumps(actors,indent=2)+'\n')
transfer.WEBOTS_DIR=project;transfer.OUT_DIR=o;transfer.FLIGHT_DIR=o/'flights'
bank=r/'results/root-motion-fidelity/dev/challenges.bin';banksha=hashlib.sha256(bank.read_bytes()).hexdigest()
fd=__import__('os').open(str(r/'results/metal-training.lock'),__import__('os').O_CREAT|__import__('os').O_RDWR,0o644)
try:
 fcntl.flock(fd,fcntl.LOCK_EX)
 for index in range(24):
  for label,actor in actors.items():
   assert hashlib.sha256(bank.read_bytes()).hexdigest()==banksha
   nav=Path(actor['nav']);assert hashlib.sha256(nav.read_bytes()).hexdigest()==actor['nav_sha256']
   slug=f'validmotion-native-{index}-{label}';world=scene.export(bank,index,nav,project,slug)
   result=transfer.run_flight(world,o/'flights'/slug,False)
   row={'index':index,'actor':label,'slug':slug,'world_sha256':hashlib.sha256(world.read_bytes()).hexdigest(),'bank_sha256':banksha,'nav_sha256':actor['nav_sha256'],'run':result};records.append(row)
   (o/'receipts.json').write_text(json.dumps(records,indent=2)+'\n');print(index,label,'valid',result['valid'],flush=True)
   if not result['valid']:raise RuntimeError('Invalidnativeflight; preserve and fixharness before resuming: '+str(result))
finally:
 fcntl.flock(fd,fcntl.LOCK_UN);__import__('os').close(fd)
print('NATIVE96FLIGHTS_COMPLETE',flush=True)
