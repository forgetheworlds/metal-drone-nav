from pathlib import Path
import importlib.util,json,hashlib,subprocess,shutil
root=Path('/Users/muadhsambul/RL');base=root/'results/root-native-bc-fast-v1';work=Path('/Users/muadhsambul/.codex/worktrees/calibrated-navigation-sensors/RL')
spec=importlib.util.spec_from_file_location('paired',work/'webots/devb_paired_transfer.py');paired=importlib.util.module_from_spec(spec);spec.loader.exec_module(paired)
records,_,_=paired.read_records();record=next(r for r in records if r['index']==127)
manifest=json.loads((base/'selection-manifest.json').read_text());out=base/'recordings-fixed';out.mkdir(exist_ok=True)
proof={'selection':'DEV-b env127 doorway, selected after complete256flightdevelopmentbenchmark toshow pairedfailure/rescue; no additiontoscore','recordings':{}}
for actor in ['fast','bc']:
 nav=Path(manifest['assets'][actor]['nav']);assert hashlib.sha256(nav.read_bytes()).hexdigest()==manifest['assets'][actor]['nav_sha256']
 slug=f'rootvideo-fixed-env127-doorway-{actor}';directory=out/slug;directory.mkdir(exist_ok=True);movie=directory/'flight.mp4'
 world=paired.lwt.write_world(record,actor,nav,movie=movie,slug=slug)
 text=world.read_text().replace('controller "local_waypoint_transfer"','controller "local_waypoint_recording"')
 text=text.replace('DEF RLRecordingViewpoint Viewpoint', 'Viewpoint')
 text=paired.lwt.benchmark_recording_viewpoint(text,record['goal_position'],(-1.6,0.32,1.65))
 assert text.count('DEF RLRecordingViewpoint') == 1
 world.write_text(text)
 run=paired.lwt.run_flight(world,directory,record_movie=True)
 (directory/'run.json').write_text(json.dumps(run,indent=2)+'\n')
 original=json.loads((base/'flights'/f'rootdbf-env127-doorway-{actor}'/'episode.json').read_text());e=run['receipt']
 assert run['valid'] and run['exit_code']==0 and e
 assert bool(e['success'])==bool(original['success']) and bool(e['collision'])==bool(original['collision'])
 assert movie.exists() and movie.stat().st_size>10000
 dest=root/'artifacts/videos'/('native-doorway-learned-success.mp4' if actor=='bc' else 'native-doorway-baseline-contact.mp4')
 shutil.copy2(movie,dest)
 proof['recordings'][actor]={'run':str(directory),'video':str(dest),'sha256':hashlib.sha256(dest.read_bytes()).hexdigest(),'success':e['success'],'collision':e['collision'],'time_s':e['time_s'],'scored_outcome_reproduced':True}
 print(actor,'movie',dest,'outcome reproduced',flush=True)
(base/'recordings-fixed/proof.json').write_text(json.dumps(proof,indent=2)+'\n')
print('ACTUAL_NATIVE_PAIRED_RECORDINGS_COMPLETE',flush=True)
