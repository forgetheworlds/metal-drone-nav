// Independent native moving-obstacle transfer fixture (omp-task-contract,
// next-validation-mission.md).
//
// Purpose
//  * Run a predeclared paired subset of the ACTUAL dev-dyn2 dynamic bank
//    (DYBANK1, 908-byte DynamicEntry records - layout read verbatim from the
//    archived dynamic module, pinned here with static_asserts) through the
//    published root waypoint runner's native stack: real depth sensing, real
//    RAPTOR plant, contact scoring, exact goal/hold/cap/deadline task path.
//  * No privileged obstacle truth reaches the actor: observations come from
//    sim_observe (depth + ego + goal) exactly as the deployed stack; all
//    threat kinematics used here live in host-side world construction,
//    grading and offline validation only.
//  * Timeline proof: the moving threat must be at center0 + velocity*t with
//    t = episode clock (t=0 at every install/auto-reset), and the GPU depth
//    frame must match the host ray model computed at that SAME episode time
//    (and differ from the frozen t=0 model) - ray attribution validated to
//    <=2e-4 like the parent contract probe.
//  * Counterfactual: --static-cf freezes the threat at its t=0 center in an
//    otherwise identical world; paired depth dumps (same pose, different
//    geometry only) prove the scene really moves.
//  * Failed/invalid loads, missing threats and gate misses stay visible: they
//    are printed with counters and cause non-zero exit - never filtered.
//
// Embeds the read-only published root runner (WAYPOINT_EMBEDDED keeps its
// main out). No existing file is modified.
//
// Build:
//   clang++ -x objective-c++ -std=c++17 -O2 -fobjc-arc \
//     -framework Foundation -framework Metal -framework Accelerate \
//     -DSOURCE_DIR='"/Users/muadhsambul/RL"' -DFIXED_PPO_ACTOR_OBS_DIM=184 \
//     -DNAV_SENSOR_PROFILE=1 local_moving_benchmark.mm -o metal_nav_moving
//
// Run (shared Metal lock):
//   python3 results/mimo-learning-next/run_locked.py -- <bin> moving-eval \
//     CKPT OUT_CSV --bank dev-dyn2.bin --draws d1,d2,... --mode 17 \
//     --seed 700001 [--static-cf] [--timeline OUT.csv] [--depth-dump OUT.bin]

#define WAYPOINT_EMBEDDED
#include "/Users/muadhsambul/RL/navigation_waypoint_training.mm"

#include <cstddef>
#include <cstring>

namespace moving {

using waypoint::BankEntry;
using waypoint::BankControl;
using waypoint::LocalRun;

// ------------------------------------------------- dynamic bank ABI (908 B)
// Verbatim field order of `struct DynamicEntry` from the archived dynamic
// module (results/omp-local-dynamics/proof/
// navigation_dynamic_tasks-trained-b84c1efbd2e1b15535acfb452a42f76bc8c736
// bb0bc4d01266597a5027b9f8d7.mm, "Layout is all-4-byte members ... matches
// the MSL declaration byte for byte"). No approximation or reconstruction:
// the physical fields are consumed from these exact bytes.
struct DynEntry908 {
    WWorld world;
    float start_position[3];
    float start_velocity[3];
    float goal_position[3];
    float start_yaw;
    float clearance_start;
    float clearance_goal;
    float route_length;
    float straight_min_clearance;
    float threat_speed_mps;
    float nominal_ttc_s;
    float wait_until_s;
    float retreat_until_s;
    float warning_s;
    float causal_collision_s;
    float measured_min_ttc_s;
    float retreat_point[3];
    float route_plus[4][3];
    float route_minus[4][3];
    uint32_t route_plus_count;
    uint32_t route_minus_count;
    uint32_t family;
    uint32_t scene_seed;
    uint32_t threat_kind;    // 0 approach, 1 crossing
    uint32_t start_stratum;  // 0 stopped, 1 toward-goal, 2 lateral
    uint32_t draw_index;
    uint32_t labels;
    uint32_t witness_mask;
    uint32_t rejected_reason;
};
static_assert(sizeof(DynEntry908) == 908, "DynamicEntry must stay 908 bytes");

struct DynHeader88 {
    char magic[8];
    uint32_t version, period, count, entry_bytes;
    char entry_sha256[64];
};
static_assert(sizeof(DynHeader88) == 88, "DynBankHeader ABI");

// Prefix + field pins shared with BankEntry (conversion must be byte-exact).
static_assert(offsetof(DynEntry908, start_yaw) == offsetof(BankEntry, start_yaw) &&
              offsetof(DynEntry908, clearance_start) == offsetof(BankEntry, clearance_start) &&
              offsetof(DynEntry908, clearance_goal) == offsetof(BankEntry, clearance_goal) &&
              offsetof(DynEntry908, clearance_goal) + 4 == 724,
              "shared prefix must end at clearance_goal");
static_assert(offsetof(DynEntry908, draw_index) == 892, "draw_index offset pin");
// NOTE: after clearance_goal the layouts diverge (dynamic keeps threat
// metadata; waypoint keeps witness fields) - family/scene_seed are mapped
// FIELD-WISE in to_bank_entry(), and the draw/family offsets are pinned for
// the python subset resolver below.

constexpr float kBodyRadius = 0.18f;

// ---------------------------------------------------------------- loading
static std::vector<DynEntry908> read_dyn_bank(const std::string& path) {
    std::ifstream file(path, std::ios::binary);
    require(bool(file), "cannot open dynamic bank " + path);
    DynHeader88 header{};
    file.read(reinterpret_cast<char*>(&header), sizeof(header));
    require(bool(file) && std::memcmp(header.magic, "DYBANK1", 7) == 0 &&
               header.version == 1 && header.entry_bytes == sizeof(DynEntry908),
            "invalid dynamic bank header " + path);
    std::vector<DynEntry908> entries(header.count);
    file.read(reinterpret_cast<char*>(entries.data()),
              std::streamsize(entries.size() * sizeof(DynEntry908)));
    require(bool(file), "truncated dynamic bank " + path);
    char trailing;
    require(!file.read(&trailing, 1), "dynamic bank has trailing bytes " + path);
    const std::string entry_hash =
        ppo_safeguard_sha256(entries.data(), entries.size() * sizeof(DynEntry908));
    require(std::memcmp(header.entry_sha256, entry_hash.data(), 64) == 0,
            "dynamic bank entry hash mismatch " + path);
    std::cout << "dyn_bank_load " << path << " entries=" << entries.size()
              << " period=" << header.period << " entry_sha256=" << entry_hash << "\n";
    return entries;
}

// DynamicEntry -> published waypoint BankEntry. Physical fields are copied
// byte-exact through clearance_goal; the remaining BankEntry fields map to
// their dynamic straight-route semantics (declared, reported in the receipt).
static BankEntry to_bank_entry(const DynEntry908& d) {
    static_assert(offsetof(BankEntry, clearance_goal) + 4 == 724, "prefix size");
    BankEntry b{};
    std::memcpy(&b, &d, 724);  // world .. clearance_goal inclusive
    b.direct_clearance = d.straight_min_clearance;
    b.witness_clearance = d.straight_min_clearance;
    b.witness_length = d.route_length;
    b.initial_distance = d.route_length;  // straight route by construction
    b.family = d.family;
    b.scene_seed = d.scene_seed;
    b.route_class = 0;  // route is straight
    b.attempts = 1;
    return b;
}

static int threat_slot(const WWorld& world) {
    for (uint32_t i = 0; i < world.count; i++)
        if (world.obstacles[i].velocity[0] != 0.0f || world.obstacles[i].velocity[1] != 0.0f ||
            world.obstacles[i].velocity[2] != 0.0f)
            return int(i);
    return -1;
}

static void freeze_threat(BankEntry& b) {
    for (uint32_t i = 0; i < b.world.count; i++) {
        WObstacle& o = b.world.obstacles[i];
        o.velocity[0] = o.velocity[1] = o.velocity[2] = 0.0f;
    }
}

// Host ray attribution: returns the nearest obstacle id (-1 = room wall) and
// the range through the same wray model the GPU sensor uses, with obstacle
// centers evaluated at episode time t (moving geometry).
static int ray_hit(const WWorld& world, const WVec& origin, const WVec& dir, float t, float* out_range) {
    float best = wray(world, origin, dir, t);
    int id = -1;
    for (uint32_t i = 0; i < world.count; i++) {
        const WObstacle& o = world.obstacles[i];
        const WVec c = wc(o, t);
        float d;
        if (o.kind == 0)
            d = wray_box(origin, dir, c, wv(o.size[0], o.size[1], o.size[2]));
        else if (o.kind == 1)
            d = wray_sphere(origin, dir, c, o.size[0]);
        else
            d = wray_cylinder(origin, dir, c, o.size[0], o.size[2]);
        if (d < best - 1e-4f) { best = d; id = int(i); }
        else if (d <= best + 1e-4f && id < 0) { best = d; id = int(i); }
    }
    if (out_range) *out_range = best;
    return id;
}

struct EnvRecord {
    uint32_t draw = 0;
    int entry_index = -1;
    DynEntry908 dyn{};
    int threat = -1;
    // grading
    bool threat_contact = false;
    float threat_contact_s = -1.0f;
    float view_warning_s = -1.0f;
    float min_threat_dist = 1e9f;
    bool terminal_sampled = false;
    float terminal_threat_dist = -1.0f;
    uint32_t view_samples = 0;
    uint64_t ray_samples = 0;
    float ray_max_err = 0.0f;
    float ray_t0_max_gap = 0.0f;  // |host_t0 - host_at_t| on threat rays
    std::string ray_max_detail;
};

static std::vector<uint32_t> parse_draws(const std::string& text) {
    std::vector<uint32_t> out;
    size_t at = 0;
    while (at < text.size()) {
        size_t comma = text.find(',', at);
        std::string tok = text.substr(at, comma == std::string::npos ? std::string::npos : comma - at);
        if (!tok.empty()) out.push_back(uint32_t(std::stoul(tok)));
        if (comma == std::string::npos) break;
        at = comma + 1;
    }
    return out;
}

// ---------------------------------------------------------------- command
static int command_moving_eval(int argc, char** argv) {
    require(argc >= 4, "moving-eval CHECKPOINT OUT_CSV --bank PATH --draws d1,..[,--static-cf]");
    const std::string checkpoint = argv[2], output = argv[3];
    std::string bank_path, draws_text, timeline_path, depth_dump;
    uint32_t mode = 17, seed = 700001, max_steps = 400, expect_rows = 0;
    bool static_cf = false;
    for (int i = 4; i < argc; i++) {
        const std::string o = argv[i];
        auto val = [&]() -> std::string {
            require(i + 1 < argc, "option " + o + " needs a value");
            return argv[++i];
        };
        if (o == "--bank") bank_path = val();
        else if (o == "--draws") draws_text = val();
        else if (o == "--mode") mode = uint32_t(std::stoul(val()));
        else if (o == "--seed") seed = uint32_t(std::stoul(val()));
        else if (o == "--max-steps") max_steps = uint32_t(std::stoul(val()));
        else if (o == "--expect-rows") expect_rows = uint32_t(std::stoul(val()));
        else if (o == "--static-cf") static_cf = true;
        else if (o == "--timeline") timeline_path = val();
        else if (o == "--depth-dump") depth_dump = val();
        else throw std::runtime_error("unknown moving-eval option " + o);
    }
    require(!bank_path.empty() && !draws_text.empty(), "--bank and --draws are required");
    require(mode == 17, "moving benchmark runs the deployed mode 17");
    require(fixed_ppo::actor_obs_dim == 184, "moving benchmark needs the 184D guided actor");

    auto all = read_dyn_bank(bank_path);
    const auto draws = parse_draws(draws_text);
    require(!draws.empty(), "empty draw list");
    if (expect_rows) require(draws.size() == expect_rows, "--expect-rows mismatch");

    // Map every requested draw to its bank entry and verify both directions.
    std::vector<EnvRecord> recs;
    std::vector<bool> used(all.size(), false);
    for (uint32_t d : draws) {
        EnvRecord r;
        r.draw = d;
        for (size_t i = 0; i < all.size(); i++)
            if (all[i].draw_index == d) {
                require(!used[i], "draw mapped twice");
                used[i] = true;
                r.entry_index = int(i);
                r.dyn = all[i];
                break;
            }
        require(r.entry_index >= 0, "draw " + std::to_string(d) + " not found in bank (invalid load)");
        r.threat = threat_slot(r.dyn.world);
        require(r.threat >= 0, "task draw " + std::to_string(d) + " has no moving threat");
        recs.push_back(r);
    }

    std::vector<BankEntry> bank;
    bank.reserve(recs.size());
    for (auto& r : recs) {
        BankEntry b = to_bank_entry(r.dyn);
        if (static_cf) freeze_threat(b);
        bank.push_back(b);
    }
    const uint32_t envs = uint32_t(bank.size());
    BankControl control{1u, envs};

    // Checkpoint: actual header + actor bytes (no diagnostics/history guesses).
    std::ifstream file(checkpoint, std::ios::binary);
    const PpoCheckpointHeader header = read_checkpoint_header(file);
    require(header.actor_count == fixed_ppo::actor_param_count, "checkpoint actor dims");
    std::vector<float> actor(header.actor_count);
    file.read(reinterpret_cast<char*>(actor.data()), std::streamsize(actor.size() * sizeof(float)));
    require(bool(file), "checkpoint actor read failed");

    Metal metal;
    metal.compile(base_source() + PPO_TRAINER_MSL + waypoint::kWaypointKernels);
    SimConfig config;
    config.n = envs;
    config.mode = mode;
    config.family = 0;
    config.eval = 1;
    config.seed = seed;
    config.speed = 1.5f;
    config.distance = 4;
    config.max_steps = max_steps;
    config.geometry_memory = 1;
    Sim sim(metal, config, 32);
    std::memcpy(sim.actor.contents, actor.data(), sizeof(float) * actor.size());
    LocalRun run = waypoint::make_local_run(sim, bank, control, metal.pipeline("waypoint_task_apply"));
    auto probe = [metal.queue commandBuffer];
    waypoint::local_probe(run, probe);
    metal.finish(probe);
    waypoint::verify_reset(run, bank, control, true);

    std::ofstream timeline;
    if (!timeline_path.empty()) {
        timeline.open(timeline_path);
        require(bool(timeline), "cannot write timeline " + timeline_path);
        timeline << "tick,env,draw,elapsed,tx,ty,tz,expected_tx,expected_ty,expected_tz,"
                    "body_x,body_y,body_z,threat_dist,view_pixels\n";
    }
    std::ofstream depth_file;
    if (!depth_dump.empty()) {
        depth_file.open(depth_dump, std::ios::binary);
        require(bool(depth_file), "cannot write depth dump " + depth_dump);
    }

    // ---- t=0 timeline contract at a true episode start -----------------
    {
        const auto* runs0 = (const SimRun*)sim.runs.contents;
        const auto* worlds0 = (const WWorld*)sim.worlds.contents;
        for (uint32_t e = 0; e < envs; e++) {
            require(runs0[e].steps == 0 && runs0[e].elapsed == 0.0f,
                    "episode clock must be 0 at install (env " + std::to_string(e) + ")");
            // In --static-cf mode every velocity is frozen, so re-detection by
            // velocity would find no threat; the record's threat index is the
            // authority and the freeze itself is asserted below.
            const int slot = static_cf ? recs[e].threat : threat_slot(worlds0[e]);
            require(slot >= 0 && slot == recs[e].threat, "threat slot mismatch after install");
            const WObstacle& o = worlds0[e].obstacles[slot];
            for (int k = 0; k < 3; k++)
                require(o.center[k] == recs[e].dyn.world.obstacles[slot].center[k],
                        "t0 threat center must equal record center0 byte-exactly");
            if (static_cf) {
                for (uint32_t k = 0; k < worlds0[e].count; k++) {
                    const WObstacle& w = worlds0[e].obstacles[k];
                    require(w.velocity[0] == 0.0f && w.velocity[1] == 0.0f &&
                                w.velocity[2] == 0.0f,
                            "static-cf must freeze every velocity");
                }
            }
        }
        std::cout << "timeline_t0 PASS envs=" << envs
                  << " clock_zero=1 threat_center_byteexact=1\n";
    }

    std::vector<RLPhysicsState> pre_states(envs);
    std::vector<SimRun> pre_runs(envs);
    std::vector<WWorld> pre_worlds(envs);

    for (uint32_t t = 0; t < max_steps; t++) {
        std::memcpy(pre_states.data(), sim.states.contents, sizeof(RLPhysicsState) * envs);
        std::memcpy(pre_runs.data(), sim.runs.contents, sizeof(SimRun) * envs);
        std::memcpy(pre_worlds.data(), sim.worlds.contents, sizeof(WWorld) * envs);
        auto cb = [metal.queue commandBuffer];
        waypoint::local_tick(run, cb, t, t == 0);
        metal.finish(cb);
        const auto* runs = (const SimRun*)sim.runs.contents;
        const auto* sensors = (const float*)sim.sensors.contents;
        const auto* poses = (const float*)sim.poses.contents;

        for (uint32_t e = 0; e < envs; e++) {
            if (pre_runs[e].episodes != 0) continue;  // terminal latched (eval)
            EnvRecord& r = recs[e];
            const float t_pre = pre_runs[e].elapsed;
            const uint32_t frame = pre_runs[e].steps % 8;
            const float* pose = poses + (size_t(e) * 8 + frame) * 12;
            const float* ranges = sensors + (size_t(e) * 8 + frame) * 320;
            const WWorld& world = pre_worlds[e];
            const WVec origin = wv(pose[0], pose[1], pose[2]);
            const RLPhysicsState& st = pre_states[e];
            const WVec body = wv(st.position[0], st.position[1], st.position[2]);
            const WObstacle& threat = world.obstacles[r.threat];
            const WVec tpos = wc(threat, t_pre);
            // arithmetic timeline identity (same ops as world.hpp wc)
            const float ex = threat.center[0] + t_pre * threat.velocity[0];
            const float ey = threat.center[1] + t_pre * threat.velocity[1];
            const float ez = threat.center[2] + t_pre * threat.velocity[2];
            require(tpos.x == ex && tpos.y == ey && tpos.z == ez, "wc(t) identity broken");
            const float threat_dist = std::sqrt((body.x - tpos.x) * (body.x - tpos.x) +
                                                (body.y - tpos.y) * (body.y - tpos.y) +
                                                (body.z - tpos.z) * (body.z - tpos.z));
            const float combined = kBodyRadius + threat.size[0];
            if (threat_dist < r.min_threat_dist) r.min_threat_dist = threat_dist;
            if (threat_dist <= combined) {
                r.threat_contact = true;
                if (r.threat_contact_s < 0) r.threat_contact_s = t_pre;
            }
            uint32_t view_pixels = 0;
            WWorld frozen = world;
            for (uint32_t k = 0; k < frozen.count; k++) {
                frozen.obstacles[k].velocity[0] = frozen.obstacles[k].velocity[1] =
                    frozen.obstacles[k].velocity[2] = 0.0f;
            }
            for (uint32_t pixel = 0; pixel < 320; pixel++) {
                const WVec ray = nav_sensor_pixel_ray(NAV_SENSOR_TAN_H, NAV_SENSOR_ACTIVE_TAN_V, pixel);
                const WVec dir = wv(pose[3] * ray.x + pose[4] * ray.y + pose[5] * ray.z,
                                    pose[6] * ray.x + pose[7] * ray.y + pose[8] * ray.z,
                                    pose[9] * ray.x + pose[10] * ray.y + pose[11] * ray.z);
                float host_range = 0.0f;
                const int hit = ray_hit(world, origin, dir, t_pre, &host_range);
                const float gpu = ranges[pixel];
                const float err = std::fabs(gpu - host_range);
                r.ray_samples++;
                if (err > r.ray_max_err) {
                    r.ray_max_err = err;
                    r.ray_max_detail = "tick=" + std::to_string(t) + " env=" + std::to_string(e) +
                                        " pixel=" + std::to_string(pixel);
                }
                if (hit == r.threat) {
                    view_pixels++;
                    float t0_range = 0.0f;
                    const int hit0 = ray_hit(frozen, origin, dir, 0.0f, &t0_range);
                    (void)hit0;
                    const float gap = std::fabs(t0_range - host_range);
                    if (gap > r.ray_t0_max_gap) r.ray_t0_max_gap = gap;
                }
            }
            if (view_pixels > 0) {
                r.view_samples++;
                if (r.view_warning_s < 0) r.view_warning_s = t_pre;
            }
            if (timeline.is_open() && (e < 2 || r.threat_contact)) {
                timeline << t << ',' << e << ',' << r.draw << ',' << t_pre << ','
                         << std::setprecision(9) << tpos.x << ',' << tpos.y << ',' << tpos.z << ','
                         << ex << ',' << ey << ',' << ez << ','
                         << body.x << ',' << body.y << ',' << body.z << ','
                         << threat_dist << ',' << view_pixels << '\n';
            }
        }
        // Terminal-tick proximity pass: the contact fires inside the advance
        // that ends the episode, so the NEXT tick's pre-state never flies and
        // pre-tick sampling alone under-samples by up to one tick (7/7 threat
        // contacts were mislabeled static before this pass). Sample the
        // post-terminal state at the frozen episode clock (exact contact time).
        for (uint32_t e = 0; e < envs; e++) {
            if (!(pre_runs[e].episodes == 0 && runs[e].episodes == 1)) continue;
            EnvRecord& r = recs[e];
            const auto* states_now = (const RLPhysicsState*)sim.states.contents;
            const auto* worlds_now = (const WWorld*)sim.worlds.contents;
            const float t_end = runs[e].elapsed;
            const WObstacle& threat = worlds_now[e].obstacles[r.threat];
            const WVec tpos = wc(threat, t_end);
            const WVec body = wv(states_now[e].position[0], states_now[e].position[1],
                                 states_now[e].position[2]);
            const float dist = std::sqrt((body.x - tpos.x) * (body.x - tpos.x) +
                                         (body.y - tpos.y) * (body.y - tpos.y) +
                                         (body.z - tpos.z) * (body.z - tpos.z));
            r.terminal_sampled = true;
            r.terminal_threat_dist = dist;
            if (dist < r.min_threat_dist) r.min_threat_dist = dist;
            const float combined = kBodyRadius + threat.size[0];
            if (dist <= combined) {
                r.threat_contact = true;
                if (r.threat_contact_s < 0) r.threat_contact_s = t_end;
            }
        }
        if (depth_file.is_open()) {
            // Tick-aligned dump for EVERY env (terminal latched ones included),
            // so a paired run compares identical frames; positions are dumped
            // to precondition geometry-only differences on pose equality.
            for (uint32_t e = 0; e < envs; e++) {
                const uint32_t frame = pre_runs[e].steps % 8;
                const float* franges = sensors + (size_t(e) * 8 + frame) * 320;
                depth_file.write(reinterpret_cast<const char*>(franges), 320 * sizeof(float));
            }
            for (uint32_t e = 0; e < envs; e++)
                depth_file.write(reinterpret_cast<const char*>(&pre_states[e].position),
                                 3 * sizeof(float));
        }
    }

    // ---- rows + gates ---------------------------------------------------
    const auto* runs = (const SimRun*)sim.runs.contents;
    std::string split_label = "custom";
    {
        size_t slash = bank_path.find_last_of('/');
        std::string base = bank_path.substr(slash == std::string::npos ? 0 : slash + 1);
        size_t dot = base.find_last_of('.');
        if (dot != std::string::npos) base = base.substr(0, dot);
        split_label = base;
    }
    std::ofstream csv(output);
    require(bool(csv), "cannot write " + output);
    csv << std::setprecision(9);
    csv << "split,env,draw_index,entry_index,threat_kind,threat_speed_mps,start_stratum,"
           "labels,family,scene_seed,mode,seed,static_cf,success,collision,timeout,"
           "contact_source,threat_contact_s,view_warning_s,time_s,path_m,min_clearance_m,"
           "final_dist_m,view_samples,ray_samples,ray_max_err,threat_t0_gap_m,min_threat_dist_m\n";
    uint32_t succ = 0, coll = 0, to = 0, threat_c = 0, static_c = 0, no_view = 0;
    float ray_gate = 0.0f, sep_gate = 0.0f;
    uint64_t view_total = 0;
    std::ofstream failures;
    const std::string fail_path = output + ".failures.csv";
    failures.open(fail_path);
    for (uint32_t e = 0; e < envs; e++) {
        const EnvRecord& r = recs[e];
        const SimRun& rr = runs[e];
        require(rr.episodes == 1, "eval env must finish exactly one episode (env " +
                                      std::to_string(e) + " episodes=" + std::to_string(rr.episodes));
        float dist = 0.0f;
        for (int k = 0; k < 3; k++) {
            const float d = ((const RLPhysicsState*)sim.states.contents)[e].position[k] - r.dyn.goal_position[k];
            dist += d * d;
        }
        const bool contact = rr.collisions > 0;
        const char* source = "none";
        if (contact && r.threat_contact) { source = "threat"; threat_c++; }
        else if (contact) { source = "static"; static_c++; }
        if (contact) {
            failures << r.draw << ",contact,"
                     << (r.terminal_sampled ? std::to_string(r.terminal_threat_dist)
                                            : std::string("no_terminal_sample"))
                     << "," << r.min_threat_dist << "\n";
        }
        succ += rr.successes ? 1 : 0;
        coll += contact ? 1 : 0;
        to += rr.timeouts ? 1 : 0;
        view_total += r.view_samples;
        if (r.view_samples == 0) no_view++;
        if (r.ray_max_err > ray_gate) ray_gate = r.ray_max_err;
        if (r.ray_t0_max_gap > sep_gate) sep_gate = r.ray_t0_max_gap;
        csv << split_label << ',' << e << ',' << r.draw << ',' << r.entry_index << ','
            << r.dyn.threat_kind << ',' << r.dyn.threat_speed_mps << ',' << r.dyn.start_stratum
            << ',' << r.dyn.labels << ',' << r.dyn.family << ',' << r.dyn.scene_seed << ','
            << mode << ',' << seed << ',' << (static_cf ? 1 : 0) << ','
            << (rr.successes ? 1 : 0) << ',' << (contact ? 1 : 0) << ',' << (rr.timeouts ? 1 : 0)
            << ',' << source << ',' << r.threat_contact_s << ',' << r.view_warning_s << ','
            << rr.elapsed << ',' << rr.path << ',' << rr.min_clearance << ',' << std::sqrt(dist)
            << ',' << r.view_samples << ',' << r.ray_samples << ',' << r.ray_max_err << ','
            << r.ray_t0_max_gap << ',' << r.min_threat_dist << '\n';
        if (!contact && rr.timeouts == 0 && rr.successes == 0)
            failures << r.draw << ",no_terminal_outcome\n";
    }
    // no-view tasks are recorded, not filtered
    for (const EnvRecord& r : recs)
        if (r.view_samples == 0) failures << r.draw << ",no_threat_view_sample\n";

    std::cout << "moving_eval split=dev-dyn2 mode=" << mode << " seed=" << seed
              << " cf=" << (static_cf ? 1 : 0) << " rows=" << envs
              << " success=" << succ << " collision=" << coll << " timeout=" << to
              << " contact_threat=" << threat_c << " contact_static=" << static_c
              << " no_view=" << no_view << "\n";
    std::cout << "moving_timeline clock_zero=1 wc_identity=1 threat_view_samples=" << view_total
              << " ray_max_err=" << ray_gate << " threat_t0_max_gap=" << sep_gate << "\n";
    std::cout << "moving_provenance checkpoint_header_version=" << header.version
              << " actor_count=" << header.actor_count << " sensor_profile=" << NAV_SENSOR_ACTIVE_NAME
              << " bank=" << bank_path << " subset_rows=" << envs
              << " static_cf=" << (static_cf ? 1 : 0) << "\n";
    // Gates: model attribution must be tight; at least one threat-in-view
    // sample must exist somewhere in the run (moving-sensor evidence).
    require(ray_gate <= 2e-4f,
            "host/GPU ray attribution exceeds 2e-4 (max " + std::to_string(ray_gate) + ")");
    require(view_total > 0, "no threat-in-view samples: moving-sensor proof unavailable (not filtered)");
    std::cout << "moving_gates PASS ray<=2e-4 threat_view>0 failures_file=" << fail_path << "\n";
    return 0;
}

}  // namespace moving

int main(int argc, char** argv) {
    @autoreleasepool {
        try {
            std::setvbuf(stdout, nullptr, _IONBF, 0);
            std::setvbuf(stderr, nullptr, _IONBF, 0);
            if (argc < 2) {
                std::cout << "commands\n  moving-eval CHECKPOINT OUT_CSV --bank P --draws d1,... "
                             "[--static-cf] [--timeline P] [--depth-dump P] [--expect-rows N]\n";
                return 0;
            }
            const std::string command = argv[1];
            if (command == "moving-eval") return moving::command_moving_eval(argc, argv);
            std::cerr << "unknown command " << command << "\n";
            return 1;
        } catch (const std::exception& e) {
            std::cerr << "ERROR: " << e.what() << "\n";
            return 1;
        }
    }
}
