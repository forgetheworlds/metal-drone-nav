#!/usr/bin/env python3
"""Source comparator: join THIS fixture's rows against the dynamic mission's
recorded dev-dyn2 rows on the exact same bank records and checkpoints.

Checkpoints (hash-pinned): full-s1.bin.best 4b5166ef..., candidate-fast.bin
.best == warmstart assets/checkpoints/local-waypoint-fast-experimental.bin
.best (7a37ace8..., stated in their report.md).

usage: python3 local_moving_compare.py --mine rows.csv --theirs theirs.csv \
       --label full|fast --out receipt.json
"""
import argparse, csv, hashlib, json, datetime


def sha256(p):
    return hashlib.sha256(open(p, "rb").read()).hexdigest()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--mine", required=True)
    ap.add_argument("--theirs", required=True)
    ap.add_argument("--label", required=True, choices=("full", "fast"))
    ap.add_argument("--out", required=True)
    ap.add_argument("--expected-checkpoint-sha", required=True)
    args = ap.parse_args()

    mine = {int(r["draw_index"]): r for r in csv.DictReader(open(args.mine))}
    theirs = {int(r["draw_index"]): r for r in csv.DictReader(open(args.theirs))}
    common = sorted(set(mine) & set(theirs))
    missing = sorted(set(mine) - set(theirs))

    succ_match = coll_match = 0
    time_exact = time_within_tick = 0
    time_mismatches = []
    time_deltas = []
    contact_disagree = []
    rows = []
    for d in common:
        m, t = mine[d], theirs[d]
        ms, ts = int(m["success"]), int(t["success"])
        mc, tc = int(m["collision"]), int(t["collision"])
        succ_match += ms == ts
        coll_match += mc == tc
        if ms and ts:
            time_deltas.append(abs(float(m["time_s"]) - float(t["time_s"])))
        if mc or tc:
            if m["contact_source"] != t["contact_source"]:
                contact_disagree.append(
                    {"draw_index": d, "mine": m["contact_source"], "theirs": t["contact_source"]})
        mt, tt = float(m["time_s"]), float(t["time_s"])
        time_exact += (mt == tt)
        if abs(mt - tt) <= 0.01:
            time_within_tick += 1
        else:
            time_mismatches.append({"draw_index": d, "mine": mt, "theirs": tt,
                                    "delta": abs(mt - tt)})
        rows.append({"draw_index": d, "success": [ms, ts], "collision": [mc, tc],
                     "time_s": [mt, tt]})

    n = len(common)
    rec = {
        "schema": "local-moving-source-comparator-v1",
        "checker": "task-contract",
        "label": args.label,
        "created_utc": datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "mine": {"path": args.mine, "sha256": sha256(args.mine), "rows": len(mine)},
        "theirs": {"path": args.theirs, "sha256": sha256(args.theirs), "rows": len(theirs)},
        "checkpoint_sha256": args.expected_checkpoint_sha,
        "common_rows": n,
        "missing_in_source": missing,
        "success_exact_matches": succ_match,
        "collision_exact_matches": coll_match,
        "success_match_rate": (succ_match / n) if n else 0.0,
        "collision_match_rate": (coll_match / n) if n else 0.0,
        "mean_abs_arrival_delta_s_on_double_success": (
            sum(time_deltas) / len(time_deltas) if time_deltas else None),
        "time_s_exact_rows": time_exact,
        "time_s_within_10ms_rows": time_within_tick,
        "time_s_mismatches_beyond_10ms": time_mismatches,
        "timing_note": "time_s is compared on every row (not only successes). The two "
                       "implementations are different engines (published root waypoint core "
                       "vs the dynamic mission's dynamic-eval over its snapshot core): "
                       "scheduler/history timing can in principle shift a trajectory, so any "
                       "row beyond one100Hz tick is listed explicitly and must be explained "
                       "per row - never averaged away. Exact rows are the expected case "
                       "because both share the same plant, sensors, task grader and record.",
        "contact_source_disagreements": contact_disagree,
        "interpretation": "independent implementation (root waypoint runner) vs the dynamic "
                          "mission's dynamic-eval pipeline on EXACT bank records and checkpoint "
                          "bytes; outcome matches support cross-implementation validity, "
                          "disagreements are first-class findings (never silently dropped)",
    }
    with open(args.out, "w") as f:
        json.dump(rec, f, indent=1, separators=(",", ":"))
        f.write("\n")
    print(f"comparator {args.label}: common={n} success_match={succ_match}/{n} "
          f"collision_match={coll_match}/{n} contact_disagree={len(contact_disagree)} "
          f"missing={missing}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
