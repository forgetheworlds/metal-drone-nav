#!/usr/bin/env python3
"""Predeclare the paired moving-obstacle benchmark subset (STRATA ONLY).

Mission: next-validation-mission.md (omp-task-contract). Selection reads the
dev-dyn2 *records* CSV only - it has construction labels (threat_kind, speed,
start_stratum, warning bits, family) and NO policy outcome columns, so an
outcome-filtered selection is impossible by schema.

Outputs a frozen JSON consumed by local_moving_benchmark.mm (task indices)
and by the parent-owned job request. Deterministic: same inputs -> same bytes.

usage: python3 local_moving_subset.py [--records PATH] [--out PATH] [--pairs N]
"""
import argparse, csv, hashlib, json, os, datetime

DYN = "/Users/muadhsambul/RL/results/omp-local-dynamics/banks"
DEFAULT_RECORDS = f"{DYN}/dev-dyn2.csv"
DEFAULT_BIN = f"{DYN}/dev-dyn2.bin"
DEFAULT_MANIFEST = f"{DYN}/dev-dyn2.json"
DEFAULT_OUT = "/Users/muadhsambul/RL/results/omp-grounded-contract/moving-subset-frozen.json"

# Pinned by the parent (recomputed at generation time; mismatch = refuse).
PINNED = {
    DEFAULT_BIN: "8b2bc51c25a1c58697daeb2d0f8f3b5a3c2387cd2a121738194b1956d63cd4aa",
    DEFAULT_MANIFEST: "53fb1349a89c479686b2f802712f796be02095e839e7abf13a81d4b8b4ca5e30",
}


def sha256(path: str) -> str:
    with open(path, "rb") as f:
        return hashlib.sha256(f.read()).hexdigest()




def challenge_panel(args) -> int:
    """Panel B: predeclared32 rows from the ORIGINAL dev-dyn bank (EXPOSED
    source selector - development/implementation evidence only, never FINAL).

    Selection is construction-strata only and outcome-free (the records csv
    has no policy outcome columns): ALL accepted in-bank rows with fast threats
    (speed >= 1.5) are taken - the scarce hard cases - then deterministic fill
    to32 by (approach first, faster speed, shorter nominal TTC, lowest draw).
    Approach/crossing,1.5/2.0 speeds, short-warning TTC and independent start
    velocity coverage are reported as realized counts with pool limits.
    """
    dyn_bin = f"{DYN}/dev-dyn.bin"
    dyn_json = f"{DYN}/dev-dyn.json"
    dyn_csv = f"{DYN}/dev-dyn.csv"
    pins = {dyn_bin: "b734466ac1772b1f825ff7b8290dc5bb56bce55e25acf45f0efdadd4cf07bb22"}
    for path, want in pins.items():
        got = sha256(path)
        if got != want:
            raise SystemExit(f"PIN MISMATCH {path}: {got} != {want}")
    manifest = json.load(open(dyn_json))
    if sha256(dyn_csv) != manifest.get("csv_sha256"):
        raise SystemExit("dev-dyn records csv sha != manifest")

    raw = open(dyn_bin, "rb").read()
    if raw[:7] != b"DYBANK1" or len(raw) != 88 + 908 * 128:
        raise SystemExit("dev-dyn.bin header/size unexpected")
    draw_at = 892
    entry_index_by_draw = {}
    for i in range(128):
        off = 88 + i * 908
        draw = int.from_bytes(raw[off + draw_at:off + draw_at + 4], "little")
        entry_index_by_draw[draw] = i
    rows = {int(r["draw_index"]): r for r in csv.DictReader(open(dyn_csv))}
    in_bank = []
    for d, i in entry_index_by_draw.items():
        r = rows.get(d)
        if r is None or int(r["binned"]) != 1:
            raise SystemExit(f"bin draw {d} not accepted in records csv")
        in_bank.append(r)

    fast = [r for r in in_bank if float(r["threat_speed_mps"]) >= 1.5]
    rest = [r for r in in_bank if float(r["threat_speed_mps"]) < 1.5]
    # deterministic tie-break: approach(kind0) first, faster, shorter TTC, draw
    fast.sort(key=lambda r: (int(r["threat_kind"]), -float(r["threat_speed_mps"]),
                             float(r["nominal_ttc_s"]), int(r["draw_index"])))
    chosen = list(fast)
    rest.sort(key=lambda r: (abs(int(r["threat_kind"])), float(r["threat_speed_mps"]),
                             float(r["nominal_ttc_s"]), int(r["draw_index"])))
    # fill toward kind balance (approach first) from the next-hardest speeds
    want_kind0 = 16 - sum(1 for r in chosen if int(r["threat_kind"]) == 0)
    for r in rest:
        if len(chosen) >= 32:
            break
        if int(r["threat_kind"]) == 0 and want_kind0 > 0:
            chosen.append(r)
            want_kind0 -= 1
    for r in rest:
        if len(chosen) >= 32:
            break
        if r not in chosen:
            chosen.append(r)
    chosen = sorted(chosen[:32], key=lambda r: int(r["draw_index"]))
    if len(chosen) < 32:
        raise SystemExit(f"challenge panel shortfall {len(chosen)}")
    entry_indices = [entry_index_by_draw[int(r["draw_index"])] for r in chosen]

    counts = {"approach": 0, "crossing": 0, "speed_1_5": 0, "speed_2_0": 0, "speed_lt_1_5": 0,
              "nominal_ttc_le_0_75": 0, "nominal_ttc_le_1_0": 0, "warning_ok": 0, "causal_bit": 0,
              "stratum_stopped": 0, "stratum_toward": 0, "stratum_lateral": 0}
    for r in chosen:
        k, sp, ttc = int(r["threat_kind"]), float(r["threat_speed_mps"]), float(r["nominal_ttc_s"])
        counts["approach" if k == 0 else "crossing"] += 1
        counts["speed_1_5" if sp == 1.5 else "speed_2_0" if sp == 2.0 else "speed_lt_1_5"] += 1
        counts["nominal_ttc_le_0_75" if ttc <= 0.75 else "nominal_ttc_le_1_0" if ttc <= 1.0 else "nominal_ttc_le_1_0"] += 1 if ttc <= 1.0 and ttc > 0.75 else 0
        if ttc <= 0.75:
            pass  # counted above
        counts["warning_ok"] += 1 if int(r["labels"]) & (1 << 3) else 0
        counts["causal_bit"] += 1 if int(r["labels"]) & (1 << 4) else 0
        counts["stratum_stopped" if int(r["start_stratum"]) == 0 else
               "stratum_toward" if int(r["start_stratum"]) == 1 else "stratum_lateral"] += 1
    # recompute ttc buckets cleanly
    counts["nominal_ttc_le_0_75"] = sum(1 for r in chosen if float(r["nominal_ttc_s"]) <= 0.75)
    counts["nominal_ttc_le_1_0"] = sum(1 for r in chosen if float(r["nominal_ttc_s"]) <= 1.0)
    fast_count = sum(1 for r in chosen if float(r["threat_speed_mps"]) >= 1.5)

    out = {
        "schema": "local-moving-subset-v1",
        "panel": "challenge",
        "created_utc": datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "selection_rule": "in-bank (dev-dyn.bin) accepted rows; ALL rows with threat speed >=1.5 "
                          "taken first (fast1.5/2.0 pool - the scarce hard cases), then "
                          "deterministic fill to32 by (approach first, faster speed, shorter "
                          "nominal TTC, lowest draw). Construction fields only; no policy outcome "
                          "field exists in the records csv and none was read",
        "bank_bin": dyn_bin,
        "bank_bin_sha256": pins[dyn_bin],
        "bank_manifest": dyn_json,
        "bank_manifest_sha256": sha256(dyn_json),
        "records_csv": dyn_csv,
        "records_csv_sha256": sha256(dyn_csv),
        "entry_bytes": 908,
        "exposure": "ORIGINAL dev-dyn is the source study's checkpoint SELECTOR (exposed "
                    "development split, Full112/109 vs warm27 reported on it): panel supports "
                    "independent implementation evidence only, never sealed-final or blind "
                    "generalization claims",
        "row_count": len(chosen),
        "fast_rows": fast_count,
        "strata_counts": counts,
        "entry_indices": entry_indices,
        "draw_indices": [int(r["draw_index"]) for r in chosen],
        "rows": [
            {"draw_index": int(r["draw_index"]),
             "entry_index": entry_index_by_draw[int(r["draw_index"])],
             "family": int(r["family"]),
             "scene_seed": int(r["scene_seed"]),
             "threat_kind": int(r["threat_kind"]),
             "start_stratum": int(r["start_stratum"]),
             "threat_speed_mps": float(r["threat_speed_mps"]),
             "nominal_ttc_s": float(r["nominal_ttc_s"]),
             "warning_s": float(r["warning_s"]),
             "labels_bits": int(r["labels"])}
            for r in chosen
        ],
        "notes": [
            f"fast pool in bank = {len(fast)} rows (all included); approach/crossing balance is "
            "pool-limited and reported as realized",
            "all rows retained regardless of outcome; failed/invalid loads counted by the runner",
        ],
    }
    with open(args.out, "w") as f:
        json.dump(out, f, indent=1, separators=(",", ":"))
        f.write("\n")
    print(f"challenge panel written {args.out} rows={len(chosen)} fast={fast_count}")
    print("strata", json.dumps(counts))
    print("sha256", sha256(args.out))
    return 0

def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--records", default=DEFAULT_RECORDS)
    ap.add_argument("--out", default=DEFAULT_OUT)
    ap.add_argument("--pairs", type=int, default=16, help="target pair count (2 rows each)")
    ap.add_argument("--panel", choices=("diagnostic", "challenge"), default="diagnostic",
                    help="diagnostic = paired dev-dyn2 (easy .5/.75, geometry ceiling); "
                         "challenge = original dev-dyn fast-threat strata panel")
    args = ap.parse_args()
    if args.panel == "challenge":
        return challenge_panel(args)

    for path, want in PINNED.items():
        got = sha256(path)
        if got != want:
            raise SystemExit(f"PIN MISMATCH {path}: {got} != {want}")
    manifest = json.load(open(DEFAULT_MANIFEST))
    got = sha256(args.records)
    if got != manifest.get("csv_sha256"):
        raise SystemExit(f"records csv sha {got} != manifest {manifest.get('csv_sha256')}")

    all_rows = list(csv.DictReader(open(args.records)))
    # Accepted-only: binned==1 rows are the records that reached dev-dyn2.bin.
    rows = [r for r in all_rows if int(r["binned"]) == 1]
    accepted_draws = {int(r["draw_index"]) for r in rows}
    header = list(rows[0].keys())
    # construction-only columns (no outcome columns exist in this file)
    need = {"draw_index", "family", "scene_seed", "threat_kind", "start_stratum",
            "threat_speed_mps", "labels"}
    # header spelling from the generator: locate the pair column too
    pair_col = next(c for c in header if c in ("pair_partner", "pair_index", "pair_draw_index", "pair"))
    speed_col = next(c for c in header if "speed" in c)
    kind_col = "threat_kind" if "threat_kind" in header else next(c for c in header if "kind" in c)
    stratum_col = "start_stratum" if "start_stratum" in header else next(c for c in header if "stratum" in c)
    missing = need - set(header)
    if missing and not ({"threat_speed_mps"} - set(header)):
        raise SystemExit(f"records csv missing columns: {missing}")

    def cell(r):
        speed = float(r[speed_col])
        return (int(r[kind_col]), 1 if speed >= 0.75 else 0, int(r[stratum_col]))

    # A pair is complete only when BOTH member draws are accepted.
    def partner_ok(r):
        p = int(r[pair_col])
        return p >= 0 and p in accepted_draws
    paired = [r for r in rows if partner_ok(r)]
    unpaired = [r for r in rows if not partner_ok(r)]  # accepted, partner rejected
    # Canonical pair id = min(draw, partner); both accepted members required.
    pair_members = {}
    for r in rows:
        p = int(r[pair_col])
        if not partner_ok(r):
            continue
        pid = min(int(r["draw_index"]), p)
        pair_members.setdefault(pid, []).append(r)
    pair_members = {k: sorted(v, key=lambda r: int(r["draw_index"]))
                    for k, v in pair_members.items() if len(v) == 2}
    pair_reps = [(members[0], pid) for pid, members in sorted(pair_members.items())]

    # Round-robin across strata cells, cells sorted for determinism.
    cells = {}
    for rep, pid in pair_reps:
        cells.setdefault(cell(rep), []).append((rep, pid))
    chosen_pairs, chosen_rows = [], []
    cell_keys = sorted(cells)
    print("cells:", {str(k): len(v) for k, v in sorted(cells.items())})
    idx = 0
    while len(chosen_pairs) < args.pairs:
        added = False
        for k in cell_keys:
            bucket = cells[k]
            if idx < len(bucket):
                rep, pid = bucket[idx]
                chosen_pairs.append(pid)
                for m in pair_members[pid]:
                    chosen_rows.append(m)
                added = True
                if len(chosen_pairs) >= args.pairs:
                    break
        if not added:
            break
        idx += 1

    # fill shortfall (fewer pairs than requested) with unpaired rows, same cells
    if len(chosen_rows) < 2 * args.pairs:
        print(f"pair pool exhausted at {len(chosen_pairs)} pairs; filling with accepted unpaired rows")
        uc = {}
        for r in sorted(unpaired, key=lambda r: int(r["draw_index"])):
            uc.setdefault(cell(r), []).append(r)
        j = 0
        while len(chosen_rows) < 2 * args.pairs and any(uc.values()):
            for k in sorted(uc):
                if uc[k]:
                    chosen_rows.append(uc[k].pop(0))
                    if len(chosen_rows) >= 2 * args.pairs:
                        break
            j += 1
            if j > 1000:
                break

    chosen_rows.sort(key=lambda r: int(r["draw_index"]))

    # Resolve entry indices from the binary itself (authoritative order:
    # DYBANK1 header + accepted entries; draw_index at struct offset pinned by
    # the C++ fixture's static_asserts). The runner re-verifies each mapping.
    raw = open(DEFAULT_BIN, "rb").read()
    header_bytes, entry_bytes = 88, 908
    if raw[:7] != b"DYBANK1" or len(raw) != header_bytes + entry_bytes * 128:
        raise SystemExit("dev-dyn2.bin header/size unexpected")
    draw_at = 892  # offsetof(DynamicEntry, draw_index): 676+36+16+... pinned in fixture
    entry_index_by_draw = {}
    for i in range(128):
        off = header_bytes + i * entry_bytes
        draw = int.from_bytes(raw[off + draw_at:off + draw_at + 4], "little")
        entry_index_by_draw[draw] = i
    entry_indices = []
    for r in chosen_rows:
        d = int(r["draw_index"])
        if d not in entry_index_by_draw:
            raise SystemExit(f"draw {d} not present in {DEFAULT_BIN}")
        entry_indices.append(entry_index_by_draw[d])

    if len(chosen_rows) < 32:
        raise SystemExit(f"subset shortfall: {len(chosen_rows)} < 32 rows")

    def bucket(r):
        return {"approach_crossing": int(r[kind_col]),
                "speed": float(r[speed_col]),
                "stratum": int(r[stratum_col]),
                "labels_bits": int(r["labels"])}

    counts = {"approach": 0, "crossing": 0, "speed_ge_075": 0, "warning_ok": 0,
              "warning_lt_0_5s": 0, "warning_ge_0_5s": 0,
              "stratum_stopped": 0, "stratum_toward": 0, "stratum_lateral": 0}
    for r in chosen_rows:
        if int(r[kind_col]) == 0:
            counts["approach"] += 1
        else:
            counts["crossing"] += 1
        if float(r[speed_col]) >= 0.75:
            counts["speed_ge_075"] += 1
        if int(r["labels"]) & (1 << 3):
            counts["warning_ok"] += 1
        ws = float(r["warning_s"])
        counts["warning_lt_0_5s" if ws < 0.5 else "warning_ge_0_5s"] += 1
        counts["stratum_stopped" if int(r[stratum_col]) == 0 else
               "stratum_toward" if int(r[stratum_col]) == 1 else "stratum_lateral"] += 1

    out = {
        "schema": "local-moving-subset-v1",
        "created_utc": datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "selection_rule": "records-csv construction strata only (threat_kind x speed bucket x start_stratum), "
                          "round-robin over sorted cells, paired rows first (pair_index>=0, both members kept), "
                          "unpaired fill on shortfall; outcome fields never read (none exist in the records csv)",
        "bank_bin": DEFAULT_BIN,
        "bank_bin_sha256": PINNED[DEFAULT_BIN],
        "bank_manifest": DEFAULT_MANIFEST,
        "bank_manifest_sha256": PINNED[DEFAULT_MANIFEST],
        "records_csv": args.records,
        "records_csv_sha256": sha256(args.records),
        "entry_bytes": 908,
        "row_count": len(chosen_rows),
        "pair_count": len(chosen_pairs),
        "strata_counts": counts,
        "entry_indices": entry_indices,
        "draw_indices": [int(r["draw_index"]) for r in chosen_rows],
        "rows": [
            {"draw_index": int(r["draw_index"]),
             "pair_index": int(r[pair_col]),
             "family": int(r["family"]),
             "scene_seed": int(r["scene_seed"]),
             "threat_kind": int(r[kind_col]),
             "start_stratum": int(r[stratum_col]),
             "threat_speed_mps": float(r[speed_col]),
             "labels_bits": int(r["labels"]),
             "warning_s": float(r["warning_s"]),
             **({} if "nominal_ttc_s" not in r else {"nominal_ttc_s": float(r["nominal_ttc_s"])})}
            for r in chosen_rows
        ],
        "entry_index_note": "entry_indices are resolved from dev-dyn2.bin bytes (draw_index field, offset pinned by the fixture's static_asserts); the runner re-verifies entry.draw_index == draw_indices[i] for every selected row",
        "notes": [
            "dev-dyn2 is the NON-selector paired dynamic bank (selection feedback on dev-dyn was exposed; "
            "this subset supports development/implementation evidence only, not sealed-final claims)",
            "LBL_WARNING_OK is witness-protocol constant on accepted rows (warning>=0.25s is an "
            "acceptance condition), so warning balance is expressed over the recorded warning_s value "
            "buckets instead of the bit",
            "all rows retained regardless of outcome; failed/invalid loads counted by the runner, never filtered",
            "paired members share construction; analysis joins draw_index^1",
        ],
    }
    with open(args.out, "w") as f:
        json.dump(out, f, indent=1, separators=(",", ":"))
        f.write("\n")
    print(f"subset written {args.out} rows={len(chosen_rows)} pairs={len(chosen_pairs)}")
    print("strata", json.dumps(counts))
    print("sha256", sha256(args.out))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
