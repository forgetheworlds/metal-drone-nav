#!/usr/bin/env python3
"""Isolated moving-obstacle Webots fixture (omp-task-contract completion mission).

Exports one ACTUAL dev-dyn / dev-dyn2 DYBANK1 record (908-byte DynamicEntry,
layout pinned identically to local_moving_benchmark.mm's static_asserts) as a
Webots world:

  * static geometry -> metal_scene.obstacle_nodes (read-only shared exporter);
  * the moving threat -> ChallengeObstacle<idx> solid at its record center0,
    driven by the existing read-only course_obstacle Supervisor driver with
    customData `movers=<idx>:center0:velocity` (repr() round-trip, exact),
    i.e. translation(t) = center0 + velocity*t with t = Webots simulation time
    from world start - the same kinematics as world.hpp wc();
  * RaptorCrazyflie instance re-declared with the record's start translation/
    rotation (world file is the pose authority - the controller only applies
    the record start VELOCITY through the Supervisor, never a teleport), and
    customData carrying the navigation config (goal_objective=hold,
    sensor_profile=legacy, motor_sampling=average, start_position/yaw/
    velocity, goal, policy path, max_steps=2000 = the 20 s source budget).

No obstacle truth enters the actor: the controller receives only start pose/
velocity, goal and the policy path - exactly the published config keys.

Subcommands:
  export --draw N [--bank dev-dyn.bin] [--policy PATH] [--out DIR]   world + validation manifest
  smoke  --world W [--policy PATH]                                   one bounded flight under the ABS lock

Validation re-parses the written world and fails loudly: geometry/mover/
robot-pose/goal/start-velocity mismatches, bounds violations, missing driver
or DEF solids are all export errors (they must never reach a benchmark).
Smoke parses the controller + driver stdout: applied start velocity must
equal the record (no forced-pose bug), first sensor pose must equal the world
start pose, and COURSE_MOVER_SAMPLE actual vs expected must match within
one Webots timestep of travel. All failures stay in the log/manifest.
"""
from __future__ import annotations

import argparse, hashlib, json, math, os, re, struct, subprocess, sys, time, datetime
from pathlib import Path

RL_ROOT = Path("/Users/muadhsambul/RL")                 # shared results + ABS lock
WT = Path("/Users/muadhsambul/.codex/worktrees/calibrated-navigation-sensors/RL")
ROOT = WT                                                # my own Webots project root
WEBOTS_DIR = ROOT / "webots"
sys.path.insert(0, str(WEBOTS_DIR))
import metal_scene as ms  # noqa: E402  (read-only shared exporter)

WEBOTS = Path("/Users/muadhsambul/embodied/work/Webots.app/Contents/MacOS/webots")
LOCK = RL_ROOT / "results/mimo-learning-next/run_locked.py"
GPU_LOCK = RL_ROOT / "results/metal-training.lock"
PORT = "23456"
MAX_STEPS = 2000           # 100 Hz RAPTOR steps = 20 s, the source DEV budget
BODY_RADIUS_M = 0.18
ENTRY_BYTES = 908
HEADER_BYTES = 88
ROOM = {"x": (-2.0, 14.0), "y": (-5.0, 5.0), "z": (0.0, 5.0)}

# DynamicEntry byte offsets (mirror local_moving_benchmark.mm static_asserts)
OFF_WWORLD = 0
OFF_START_POS = 676
OFF_START_VEL = 688
OFF_GOAL_POS = 700
OFF_START_YAW = 712
OFF_ROUTE_LENGTH = 724
OFF_FAMILY = 876
OFF_SCENE_SEED = 880
OFF_THREAT_KIND = 884
OFF_STRATUM = 888
OFF_DRAW = 892
OFF_LABELS = 896


def sha256_file(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def f32(b: bytes) -> float:
    return struct.unpack("<f", b)[0]


def u32(b: bytes) -> int:
    return struct.unpack("<I", b)[0]


def read_bank(path: Path) -> list[bytes]:
    raw = path.read_bytes()
    if raw[:7] != b"DYBANK1":
        raise SystemExit(f"{path}: not a DYBANK1 bank")
    entry_bytes = u32(raw[20:24])
    count = u32(raw[16:20])
    if entry_bytes != ENTRY_BYTES:
        raise SystemExit(f"{path}: entry_bytes {entry_bytes} != {ENTRY_BYTES}")
    if len(raw) != HEADER_BYTES + entry_bytes * count:
        raise SystemExit(f"{path}: truncated/size mismatch")
    return [raw[HEADER_BYTES + i * entry_bytes: HEADER_BYTES + (i + 1) * entry_bytes]
            for i in range(count)]


def entry_to_record(entry: bytes, bank_sha: str, bank_path: Path) -> dict:
    obstacles = []
    moving = []
    for i in range(16):
        base = i * 40
        kind = u32(entry[base:base + 4])
        center = [f32(entry[base + 4 + 4 * k: base + 8 + 4 * k]) for k in range(3)]
        size = [f32(entry[base + 16 + 4 * k: base + 20 + 4 * k]) for k in range(3)]
        velocity = [f32(entry[base + 28 + 4 * k: base + 32 + 4 * k]) for k in range(3)]
        obstacles.append({"kind": kind, "center": center, "half_extent": size,
                          "velocity": velocity})
    count = u32(entry[640:644])
    world_seed = u32(entry[644:648])
    world_family = u32(entry[648:652])
    world_goal = [f32(entry[652 + 4 * k: 656 + 4 * k]) for k in range(3)]
    wind = [f32(entry[664 + 4 * k: 668 + 4 * k]) for k in range(3)]
    start = [f32(entry[OFF_START_POS + 4 * k: OFF_START_POS + 4 + 4 * k]) for k in range(3)]
    vel = [f32(entry[OFF_START_VEL + 4 * k: OFF_START_VEL + 4 + 4 * k]) for k in range(3)]
    goal = [f32(entry[OFF_GOAL_POS + 4 * k: OFF_GOAL_POS + 4 + 4 * k]) for k in range(3)]
    yaw = f32(entry[OFF_START_YAW:OFF_START_YAW + 4])
    route_length = f32(entry[OFF_ROUTE_LENGTH:OFF_ROUTE_LENGTH + 4])
    family = u32(entry[OFF_FAMILY:OFF_FAMILY + 4])
    scene_seed = u32(entry[OFF_SCENE_SEED:OFF_SCENE_SEED + 4])
    draw = u32(entry[OFF_DRAW:OFF_DRAW + 4])
    labels = u32(entry[OFF_LABELS:OFF_LABELS + 4])
    threat_kind = u32(entry[OFF_THREAT_KIND:OFF_THREAT_KIND + 4])
    stratum = u32(entry[OFF_STRATUM:OFF_STRATUM + 4])
    if any(abs(w) > 1e-8 for w in wind):
        raise SystemExit(f"draw {draw}: record declares wind; fixture is zero-wind only")
    used = obstacles[:count]
    moving = [i for i, o in enumerate(used) if any(v != 0.0 for v in o["velocity"])]
    if len(moving) != 1:
        raise SystemExit(f"draw {draw}: expected exactly1 moving threat, found {moving}")
    return {
        "failure_id": f"dyn-draw{draw}",
        "record_type": "challenge",
        "schema_version": 1,
        "split": "dev",
        "family": family,
        "seed": scene_seed,
        "scene_seed": scene_seed,
        "draw_index": draw,
        "labels_bits": labels,
        "threat_kind": threat_kind,
        "start_stratum": stratum,
        "bank_path": str(bank_path),
        "bank_sha256": bank_sha,
        "room_bounds": {k: list(v) for k, v in ROOM.items()},
        "body_radius_m": BODY_RADIUS_M,
        "wind": wind,
        "goal": goal,
        "goal_position": goal,
        "start_position": start,
        "start_velocity": vel,
        "start_yaw": yaw,
        "initial_distance": route_length,
        "sim_config": {"distance": route_length},
        "world_count": count,
        "world_goal": world_goal,
        "obstacles": used,
        "moving_indices": moving,
    }


def validate_record(record: dict) -> None:
    if record["body_radius_m"] != BODY_RADIUS_M:
        raise SystemExit("body radius mismatch with the RaptorCrazyflie sphere")
    for axis, name in enumerate("xyz"):
        lo, hi = ROOM[name]
        g = record["goal_position"][axis]
        if not (lo < g < hi):
            raise SystemExit(f"goal outside room on {name}: {g}")
        s = record["start_position"][axis]
        if not (lo <= s <= hi):
            raise SystemExit(f"start outside room on {name}: {s}")
    for axis, name in enumerate("xyz"):
        lo, hi = ROOM[name]
        for index, o in enumerate(record["obstacles"][:record["world_count"]]):
            if o["kind"] == 0:
                extent = o["half_extent"][axis]
            elif o["kind"] == 1:
                extent = o["half_extent"][0]
            else:
                extent = o["half_extent"][0] if axis < 2 else o["half_extent"][2]
            c = o["center"][axis] + 0.0
            # Source primitives may intersect the floor, ceiling or walls.
            # Render them unchanged; requiring full containment rejects valid
            # source geometry (for example a box anchored through the floor).
            if not all(math.isfinite(v) for v in (c,extent)) or extent<=0:
                raise SystemExit(f"obstacle {index} invalid extent on {name}")
    speed = math.sqrt(sum(v * v for v in record["start_velocity"]))
    if speed > 1.0 + 1e-6:
        raise SystemExit(f"start speed {speed} above the1 m/s bank envelope")
    distance = math.dist(record["start_position"], record["goal_position"])
    if abs(distance - record["initial_distance"]) > 1e-4:
        raise SystemExit(f"goal distance {distance} != route_length {record['initial_distance']}")


def mover_custom_data(record: dict) -> str:
    entries = []
    for index in record["moving_indices"]:
        o = record["obstacles"][index]
        center = ",".join(repr(float(v)) for v in o["center"])
        velocity = ",".join(repr(float(v)) for v in o["velocity"])
        entries.append(f"{index:02d}:{center}:{velocity}")
    return "movers=" + "|".join(entries)


def build_world(record: dict, policy_rel: str, run_slug: str) -> str:
    template = ms.BOUNDED_TEMPLATE.read_text()
    marker = "# WEBOTS_OBSTACLES_INSERTION_POINT"
    if template.count(marker) != 1:
        raise SystemExit("template marker problem")
    text, replaced = re.subn(r"\bbasicTimeStep\s+10\b", "basicTimeStep 1", template, count=1)
    if replaced != 1:
        raise SystemExit("template basicTimeStep problem")
    # All solids (including the mover at its t=0 center) come from the shared
    # exact obstacle renderer; the Supervisor driver then moves the mover.
    statics = [o for i, o in enumerate(record["obstacles"][:record["world_count"]])
               if i not in record["moving_indices"]]
    mover_nodes = [record["obstacles"][i] for i in record["moving_indices"]]
    # obstacle_nodes names solids DEF ChallengeObstacle<index> by LIST POSITION,
    # so render the full used list to keep DEF indices aligned with the driver.
    full = [dict(o) for o in record["obstacles"][:record["world_count"]]]
    text = text.replace(marker, ms.obstacle_nodes(full), 1)
    driver = (
        "\nDEF CourseMoverDriver Robot { name \"course_mover_driver\" "
        "controller \"course_obstacle\" supervisor TRUE translation 0 0 0 "
        f'customData "{mover_custom_data(record)};diagnostic_trace=1" }}\n'
    )
    text = text.rstrip("\n") + driver
    start = record["start_position"]
    yaw = record["start_yaw"]
    config = {
        "phase": "navigation",
        "seed": str(record["scene_seed"]),
        "policy": policy_rel,
        "speed": "1.5",
        "distance": f"{record['initial_distance']:.9g}",
        "goal": ",".join(f"{v:.9g}" for v in record["goal_position"]),
        "max_steps": str(MAX_STEPS),
        "profile": "hover",
        "motor_sampling": "average",
        "goal_objective": "hold",
        "sensor_profile": "legacy",
        "policy_version": "1",
        "start_yaw": f"{yaw:.9g}",
        "start_position": ",".join(f"{v:.9g}" for v in start),
        "start_velocity": ",".join(f"{v:.9g}" for v in record["start_velocity"]),
        "run_slug": run_slug,
        "capture_trajectory": "1",
    }
    custom = ";".join(f"{k}={v}" for k, v in config.items())
    robot = (f'RaptorCrazyflie {{ translation {ms.vrml_float(start[0])} {ms.vrml_float(start[1])} '
             f'{ms.vrml_float(start[2])} rotation 0 0 1 {ms.vrml_float(yaw)} '
             f'name "RaptorCrazyflie" controller "local_waypoint_transfer" supervisor TRUE '
             f'customData "{custom}" }}')
    text, replaced = re.subn(r"RaptorCrazyflie \{[^}]*\}", robot, text, count=1)
    if replaced != 1:
        raise SystemExit("template must contain exactly one RaptorCrazyflie instance")
    text, replaced = re.subn(r'title "[^"]*"', f'title "{record["failure_id"]}"', text, count=1)
    if replaced != 1:
        raise SystemExit("template title problem")
    return text


def validate_world(text: str, record: dict) -> dict:
    """Re-parse the written world; every mismatch is an export error."""
    solids = {}
    for m in re.finditer(r"DEF (ChallengeObstacle\d+) Solid \{ name \"[^\"]*\" translation "
                         r"([-\d.e]+) ([-\d.e]+) ([-\d.e]+).*?geometry (\w+) \{ "
                         r"(?:size ([-\d.e]+) ([-\d.e]+) ([-\d.e]+)|radius ([-\d.e]+)[^}]*?"
                         r"(?:height ([-\d.e]+))?)", text, re.S):
        pass  # full structural check below via simpler targeted asserts
    # 1. every used obstacle solid exists with exact t=0 translation
    for index, o in enumerate(record["obstacles"][:record["world_count"]]):
        name = f"ChallengeObstacle{index:02d}"
        if f"DEF {name} Solid" not in text:
            raise SystemExit(f"missing solid {name}")
        m = re.search(rf"DEF {name} Solid \{{ name \"[^\"]*\" translation "
                      rf"([-\d.e+]+) ([-\d.e+]+) ([-\d.e+]+)", text)
        if not m:
            raise SystemExit(f"cannot parse translation of {name}")
        got = [float(m.group(i)) for i in (1, 2, 3)]
        for k in range(3):
            if abs(got[k] - o["center"][k]) > 1e-6 * max(1.0, abs(o["center"][k])):
                raise SystemExit(f"{name} translation {got} != record {o['center']}")
    # 2. mover driver table exact (repr round-trip)
    dm = re.search(r'customData "(movers=[^"]*)"', text)
    if not dm:
        raise SystemExit("world lacks the CourseMoverDriver customData")
    if dm.group(1).split(";")[0] != mover_custom_data(record):
        raise SystemExit("mover table does not round-trip the record bytes")
    if 'controller "course_obstacle"' not in text:
        raise SystemExit("missing course_obstacle mover driver")
    # 3. robot pose authority + config
    rm = re.search(r"RaptorCrazyflie \{ translation ([-\d.e+]+) ([-\d.e+]+) ([-\d.e+]+) "
                   r"rotation 0 0 1 ([-\d.e+]+).*?customData \"([^\"]*)\"", text, re.S)
    if not rm:
        raise SystemExit("cannot parse RaptorCrazyflie instance")
    pose = [float(rm.group(i)) for i in (1, 2, 3)]
    yaw = float(rm.group(4))
    for k in range(3):
        if abs(pose[k] - record["start_position"][k]) > 1e-6 * max(1.0, abs(record["start_position"][k])):
            raise SystemExit(f"robot translation {pose} != record start {record['start_position']}")
    if abs(yaw - record["start_yaw"]) > 1e-6:
        raise SystemExit("robot rotation != record start_yaw (no forced-pose drift allowed)")
    cfg = dict(kv.split("=", 1) for kv in rm.group(5).split(";"))
    if cfg["goal"] != ",".join(f"{v:.9g}" for v in record["goal_position"]):
        raise SystemExit("robot goal config != record goal")
    if cfg["start_position"] != ",".join(f"{v:.9g}" for v in record["start_position"]):
        raise SystemExit("robot start_position config != record")
    if cfg["start_velocity"] != ",".join(f"{v:.9g}" for v in record["start_velocity"]):
        raise SystemExit("robot start_velocity config != record")
    if cfg.get("goal_objective") != "hold" or cfg.get("sensor_profile") != "legacy":
        raise SystemExit("hold/legacy profile config keys changed")
    if cfg.get("motor_sampling") != "average" or cfg.get("max_steps") != str(MAX_STEPS):
        raise SystemExit("motor sampling / budget config changed")
    if cfg.get("distance") != f"{record['initial_distance']:.9g}":
        raise SystemExit("distance config != route_length")
    # 4. statics must not be listed in the mover table
    mover_ids = {int(e.split(":")[0]) for e in dm.group(1).split(";", 1)[0][7:].split("|")}
    if mover_ids != set(record["moving_indices"]):
        raise SystemExit("mover index set mismatch")
    for i in range(record["world_count"]):
        o = record["obstacles"][i]
        if i not in mover_ids and any(v != 0.0 for v in o["velocity"]):
            raise SystemExit(f"static solid {i} carries velocity in the record")
    return {"mover_indices": sorted(mover_ids), "config_keys": sorted(cfg)}


def cmd_export(args) -> int:
    bank = Path(args.bank)
    entries = read_bank(bank)
    target = None
    entry = None
    for i, e in enumerate(entries):
        if u32(e[OFF_DRAW:OFF_DRAW + 4]) == args.draw:
            target, entry = i, e
            break
    if entry is None:
        raise SystemExit(f"draw {args.draw} not in {bank}")
    bank_sha = sha256_file(bank)
    record = entry_to_record(entry, bank_sha, bank)
    validate_record(record)
    policy = Path(args.policy)
    if not policy.is_file():
        raise SystemExit(f"NAV asset missing: {policy}")
    # Absolute path in customData: unambiguous, delimiter-safe, hash-bound.
    policy_rel = str(policy.resolve())
    max_actor_error = None
    if args.export_log:
        import re as _re
        m = _re.search(r"max_actor_error=([0-9.eE+-]+)", Path(args.export_log).read_text())
        if not m:
            raise SystemExit(f"export log has no max_actor_error: {args.export_log}")
        max_actor_error = float(m.group(1))
        if max_actor_error != 0.0:
            raise SystemExit(f"NAV export parity failed: max_actor_error={max_actor_error}")
    run_slug = f"mv-{args.draw}-{args.actor}"
    text = build_world(record, policy_rel, run_slug)
    checks = validate_world(text, record)
    out_dir = Path(args.out)          # manifest/log dir (results tree)
    out_dir.mkdir(parents=True, exist_ok=True)
    # The world MUST live in the Webots project tree: the template resolves
    # ../protos/RaptorCrazyflie.proto and Webots resolves controller
    # directories (controllers/course_obstacle, controllers/
    # local_waypoint_transfer) relative to the project containing the world.
    world_dir = Path(WEBOTS_DIR) / "worlds"
    world_path = world_dir / f"moving-{record['failure_id']}-{args.actor}.wbt"
    world_path.write_text(text)
    manifest = {
        "schema": "local-moving-webots-world-v1",
        "created_utc": datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "draw_index": args.draw,
        "entry_index": target,
        "nav_asset": {"path": str(policy), "sha256": sha256_file(policy),
                      "max_actor_error": max_actor_error,
                      "export_log": args.export_log or None,
                      "export_log_sha256": sha256_file(Path(args.export_log)) if args.export_log else None},
        "source_checkpoint": {"path": str(args.checkpoint), "sha256": sha256_file(Path(args.checkpoint))},
        "exporter_binary": {"path": str(ROOT / "build/metal_nav_guided"),
                            "sha256": sha256_file(ROOT / "build/metal_nav_guided") if (ROOT / "build/metal_nav_guided").is_file() else None},
        "bank": {"path": str(bank), "sha256": bank_sha, "entry_bytes": ENTRY_BYTES},
        "world": {"path": str(world_path), "sha256": sha256_file(world_path)},
        "run_slug": run_slug,
        "controller": {"policy_controller": "local_waypoint_transfer",
                       "cpp_sha256": sha256_file(WEBOTS_DIR / "controllers/local_waypoint_transfer/local_waypoint_transfer.cpp"),
                       "mover_driver": "course_obstacle",
                       "driver_sha256": sha256_file(WEBOTS_DIR / "controllers/course_obstacle/course_obstacle.py")},
        "template": {"path": str(ms.BOUNDED_TEMPLATE), "sha256": sha256_file(ms.BOUNDED_TEMPLATE)},
        "shared_exporter": {"path": str(WEBOTS_DIR / "metal_scene.py"),
                            "sha256": sha256_file(WEBOTS_DIR / "metal_scene.py")},
        "checks": checks,
        "timeline": "translation(t) = center0 + velocity*t with t = Webots time from world "
                    "start (course_obstacle driver); robot pose comes from the world file, "
                    "the controller applies only the record start velocity via Supervisor",
        "actor_inputs": "depth/RangeFinder + ego sensors + goal via customData; obstacle "
                        "geometry/velocity never enters the controller config",
    }
    mpath = out_dir / world_path.with_suffix(".world.json").name
    manifest_world_note = str(world_path)
    mpath.write_text(json.dumps(manifest, indent=1) + "\n")
    print(f"world_export {world_path.name} draw={args.draw} entry={target} "
          f"movers={checks['mover_indices']} world_sha256={manifest['world']['sha256'][:12]}")
    return 0


def lock_free() -> bool:
    import fcntl
    fd = os.open(GPU_LOCK, os.O_RDWR | os.O_CREAT, 0o666)
    try:
        fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
        fcntl.flock(fd, fcntl.LOCK_UN)
        return True
    except BlockingIOError:
        return False
    finally:
        os.close(fd)


def descendants(pid: int) -> list[int]:
    out = subprocess.run(["ps", "-axo", "pid,command"], capture_output=True, text=True).stdout
    return [int(l.split(None, 1)[0]) for l in out.splitlines()
            if "moving-dyn-draw" in l or "webots --port=23456" in l]


def cmd_smoke(args) -> int:
    """Bounded, OWNED smoke: this process holds the ABS lock, spawns Webots
    directly as its own child in a new session, streams output to a file, and
    records the ACTUAL Webots child exit code (never a wrapper's). On timeout
    the whole process group is killed and re-verified absent from ps."""
    import fcntl, signal
    world = Path(args.world)
    log_path = Path(args.log)
    log_path.parent.mkdir(parents=True, exist_ok=True)

    fd = os.open(GPU_LOCK, os.O_RDWR | os.O_CREAT, 0o666)
    acquired = time.time()
    try:
        try:
            fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            print("waiting for metal-training.lock", flush=True)
            fcntl.flock(fd, fcntl.LOCK_EX)
        lock_wait_s = time.time() - acquired

        cmd = [str(WEBOTS), f"--port={PORT}", "--minimize", "--batch", "--mode=fast",
               "--no-rendering", "--stdout", "--stderr", str(world)]
        logf = open(log_path, "w")
        proc = subprocess.Popen(cmd, stdout=logf, stderr=subprocess.STDOUT,
                                cwd=str(ROOT), start_new_session=True)
        child_pid = proc.pid
        deadline = time.time() + float(args.timeout)
        killed = False
        while time.time() < deadline:
            if proc.poll() is not None:
                break
            time.sleep(1.0)
        else:
            killed = True
            try:
                os.killpg(os.getpgid(proc.pid), signal.SIGTERM)
                time.sleep(5)
                os.killpg(os.getpgid(proc.pid), signal.SIGKILL)
            except ProcessLookupError:
                pass
            proc.wait(timeout=15)
        logf.write(f"\nSMOKE_EOF killed_by_us={int(killed)} child_exit={proc.returncode}\n")
        logf.close()
        child_exit = proc.returncode
    finally:
        os.close(fd)

    # Orphan verification against the live process table.
    leftovers = [p for p in descendants(child_pid) if p != os.getpid()]
    text = log_path.read_text()

    wm = re.search(r'RaptorCrazyflie \{[^}]*customData "([^"]*)"', world.read_text(), re.S)
    slug = dict(kv.split("=", 1) for kv in wm.group(1).split(";")).get("run_slug") \
        if wm else world.stem
    results_dir = WEBOTS_DIR / "results"
    episode_files = sorted(results_dir.glob(f"{slug}.episode.json"))
    marker_files = sorted(results_dir.glob(f"{slug}.exit.marker"))

    report = {"schema": "local-moving-webots-smoke-v2",
              "created_utc": datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
              "world": str(world), "world_sha256": sha256_file(world),
              "lock_wait_s": round(lock_wait_s, 1),
              "webots_child": {"pid": child_pid, "exit_code": child_exit,
                                "timeout_killed": killed},
              "orphan_check": {"leftover_pids": leftovers, "verified_absent": not leftovers},
              "log": str(log_path), "log_sha256": hashlib.sha256(text.encode()).hexdigest(),
              "markers": {}}
    if episode_files:
        ep = json.loads(episode_files[0].read_text())
        report["markers"]["goal_graded_result"] = {
            "success": ep.get("success"), "collision": ep.get("collision"),
            "timeout": ep.get("timeout"), "steps": ep.get("steps"),
            "nav_loaded": 1 if ep.get("navigation_loaded") else 0,
            "raptor_loaded": 1 if ep.get("raptor_loaded") else 0,
            "grading": ep.get("grading"), "goal_dwell_s": ep.get("goal_dwell_s"),
            "final_error_m": ep.get("final_error_m"),
            "sensor_profile": ep.get("sensor_profile"),
            "time_s": ep.get("time_s"),
            "source": "episode.json (authoritative; controller stdout may lose its tail at quit)"}
    for key, pat in (("policy_load", r"WEBOTS_POLICY .*?policy_version=(\d+)"),
                     ("raptor_model", r"WEBOTS_MODELS raptor=(\w+)"),
                     ("sensor_frame", r"WEBOTS_SENSORS range=(\d+x\d+)"),
                     ("motor_set", r"WEBOTS_SET motors="),
                     ("loop_exit", r"WEBOTS_LOOP_EXIT steps=(\d+) completed=(\d+)")):
        mm = re.search(pat, text)
        if mm:
            report["markers"][key] = list(mm.groups()) if mm.groups() else True
    vm = re.search(r"WEBOTS_INITIAL_VELOCITY requested=([-\d.,]+) applied=([-\d.,]+)", text)
    if vm:
        req = [float(x) for x in vm.group(1).split(",")]
        app = [float(x) for x in vm.group(2).split(",")]
        report["markers"]["initial_velocity"] = {
            "requested": req, "applied": app,
            "max_error": max(abs(a - b) for a, b in zip(req, app))}
    rm = re.search(r"WEBOTS_READ sensors ([-\d.,]+)", text)
    world_start = None
    if rm:
        world_start = [float(x) for x in rm.group(1).split(",")[:3]]
        report["markers"]["first_sensor_pose"] = world_start
    sm = re.search(r"RaptorCrazyflie \{ translation ([-\d.e+]+) ([-\d.e+]+) ([-\d.e+]+)", world.read_text())
    if sm and world_start:
        declared = [float(sm.group(i)) for i in (1, 2, 3)]
        vel = report["markers"].get("initial_velocity", {}).get("applied", [0, 0, 0])
        speed = sum(v * v for v in vel) ** 0.5
        err = max(abs(a - b) for a, b in zip(declared, world_start))
        report["markers"]["pose_match"] = {
            "world_declared": declared, "first_sensor_pose": world_start,
            "error_m": err,
            "bound_m": speed * 0.011 + 1e-4,
            "note": "first WEBOTS_READ is taken after one 10 ms physics step, so the "
                    "declared-vs-sensed bound is |v| * 0.011; a teleport would show up "
                    "as an unbounded offset"}
    samples = re.findall(r"COURSE_MOVER_SAMPLE time_s=([\d.]+) def=(\S+) "
                         r"actual_xyz=([-\d.,]+) expected_xyz=([-\d.,]+)", text)
    if samples:
        errs = [max(abs(float(a) - float(b)) for a, b in
                    zip([float(x) for x in av.split(",")], [float(x) for x in ev.split(",")]))
                for _, _, av, ev in samples]
        report["markers"]["mover_samples"] = {
            "count": len(samples), "max_abs_error_m": max(errs),
            "first": samples[0], "last": samples[-1]}
    report["markers"]["episode_json"] = [str(p) for p in episode_files]
    report["markers"]["exit_marker"] = [str(p) for p in marker_files]
    if args.nav and Path(args.nav).is_file():
        report["nav_asset"] = {"path": args.nav, "sha256": sha256_file(Path(args.nav))}

    checks = {
        "child_exit_zero": child_exit == 0 and not killed,
        "orphan_absent": not leftovers,
        "goal_graded": "goal_graded_result" in report["markers"],
        "nav_loaded": report["markers"].get("goal_graded_result", {}).get("nav_loaded") == 1,
        "raptor_loaded": report["markers"].get("goal_graded_result", {}).get("raptor_loaded") == 1
                         or report["markers"].get("raptor_model", [None])[0] == "loaded",
        "sensors": "sensor_frame" in report["markers"] and "first_sensor_pose" in report["markers"],
        "motors": "motor_set" in report["markers"],
        "pose_match": report["markers"].get("pose_match", {}).get("error_m", 9e9)
                      <= report["markers"].get("pose_match", {}).get("bound_m", 0),
        "velocity_applied": report["markers"].get("initial_velocity", {}).get("max_error", 9e9) <= 1e-5,
        "movers_moved": report["markers"].get("mover_samples", {}).get("count", 0) >= 3,
        "mover_timeline": report["markers"].get("mover_samples", {}).get("max_abs_error_m", 9e9) <= 0.01,
        "episode_json_written": bool(episode_files),
        "exit_marker_written": bool(marker_files),
    }
    report["checks"] = checks
    report["verdict"] = "PASS" if all(checks.values()) else "FAIL"
    rpath = log_path.with_suffix(".receipt.json")
    rpath.write_text(json.dumps(report, indent=1) + "\n")
    print(f"webots_smoke {report['verdict']} child_exit={child_exit} killed={int(killed)} "
          f"leftovers={leftovers} checks_failed={[k for k, v in checks.items() if not v]}")
    print(f"receipt={rpath}")
    return 0 if report["verdict"] == "PASS" else 2


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    sub = ap.add_subparsers(dest="cmd", required=True)
    ex = sub.add_parser("export")
    ex.add_argument("--draw", type=int, required=True)
    ex.add_argument("--bank", default=str(ROOT / "results/omp-local-dynamics/banks/dev-dyn2.bin"))
    ex.add_argument("--policy", required=True, help="NAV asset path (controller loads NAV, not a checkpoint)")
    ex.add_argument("--checkpoint", required=True, help="source PPO checkpoint bound in the manifest")
    ex.add_argument("--export-log", default="", help="metal_nav_guided export log (max_actor_error=0 evidence)")
    ex.add_argument("--actor", default="fast")
    ex.add_argument("--out", default=str(RL_ROOT / "results/omp-grounded-contract/moving-webots"))
    ex.set_defaults(func=cmd_export)
    sm = sub.add_parser("smoke")
    sm.add_argument("--world", required=True)
    sm.add_argument("--log", required=True)
    sm.add_argument("--nav", default="", help="NAV asset bound to this world (recorded in the receipt)")
    sm.add_argument("--timeout", default=180)
    sm.set_defaults(func=cmd_smoke)
    args = ap.parse_args()
    return args.func(args)


if __name__ == "__main__":
    raise SystemExit(main())
