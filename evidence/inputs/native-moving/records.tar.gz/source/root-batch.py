from pathlib import Path
import importlib.util,sys,json,hashlib,subprocess,shutil,fcntl,os,signal,time,re
from datetime import datetime,timezone
r=Path("/Users/muadhsambul/RL");w=Path("/Users/muadhsambul/.codex/worktrees/calibrated-navigation-sensors/RL");out=r/"results/root-native-moving-v1";out.mkdir(exist_ok=True)
spec=importlib.util.spec_from_file_location("moving",w/"local_moving_webots_export.py");m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
spec=importlib.util.spec_from_file_location("flight",w/"webots/local_waypoint_transfer.py");flight=importlib.util.module_from_spec(spec);spec.loader.exec_module(flight)
req=json.loads((r/"results/omp-grounded-contract/parent-owned-job-request-moving.json").read_text())
for name,h in req["step0_root_code_review"]["sources"].items():
 if name=="local_moving_webots_export.py":h=json.loads((r/"results/omp-grounded-contract/root-native-export-correction.json").read_text())["new_exporter_sha256"]
 assert m.sha256_file(w/name)==h,name
panels=[("diagnostic",r/"results/omp-grounded-contract/moving-subset-frozen.json"),("challenge",r/"results/omp-grounded-contract/moving-subset-challenge.json")]
records=json.loads((out/"progress.json").read_text()) if (out/"progress.json").exists() else []
completed={(x["panel"],x["draw"],x["actor"]) for x in records};manifests=[]
for panel,selection in panels:
 subset=json.loads(selection.read_text());bank=Path(subset["bank_bin"]);assert m.sha256_file(bank)==subset["bank_bin_sha256"]
 entries={m.u32(e[m.OFF_DRAW:m.OFF_DRAW+4]):e for e in m.read_bank(bank)}
 assert len(subset["draw_indices"])==32
 for draw in subset["draw_indices"]:
  entry=entries[draw];record=m.entry_to_record(entry,m.sha256_file(bank),bank);m.validate_record(record)
  for actor in ["fast","full"]:
   if (panel,draw,actor) in completed:continue
   asset=req["step4_webots_moving_fixture"]["nav_export"]["nav_"+actor];nav=r/asset["path"];assert m.sha256_file(nav)==asset["sha256"]
   slug=f"rootmoving-{panel}-draw{draw}-{actor}";directory=out/slug;assert not directory.exists();directory.mkdir()
   text=m.build_world(record,str(nav.resolve()),slug);m.validate_world(text,record)
   text=text.replace('controller "course_obstacle"','controller "local_moving_obstacle"')
   world=w/"webots/worlds"/(slug+".wbt");world.write_text(text)
   manifest={"panel":panel,"draw":draw,"actor":actor,"slug":slug,"bank_sha256":subset["bank_bin_sha256"],"entry_sha256":hashlib.sha256(entry).hexdigest(),"subset_sha256":m.sha256_file(selection),"nav_sha256":asset["sha256"],"world_sha256":m.sha256_file(world),"controller_sha256":m.sha256_file(w/"webots/controllers/local_waypoint_transfer/local_waypoint_transfer.cpp"),"mover_driver_sha256":m.sha256_file(w/"webots/controllers/local_moving_obstacle/local_moving_obstacle.py"),"record":record}
   (directory/"manifest.json").write_text(json.dumps(manifest,indent=2)+"\n");shutil.copy2(world,directory/"world.wbt")
   with (r/"results/metal-training.lock").open("a") as lock:
    fcntl.flock(lock.fileno(),fcntl.LOCK_EX)
    run=flight.run_flight(world,directory,record_movie=False)
   (directory/"run.json").write_text(json.dumps(run,indent=2)+"\n")
   # An execution-invalid flight halts the batch; it is preserved, never scored
   # as a policy miss or silently filtered. Valid contacts/timeouts continue.
   assert run["valid"] and run["exit_code"]==0,(slug,run.get("reason"),run.get("exit_code"))
   episode=run["receipt"];assert episode["navigation_loaded"] and episode["raptor_loaded"]
   assert episode["grading"]=="navigation_task_step"
   log=(directory/"webots.log").read_text();samples=re.findall(r"COURSE_MOVER_SAMPLE time_s=([\d.]+) def=(\S+) actual_xyz=([-\d.,]+) expected_xyz=([-\d.,]+)",log)
   assert len(samples)>=3,(slug,"missing mover observations")
   errors=[max(abs(float(a)-float(b)) for a,b in zip(actual.split(","),expected.split(","))) for _,_,actual,expected in samples]
   assert max(errors)<=.01,(slug,"mover time/pose mismatch")
   assert float(samples[-1][0])>float(samples[0][0]),(slug,"no mover elapsed time")
   row={"panel":panel,"draw":draw,"actor":actor,"success":episode["success"],"collision":episode["collision"],"timeout":episode["timeout"],"time_s":episode["time_s"],"mover_samples":len(samples),"mover_max_error_m":max(errors),"exit_code":run["exit_code"],"directory":str(directory)};records.append(row)
   (out/"progress.json").write_text(json.dumps(records,indent=2)+"\n");print(panel,draw,actor,"success",row["success"],"contact",row["collision"],flush=True)
assert len(records)==128
(out/"complete.json").write_text(json.dumps({"flights":128,"complete":True,"scope":"construction-stratified development; frozen source weights and navigation, no native training; two panels separately reported"},indent=2)+"\n")
print("ROOT_NATIVE_MOVING_128_COMPLETE",flush=True)
