#define WAYPOINT_EMBEDDED 1
#include "/Users/muadhsambul/RL/results/omp-functional-retention/trainer_for_retention.mm"
#undef WAYPOINT_EMBEDDED
int main(int argc,char** argv) {@autoreleasepool {try {
    require(argc==7,"evaluate CHECKPOINT BANK CSV MODE SEED NOISE_OFF");
    const uint mode=uint(std::stoul(argv[4])),seed=uint(std::stoul(argv[5]));const bool noise_off=std::stoi(argv[6])!=0;
    require(mode==17||mode==22,"diagnostic modes17/22 only");
    std::string shader=base_source();
    if(noise_off) {
        const std::string before="((cfg.mode==0||cfg.mode==22)?exp(actor[PPO_ACTOR_LOG_STD+j])*sim_normal(rng):0)";
        const auto pos=shader.find(before);require(pos!=std::string::npos&&shader.find(before,pos+1)==std::string::npos,"unique sampler seam");
        shader.replace(pos,before.size(),"0.0f");
    }
    Metal metal;metal.compile(shader+PPO_TRAINER_MSL+waypoint::kWaypointKernels);
    waypoint::BankControl control{};std::string hash;auto bank=waypoint::read_bank(argv[2],control,hash);require(control.period==1,"one task per lane");
    SimConfig cfg;cfg.n=control.count;cfg.eval=1;cfg.mode=mode;cfg.seed=seed;cfg.speed=1.5f;cfg.max_steps=400;cfg.geometry_memory=1;
    Sim sim(metal,cfg,32);auto run=waypoint::make_local_run(sim,bank,control,metal.pipeline("waypoint_task_apply"));
    navigation_training::load_actor(sim,argv[1],false);
    const auto actor_hash=ppo_safeguard_sha256(sim.actor.contents,sim.actor.length);
    auto cb=[metal.queue commandBuffer];waypoint::local_probe(run,cb);metal.finish(cb);waypoint::verify_reset(run,bank,control,true);
    cb=[metal.queue commandBuffer];waypoint::local_collect(run,cb,400);metal.finish(cb);
    require(actor_hash==ppo_safeguard_sha256(sim.actor.contents,sim.actor.length),"diagnostic modified actor parameters");
    const auto* results=(const SimRun*)sim.runs.contents;uint success=0,collision=0,timeout=0;
    for(uint n=0;n<cfg.n;n++) {
        require(results[n].episodes==1&&results[n].successes+results[n].collisions+results[n].timeouts==1,"exactly one scored episode");
        success+=results[n].successes;collision+=results[n].collisions;timeout+=results[n].timeouts;
    }
    waypoint::write_eval_csv(argv[3],noise_off?"noise-off":"nominal",nullptr,bank,control,sim,seed,mode);
    std::ofstream receipt(std::string(argv[3])+".json");receipt<<"{\"mode\":"<<mode<<",\"seed\":"<<seed<<",\"noise_off\":"<<noise_off<<",\"tasks\":"<<cfg.n<<",\"success\":"<<success<<",\"collision\":"<<collision<<",\"timeout\":"<<timeout<<",\"actor_parameters_unchanged\":true}\n";
    std::cout<<"FROZEN_DIAGNOSTIC mode="<<mode<<" noise_off="<<noise_off<<" S="<<success<<" C="<<collision<<" T="<<timeout<<'\n';return 0;
}catch(const std::exception& e){std::cerr<<e.what()<<'\n';return 1;}}}
