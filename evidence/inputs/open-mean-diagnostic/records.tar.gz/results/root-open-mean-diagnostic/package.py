from pathlib import Path
import json,hashlib,tarfile,io
ROOT=Path('/Users/muadhsambul/RL');OUT=ROOT/'results/root-open-mean-diagnostic';req=json.loads((OUT/'request.json').read_text());paths={}
for p in req['freeze']:paths[str(Path(p).relative_to(ROOT))]=Path(p)
WORK=Path('/Users/muadhsambul/.codex/worktrees/navigation-actor-capacity/RL')
for p in json.loads((OUT/'build-inputs.json').read_text()):
 p=Path(p);name=str(p.relative_to(ROOT)) if p.is_relative_to(ROOT) else 'worktree/'+str(p.relative_to(WORK));paths[name]=p
for p in OUT.iterdir():
 if p.is_file() and p.name!='evaluate':paths[str(p.relative_to(ROOT))]=p
folder=ROOT/'evidence/inputs/open-mean-diagnostic';folder.mkdir(parents=True,exist_ok=True)
manifest={n:hashlib.sha256(p.read_bytes()).hexdigest() for n,p in paths.items()}
with tarfile.open(folder/'records.tar.gz','w:gz') as archive:
 for name,p in sorted(paths.items()):
  data=p.read_bytes();info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;archive.addfile(info,io.BytesIO(data))
 data=(json.dumps(manifest,indent=2)+'\n').encode();info=tarfile.TarInfo('SHA256.json');info.size=len(data);archive.addfile(info,io.BytesIO(data))
print(len(paths),(folder/'records.tar.gz').stat().st_size)
