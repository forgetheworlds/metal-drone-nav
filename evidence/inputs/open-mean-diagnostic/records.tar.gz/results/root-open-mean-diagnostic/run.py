"""Matched frozen-policy diagnosis, not a training or noise-coefficient sweep."""
from pathlib import Path
import json,hashlib,subprocess,csv,time
ROOT=Path('/Users/muadhsambul/RL');OUT=ROOT/'results/root-open-mean-diagnostic'
actor=ROOT/'results/omp-functional-retention/runs/pilot-treatment-s1/pilot-treatment-s1.bin'
bank=ROOT/'results/omp-local-dynamics/banks/open-static.bin'
reference=ROOT/'results/omp-functional-retention/evals/treatment-s1-open-nominal.csv'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
freeze={str(p):sha(p) for p in [actor,bank,reference,OUT/'evaluate',OUT/'evaluate.mm']}
ref={int(r['env']):r for r in csv.DictReader(reference.open())};failed=[i for i,r in ref.items() if r['success']=='0']
request={'scope':'Frozen priorunmasked s1 actor, exact128 open DEV tasks, nominal physics/sensors; no learning, modified parameters or target-side tuning. Mode22 uses learned Gaussian variance; noise-off is an explicit sampler-only source intervention.','failed_mean_tasks':failed,'seeds':list(range(700001,700009)),'freeze':freeze,'diagnostic_question':'Can sampled actions rescue deterministic mean failures despite unchanged actor weights? Positive evidence does not prove an adaptive-noise remedy or a universal cause.','preregistered_support':'At least4 of the mechanically selected failed mean tasks reach stable goal in at least4/8 stochastic seeds; report every128-task outcome and any new contacts/timeouts.'}
(OUT/'request.json').write_text(json.dumps(request,indent=2)+'\n');jobs=[]
for tag,mode,seed,off in [('mean17',17,700001,0),('mean22-off',22,700001,1)]+[(f'stoch-{s}',22,s,0) for s in request['seeds']]:
 for p,h in freeze.items():assert sha(p)==h,p
 output=OUT/(tag+'.csv');assert not output.exists()
 args=['python3',str(ROOT/'run_locked.py'),'--',str(OUT/'evaluate'),str(actor),str(bank),str(output),str(mode),str(seed),str(off)]
 with (OUT/(tag+'.log')).open('w') as log:
  start=time.time();p=subprocess.Popen(args,stdout=log,stderr=subprocess.STDOUT);record={'tag':tag,'mode':mode,'seed':seed,'noise_off':off,'argv':args,'pid':p.pid};jobs.append(record);(OUT/'jobs.json').write_text(json.dumps(jobs,indent=2)+'\n');record['exit']=p.wait();record['wall_s']=time.time()-start
 assert record['exit']==0,(OUT/(tag+'.log')).read_text()[-1200:]
 actual={int(r['env']):r for r in csv.DictReader(output.open())}
 if tag=='mean17':assert actual==ref,'Exact scored baseline parity failed'
 if tag=='mean22-off':
  for i,row in actual.items():
   for k,v in row.items():
    if k not in ['mode','split']:assert v==ref[i][k],(i,k,v,ref[i][k])
 record['csv_sha256']=sha(output);(OUT/'jobs.json').write_text(json.dumps(jobs,indent=2)+'\n');print('FROZEN_PROBE_COMPLETE',tag,flush=True)
(OUT/'complete.json').write_text(json.dumps({'completed':len(jobs),'actual_flights':len(jobs)*128,'no_training':True},indent=2)+'\n')
