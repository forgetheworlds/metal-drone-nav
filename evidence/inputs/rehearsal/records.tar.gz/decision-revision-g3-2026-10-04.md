# G3 predeclaration — fixed rehearsal weighting (train-only), 2026-10-04 21:1xZ

Written BEFORE any G3 implementation runs (code changes, bank freeze, or
jobs) and separate from the completed G study. The G study's gates are not
retroactively changed; its verdict (NOT ADOPTED, dev-c −12 vs bound −3)
stands. Evidence basis: `report.md` §6b diagnosis and `diagnosis-g.json`.

## Question

Can a **fixed rehearsal-weighted episode schedule** keep the grounded
mixture's new blocked-route skill while preventing the loss of the original
tight, cold-start, goal-directed detour capability (dev-c −12: contacts +9,
timeouts +3,100 % tight cells,100 % goal-directed starts)?

## Mechanism (ONE change; train-only; no scores)

Episode-schedule rebalancing for `--spec grounded-mix` runs only, flag
`--rehearsal-weight1` (default0 = today's behavior, byte-for-byte
unchanged for every existing protocol):

- slot cycle per environment over24 episodes:
  `[s0..s7, s0..s7, g8..g15]` — source rehearsal **16/24 =66.7 % of
  episodes** (was50 %), grounded **8/24 =33.3 %** with **every grounded
  slot still served once per cycle** (broad floor preserved, fixed bank,
  round-robin determinism preserved within each class).
- Estimated transition share (duration-weighted, eval means2.64 s source /
  2.12 s grounded): source ≈71 % (was ≈55 %).
- Named accurately: this is **fixed rehearsal weighting / episode-schedule
  rebalancing** — *not* prioritized level replay, *not* failure replay: no
  TRAIN scores, no staleness, no adaptive probabilities exist or are added.
  Score-based replay was rejected because (a) the lost cells are
  hard-but-solvable (control solves14/14) and score-driven oversampling of
  unsolved mass risks amplifying possibly-infeasible tasks, (b) this runner
  has no score/staleness machinery and adding it exceeds "minimum", (c) the
  exposure question is answerable by construction (below).
- No reward, observation, dynamics, network, optimizer, threshold or bank
  byte changes. `BankControl.rehearsal_weight` is bound into the training
  sidecar contract so a resume cannot silently switch schedules.

## Arms, budget, selector, evaluation

- **2 fresh runs** (not4 — the completed unweighted arms are not repeated
  under new seeds): `armG3-W-s1`, `armG3-W-s2`;
  `local-train 10000 runs/armG3-W-s{1,2}.bin candidate-fast.bin.best
  --spec grounded-mix --seed {20261015,20261016} --time-cost1.0 --eval-spec
  dev-g1 --eval-every50 --rehearsal-weight1 --preflight <treatment receipt
  re-issued for the new runner hash>`. Same warmstart, action map, reward,
  network, dynamics, budget as the completed study (matched to it).
- **Selector:** frozen dev-g1 (unchanged rule; final primary, `.best`
  secondary). **Fresh non-selector:** new frozen `dev-h` bank (grounded
  rules, seed **20261071**, n128, families {2,4,5,14,15,16}) — built and
  hashed BEFORE any G3 run, never used for selection; both G3 finals and the
  frozen C/T references are scored on it.
- Exposed retention controls: dev-a/dev-b/dev-c/open/clutter (pooled n=256
  per bank over2 seeds). dev-c remains exposed feedback, never a sealed test.

## Gates (pooled over the two G3 seeds unless stated; frozen before runs)

1. **Retention:** every exposed split ≥ the completed control's pooled
   count −3 → dev-a ≥190, dev-b ≥195, **dev-c ≥193**, open ≥253,
   clutter ≥186 (of256).
2. **New skill retained:** dev-g1+dev-g2 blocked pooled (n=128) ≥
   control blocked +10 (**≥89**; control=79, completed T=91).
3. **Fresh generalization:** dev-h blocked pooled ≥ the frozen control's
   dev-h blocked +5 (control's dev-h value measured at evaluation; relative
   gate, fixed now).
4. **Safety/speed:** pooled blocked dev-g contacts and timeouts ≤ control+3
   each; pooled dev-g mean episode time ≤ control +0.5 s; exposed-split
   times reported in full (all episodes, mean/median/p90).

**Falsifier:** any missed gate → the rehearsal-weighting mechanism is
rejected at this budget and reported as a negative result. No coefficient
sweeps, no schedule variants, no reward/obs changes afterwards. A pass
supports only "this fixed weighting fixes this interference under this
bank" — adoption still requires Root review.

## Execution ownership and safety

Heavy execution is **parent-owned** (exact commands in
`parent-owned-job-request-g3.json`): contract re-review of the G3 code diff
→ new role receipts (runner hash changes) → weighted smoke →2 arms
foreground under the ABS lock → matrix (incl. dev-h) → analysis. No live
background jobs on my side; `local-train` remains incremental (resume
subtract arithmetic stated in the job request); invalid pilot stays archived;
completed G arms untouched.
