from pathlib import Path
import subprocess,json,time
root=Path('/Users/muadhsambul/RL');g=root/'results/omp-grounded-navigation';binary=Path('/Users/muadhsambul/.codex/worktrees/navigation-awareness/RL/build/omp-aware-navigation/metal_nav_aware');header=root/'results/root-contract-review/checkpoint-header'
checkpoints=[g/'runs'/f'armG3-weight{w}-s{s}.bin' for s in [20261015,20261016] for w in [0,1]]
while True:
 if all(p.exists() for p in checkpoints):
  text=subprocess.check_output([str(header),*(str(p) for p in checkpoints)],text=True)
  if len(text.splitlines())==4 and all('completed_rollouts=10000 ' in x for x in text.splitlines()):break
 alive=subprocess.run(['ps','-p','61070','-o','pid='],stdout=subprocess.DEVNULL).returncode==0
 if not alive:raise RuntimeError('G3 producer ended without all four complete headers; inspect logs, do not retrain blindly')
 time.sleep(10)
receipts=[]
for weight in [0,1]:
 for seed in [20261015,20261016]:
  for best in [False,True]:
   label=f'armG3-weight{weight}-s{seed}'+('-best' if best else '');ck=g/'runs'/(f'armG3-weight{weight}-s{seed}.bin'+('.best' if best else ''))
   for split in ['dev-h','dev-g1','dev-g2','dev-a','dev-b','dev-c','open','clutter']:
    output=g/'evals'/f'{label}-{split}-mode17.csv';args=[str(binary),'local-eval',str(ck),str(output),'--spec',split,'--mode','17','--seed','700001']
    r={'actor':label,'split':split,'argv':args};receipts.append(r)
    with (g/'logs'/f'{label}-{split}-eval.log').open('w') as log: r['exit']=subprocess.run(['python3',str(root/'results/mimo-learning-next/run_locked.py'),'--',*args],stdout=log,stderr=subprocess.STDOUT).returncode
    (g/'provenance/root-g3-matched-eval-receipts.json').write_text(json.dumps(receipts,indent=2)+'\n');assert r['exit']==0
    print(label,split,'exit',r['exit'],flush=True)
print('G3_MATCHED_EVAL_COMPLETE',flush=True)
