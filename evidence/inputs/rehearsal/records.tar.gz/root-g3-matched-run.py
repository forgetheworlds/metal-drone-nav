from pathlib import Path
import subprocess,json,hashlib
from datetime import datetime,timezone
root=Path('/Users/muadhsambul/RL');g=root/'results/omp-grounded-navigation';wt=Path('/Users/muadhsambul/.codex/worktrees/navigation-awareness/RL');binary=wt/'build/omp-aware-navigation/metal_nav_aware'
assert hashlib.sha256((wt/'navigation_aware_training.mm').read_bytes()).hexdigest()=='b696214e0b244faf56fa2fa348e6dfd29f43b8e3d30da8f11475229334c650f4'
receipts=[]
for seed in [20261015,20261016]:
 for weight in [0,1]:
  label=f'armG3-weight{weight}-s{seed}';ck=g/'runs'/(label+'.bin');assert not ck.exists()
  argv=['python3',str(root/'results/mimo-learning-next/run_locked.py'),'--',str(binary),'local-train','10000',str(ck),str(root/'assets/checkpoints/local-waypoint-fast-experimental.bin.best'),'--spec','grounded-mix','--seed',str(seed),'--time-cost','1.0','--eval-spec','dev-g1','--eval-every','50','--rehearsal-weight',str(weight),'--preflight',str(root/'results/omp-contract-preflight-treatment-g3.json')]
  r={'arm':label,'argv':argv,'started_utc':datetime.now(timezone.utc).isoformat(),'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest()};receipts.append(r)
  with (g/'logs'/(label+'.log')).open('w') as log:
   proc=subprocess.Popen(argv,stdout=log,stderr=subprocess.STDOUT);r['pid']=proc.pid;(g/'provenance/root-g3-matched-jobs.json').write_text(json.dumps(receipts,indent=2)+'\n');r['exit']=proc.wait()
  r['finished_utc']=datetime.now(timezone.utc).isoformat();(g/'provenance/root-g3-matched-jobs.json').write_text(json.dumps(receipts,indent=2)+'\n')
  print(label,'exit',r['exit'],flush=True);assert r['exit']==0
print('G3_MATCHED_TRAIN_COMPLETE',flush=True)
