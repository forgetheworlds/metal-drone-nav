from pathlib import Path
import subprocess,csv,json,hashlib
root=Path('/Users/muadhsambul/RL');out=root/'results/root-capture-age';receipts=[]
inputs=[root/p for p in ['guidance.hpp','memory.metal','sim.metal','cpu_reference.hpp','navigation_stress_eval.mm','build/navigation_capture_age']]
(out/'freeze.json').write_text(json.dumps({str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in inputs},indent=2)+'\n')
args=['python3',str(root/'run_locked.py'),'--',str(root/'build/navigation_capture_age'),'capture-age-check']
with (out/'check.log').open('w') as log:assert subprocess.run(args,stdout=log,stderr=subprocess.STDOUT).returncode==0
for seed in (1,2):
 checkpoint=root/'results/root-consolidated-ppo/runs'/f'consolidated-T-s{seed}.bin'
 for panel,bank in [('composite',root/'results/root-motion-fidelity/dev/challenges.bin'),('open',root/'results/omp-local-dynamics/banks/open-static.bin'),('long-hall',root/'results/root-distance-learning/dev/hallway.bin')]:
  for profile in (('nominal','both-delay','combined') if panel=='composite' else ('nominal',)):
   label=f'T-s{seed}-{panel}-{profile}';flight=out/(label+'.csv')
   args=['python3',str(root/'run_locked.py'),'--',str(root/'build/navigation_capture_age'),str(checkpoint),str(bank),str(flight),profile]
   with (out/(label+'.log')).open('w') as log:code=subprocess.run(args,stdout=log,stderr=subprocess.STDOUT).returncode
   assert code==0,label
   actual=list(csv.DictReader(flight.open()));baseline=list(csv.DictReader((root/'results/root-stress-matrix/evals'/f'T-s{seed}-{panel}-{profile}.csv').open()));assert len(actual)==len(baseline)==128
   if profile=='nominal':assert actual==baseline,(label,'nominal changed')
   wins=losses=0
   for a,b in zip(actual,baseline):
    assert all(a[k]==b[k] for k in ['env','scene_seed','goal_x','goal_y','goal_z'])
    wins+=int(a['success'])>int(b['success']);losses+=int(a['success'])<int(b['success'])
   summary={k:sum(int(x[col]) for x in actual) for k,col in [('S','success'),('C','collision'),('T','timeout')]}
   receipt={'label':label,'exit':code,'summary':summary,'wins':wins,'losses':losses,'nominal_parity':profile=='nominal','argv':args}
   receipt['hashes']={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in (checkpoint,bank,flight)}
   receipts.append(receipt);(out/'receipts.json').write_text(json.dumps(receipts,indent=2)+'\n');print(label,summary,'wins',wins,'losses',losses,flush=True)
print('CAPTURE_AGE10EVAL_COMPLETE',flush=True)
