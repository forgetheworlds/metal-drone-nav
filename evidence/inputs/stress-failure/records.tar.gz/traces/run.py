from pathlib import Path
import subprocess,json,csv,hashlib
root=Path('/Users/muadhsambul/RL');out=root/'results/root-stress-failure-traces'
binary=root/'build/navigation_stress_trace';bank=root/'results/root-motion-fidelity/dev/challenges.bin'
receipts=[]
for seed in (1,2):
 checkpoint=root/'results/root-consolidated-ppo/runs'/f'consolidated-T-s{seed}.bin'
 for profile in ('nominal','both-delay','combined'):
  label=f'T-s{seed}-{profile}';flight=out/(label+'.csv');trace=out/(label+'-trace.csv')
  args=['python3',str(root/'run_locked.py'),'--',str(binary),str(checkpoint),str(bank),str(flight),profile,str(trace)]
  with (out/(label+'.log')).open('w') as log:code=subprocess.run(args,stdout=log,stderr=subprocess.STDOUT).returncode
  assert code==0,label
  actual=list(csv.DictReader(flight.open()));old=list(csv.DictReader((root/'results/root-stress-matrix/evals'/f'T-s{seed}-composite-{profile}.csv').open()));assert len(actual)==len(old)==128
  assert actual==old,(label,'400-step capture changed scored flights')
  records=list(csv.DictReader(trace.open()));assert len(records)>0
  receipt={'label':label,'exit':code,'flight_rows':len(actual),'trace_rows':len(records),'scored_flight_parity':True,'argv':args}
  receipt['hashes']={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in (binary,checkpoint,bank,flight,trace)}
  receipts.append(receipt);(out/'receipts.json').write_text(json.dumps(receipts,indent=2)+'\n')
  print(label,len(records),'TRACE_AND_FLIGHT_PARITY_PASS',flush=True)
print('SIX_TRACE_REPLAYS_COMPLETE',flush=True)
