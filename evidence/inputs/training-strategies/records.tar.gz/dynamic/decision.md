# Decision — local dynamic-threat capability mission (pre-generation, pre-training)

Written 2026-10-04 BEFORE any bank generation, witness flight, or training run.
Session 01a10753-8d11-7135-b9de-1e711df85f77, worktree
`/Users/muadhsambul/.codex/worktrees/local-training-experiments/RL`.
Deliverable root: `ROOT/results/omp-local-dynamics/**`. The failed shaping
experiment stays immutable; its modified sources were archived to
`results/omp-research-experiments/waypoint-potential/source-snapshot/`
(hashes in `SHA256SUMS.json`), and this mission embeds a byte-identical
snapshot of the PUBLISHED root runner in `dynamic_snapshot/`
(27 files, `SNAPSHOT.json`: all_byte_identical=true; main.mm `fe55d0d0…`,
sim.metal `53451f9d…`) with `SOURCE_DIR` pointed at that snapshot, so none of
my shaping edits can contaminate this experiment.

## 1. Source inspection facts (verified before design)

- Moving obstacles: `WObstacle.velocity`; positions are pure functions of
  episode time `wc(o,t)=center+velocity*t`. Episode clock `SimRun.elapsed` is
  zeroed at every install/reset (`waypoint_task_apply`-style installs zero
  it), accumulated `p.dt` per substep, and is the SAME `t` used by physics
  contact (`wclearance(...,elapsed)`) and sensor rays (`wray(...,elapsed)`).
  Threat motion is therefore deterministic, reset-consistent, and visible in
  depth. Threat primitives: sphere kind=1, radius 0.35 m, source speeds
  {0.5,1.0,2.0} m/s, nominal TTC construction in `threat_evaluation.hpp`
  (`add_threat_sphere`: approach −x, crossing +y, room/path/start overlap
  guards; TTC = nominal straight-line encounter time, NOT a closed-loop
  measurement). Existing guarded generator reused, parameterized for
  start/goal in my module (its start/goal are hardcoded for the old matrix).
- Prior actual evidence (not literature): threat-joint controlled 24-case
  matrix (mode 17, flying start 1.5 m/s, empty room): 2 m/s crossings at
  1.0 s TTC 0%→100% after training; **still failing: crossing 0.5 s TTC at
  both 0.5 and 2.0 m/s (0%), approach 2 m/s @0.5 s (75%)**. Family-3 moving
  sphere: learned 98.4% vs geometry-only 94.5% vs goal-script 72.7%.
  Reaction-latency diagnostic: command response 50 ms clean / 200 ms delayed
  (simulated, not evasion proof). Static local and moving-threat evidence
  bodies are separate today ("moving obstacles on real routes" is the
  published next goal). These encounters had NO static clutter and a fixed
  start/goal; my mission combines threats with local goal-reaching.
- History ablation precedent already in source: `sim.metal` mode 18
  ("remove the actor's previous-depth channel": obs[80..159] ← obs[0..79],
  evaluated BEFORE the geometry-prior computation, so prior guidance also
  sees the newest frame only; critic untouched). BENCHMARKS records its
  fixed-weight use. `sim_observe` reads `cfg.mode` NOWHERE except this
  branch (verified by extraction), so dispatching `sim_observe` with a
  mode-18 variant of the config while `sim_act`/`sim_advance` keep the real
  config reproduces EXACT mode-18 semantics with ZERO shader edits — this is
  the ablation mechanism.
- Generic local task generator rejects dynamic clutter (unchanged); my
  module installs its own bank worlds (waypoint-install pattern), which
  bypasses that generator without editing it.
- Warmstart candidate `local-waypoint-fast-experimental.bin.best`
  `7a37ace8…` (strongest verified static baseline). NOT repeated: BC+PPO 10k
  (learner's arm), scale-16 geodesic shaping (mine, failed 2 seeds), any
  coefficient sweep.

## 2. Primary-source verification (checked before coding)

| claim used | primary source | verified content |
|---|---|---|
| TTC is an optic variable available only from image *motion* (looming rate) | D. N. Lee, *A Theory of Visual Control of Braking Based on Information about Time-to-Collision*, Perception 5(4):437–459, 1976, DOI 10.1068/p050437 | τ = time-to-collision from optical expansion; τ̇ predicts collision if deceleration is maintained. Expansion rate is a temporal derivative → single frames cannot carry it |
| Extracting obstacle kinematics from range data requires multiple historical frames | Fan, Lu, Xu, Lu, *Flying in Highly Dynamic Environments with End-to-end Learning Approach*, arXiv:2503.14352 (2025) | multi-frame historical scans compressed to a map "to extract the kinematics of dynamic and static obstacles" — architecture-level precedent for motion history as the velocity cue |
| Temporal stacking of raw visual frames is standard for control from pixels | Mnih et al., *Playing Atari with Deep RL*, arXiv:1312.5602 (2013) / Nature 518:529 (2015) | 4-frame stacks predate the network; history input is the accepted mechanism, not a larger model |
| Source threat model + nominal-TTC semantics | `world.hpp` `wgenerate_threat_sphere`, `threat_evaluation.hpp` (source) | speeds {0.5,1.0,2.0}, TTC ∈ [0.7,1.5] construction, guards — mirrored below and labeled "nominal, not measured" |
| Prior in-repo threat results and mode-18 ablation | `evidence/inputs/threat-joint-controlled.csv`, `docs/BENCHMARKS.md`, `sim.metal:191` (source) | numbers in §1 |

## 3. Causal hypothesis

**H:** the deployed observation's previous-pooled-depth channel carries the
threat's image motion; a source PPO trained on observable moving-threat local
tasks uses that motion history to convert an unreactive controller into one
that yields/detours in time, and this is learnable at the published recipe
scale without new memory, larger networks, or reward changes.

Mechanism (falsifiable chain): (i) threat velocity is not a function of one
depth frame (Lee 1976; Fan 2025); (ii) with prev-depth := current-depth the
actor loses exactly that channel while everything else stays fixed;
(iii) therefore the ablated arm must lose success specifically where timing
matters (short TTC, fast threats), not on static retention.

## 4. Numerical predictions (pre-registered)

Warmstart reference = fresh mode-17 eval of `7a37ace8…` on every split
(recorded before training).

- **P1 (learning):** FULL arm selected checkpoint ≥ 50/128 (39%) success on
  frozen dev-dyn, while scripted blind mode-2 on dev-dyn ≤ 20/128.
- **P2 (history):** FULL − ABLATED ≥ 10/128 on dev-dyn overall, and
  ≥ 6/128 within the fast-threat stratum (threat speed 2.0 or nominal TTC
  ≤ 0.75 s); cross-probe (FULL weights, ablated input at inference, labeled
  contract-violation probe) drops ≥ 8/128 vs its own contract eval.
- **P3 (retention):** FULL static dev-a ≥ 95/128 and open = 128/128 at the
  selected checkpoint; dev-b/clutter/dev-c within −5 of the warmstart row.

## 5. Falsifiers (any one decides the outcome; no rerun to change it)

- **F1:** FULL < 50/128 dev-dyn → source PPO at this recipe/budget does not
  learn avoidance on this distribution (report the limit, fix nothing post
  hoc).
- **F2:** (FULL − ABLATED < 10/128) AND cross-probe drop < 8/128 → no
  evidence the learned policy causally uses motion history; any speed
  difference is attributable to noise.
- **F3:** FULL static dev-a < 95 or open < 128 → dynamic gain with static
  regression; candidate not adoptable regardless of P1/P2.
- Generator gates failing (frustum grounding, witness feasibility, parity)
  → fix contract or document the unresolved limit with real tests; never
  manufacture a training gain.

## 6. Variables changed (exhaustive)

- **Between the two trained arms, exactly one:** `ablate` flag. FULL:
  `sim_observe` dispatched with the real config (mode 22 train / 17 eval).
  ABLATED: `sim_observe` dispatched with a byte-identical config whose only
  change is `mode=18`, at every train and own-contract eval tick → actor
  previous-depth channel and geometry-prior prev input receive the current
  frame; critic observation, actor weights, everything else unchanged.
- Identical across arms: dynamic+static TRAIN bank bytes, warmstart,
  seeds (paired), 5000-rollout budget, 128 envs × 32 horizon, epochs 2,
  lr 1e-4, entropy 1e-3, logσ −1, γ .99, λ .95, risk 0, time cost 0.2,
  mode-22 action map, plant/RAPTOR, reward = unchanged
  `navigation_task_step` (contact −10, stable-arrival +10, 0.35 m/0.5 m/s/
  0.2 s gate, 400 ticks/20 s), network 184→64→4 unchanged, eval seed 700001.
- **No changes to:** root/production code, sim.metal, shaping code, Webots,
  FINAL suites, other missions' files. New code confined to
  `navigation_dynamic_tasks.mm` + `dynamic_snapshot/` in my worktree.
- Static reference = warmstart row (no static-only arm: the matched
  comparison the mission requires is temporal input vs its ablation;
  retention is measured against warmstart + published baselines).

## 7. Banks (frozen before any training run)

**Geometry rules (declared):** static base family ∈ {0,1,2,4,5} via
`wgenerate(scene_seed, family, 4.0)`; start box x∈[−1.4,1], y∈[−3,3],
z∈[0.8,2.6] (waypoint convention); goal 1–3 m in the waypoint goal box;
endpoint body clearance > 0.30 m (surface ≥ 0.48 m); **goal grounded** iff
body-frame projection at start satisfies `body_x>0 ∧ |y/x| ≤ tan_h ∧ |z/x| ≤
tan_v` (active sensor profile: tan_h 1.0, tan_v 0.75) AND line-of-sight ray
to the goal is unobstructed (else reject `goal_not_grounded`);
threat = one sphere r=0.35 placed with the source TTC construction
generalized to the start→goal axis: kinds {approach, crossing}, TRAIN speeds
{0.5, 1.0, 2.0} m/s, nominal TTC ~ U[0.5, 2.0] s, path sampled for room +
static-geometry overlap (source guards); start speed strata in thirds:
{0, U(0.3,0.8) toward-goal, U(0.3,0.8) perpendicular} (independent of goal
direction — fixes the M2 coupling for dynamic tasks); start yaw uniform ±π
then re-checked by grounding; nothing else varies. Control/sensor stress
(steps: delay/noise/dropout/wind) is NOT in this experiment — separation
declared: only geometry and relative threat motion vary.

**Causal/observability labels (host, offline, never actor input):**
`causal_straight` = scripted full-speed straight flight contacts the THREAT;
`hover_safe` = threat misses the start pose by ≥ combined radius + 0.15 m;
`warning_s` = first time threat is in-frustum with LOS from the start pose,
measured against the counterfactual collision time (require ≥ 0.25 s, else
reject `insufficient_warning` — a moving pixel inside the deadline is not
observability); `measured_ttc_min` during witness flights.

**Feasibility acceptance (pre-declared, policy-free):** each TRAIN/DEV task
must (a) be causal, (b) hover_safe, (c) plant-succeed WAIT-then-go
(hold until threat clears the corridor + 0.3 s, then straight), (d)
plant-succeed DETOUR along the validated static route (0/1–2 waypoints).
Accept iff all four; ≥2 feasible evasion actions {wait, detour} guaranteed.
**All rows are kept** in the bank file including rejected ones with
`rejected_reason`; rejection counts per reason are reported; nothing is
re-touched after any policy outcome is seen. Witness flights use real
RAPTOR through the actual Sim path (my tick, scripted command kernel),
same success gate; failing witness rows retained.

**Splits:** TRAIN dynamic = 128 envs × 4 slots = 512 tasks (seed 20261021);
TRAIN static = published `train-source-1024.bin` bytes (sha 72ba5a3a…)
loaded read-only; mixture period 12 per env: slots 0–3 dynamic, slots 4–11
static slot 0–7 (all eight static families) → **static floor 66.7%**,
exposure counts derived from the schedule + episode counters each eval.
DEV dynamic `dev-dyn` = 128 tasks (seed 20261022), same rules, unseen scene
seeds/timing/geometry, speeds drawn from {0.5, 0.75, 1.0, 1.5, 2.0} so
{0.75, 1.5} are unseen speed values (labeled `seen_speed`). Static retention
controls: dev-a, dev-b, dev-c (predeclared bytes), open, clutter — exposed
controls, never selection. All banks frozen + hashed before run 1.

## 8. Budgets, selection, evaluation (fixed now)

- 4 complete runs: {FULL, ABLATED} × seeds {20261012, 20261013},
  **exactly 5000 rollouts each, all four regardless of seed-1 outcome**,
  executed as foreground lock sections in 1000-rollout chunks with strict
  remaining-count arithmetic against the sidecar header (resume is
  incremental; chunked == continuous is guaranteed by the published
  byte-identical resume check and identical eval cadence at multiples of
  250). One recipe; no sweeps.
- Selection: dev-dyn success every 250 rollouts → tie: fewer contacts →
  shorter mean arrival (existing rule). Static dev-a recorded at the same
  cadence as the retention guard (P3), never used for selection.
- Final evals per selected checkpoint: dev-dyn (per-tick rich record:
  success/contact/timeout, threat-vs-static contact classification, measured
  min TTC, warning time, arrival/path/time incl. failures, speed and TTC
  strata, paired vs other arm on identical rows), static dev-a/dev-b/dev-c/
  open/clutter (batched, published protocol), comparators: geometry-only
  mode 13 and actor-only mode 4 on dev-dyn, scripted blind mode 2 on dev-dyn
  (label validation: must fail ≈ causal rate), warmstart baseline row on all
  splits, cross-probe FULL-with-ablated-input (labeled contract-violation
  sensitivity probe, not a capability claim). History ablation at eval always
  matches the trained contract except the declared cross-probe.
- All GPU work under ABS `results/metal-training.lock` via `run_locked.py`,
  blocking foreground calls; no turn ends while a job runs; receipts
  (PID/exit/finished_utc) per chunk to the coordination inbox.
- Literature claim boundary: none of the three papers is evidence that OUR
  policy will learn this; they justify that history is the right variable to
  ablate. Acceptance = learned performance only.

## 10. Addendum (pre-run, 2026-10-04 ~14:35) — approach geometry correction

Written AFTER generator attempt 1 and BEFORE any policy training, checkpoint,
or eval outcome existed. Nothing in §4–§8 (predictions, falsifiers, budgets,
mixture, acceptance, splits) changes.

Observed in attempt 1 (preserved: `banks/attempt1-crossing-only/`,
`banks/attempt1-crossing-only/bank-train-attempt1.log`, counts also in
`logs/bank-train.log` history): 36,864 draws reached 512/512 only with
**crossing=512, approach=0** — the dead-on approach construction
(`wgenerate_threat_sphere`-style, velocity anti-parallel to the corridor)
passes within ±0.10 m of the start pose, so waiting/retreating at the start
are physically unsafe; among 679 plant-tested approach tasks, 614 (90%) had
ZERO feasible actions (detour sides also often failed static clearance and
fell back to straight). This violates the declared rule "task families contain
≥2 feasible actions where possible" and the mission's
"observable crossings/**approaches**".

Correction (source-consistent, one variable): the approach threat now travels
at a **45° front-quarter bearing** — direction `normalize(-e + perp·sign)`,
positioned to cross the corridor at `cruise·nominal_ttc` (the same meeting
point as before; `sign` alternates per draw). The threat then passes to the
side of the start pose, which is what makes yield feasible; the causal test
and all acceptance rules are unchanged and still decided by real RAPTOR
witness flights. Dead-on approaches are excluded by the (unchanged)
requirement that ≥2 of {wait, retreat, detour+, detour−} succeed on the
plant — a geometry where no safe wait exists by construction is rejected as
`single_action`, exactly as attempt 1 demonstrated.

Post-correction receipts (both banks regenerated from scratch with the final
binary; hashes in `manifest.json`):
- dev: 128/128 accepted from 8,192 draws; **approach 56 / crossing 72**;
  strata stopped 36 / toward 49 / lateral 43; speeds {0.5:27, 0.75:27,
  1.0:43, 1.5:20, 2.0:11} (0.75/1.5 unseen in training); rejects
  single_action 28, not_causal 61, insufficient_warning 49, host reasons in
  `banks/dev-dyn.json`/log.
- train: 512/512 accepted from 20,480 draws; **approach 257 / crossing 255**;
  strata stopped 228 / toward 154 / lateral 130; speeds {0.5:251, 1.0:180,
  2.0:81}; rejects single_action 122, not_causal 164,
  insufficient_warning 138, plus all host reasons (`banks/dyn-train.json`).
A second pre-run correction is recorded for completeness: the first dev
generation ran on a stale binary that failed to compile the fix (archived
`banks/attempt2-stale-binary/`) and was discarded before any use.

Also pre-run: the acceptance draw cap (implementation safety bound, not a
declared rule) was raised from 60× to 150× target after attempt 0 showed the
measured end-to-end acceptance is ~1.4% of draws (grounding ≈10% × plant
≈34%) — generation then completed at 20,480 draws with rejection counts
reported above.

