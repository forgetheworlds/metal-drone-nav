# decision.md — grounded capability distribution experiment (pre-registration)

Written **before any generator implementation, bank build, or training run**
of this experiment (2026-10-04, session 01a106db). Supersedes nothing; the
first experiment (`results/omp-local-capability/report.md`) is complete and
frozen. Archive of the pre-experiment runner/recipes:
`provenance/archive-pre-grounded/HASHES.txt`.

## Question

Can a **minimal grounded task distribution** teach obstacle avoidance on
*locally observable* goals while retaining the previously learned general
navigation — without touching reward, network, optimizer, action map,
dynamics, or any threshold?

Known constraints carried in (measured, not assumed):
- The original TRAIN bank forces start velocity **toward** the goal and draws
  start yaw uniformly, so ~75 % of TRAIN starts have the goal outside the
  camera yaw-hemisphere (246/1024 in-FOV; 169/1024 under the legacy camera
  frustum). Cold out-of-FOV goals alias.
- First experiment: BC taught a real observe-before-motion behaviour (labels
  proven pure observation functions) but matched PPO did not convert it into
  a gate-passing held-out win (+3/+4/−1/+3/0, gate ≥+4 missed). No larger
  network, new optimizer, or potential shaping (shaping failed two seeds at
  scale 16 elsewhere — not repeated).
- A blocked-surface pixel is **not** proof of a visible opening; Root's note
  applies. This experiment verifies openings geometrically (flyable LOS)
  and physically (flown witness controls), and labels both.

## Hypothesis (falsifiable)

With (a) the goal in the camera view direction at task issue, (b) start
velocity decoupled from the goal, and (c) every blocked route carrying a
*verified visible, flyable opening* at issue, PPO from the same frozen
warmstart learns materially more blocked-route success on *new,
independently seeded* grounded problems than the same PPO on the current
bank, while a cumulative source+grounded rehearsal mixture retains the old
capability.

## What changes (exactly one change: the task generator)

New optional bank rules (host-side generation only), flagged per spec:
1. **Start yaw constructed**: goal world bearing − start yaw = θ uniform in
   [−45°, +45°] (yaw-hemisphere), goal elevation from start ≤ atan(0.75) =
   36.87° (legacy vertical frustum) — goal direction is in view at issue.
   Rejection: `goal_elevation_out`.
2. **Start velocity independent of the goal**: direction = uniform azimuth ×
   elevation [−30°, +30°], speed uniform [0.2, 1.0] m/s (≤ existing cap).
   Never rejected for its value; **labelled** (toward/lateral/away ×
   vertical × speed bucket) as control stress.
3. **Class rules**: direct task ⇔ straight-line clearance ≥ 0.12 m
   body-subtracted (surfaces ≥ 0.30 m) — a visibly flyable line; blocked task
   ⇔ straight line ≤ 0.02 m body-subtracted **and** an existing validated
   route (witness dogleg or lattice, ratio ≤ 2.5, unchanged) **and** the
   first route bend is (i) inside the frustum (|bearing| ≤ 45°, |elev| ≤
   36.87°) and (ii) reachable on a flyable line-of-sight from the start
   (segment clearance ≥ 0.12 m body-subtracted, sampled every 5 cm).
   Rejections: `direct_not_visible`, `class_mismatch`, `opening_not_visible`,
   `no_route`, `ratio_too_long`. The bend is retained (witness point 1 or
   lattice point) as the opening label. Blocked tasks alternate a
   left/right round-robin target side (fallback accepted and labelled
   `side_fallback` after bounded retries) so no detour direction is
   hardcoded; vertical direction is labelled, never forced.
- Everything else identical: endpoint clearance rules (≥0.30 body-
  subtracted), families, distance 1–3 m, seeds-driven scenes, 18 cm sphere
  contact, speed cap 1.5, yaw rate 0.5, stable-hold gate, 20 s/400-step
  deadline, witness ≥0.02 floor (unchanged; witness alone remains only
  geometric feasibility).

**Pre-freeze corrections (documented, before any bank was frozen):**
(a) the vertical-frustum rejection was implemented one-sided and is
corrected to `|elevation| ≤ 36.87°` — the first generated banks exposed
12/10/74 goal-below-start violations on dev-g1/dev-g2/grounded; all banks
were regenerated after the fix and re-validated (validator: every row
|bearing| ≤ 45°, |elev| ≤ 36.87°, speed ∈ [0.2,1.0], direct clearance
≥ 0.12, blocked clearance ≤ 0.02 with visible opening, ratio ≤ 2.5).

Generator truth (bend, frustum, clearances) is used **only** for
accept/reject, labels, and the offline witness control — never as an actor
input; the actor observation is unchanged.

**No other change**: reward (time cost 1.0 recipe), network, optimizer
defaults, action map (mode 22 train / mode 17 eval), dynamics, warmstart,
transition budget, and thresholds are frozen. No curriculum: the grounded
tasks and the original source tasks are both present from rollout 0
(cumulative broad-floor rehearsal; no capability discarded).

## Banks (all host-built, frozen and hashed before any training run)

| bank | seed | size | rules | role |
|---|---|---|---|---|
| `source` (unchanged) | 20261004 | 1024 (envs128 × period8) | original | control arm bank; byte-parity required after the edit (entry sha must remain `d8db583a…`) |
| `grounded` (TRAIN component) | 20261011 | 1024 | grounded | treatment training half |
| `grounded-mix` | — | 2048 (period16) | source 1024 slots0–7 + grounded 1024 slots8–15 per env | treatment arm bank |
| `dev-g1` | 20261021 | 128 | grounded | **new frozen selector/dev bank** |
| `dev-g2` | 20261022 | 128 | grounded | second frozen dev bank (robustness, never selector) |

Label schema (declared, new): extra columns in the grounded banks' CSV
(`goal_bearing_deg`, `goal_elevation_deg`, `side`, `vertical`, `opening_x/y/z`,
`opening_visible`, `direct/segment clearances`, `velocity_*`, `route_ratio`)
plus a `*.labels.json` rejection-reason and label-histogram manifest. Old
bank `.bin` schema unchanged (`BankEntry` ABI untouched; binding for new
banks = `.bin` geometry bytes + this declared label schema).

Physical feasibility receipts: a **truth-scripted witness control** (bend →
goal, proportional braking, yaw-to-target — measurement only, not a policy)
flown through actual RAPTOR on every grounded TRAIN task and both dev-g
banks, retaining passing **and** failing flights
(`local-witness` command). Claims about feasibility cite these flights, not
witness geometry alone.

## Matched training (4 runs, none conditional on another)

- Control arm: `local-train` on `--spec source`; treatment arm: same command
  on `--spec grounded-mix`.
- Both arms: warmstart `candidate-fast.bin.best` `7a37ace8…`, seeds
  **20261005 and 20261006** (fresh, both arms, both seeds — seed 2 is NOT
  conditional on seed 1), **10 000 rollouts each** (fixed before results:
  same transition budget as the first experiment for cross-comparability;
  ≥5 000 requirement exceeded; ~7 min wall per run), time cost 1.0,
  epochs 2, lr 1e-4, entropy 1e-3, logstd −1, horizon 32, envs 128,
  eval every 50.
- Selector: `.best` = dev-g1 mode-17 success (frozen pre-learning bank).
  **Primary number = final 10 000-rollout checkpoint** (first experiment's
  rule, unchanged). Old dev-a/dev-b/dev-c/open/clutter = **exposed
  development retention controls** (not blind, not selector, not FINAL).

## Numerical prediction and falsifier

- **Primary endpoint** (pooled over the two seeds, final checkpoints,
  blocked-route cells of dev-g1 + dev-g2, mode 17, seed 700001):
  **treatment − control ≥ +10 successes out of the pooled blocked n**
  (≈128 blocked tasks).
- **Retention gate**: on each of dev-a, dev-b, dev-c, open, clutter the
  pooled treatment must be ≥ pooled control − 3 successes (per bank n=128).
- **Safety**: contacts and timeouts on dev-g pooled blocked cells must not
  exceed control by > +3 each.
- **Falsifier**: primary gain < +10 **or** any retention split below
  control − 3 **or** safety regression > +3 → the hypothesis is rejected at
  this budget and reported as a negative result (no coefficient/seed
  sweeps; the next candidate would be a separately predeclared experiment).

Secondary measurements (no gate): full-episode time distributions
(mean/median/p90 over ALL episodes, not survivor-only), path ratio over all
episodes, yaw/visibility traces on a predeclared sample (first 8 blocked
dev-g1 tasks per arm), mode 13 geometry-only / mode 4 actor-only / mode 17
deployed residual on dev-g1 with those labels, per-task T-vs-C pairs,
wall-clock per stage.

## Report obligations

Blocked-route vs direct rates with denominators; safety contacts/timeouts;
time distributions both ways; path efficiency; yaw/visibility behaviour;
per-task pairs; wall clock; rejection counts/reasons and conditional success
rates per capability label; witness receipts both outcomes; exposure
statement (dev-g fresh; dev-a/b/c exposed development); no relaxed
thresholds; 1–3 m documented as this test's range, not a permanent contract;
no adoption claim without Root review.
