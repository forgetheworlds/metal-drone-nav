# Decision: collision penalty 10 vs 50, matched PPO arms (preregistration)

Written BEFORE any dev-r bank generation and BEFORE any training run, on
2026-10-04, in the managed worktree `collision-reward-learning` at origin/main
`fd0c5fc`. Owner: collision-reward mission (OMP `opencode-go/mimo-v2.6-flash`).

## Question

Does a stronger per-contact collision cost, with every other reward term,
action map, network, plant, task bank and PPO setting held equal, teach faster
and more reliable static obstacle avoidance — or does it mainly buy safety with
hovering, stopping or timeouts?

This is the one fixed contrast the brief authorizes. It is not a coefficient
sweep and it does not revisit geodesic shaping (scale 16, falsified over 2
seeds) or any older global-hidden-maze gamma pilot.

## Source evidence for the contrast (checked before running)

- The contact cost is an existing, wired reward term, not a new mechanism:
  `navigation_tasks.hpp::navigation_task_step` computes
  `reward = progress_reward_per_m * progress - time_cost_per_s * nav_period_s
  - command_smoothness_weight * |delta command|^2 * nav_period_s
  - contact_penalty (on contact) + stable_arrival_bonus (on stable success)`,
  with `contact_penalty` default `10.0f` (`navigation_task_default_config`).
- During local waypoint training the term is reached through the real kernel
  path: `sim.metal::sim_advance` calls `navigation_task_step` when
  `task_control.enabled != 0`, and `waypoint_task_apply`/`local_task_recipe`
  install `task_control` from the host recipe. Both arms therefore differ in
  exactly one float in `NavigationTaskConfig`.
- The contrast is valid as specified: no source evidence invalidates comparing
  `contact_penalty = 10` against `contact_penalty = 50` while everything else
  is identical. Nothing was changed after any outcome, because no outcome
  exists yet.

## Hypothesis

H1: the present objective trades too much safety for direct goal progress and
time. Raising the contact cost from 10 to 50 (5x the stable-arrival bonus of
10, above the 20 s nominal time cost of 20 at `time_cost_per_s = 1.0`) makes
the policy learn earlier and stronger detours, so the collision rate on
unseen local tasks falls materially, without the fall being paid for by
stopping, hovering or extra timeouts.

Mechanistic sub-question (measured, not assumed): does penalty scaling change
effective learning through the shared actor/critic gradient clipping? Actor
and critic gradients are each globally norm-clipped at 0.5 (`main.mm`
`ppo_grad_scale_factor`, `actor_max_norm_b = critic_max_norm_b = 0.5`) with
separate scale factors; exact pre-clip actor/critic gradient norms and clip
fractions are recorded per rollout in this mission's diagnostics, and clipping
is reported, never fixed, in this comparison.

## Numerical predictions (fixed before generation/training)

Denominators: 128 flights per bank per checkpoint, mode 17 (deployed
overhead-gated residual), eval seed 700001, no delays.

- P1 (primary safety): pooled over both training seeds on **dev-r2**
  (nonselector), the FINAL checkpoints of the penalty-50 arms produce at
  least **8 fewer contacts out of 256** than the FINAL checkpoints of the
  penalty-10 arms (about 4 fewer per 128).
- P2 (not stalling): on the same pooled dev-r2 finals, penalty-50 has
  **no more than 4 additional timeouts out of 256**, and its mean successful
  arrival time is **no more than 0.5 s slower** than penalty-10.
- P3 (retention): on each of the exposed retention banks
  (dev-a, dev-b, dev-c, open, clutter), a penalty-50 FINAL checkpoint loses
  **no more than 5 successes per 128** against the frozen BC warmstart
  measured on the same bank.

## Falsifiers (declared now)

- F1: pooled dev-r2 contact reduction < 8/256 → H1 rejected; report the
  honest negative result with the smallest measured blocker.
- F2: P1 accompanied by a P2 violation (timeouts +≥5/256, or success arrival
  slower by > 0.5 s with no contact gain) → any "safety" gain is classified
  as stalling/hovering, not avoidance.
- F3: seed disagreement — one penalty-50 seed improves pooled contacts by
  ≥ 8/128 while the other worsens by ≥ 8/128 → result labeled unstable; no
  penalty claim either way.
- F4: retention violation of P3 → safety gain bought by forgetting; report
  as a tradeoff, not an improvement.

## Fixed design

- Arms (4, unconditional, all complete): `contact_penalty ∈ {10, 50}` ×
  training seed `∈ {20261014, 20261015}`; exactly **5000 rollouts** each,
  no promising-seed selection, no early stop, no re-run with different
  settings. An interrupted arm is resumed to exactly 5000 with the same
  binary/contract (incremental resume), never restarted or extended.
- Warmstart: same frozen BC checkpoint for all four arms,
  `ROOT/results/omp-local-capability/runs/bc.bin`,
  sha256 `b85650358b040469676fd3a7849086ddf210ea4cd9909a77902e699b00d18a33`,
  parameter warmstart (actor+critic, Adam moments reset), not resume.
- Everything else identical and fixed: training `--spec source` (immutable
  original 1024 tasks, period 8, all 8 slots exercised by the episode-slot
  mapping), `--envs 128 --horizon 32 --epochs 2`, `--time-cost 1.0`,
  `--learning-rate 1e-4`, `--entropy 1e-3`, `--logstd -1`,
  `--eval-every 50`, `--eval-spec dev-r1` (selector), mode 22 collect /
  mode 17 eval, gamma .99, lambda .95, PPO clip .2, value coef .5, risk coef 0,
  global grad-norm clip 0.5 (unchanged), geometry memory on, speed cap 1.5.
- The source bank must rebuild to entry sha256
  `d8db583ae543f5eb68e729d8bcd1d89d85dc10e8064267d513b13b60a01323ac`
  (recorded in `omp-local-capability/runs/armT.bin.train.json`) before any run.

## New development banks (frozen before learning)

- `dev-r1`, seed **20261101**, selector (used only for in-training
  checkpoint selection, at `--eval-every 50`).
- `dev-r2`, seed **20261102**, nonselector (never used for selection; read
  once per checkpoint after training).
- Both built by the original local bank generator with the same distribution
  as dev-a/dev-b: families `{2,4,5,14,15,16}`, 128 environments, period 1,
  route-length ratio cap 2.5, endpoint clearance 0.30 m, witness floor 0.02 m,
  goal 1–3 m, start speed ≤ 1 m/s, no current-view requirement anywhere in
  acceptance. Frozen as `.bin`/`.csv`/`.json` with sha256 recorded BEFORE the
  first training command; the training contract's `eval_entry_sha256` must
  equal the frozen dev-r1 entry hash (asserted in preflight).

## Exposure and labeling

- dev-r1/dev-r2: fresh, not viewed before freeze. dev-r1 is the selector;
  dev-r2 is the only nonselector bank claimed as new evidence.
- dev-a, dev-b, dev-c, open, clutter: EXPOSED retention banks from prior
  missions. Never described as blind/FINAL.
- No FINAL claim, no native/Webots run, no target-side tuning, no default
  asset or deployed checkpoint change, no new network, optimizer, curriculum
  or reward shaping.

## Selection and judging

- Primary per arm: the **FINAL rollout-5000** checkpoint.
- Secondary: the `.best` checkpoint chosen by the existing in-training rule
  (dev-r1 success, then contacts, then arrival time) — labeled "best-on-dev-r1".
- Judged measures, all with full denominators: goal arrival success, contact,
  timeout, 20 s budget, 0.35 m / 0.5 m/s / 0.2 s stable-hold rule as
  implemented, time and speed including failures, direct vs detour
  (`route_class`), visibility strata (yaw-hemisphere, `|θ| ≤ 45°`,
  `θ = remainder(bearing − yaw, 2π)`), start-speed strata, paired per-env
  outcomes between arms, wallclock.
- Modes compared with correct labels: **17 = deployed overhead-gated
  residual**, **4 = actor-only (full learned mean, no prior blend)**,
  **13 = geometry-only prior (no learned residual)**.
- After nominal evaluation only, a 100 ms sensor-delay (2 frames) and
  100 ms command-delay (2 steps) probe is run on the frozen FINAL candidates
  with no other change and no retuning.
- Improvement must exceed hovering/stalling: successes, contacts and
  conditional AND unconditional times are reported side by side.

## Implementation contract (minimum change)

- `--contact-penalty` flag in this worktree's isolated local training recipe,
  default `10.0`, recorded as `contact_penalty` in the strict training sidecar
  and checked by `require_contract_matches` BEFORE any checkpoint load or
  write; a mismatched resume fails before checkpoint mutation.
- Default 10 must reproduce the existing bank/step/action/baseline exactly:
  verified by a pristine-vs-modified parity run (100 rollouts, seed 20261014,
  penalty 10) comparing history, dev CSV and checkpoint bytes.
- Measurement-only addition: per-minibatch pre-clip actor/critic gradient
  norms recorded in the diagnostics CSV. No optimizer, clip norm, loss or
  reward change accompanies it.
- `local-reward-audit` command records the ACTUAL kernel reward and its
  components on flown trajectories (safe, contact, timeout, hover, blind
  goal script) for both penalty values — decomposition evidence, not a
  unit test that mirrors the implementation.
- No generic reward framework, no second production runner, no edits outside
  this worktree. Root reviews before any public integration.

## Budget and stops

- Fixed budget: 4 × 5000 rollouts, two eval banks, retention banks, delay
  probe. No coefficient sweep. If F1 fires, the negative result stands; any
  follow-up must be preregistered separately inside mission time with its own
  controls and must not be "just try 100".
- Heavy Metal work runs exclusively through
  `results/mimo-learning-next/run_locked.py` against
  `ABS results/metal-training.lock`, foreground, with PID/log/exit receipts.
